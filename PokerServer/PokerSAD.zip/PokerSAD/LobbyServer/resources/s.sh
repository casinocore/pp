ulimit -n 65000
java -Dfile.encoding=UTF-8 -server -Xms128m -Xmx512m -jar ./bin/lobbyserver.jar 1>out.log 2>err.log &