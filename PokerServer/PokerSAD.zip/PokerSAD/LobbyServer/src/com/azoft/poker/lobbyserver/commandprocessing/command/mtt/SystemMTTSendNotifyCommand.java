package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import org.apache.mina.core.session.IoSession;

public class SystemMTTSendNotifyCommand extends MTTNotifyCommand {

    private boolean single = true;

    private Long value;

    public SystemMTTSendNotifyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public boolean isSingle() {
        return single;
    }

    public void setSingle(boolean single) {
        this.single = single;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return super.toString() + " - SystemMTTSendNotifyCommand{" +
                "single=" + single +
                ", value=" + value +
                '}';
    }

}