package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class GetBalanceCommand extends RequestCommand {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetBalanceCommand.class);

    private Long balance;

    public GetBalanceCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getBalance() {
        return balance;
    }

    public void setBalance(Long balance) {
        this.balance = balance;
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (balance != null) {
            dos.writeLong(balance);
        } else {
            dos.writeLong(0L);
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}