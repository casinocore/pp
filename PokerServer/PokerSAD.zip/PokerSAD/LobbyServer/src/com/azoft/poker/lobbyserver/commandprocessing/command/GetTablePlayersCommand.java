package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GetTablePlayersCommand extends RequestCommand {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetTablePlayersCommand.class);

    public List<String> getSocialNetworkIDs() {
        return socialNetworkIDs;
    }

    public void setSocialNetworkIDs(List<String> socialNetworkIDs) {
        this.socialNetworkIDs = socialNetworkIDs;
    }

    public List<Long> getIDs() {
        return IDs;
    }

    public void setIDs(List<Long> IDs) {
        this.IDs = IDs;
    }

    Long tableID;

    List<String> socialNetworkIDs;
    List<Long> IDs;

    public Long getTableID() {
        return tableID;
    }

    public void setTableID(Long tableID) {
        this.tableID = tableID;
    }

    public GetTablePlayersCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
        socialNetworkIDs = new ArrayList<String>();
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setTableID(dis.readLong());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        int count = socialNetworkIDs.size();
        if (!isExistsError()) {
            dos.writeInt(count);

            for (int i = 0; i < count; i++) {
                dos.writeUTF(socialNetworkIDs.get(i));
                dos.writeLong(IDs.get(i));
            }

            dos.flush();
            byte[] body = baos.toByteArray();
            //encode body size
            setBodySize(body.length);
            out.writeInt(body.length);
            //encode body itself
            out.write(body);
        }

    }
}
