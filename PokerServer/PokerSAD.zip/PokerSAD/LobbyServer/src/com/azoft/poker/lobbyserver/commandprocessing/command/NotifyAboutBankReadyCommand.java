package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.bet.Bank;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class NotifyAboutBankReadyCommand extends Command {
    private final static Logger LOGGER = LoggerFactory.getLogger(NotifyAboutNewPlayerCommand.class);

    private Table table;


    public NotifyAboutBankReadyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Table getTable() {
        return table;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    @Override
    public String toString() {
        return super.toString() + " - NotifyAboutBankReadyCommand{" +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content

        Map<Long, Long> bets = table.getGameEngine().getCurrentPlayerBets();
        //write players size
        //System.out.println("Banks size: "+bets.size());
        dos.writeByte(bets.size());
        for (long userId : bets.keySet()) {
            //playerId
            dos.writeLong(userId);
            //System.out.println("User: "+userId);
            //write bets & banks for player
            List<Bank> banks = table.getGameEngine().getCurrentPlayerBanks(userId);
            //bank count
            dos.writeByte(banks.size());
            //System.out.println("number of banks: "+banks.size());
            //values
            for (Bank b : banks) {
                //System.out.println("Bank number: "+b.getCounter());
                dos.writeByte(b.getCounter());
                //System.out.println("Bank value: "+b.getPlayerIds().get(userId));
                dos.writeLong(b.getPlayerIds().get(userId));
            }
        }

        Map<Integer, Long> banks = table.getGameEngine().getFormedBanks();
        //System.out.println("BANKS: "+banks);
        dos.writeByte(banks.size());
        for (int bankNum : banks.keySet()) {
            dos.writeByte(bankNum);
            dos.writeLong(banks.get(bankNum));
        }

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}