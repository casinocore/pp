package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.lobbyserver.commandprocessing.command.NotifyTournamentCommand;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class MTTNotifyRatingCommand extends NotifyTournamentCommand {

    private Long playerId;

    private Long place;

    private Byte prizePlace;

    public MTTNotifyRatingCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Long playerId) {
        this.playerId = playerId;
    }

    public Long getPlace() {
        return place;
    }

    public void setPlace(Long place) {
        this.place = place;
    }

    public Byte getPrizePlace() {
        return prizePlace;
    }

    public void setPrizePlace(Byte prizePlace) {
        this.prizePlace = prizePlace;
    }

    @Override
    public String toString() {
        return super.toString() + " - MTTNotifyRatingCommand{" +
                "playerId=" + playerId +
                ", place=" + place +
                ", prizePlace=" + prizePlace +
                '}';
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content
        super.encodeBody(dos);
        dos.writeLong(playerId);
        dos.writeLong(place);
        dos.writeByte(prizePlace);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}