package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import com.azoft.poker.common.persistence.news.NewsBean;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GetNewsCommand extends RequestCommand {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetNewsCommand.class);

    private int newsNumber;

    private boolean onlyNotRead;

    private List<NewsBean> infoNews;

    public GetNewsCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
        infoNews = new ArrayList<NewsBean>();
    }

    public int getNewsNumber() {
        return newsNumber;
    }

    public void setNewsNumber(int newsNumber) {
        this.newsNumber = newsNumber;
    }

    public boolean isOnlyNotRead() {
        return onlyNotRead;
    }

    public void setOnlyNotRead(boolean onlyNotRead) {
        this.onlyNotRead = onlyNotRead;
    }

    public List<NewsBean> getInfoNews() {
        return infoNews;
    }

    public void setInfoNews(List<NewsBean> infoNews) {
        this.infoNews = infoNews;
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setNewsNumber(dis.readInt());
            byte onlyNotReadFlag = dis.readByte();
            setOnlyNotRead(onlyNotReadFlag == PersistenceManagerImpl.TRUE_VALUE);
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            dos.writeInt(infoNews.size());

            for (NewsBean newsBean : infoNews) {
                dos.writeLong(newsBean.getNews().getId());
                dos.writeLong(newsBean.getNews().getTimeStamp().getTime());
                dos.writeByte(newsBean.getNews().isPrivateAccess() ? PersistenceManagerImpl.TRUE_VALUE : PersistenceManagerImpl.FALSE_VALUE);
                dos.writeByte((newsBean.getRead()));
                dos.writeUTF(newsBean.getNews().getPreview());
                dos.writeUTF(StringHelper.makeEmpty(newsBean.getNews().getBody()));
            }

            dos.flush();
            byte[] body = baos.toByteArray();
            //encode body size
            setBodySize(body.length);
            out.writeInt(body.length);
            //encode body itself
            out.write(body);
        }

    }
}