package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.lobbyserver.Constants;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;

public class GetLobbyCashCommand extends RequestCommand {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetLobbyCashCommand.class);

    private Integer bigBlind;

    private List<Table> tables;

    public Integer getBigBlind() {
        return bigBlind;
    }

    public void setBigBlind(Integer bigBlind) {
        this.bigBlind = bigBlind;
    }

    public List<Table> getTables() {
        return tables;
    }

    public void setTables(List<Table> tables) {
        this.tables = tables;
    }

    public GetLobbyCashCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        StringBuffer stringBuffer = new StringBuffer(super.toString());
        stringBuffer.append(" - GetLobbyCashCommand{")
                .append("bigBlind=").append(bigBlind);
        if (tables != null) {
            stringBuffer.append(", tables=").append(tables);
        }
        stringBuffer.append("}");
        return stringBuffer.toString();
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setBigBlind(dis.readInt());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        int count = tables.size();
        if (!isExistsError()) {
            dos.writeInt(count);
            for (int i = 0; i < count; i++) {
                Table table = tables.get(i);
                JoinTableCommand.writeTable(dos, table);
                dos.writeInt(Constants.bigBlindMultiplier);
            }
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
