package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public abstract class NotifyTournamentCommand extends Command implements TournamentIdCommand {

    /**
     * Tournament identifier
     */
    private Long tournamentId;

    public NotifyTournamentCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Long tournamentId) {
        this.tournamentId = tournamentId;
    }

    @Override
    public String toString() {
        return super.toString() + " - NotifyTournamentCommand{" +
                "tournamentId=" + tournamentId +
                '}';
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        tournamentId = dis.readLong();
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        out.writeLong(tournamentId);
    }

}