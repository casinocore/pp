package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.service.MedalTypeID;
import com.azoft.poker.lobbyserver.commandprocessing.command.PlayNowCommand;
import com.azoft.poker.lobbyserver.commandprocessing.command.TournamentCommand;
import com.azoft.poker.lobbyserver.mtt.MTTTournament;
import com.azoft.poker.lobbyserver.tableprocessing.mtt.MTTTable;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MTTRegisterCommand extends TournamentCommand {

    private final static org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MTTRegisterCommand.class);

    private Long playerId;

    private Long amount;

    private Long mttBalance;

    /**
     * Table
     */
    private MTTTable table = null;

    private MTTTournament mttTournament;

    private boolean startDealTable = false;

    /**
     * placeId - place identifier at table
     */
    private Byte placeId;

    private Player player;

    private Map<Long, List<MedalTypeID>> medalsMap = new HashMap<Long, List<MedalTypeID>>();

    public Long getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Long playerId) {
        this.playerId = playerId;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Long getMttBalance() {
        return mttBalance;
    }

    public void setMttBalance(Long mttBalance) {
        this.mttBalance = mttBalance;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public MTTRegisterCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public MTTTable getTable() {
        return table;
    }

    public void setTable(MTTTable table) {
        this.table = table;
    }

    public MTTTournament getMttTournament() {
        return mttTournament;
    }

    public void setMttTournament(MTTTournament mttTournament) {
        this.mttTournament = mttTournament;
    }

    public boolean isStartDealTable() {
        return startDealTable;
    }

    public void setStartDealTable(boolean startDealTable) {
        this.startDealTable = startDealTable;
    }

    public Byte getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    public Map<Long, List<MedalTypeID>> getMedalsMap() {
        return medalsMap;
    }

    public void setMedalsMap(Map<Long, List<MedalTypeID>> medalsMap) {
        this.medalsMap = medalsMap;
    }

    @Override
    public String toString() {
        return PlayNowCommand.InfoPlayToString(
                "MTTRegisterCommand", super.toString(), getUserId(), table, placeId);
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            dos.writeLong(playerId);
            dos.writeLong(amount);
            dos.writeLong(mttBalance);
            if (table != null && player != null) {
                LOGGER.debug("1: " + this.toString());
                dos.writeByte(1);
                PlayNowCommand.writeInfoPlay(dos, table, medalsMap);
            } else {
                LOGGER.debug("0: " + this.toString());
                dos.writeByte(0);
            }
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}