package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.persistence.person.InvitedFriendsBean;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;

public class GetTopInvitedFriendsCommand extends RequestCommand {

    private Integer topPlayerCount;

    private InvitedFriendsBean infoPlayer;

    private List<InvitedFriendsBean> topInfoPlayers;

    public GetTopInvitedFriendsCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Integer getTopPlayerCount() {
        return topPlayerCount;
    }

    public void setTopPlayerCount(Integer topPlayerCount) {
        this.topPlayerCount = topPlayerCount;
    }

    public InvitedFriendsBean getInfoPlayer() {
        return infoPlayer;
    }

    public void setInfoPlayer(InvitedFriendsBean infoPlayer) {
        this.infoPlayer = infoPlayer;
    }

    public List<InvitedFriendsBean> getTopInfoPlayers() {
        return topInfoPlayers;
    }

    public void setTopInfoPlayers(List<InvitedFriendsBean> topInfoPlayers) {
        this.topInfoPlayers = topInfoPlayers;
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setTopPlayerCount(dis.readInt());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            GetTournamentPlayersCommand.writeInfoPlayer(dos, infoPlayer);
            dos.writeInt(infoPlayer.getInvitedFriendsCount());
            int topTournamentPlayersCount = topInfoPlayers.size();
            dos.writeInt(topTournamentPlayersCount);
            for (int i = 0; i < topTournamentPlayersCount; i++) {
                InvitedFriendsBean topInfoPlayer = topInfoPlayers.get(i);
                GetTournamentPlayersCommand.writeInfoPlayer(dos, topInfoPlayer);
                dos.writeInt(topInfoPlayer.getInvitedFriendsCount());
            }
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}