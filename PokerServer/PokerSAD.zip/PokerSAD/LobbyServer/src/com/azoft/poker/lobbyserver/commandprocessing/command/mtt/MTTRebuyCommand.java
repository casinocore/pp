package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.lobbyserver.commandprocessing.command.TournamentCommand;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class MTTRebuyCommand extends TournamentCommand {

    private Long playerId;

    private Long amount;

    private Long mttBalance;

    public MTTRebuyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Long playerId) {
        this.playerId = playerId;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Long getMttBalance() {
        return mttBalance;
    }

    public void setMttBalance(Long mttBalance) {
        this.mttBalance = mttBalance;
    }

    @Override
    public String toString() {
        return super.toString() + " - MTTRebuyCommand{" +
                "playerId=" + playerId +
                ", amount=" + amount +
                ", mttBalance=" + mttBalance +
                '}';
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            dos.writeLong(playerId);
            dos.writeLong(amount);
            dos.writeLong(mttBalance);
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}