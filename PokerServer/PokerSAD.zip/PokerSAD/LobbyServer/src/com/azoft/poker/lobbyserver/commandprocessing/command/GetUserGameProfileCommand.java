package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.helper.StringHelper;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class GetUserGameProfileCommand extends RequestCommand {
    private final static Logger LOGGER = LoggerFactory.getLogger(GetUserGameProfileCommand.class);

    Long personID;

    String snID;

    Long playerSince;

    Long totalPlayTime;

    Long lastPlayTime;

    Long totalChips;

    Long highestChipLevel;

    Long biggestPotWon;

    Integer handsPlayed;

    Integer handsWon;

    Short BestHand;

    Byte friendFlag;

    public Long getPersonID() {
        return personID;
    }

    public void setPersonID(Long personID) {
        this.personID = personID;
    }

    public String getSnID() {
        return snID;
    }

    public void setSnID(String snID) {
        this.snID = snID;
    }

    public Long getPlayerSince() {
        return playerSince;
    }

    public void setPlayerSince(Long playerSince) {
        this.playerSince = playerSince;
    }

    public Long getTotalPlayTime() {
        return totalPlayTime;
    }

    public void setTotalPlayTime(Long totalPlayTime) {
        this.totalPlayTime = totalPlayTime;
    }

    public Long getLastPlayTime() {
        return lastPlayTime;
    }

    public void setLastPlayTime(Long lastPlayTime) {
        this.lastPlayTime = lastPlayTime;
    }

    public Long getTotalChips() {
        return totalChips;
    }

    public void setTotalChips(Long totalChips) {
        this.totalChips = totalChips;
    }

    public Long getHighestChipLevel() {
        return highestChipLevel;
    }

    public void setHighestChipLevel(Long highestChipLevel) {
        this.highestChipLevel = highestChipLevel;
    }

    public Long getBiggestPotWon() {
        return biggestPotWon;
    }

    public void setBiggestPotWon(Long biggestPotWon) {
        this.biggestPotWon = biggestPotWon;
    }

    public Integer getHandsPlayed() {
        return handsPlayed;
    }

    public void setHandsPlayed(Integer handsPlayed) {
        this.handsPlayed = handsPlayed;
    }

    public Integer getHandsWon() {
        return handsWon;
    }

    public void setHandsWon(Integer handsWon) {
        this.handsWon = handsWon;
    }

    public Short getBestHand() {
        return BestHand;
    }

    public void setBestHand(Short bestHand) {
        BestHand = bestHand;
    }

    public Byte getFriendFlag() {
        return friendFlag;
    }

    public void setFriendFlag(Byte friendFlag) {
        this.friendFlag = friendFlag;
    }

    public GetUserGameProfileCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setPersonID(dis.readLong());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);

        if (!isExistsError()) {
            dos.writeUTF(StringHelper.makeEmpty(getSnID()));

            if (null != getPlayerSince()) {
                dos.writeLong(getPlayerSince().longValue());
            } else {
                dos.writeLong(new Long(0));
            }

            if (null != getTotalPlayTime()) {
                dos.writeLong(getTotalPlayTime().intValue());
            } else {
                dos.writeInt(0);
            }

            if (null != lastPlayTime) {
                dos.writeLong(lastPlayTime.longValue());
            } else {
                dos.writeLong(new Long(0));
            }

            if (null != totalChips) {
                dos.writeLong(totalChips.longValue());
            } else {
                dos.writeLong(new Long(0));
            }

            if (null != highestChipLevel) {
                dos.writeLong(highestChipLevel.longValue());
            } else {
                dos.writeLong(new Long(0));
            }

            if (null != biggestPotWon) {
                dos.writeLong(biggestPotWon.longValue());
            } else {
                dos.writeLong(new Long(0));
            }

            if (null != handsPlayed) {
                dos.writeInt(handsPlayed.intValue());
            } else {
                dos.writeInt(new Integer(0));
            }

            if (null != handsWon) {
                dos.writeInt(handsWon.intValue());
            } else {
                dos.writeInt(new Integer(0));
            }

            dos.writeShort(getBestHand());
            dos.writeByte(getFriendFlag());
        }

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }
}
