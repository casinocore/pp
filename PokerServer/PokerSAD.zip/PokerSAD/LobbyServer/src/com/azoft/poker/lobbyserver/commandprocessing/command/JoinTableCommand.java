package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import com.azoft.poker.common.service.MedalTypeID;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JoinTableCommand extends RequestCommand {

    private Long tableID;

    private Table table = null;

    private Map<Long, List<MedalTypeID>> medalsMap = new HashMap<Long, List<MedalTypeID>>();

    public Long getTableID() {
        return tableID;
    }

    public void setTableID(Long tableID) {
        this.tableID = tableID;
    }

    public Table getTable() {
        return table;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    public Map<Long, List<MedalTypeID>> getMedalsMap() {
        return medalsMap;
    }

    public void setMedalsMap(Map<Long, List<MedalTypeID>> medalsMap) {
        this.medalsMap = medalsMap;
    }

    public JoinTableCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - JoinTableCommand{" +
                "tableID=" + tableID +
                (table != null ? (", table=" + table) : "") +
                '}';
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setTableID(dis.readLong());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);

        if (!isExistsError() && null != table) {
            writeTable(dos, table);

            dos.writeByte(table.getPlayerCount());
            for (Player player : table.getPlayers()) {
                writePlayerOnTable(dos, player, medalsMap.get(player.getId()), table.getGameEngine().isHasCards(player.getId()));
            }

            //TableGameInfo
            //cards on table
            List<Card> cards = table.getGameEngine().getTableCards();
            dos.writeByte(cards.size());
            for (Card c : cards) {
                dos.writeByte(c.getSuit());
                dos.writeByte(c.getValue());
            }
            //formed banks
            Map<Integer, Long> banks = table.getGameEngine().getFormedBanks();
            //System.out.println("BANKS: "+banks);
            dos.writeByte(banks.size());
            for (int bankNum : banks.keySet()) {
                dos.writeByte(bankNum);
                dos.writeLong(banks.get(bankNum));
            }
            //current player bets
            Map<Long, Long> bets = table.getGameEngine().getCurrentPlayerBets();
            dos.writeByte(bets.size());
            for (long userId : bets.keySet()) {
                dos.writeLong(userId);
                dos.writeLong(bets.get(userId));
            }

        }

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public static void writeTable(DataOutputStream dos, Table table) throws IOException {
        dos.writeLong(table.getTableId());
        dos.writeUTF(StringHelper.makeEmpty(table.getTableName()));
        if (table.getMode() != null) {
            dos.writeByte(table.getMode().getModeId());
            dos.writeByte(table.getMode().getTime());
        } else {
            dos.writeByte(0);
            dos.writeByte(0);
        }
        if (table.getPlayerCountMax() != null) {
            dos.writeByte(table.getPlayerCountMax().intValue());
        } else {
            dos.writeByte(0);
        }
        dos.writeByte(table.getPlayerCount());
        if (table.getBigBlind() != null) {
            dos.writeInt(table.getBigBlind().intValue());
        } else {
            dos.writeInt(0);
        }
        if (table.getSmallBlind() != null) {
            dos.writeInt(table.getSmallBlind().intValue());
        } else {
            dos.writeInt(0);
        }
        dos.writeByte(table.getGameType().byteValue());
    }

    public static void writePlayerOnTable(DataOutputStream dos, Player player, List<MedalTypeID> medals,
                                          boolean isHasCards) throws IOException {
        Byte hasCards = isHasCards ? PersistenceManagerImpl.TRUE_VALUE : PersistenceManagerImpl.FALSE_VALUE;
        dos.writeLong(player.getId());
        dos.writeByte(player.getPlaceId());
        dos.writeUTF(StringHelper.makeEmpty(player.getNetworkUserId()));
        dos.writeLong(player.getGameBalance());
        dos.writeByte(hasCards);
        dos.writeByte(player.getPlaying());
        if (medals != null) {
            dos.writeByte(medals.size());
            for (MedalTypeID medal : medals) {
                dos.writeByte(medal.getTypeId());
            }
        } else {
            dos.writeByte(0);
        }
    }

}
