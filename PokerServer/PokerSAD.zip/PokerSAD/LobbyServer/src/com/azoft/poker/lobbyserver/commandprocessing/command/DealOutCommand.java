package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;

public class DealOutCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(SitCommand.class);

    /**
     * deal identifier (in)
     */
    private Byte dealId;

    /**
     * Cards (in)
     */
    private List<Card> cards;


    public DealOutCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - DealOutCommand{" +
                "dealId='" + dealId + '\'' +
                ", cards='" + cards + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content

        dos.writeByte(this.dealId);
        for (Card card : cards) {
            dos.writeByte(card.getSuit());
            dos.writeByte(card.getValue());
        }

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }


    public void setDealId(Byte dealId) {
        this.dealId = dealId;
    }

    public void setCards(List<Card> cards) {
        this.cards = cards;
    }
}
