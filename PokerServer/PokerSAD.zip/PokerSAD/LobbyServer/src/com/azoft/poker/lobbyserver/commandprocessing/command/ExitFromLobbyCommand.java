package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.EmptyCommand;
import org.apache.mina.core.session.IoSession;

public class ExitFromLobbyCommand extends EmptyCommand {

    private boolean requiredCloseSession = true;

    public ExitFromLobbyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public boolean isRequiredCloseSession() {
        return requiredCloseSession;
    }

    public void setRequiredCloseSession(boolean requiredCloseSession) {
        this.requiredCloseSession = requiredCloseSession;
    }

    @Override
    public String toString() {
        return "ExitFromLobbyCommand{" +
                "userId='" + getUserId() + '\'' +
                ", requiredCloseSession=" + requiredCloseSession +
                '}';
    }

}
