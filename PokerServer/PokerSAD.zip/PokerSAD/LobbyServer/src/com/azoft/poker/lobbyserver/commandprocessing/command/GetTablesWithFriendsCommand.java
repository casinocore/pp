package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.lobbyserver.Constants;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetTablesWithFriendsCommand extends RequestCommand {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetTablesWithFriendsCommand.class);

    private static final int NOT_EXISTS_TABLE = 0;
    private static final int EXISTS_TABLE = 1;

    private List<String> friends = new ArrayList<String>();

    private Map<FriendID, Table> friendsTables = new HashMap<FriendID, Table>();

    private class FriendID {

        private Long personId;

        private String socialNetworkID;

        private FriendID(Long personId, String socialNetworkID) {
            this.personId = personId;
            this.socialNetworkID = socialNetworkID;
        }

        public Long getPersonId() {
            return personId;
        }

        public String getSocialNetworkID() {
            return socialNetworkID;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            FriendID friendID = (FriendID) o;

            if (!personId.equals(friendID.personId)) return false;

            return true;
        }

        @Override
        public int hashCode() {
            return personId.hashCode();
        }
    }

    public List<String> getFriends() {
        return friends;
    }

    public void addFriendsTables(Long personId, String friendsSNid, Table tbl) {
        FriendID frientID = new FriendID(personId, friendsSNid);
        if (!this.friendsTables.containsKey(frientID)) {
            this.friendsTables.put(frientID, tbl);
        }
    }

    public Map<FriendID, Table> getFriendsTables() {
        return friendsTables;
    }

    public GetTablesWithFriendsCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            int count = dis.readInt();
            for (int i = 0; i < count; i++) {
                friends.add(dis.readUTF());
            }
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);

        int count = friendsTables.size();
        if (!isExistsError()) {
            dos.writeInt(count);

            for (Map.Entry<FriendID, Table> entry : friendsTables.entrySet()) {
                FriendID friendID = entry.getKey();
                dos.writeLong(friendID.getPersonId());
                dos.writeUTF(friendID.getSocialNetworkID());
                Table table = entry.getValue();
                if (table == null) {
                    dos.writeByte(NOT_EXISTS_TABLE);
                } else {
                    dos.writeByte(EXISTS_TABLE);
                    JoinTableCommand.writeTable(dos, table);
                    dos.writeInt(Constants.bigBlindMultiplier);
                }
            }

            dos.flush();
            byte[] body = baos.toByteArray();
            //encode body size
            setBodySize(body.length);
            out.writeInt(body.length);
            //encode body itself
            out.write(body);
        }
    }
}
