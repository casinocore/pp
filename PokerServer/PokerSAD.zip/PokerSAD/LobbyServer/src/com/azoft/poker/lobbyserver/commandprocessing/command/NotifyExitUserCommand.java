package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class NotifyExitUserCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(NotifyExitUserCommand.class);

    private String friendSocialNetworkID;

    private Long friendUserId;

    public String getFriendSocialNetworkID() {
        return friendSocialNetworkID;
    }

    public void setFriendSocialNetworkID(String friendSocialNetworkID) {
        this.friendSocialNetworkID = friendSocialNetworkID;
    }

    public NotifyExitUserCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeLong(friendUserId);
        dos.writeUTF(friendSocialNetworkID);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        out.write(body);
    }

    public Long getFriendUserId() {
        return friendUserId;
    }

    public void setFriendUserId(Long userId) {
        this.friendUserId = userId;
    }
}