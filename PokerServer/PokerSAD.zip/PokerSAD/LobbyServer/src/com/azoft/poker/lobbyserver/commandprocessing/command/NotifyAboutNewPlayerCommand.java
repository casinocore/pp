package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.common.service.MedalTypeID;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class NotifyAboutNewPlayerCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(NotifyAboutNewPlayerCommand.class);

    /**
     * Player info (in)
     */

    private Player player;

    private List<MedalTypeID> medals = new ArrayList<MedalTypeID>();

    private boolean hasCards;

    public NotifyAboutNewPlayerCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public List<MedalTypeID> getMedals() {
        return medals;
    }

    public void setMedals(List<MedalTypeID> medals) {
        this.medals = medals;
    }

    public boolean isHasCards() {
        return hasCards;
    }

    public void setHasCards(boolean hasCards) {
        this.hasCards = hasCards;
    }

    @Override
    public String toString() {
        return super.toString() + " - NotifyAboutNewPlayerCommand{" +
                "player='" + player + '\'' + '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        //encode content
        JoinTableCommand.writePlayerOnTable(dos, player, medals, hasCards);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }
}
