package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.mtt.MTTTable;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.DataOutputStream;
import java.io.IOException;

public class SystemMTTNotifyTableCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(SystemMTTNotifyTableCommand.class);

    private MTTTable table;

    public SystemMTTNotifyTableCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public MTTTable getTable() {
        return table;
    }

    public void setTable(MTTTable table) {
        this.table = table;
    }

    @Override
    public String toString() {
        return super.toString() + " - SystemMTTNotifyTableCommand{" +
                "table=" + table +
                '}';
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
    }

    public void run() {
        try {
            table.processCommand(this);
        } catch (Throwable e) {
            LOGGER.error("run", e);
        }
    }

}
