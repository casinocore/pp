package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


public class HandOutDealerButtonCommand extends Command {
    private final static Logger LOGGER = LoggerFactory.getLogger(HandOutDealerButtonCommand.class);

    /**
     * Place identifier (in)
     */

    private Byte placeId;

    /**
     * lead time (in)
     */
    private Byte leadTime;


    public HandOutDealerButtonCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - HandOutDealerButtonCommand{" +
                "userId='" + getUserId() + '\'' + "," +
                "placeId='" + placeId + '\'' + "," +
                "leadTime='" + leadTime + '\'' + '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content
        dos.writeByte(placeId);
        dos.writeByte(leadTime);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public Byte getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    public Byte getLeadTime() {
        return leadTime;
    }

    public void setLeadTime(Byte leadTime) {
        this.leadTime = leadTime;
    }
}
