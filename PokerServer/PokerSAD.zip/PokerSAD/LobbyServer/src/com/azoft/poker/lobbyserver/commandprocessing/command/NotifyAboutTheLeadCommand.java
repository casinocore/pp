package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.lead.Lead;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class NotifyAboutTheLeadCommand extends Command {

    /**
     * Not exists player
     */
    public final static Long NOT_EXISTS_PLAYER = -1L;

    /**
     * player identifier (in)
     */
    private Long id;

    private Long gameBalance;

    /**
     * Lead (in)
     */
    private Lead lead;

    /**
     * Next player identifier (in)
     */
    private Long nextId;

    private Long callValue;

    public NotifyAboutTheLeadCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - NotifyAboutTheLeadCommand{" +
                "id='" + getId() + '\'' +
                ", balance='" + gameBalance + '\'' +
                ", lead='" + lead + '\'' +
                ", nextId='" + nextId + '\'' +
                ", callValue='" + callValue + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content

        dos.writeLong(id);
        dos.writeLong(gameBalance);
        dos.writeByte(lead.getLeadId());
        dos.writeLong(lead.getValue());
        dos.writeLong(nextId);
        dos.writeLong(callValue);

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public void setLead(Lead lead) {
        this.lead = lead;
    }

    public Lead getLead() {
        return lead;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getNextId() {
        return nextId;
    }

    public void setNextId(Long nextId) {
        this.nextId = nextId;
    }

    public Long getGameBalance() {
        return gameBalance;
    }

    public void setGameBalance(Long gameBalance) {
        this.gameBalance = gameBalance;
    }

    public Long getCallValue() {
        return callValue;
    }

    public void setCallValue(Long callValue) {
        this.callValue = callValue;
    }
}
