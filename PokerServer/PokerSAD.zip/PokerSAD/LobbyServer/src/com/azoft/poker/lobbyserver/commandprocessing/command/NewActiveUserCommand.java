package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class NewActiveUserCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(NewActiveUserCommand.class);

    private String socialNetworkID;

    private long balance;

    public long getBalance() {
        return balance;
    }

    public void setBalance(long balance) {
        this.balance = balance;
    }

    public String getSocialNetworkID() {
        return socialNetworkID;
    }

    public void setSocialNetworkID(String socialNetworkID) {
        this.socialNetworkID = socialNetworkID;
    }

    public NewActiveUserCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeUTF(socialNetworkID);
        dos.writeLong(balance);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        out.write(body);
    }
}
