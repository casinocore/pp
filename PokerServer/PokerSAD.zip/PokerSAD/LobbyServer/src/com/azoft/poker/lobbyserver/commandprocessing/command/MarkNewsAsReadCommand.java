package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MarkNewsAsReadCommand extends Command {

    private List<Long> newsIds;

    public MarkNewsAsReadCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
        newsIds = new ArrayList<Long>();
    }

    public List<Long> getNewsIds() {
        return newsIds;
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        int newsNumber = dis.readInt();
        for (int i = 0; i < newsNumber; i++) {
            newsIds.add(dis.readLong());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
    }

}