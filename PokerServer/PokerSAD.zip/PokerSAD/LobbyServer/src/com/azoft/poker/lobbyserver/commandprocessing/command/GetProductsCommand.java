package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.persistence.product.Product;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GetProductsCommand extends RequestCommand {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetProductsCommand.class);

    private List<Product> products;

    private byte defaultProduct;

    public GetProductsCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
        products = new ArrayList<Product>();
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public byte getDefaultProduct() {
        return defaultProduct;
    }

    public void setDefaultProduct(byte defaultProduct) {
        this.defaultProduct = defaultProduct;
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        int count = products.size();
        if (!isExistsError()) {
            dos.writeInt(count);

            for (int i = 0; i < count; i++) {
                dos.writeUTF(products.get(i).getProductCode());
                dos.writeUTF(products.get(i).getProductDescriptor());
                dos.writeLong(products.get(i).getAmount());
                dos.writeLong(products.get(i).getBalance());
            }

            dos.writeByte(defaultProduct);
            dos.flush();
            byte[] body = baos.toByteArray();
            //encode body size
            setBodySize(body.length);
            out.writeInt(body.length);
            //encode body itself
            out.write(body);
        }
    }

}