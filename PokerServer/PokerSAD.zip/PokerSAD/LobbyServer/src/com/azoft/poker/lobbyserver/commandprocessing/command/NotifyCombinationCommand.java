package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerCombinationAnalyzer;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class NotifyCombinationCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(NotifyCombinationCommand.class);

    private static final int NOT_EXISTS_CARD_VALUE = -1;

    /**
     * Table identifier
     */
    private PokerCombinationAnalyzer combinationAnalyzer;

    public NotifyCombinationCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public PokerCombinationAnalyzer getCombinationAnalyzer() {
        return combinationAnalyzer;
    }

    public void setCombinationAnalyzer(PokerCombinationAnalyzer combinationAnalyzer) {
        this.combinationAnalyzer = combinationAnalyzer;
    }

    @Override
    public String toString() {
        return "NotifyCombinationCommand{" +
                "combinationAnalyzer=" + combinationAnalyzer +
                '}';
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeByte(combinationAnalyzer.getHandRating().getTypeId());
        if (combinationAnalyzer.getValue1() != null) {
            dos.writeByte(combinationAnalyzer.getValue1());
        } else {
            dos.writeByte(NOT_EXISTS_CARD_VALUE);
        }
        if (combinationAnalyzer.getValue2() != null) {
            dos.writeByte(combinationAnalyzer.getValue2());
        } else {
            dos.writeByte(NOT_EXISTS_CARD_VALUE);
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        out.write(body);
    }

}