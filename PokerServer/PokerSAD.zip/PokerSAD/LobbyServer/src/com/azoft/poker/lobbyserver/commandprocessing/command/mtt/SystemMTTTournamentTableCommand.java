package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.lobbyserver.tableprocessing.mtt.MTTTable;
import org.apache.mina.core.session.IoSession;

public class SystemMTTTournamentTableCommand extends MTTNotifyCommand {

    /**
     * Table
     */
    private MTTTable table;

    private boolean firstCall = true;

    private Long dealCounter;

    public SystemMTTTournamentTableCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public MTTTable getTable() {
        return table;
    }

    public void setTable(MTTTable table) {
        this.table = table;
    }

    public boolean isFirstCall() {
        return firstCall;
    }

    public void setFirstCall(boolean firstCall) {
        this.firstCall = firstCall;
    }

    public Long getDealCounter() {
        return dealCounter;
    }

    public void setDealCounter(Long dealCounter) {
        this.dealCounter = dealCounter;
    }

    @Override
    public String toString() {
        return super.toString() + " - SystemMTTTournamentTableCommand{" +
                "table=" + table +
                ", firstCall=" + firstCall +
                ", dealCounter=" + dealCounter +
                '}';
    }

}
