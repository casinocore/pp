package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.Winner;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import com.azoft.poker.lobbyserver.tableprocessing.player.PlayerCard;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerHand;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;

public class DealFinishedCommand extends Command {
    private final static Logger LOGGER = LoggerFactory.getLogger(DealFinishedCommand.class);

    /**
     * winners (in)
     */
    private List<Winner> winners;

    /**
     * players (in)
     */
    private List<PlayerCard> players;


    public DealFinishedCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - DealFinishedCommand{" +
                "winners='" + winners + '\'' +
                ", players='" + players + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content

        dos.writeByte(winners.size());
        for (Winner winner : winners) {
            PokerHand pokerHand = winner.getPokerHand();
            dos.writeLong(pokerHand.getPlayerId());
            dos.writeByte(pokerHand.getHandRating().getTypeId());
            for (Card card : pokerHand.getWinCards()) {
                dos.writeByte(card.getSuit());
                dos.writeByte(card.getValue());
            }
            for (Card card : pokerHand.getHighCards()) {
                dos.writeByte(card.getSuit());
                dos.writeByte(card.getValue());
            }
            dos.writeLong(winner.getValue());
            dos.writeByte(winner.getBankNumbers().size());
            //System.out.println("!!!!!!! " + winner.getBankNumbers());
            //System.out.println("!!!!!!! " + winner.getBankNumbers().getClass());
            for (Byte b : winner.getBankNumbers().keySet()) {
                dos.writeByte(b);
                dos.writeLong(winner.getBankNumbers().get(b));
            }
        }
        dos.writeByte(players.size());


        for (PlayerCard pc : players) {
            dos.writeLong(pc.getPlayerId());
            List<Card> cards = pc.getCards();
            for (Card card : cards) {
                dos.writeByte(card.getSuit());
                dos.writeByte(card.getValue());
            }
            dos.writeLong(pc.getValue());
        }

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself

        out.write(body);
    }


    public void setWinners(List<Winner> winners) {
        this.winners = winners;
    }

    public void setPlayers(List<PlayerCard> players) {
        this.players = players;
    }
}
