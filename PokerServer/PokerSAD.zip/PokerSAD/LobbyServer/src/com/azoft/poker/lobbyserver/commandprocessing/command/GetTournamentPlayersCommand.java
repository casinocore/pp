package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.persistence.person.InfoPlayerBean;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;

public class GetTournamentPlayersCommand extends RequestCommand {

    /**
     * Value - not tournament register
     */
    public static final int NOT_TOURNAMENT_REGISTER = 0;

    /**
     * Value - tournament register
     */
    public static final int TOURNAMENT_REGISTER = 1;

    private Long tournamentId;

    private Integer topPlayerCount;

    private InfoPlayerBean infoPlayer;

    private Long tournamentPayment;

    private List<InfoPlayerBean> topInfoPlayers;

    public GetTournamentPlayersCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Long tournamentId) {
        this.tournamentId = tournamentId;
    }

    public Integer getTopPlayerCount() {
        return topPlayerCount;
    }

    public void setTopPlayerCount(Integer topPlayerCount) {
        this.topPlayerCount = topPlayerCount;
    }

    public InfoPlayerBean getTournamentPlayer() {
        return infoPlayer;
    }

    public void setTournamentPlayer(InfoPlayerBean infoPlayer) {
        this.infoPlayer = infoPlayer;
    }

    public Long getTournamentPayment() {
        return tournamentPayment;
    }

    public void setTournamentPayment(Long tournamentPayment) {
        this.tournamentPayment = tournamentPayment;
    }

    public List<InfoPlayerBean> getTopTournamentPlayers() {
        return topInfoPlayers;
    }

    public void setTopTournamentPlayers(List<InfoPlayerBean> topInfoPlayers) {
        this.topInfoPlayers = topInfoPlayers;
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setTournamentId(dis.readLong());
            setTopPlayerCount(dis.readInt());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            dos.writeLong(tournamentId);
            writeCurrentTournamentPlayer(dos, infoPlayer);
            dos.writeLong(tournamentPayment);
            int topTournamentPlayersCount = topInfoPlayers.size();
            dos.writeInt(topTournamentPlayersCount);
            for (int i = 0; i < topTournamentPlayersCount; i++) {
                InfoPlayerBean topInfoPlayer = topInfoPlayers.get(i);
                writeInfoPlayer(dos, topInfoPlayer);
            }
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public static void writeCurrentTournamentPlayer(DataOutputStream dos, InfoPlayerBean infoPlayer) throws IOException {
        if (infoPlayer != null) {
            dos.writeByte(TOURNAMENT_REGISTER);
            writeInfoPlayer(dos, infoPlayer);
        } else {
            dos.writeByte(NOT_TOURNAMENT_REGISTER);
        }
    }

    public static void writeInfoPlayer(DataOutputStream dos, InfoPlayerBean infoPlayer) throws IOException {
        dos.writeLong(infoPlayer.getPlayerId());
        if (infoPlayer.getRanked() != null) {
            dos.writeLong(infoPlayer.getRanked());
        } else {
            dos.writeLong(EMPTY_VALUE);
        }
        dos.writeUTF(infoPlayer.getSocialNetworkID());
        dos.writeLong(infoPlayer.getBalance());
    }

    @Override
    public String toString() {
        return super.toString() + " - GetTournamentPlayersCommand{" +
                "tournamentId=" + tournamentId +
                ", topPlayerCount=" + topPlayerCount +
                ", infoPlayer=" + infoPlayer +
                ", tournamentPayment=" + tournamentPayment +
                ", topInfoPlayers.size=" + (topInfoPlayers != null ? topInfoPlayers.size() : "0") +
                '}';
    }

}