package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.persistence.tournament.Tournament;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetTournamentsLobbyCommand extends RequestCommand {

    private Byte tournamentType;

    private Byte tournamentStatus;

    private List<Tournament> tournaments;

    private Map<Long, Long> tournamentPaymentMap = new HashMap<Long, Long>();

    public Byte getTournamentType() {
        return tournamentType;
    }

    public void setTournamentType(Byte tournamentType) {
        this.tournamentType = tournamentType;
    }

    public Byte getTournamentStatus() {
        return tournamentStatus;
    }

    public void setTournamentStatus(Byte tournamentStatus) {
        this.tournamentStatus = tournamentStatus;
    }

    public List<Tournament> getTournaments() {
        return tournaments;
    }

    public void setTournaments(List<Tournament> tournaments) {
        this.tournaments = tournaments;
    }

    public void putTournamentPayment(Long tournamentId, Long tournamentPayment) {
        this.tournamentPaymentMap.put(tournamentId, tournamentPayment);
    }

    public GetTournamentsLobbyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setTournamentType(dis.readByte());
            setTournamentStatus(dis.readByte());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        int count = tournaments.size();
        if (!isExistsError()) {
            dos.writeInt(count);
            for (Tournament tournament : tournaments) {
                Long tournamentPayment = tournamentPaymentMap.get(tournament.getId());
                GetTournamentCommand.writeTournament(dos, getUserId(), tournament, tournamentPayment);
            }
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
