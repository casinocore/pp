package com.azoft.poker.lobbyserver.codec;

import com.azoft.poker.common.codec.AbstractCommandDecoder;
import com.azoft.poker.lobbyserver.commandprocessing.LobbyCommandFactoryImpl;

public class LobbyCommandDecoder extends AbstractCommandDecoder {

    public LobbyCommandDecoder() {
        super();
        setCommandFactory(new LobbyCommandFactoryImpl());
    }
}
