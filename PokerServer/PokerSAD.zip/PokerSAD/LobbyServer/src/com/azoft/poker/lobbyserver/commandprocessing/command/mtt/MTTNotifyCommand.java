package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.lobbyserver.commandprocessing.command.NotifyTournamentCommand;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class MTTNotifyCommand extends NotifyTournamentCommand {

    public MTTNotifyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content
        super.encodeBody(dos);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}