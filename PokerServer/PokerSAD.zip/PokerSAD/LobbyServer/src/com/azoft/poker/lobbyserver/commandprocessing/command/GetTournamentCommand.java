package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.bean.Blind;
import com.azoft.poker.common.bean.SynchronousHand;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import com.azoft.poker.common.persistence.tournament.*;
import com.azoft.poker.lobbyserver.mtt.MTTTournament;
import com.azoft.poker.lobbyserver.mtt.MTTTournamentServiceImpl;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

public class GetTournamentCommand extends RequestCommand {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetTournamentCommand.class);

    private Long tournamentId;

    private Tournament tournament;

    private Long tournamentPayment;

    private List<Table> tables;

    public GetTournamentCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Long tournamentId) {
        this.tournamentId = tournamentId;
    }

    public Tournament getTournament() {
        return tournament;
    }

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
    }

    public Long getTournamentPayment() {
        return tournamentPayment;
    }

    public void setTournamentPayment(Long tournamentPayment) {
        this.tournamentPayment = tournamentPayment;
    }

    public List<Table> getTables() {
        return tables;
    }

    public void setTables(List<Table> tables) {
        this.tables = tables;
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setTournamentId(dis.readLong());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            writeTournament(dos, getUserId(), tournament, tournamentPayment);
            int tablesCount = tables.size();
            dos.writeInt(tablesCount);
            for (int i = 0; i < tablesCount; i++) {
                Table table = tables.get(i);
                JoinTableCommand.writeTable(dos, table);
            }
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public static boolean writeTournament(DataOutputStream dos, Long userId, Tournament tournament,
                                          Long tournamentPayment)
            throws IOException {
        TournamentManager tournamentManager = TournamentManagerImpl.getInstance();
        TournamentPersonStatus tps = tournamentManager.getTournamentPersonStatus(tournament.getId(), userId);
        boolean result = tps != null;
        Byte tournamentRegister;
        if (result) {
            tournamentRegister = GetTournamentPlayersCommand.TOURNAMENT_REGISTER;
        } else {
            tournamentRegister = GetTournamentPlayersCommand.NOT_TOURNAMENT_REGISTER;
        }
        Long tournamentPlayerCount = tournamentManager.getTournamentPersonStatusCount(tournament.getId());

        dos.writeLong(tournament.getId());
        dos.writeByte(tournamentRegister);
        dos.writeUTF(tournament.getName());
        dos.writeByte(tournament.getType());
        dos.writeByte(tournament.getStatus());
        if (tournament.getMinPlayersCount() != null) {
            dos.writeLong(tournament.getMinPlayersCount());
        } else {
            dos.writeLong(EMPTY_VALUE);
        }
        if (tournament.getMaxPlayersCount() != null) {
            dos.writeLong(tournament.getMaxPlayersCount());
        } else {
            dos.writeLong(EMPTY_VALUE);
        }
        dos.writeLong(tournamentPlayerCount);
        dos.writeLong(tournamentPayment);
        dos.writeByte(tournament.getWinnerCount());
        dos.writeLong(tournament.getStartChipsCount());
        if (tournament.getFromDate() != null) {
            dos.writeLong(tournament.getFromDate().getTime());
        } else {
            dos.writeLong(EMPTY_VALUE);
        }
        if (tournament.getToDate() != null) {
            dos.writeLong(tournament.getToDate().getTime());
        } else {
            dos.writeLong(EMPTY_VALUE);
        }
        long delta = tournament.calculateTimeBeforeStart();
        dos.writeLong(delta);
        delta = tournament.calculateTimeBeforeEnd();
        dos.writeLong(delta);
        dos.writeUTF(StringHelper.makeEmpty(tournament.getDescriptor()));
        if (TournamentTypeID.MTT_TOURNAMENT.getTypeId() == tournament.getType()) {
            writeMTTTournament(dos, tps, TournamentFactoryImpl.createMTTTournamentWrapper(tournament));
        }
        return result;
    }

    private static void writeMTTTournament(DataOutputStream dos, TournamentPersonStatus tps,
                                           MTTTournamentWrapper tournament) throws IOException {
        MTTTournament mttTournament =
                MTTTournamentServiceImpl.getInstance().getMTTTournament(tournament.getEntity().getId());
        Date startRegistration = tournament.getStartRegistration();
        Short lateRegistrationPeriod = tournament.getLateRegistrationPeriod();
        if (startRegistration != null) {
            dos.writeLong(startRegistration.getTime());
            dos.writeLong(tournament.getBeforeStartRegistration());
        } else {
            dos.writeLong(EMPTY_VALUE);
            dos.writeLong(EMPTY_VALUE);
        }
        Byte cancelRegistrationIsAccessible = tournament.getCancelRegistrationIsAccessible();
        dos.writeByte(cancelRegistrationIsAccessible != null ? cancelRegistrationIsAccessible : 0);
        Short cancelRegistrationPeriod = tournament.getCancelRegistrationPeriod();
        dos.writeShort(cancelRegistrationPeriod != null ? cancelRegistrationPeriod : 0);
        dos.writeShort(lateRegistrationPeriod != null ? lateRegistrationPeriod : 0);
        Short beforeStartNotificationPeriod = tournament.getBeforeStartNotificationPeriod();
        dos.writeShort(beforeStartNotificationPeriod != null ? beforeStartNotificationPeriod : 0);
        Byte rebuyIsAccessible = tournament.getRebuyIsAccessible();
        dos.writeByte(rebuyIsAccessible != null ? rebuyIsAccessible : 0);
        Short rebuyPeriod = tournament.getRebuyPeriod();
        dos.writeShort(rebuyPeriod != null ? rebuyPeriod : 0);
        Long rebuy = tournament.getRebuy();
        dos.writeLong(rebuy != null ? rebuy : EMPTY_VALUE);
        Short blindPeriod = tournament.getBlindPeriod();
        dos.writeShort(blindPeriod != null ? blindPeriod : EMPTY_VALUE);
        List<Blind> blinds = tournament.getBlinds();
        dos.writeByte(blinds.size());
        for (Blind blind : blinds) {
            dos.writeInt(blind.getSmallBlind());
            dos.writeInt(blind.getBigBlind());
        }
        Blind blindCurrent = (mttTournament != null ? mttTournament.getCurrentBlind() : null);
        dos.writeInt(blindCurrent != null ? blindCurrent.getSmallBlind() : EMPTY_VALUE);
        dos.writeInt(blindCurrent != null ? blindCurrent.getBigBlind() : EMPTY_VALUE);
        Short breakPeriod = tournament.getBreakPeriod();
        dos.writeShort(breakPeriod != null ? breakPeriod : EMPTY_VALUE);
        Short breakTime = tournament.getBreakTime();
        dos.writeShort(breakTime != null ? breakTime : EMPTY_VALUE);
        dos.writeLong(mttTournament != null ? mttTournament.getBeforeBreakStart() : 0L);
        dos.writeLong(mttTournament != null ? mttTournament.getBeforeBreakFinished() : 0L);
        List<SynchronousHand> synchronousHands = tournament.getSynchronousHands();
        dos.writeByte(synchronousHands.size());
        for (SynchronousHand synchronousHand : synchronousHands) {
            dos.writeLong(synchronousHand.getStartNumber());
            dos.writeLong(synchronousHand.getFinishedNumber());
        }
        Long activePlayerCount = mttTournament != null ? mttTournament.getActivePlayerCount() : 0L;
        dos.writeLong(activePlayerCount != null ? activePlayerCount : 0L);
        Byte activePlayer;
        if (tps != null && tps.getLeavingTime() == null) {
            activePlayer = PersistenceManagerImpl.TRUE_VALUE;
        } else {
            activePlayer = PersistenceManagerImpl.FALSE_VALUE;
        }
        dos.writeByte(activePlayer);
    }

}
