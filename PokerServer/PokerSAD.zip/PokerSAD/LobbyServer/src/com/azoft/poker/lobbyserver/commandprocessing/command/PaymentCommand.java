package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.helper.StringHelper;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class PaymentCommand extends RequestCommand {

    /**
     * Product code
     */
    private String productCode;

    /**
     * Test mode
     */
    private Byte testMode;

    /**
     * Transferred amount
     */
    private Long amount;

    /**
     * Extern error code
     */
    private Long externErrorCode;

    /**
     * Extern error message
     */
    private String externErrorMessage;

    public PaymentCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Byte getTestMode() {
        return testMode;
    }

    public void setTestMode(Byte testMode) {
        this.testMode = testMode;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Long getExternErrorCode() {
        return externErrorCode;
    }

    public void setExternErrorCode(Long externErrorCode) {
        this.externErrorCode = externErrorCode;
    }

    public String getExternErrorMessage() {
        return externErrorMessage;
    }

    public void setExternErrorMessage(String externErrorMessage) {
        this.externErrorMessage = externErrorMessage;
    }

    @Override
    public String toString() {
        return super.toString() + " - PaymentCommand{" +
                "productCode='" + productCode + '\'' +
                ", testMode=" + testMode +
                ", amount=" + amount +
                ", externErrorCode=" + externErrorCode +
                ", externErrorMessage=" + externErrorMessage +
                '}';
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setProductCode(dis.readUTF());
            setTestMode(dis.readByte());
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            if (amount != null) {
                dos.writeLong(amount);
            } else {
                dos.writeLong(0);
            }
            if (externErrorCode != null) {
                dos.writeLong(externErrorCode);
                dos.writeUTF(StringHelper.makeEmptyTrimmed(externErrorMessage));
            } else {
                dos.writeLong(0);
            }
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}