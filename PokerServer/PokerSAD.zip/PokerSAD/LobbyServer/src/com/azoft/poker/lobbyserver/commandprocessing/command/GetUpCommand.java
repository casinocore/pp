package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.TableManagerImpl;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class GetUpCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetUpCommand.class);

    /**
     * place identifier at the table
     */
    private Byte placeId;

    public GetUpCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    @Override
    public String toString() {
        return "GetUpCommand{" +
                "userId='" + getUserId() + '\'' +
                ", placeId=" + placeId +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        placeId = dis.readByte();
    }

    public void encodeBody(DataOutputStream out) throws IOException {

    }

    public Byte getPlaceId() {
        return placeId;
    }

    public void run() {
        Table table = TableManagerImpl.getTableAttribute(getSession());
        try {
            //LOGGER.debug("start process command: " + toString());
            table.processCommand(this);
            //LOGGER.debug("end process command: " + toString());
        } catch (Throwable e) {
            LOGGER.error("run", e);
        }
    }

}
