package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.TableManagerImpl;
import com.azoft.poker.lobbyserver.tableprocessing.lead.Lead;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class LeadCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(SitCommand.class);

    /**
     *  Unique user id (in) - Long getUserId() / setUserId(Long UserId)
     */

    /**
     * Lead (in)
     */
    private Lead lead;

    public LeadCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - LeadCommand{" +
                "userId='" + getUserId() + '\'' +
                ", lead='" + lead + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        lead = new Lead();
        lead.setLeadId(dis.readByte());
        lead.setValue(dis.readLong());
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
    }

    public void run() {
        Table table = TableManagerImpl.getTableAttribute(getSession());
        try {
            table.processCommand(this);
        } catch (Throwable e) {
            LOGGER.error("run", e);
        }
    }

    public void setLead(Lead lead) {
        this.lead = lead;
    }

    public Lead getLead() {
        return lead;
    }
}
