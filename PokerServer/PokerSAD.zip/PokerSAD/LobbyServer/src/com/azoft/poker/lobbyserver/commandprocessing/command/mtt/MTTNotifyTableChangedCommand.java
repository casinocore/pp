package com.azoft.poker.lobbyserver.commandprocessing.command.mtt;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.service.MedalTypeID;
import com.azoft.poker.lobbyserver.commandprocessing.command.NotifyTournamentCommand;
import com.azoft.poker.lobbyserver.commandprocessing.command.PlayNowCommand;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MTTNotifyTableChangedCommand extends NotifyTournamentCommand {

    /**
     * Table
     */
    private Table table = null;

    private Player player;

    private Map<Long, List<MedalTypeID>> medalsMap = new HashMap<Long, List<MedalTypeID>>();

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public MTTNotifyTableChangedCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Table getTable() {
        return table;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    public Map<Long, List<MedalTypeID>> getMedalsMap() {
        return medalsMap;
    }

    public void setMedalsMap(Map<Long, List<MedalTypeID>> medalsMap) {
        this.medalsMap = medalsMap;
    }

    @Override
    public String toString() {
        return PlayNowCommand.InfoPlayToString("MTTNotifyTableChangedCommand", super.toString(),
                this.getSession() != null ? getUserId() : null,
                table, player != null ? player.getPlaceId() : null);
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        PlayNowCommand.writeInfoPlay(dos, table, medalsMap);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}