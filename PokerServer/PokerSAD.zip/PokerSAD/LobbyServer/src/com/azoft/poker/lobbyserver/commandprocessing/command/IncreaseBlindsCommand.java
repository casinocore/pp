package com.azoft.poker.lobbyserver.commandprocessing.command;

import com.azoft.poker.common.bean.Blind;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class IncreaseBlindsCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(SitCommand.class);

    private Table table;

    private Blind blind;

    private Short blindPeriod;

    public IncreaseBlindsCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - IncreaseBlindsCommand{" +
                "tableName=" + (table != null ? table.getTableName() : null) +
                ", blind=" + blind +
                ", blindPeriod=" + blindPeriod +
                '}';
    }

    public Blind getBlind() {
        return blind;
    }

    public void setBlind(Blind blind) {
        this.blind = blind;
    }

    public Short getBlindPeriod() {
        return blindPeriod;
    }

    public void setBlindPeriod(Short blindPeriod) {
        this.blindPeriod = blindPeriod;
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public void run() {
        try {
            table.processCommand(this);
        } catch (Throwable e) {
            LOGGER.error("run", e);
        }
    }


    public Table getTable() {
        return table;
    }

    public void setTable(Table table) {
        this.table = table;
    }

}