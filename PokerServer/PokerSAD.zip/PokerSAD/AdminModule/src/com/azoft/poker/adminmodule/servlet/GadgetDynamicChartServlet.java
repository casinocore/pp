package com.azoft.poker.adminmodule.servlet;

import com.azoft.poker.adminmodule.gadget.QuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.chart.ChartFactoryImpl;
import com.azoft.poker.adminmodule.gadget.chart.ConverterUtils;
import com.azoft.poker.adminmodule.gadget.chart.ImageType;
import com.azoft.poker.adminmodule.gadget.chart.properties.ChartProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Gadget dynamic chart servlet
 */
public class GadgetDynamicChartServlet extends HttpServlet {

    private final static Logger LOGGER = LoggerFactory.getLogger(GadgetDynamicChartServlet.class);

    private static final String CONTENT_TYPE = "image/png";

    private static final String PARAMETER_IMAGE_TYPE = "imageType";

    @Override
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String chartTypeName = request.getParameter(PARAMETER_IMAGE_TYPE);
            ImageType imageType = ImageType.valueOf(chartTypeName);
            ChartProperties chartProperties = ChartFactoryImpl.createChartProperties(imageType);
            List<QuantityInfoBean> quantityInfoList = ChartFactoryImpl.getChartQuantityInfoList(imageType);
            response.setContentType(CONTENT_TYPE);
            ConverterUtils.writeChartAsPNG(response.getOutputStream(), chartProperties, quantityInfoList);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        }
    }

}