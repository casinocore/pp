package com.azoft.poker.adminmodule.servlet;

import com.azoft.poker.adminmodule.service.AdminModuleLifecycleServiceImpl;

import javax.servlet.http.HttpServlet;

/**
 * Admin module servlet
 */
public class AdminModuleServlet extends HttpServlet {

    public void init() throws javax.servlet.ServletException {
        super.init();
        AdminModuleLifecycleServiceImpl.getInstance().initialization(null);
    }

    public void destroy() {
        AdminModuleLifecycleServiceImpl.getInstance().shutdown();
        super.destroy();
    }

}