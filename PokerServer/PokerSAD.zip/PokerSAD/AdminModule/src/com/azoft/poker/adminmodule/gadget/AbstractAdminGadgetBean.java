package com.azoft.poker.adminmodule.gadget;

/**
 * Abstract admin gadget bean for admin gadget
 */
public abstract class AbstractAdminGadgetBean {

    protected Long timestamp;

    private Long lifeTime = 0L;

    public AbstractAdminGadgetBean() {
    }

    protected AbstractAdminGadgetBean(Long lifeTime) {
        this.lifeTime = lifeTime;
    }

    public boolean isActual() {
        return timestamp != null && (System.currentTimeMillis() - timestamp) < lifeTime;
    }

    public void resetTimestamp() {
        timestamp = System.currentTimeMillis();
    }

    public Long getLifeTime() {
        return lifeTime;
    }

    public void setLifeTime(Long lifeTime) {
        this.lifeTime = lifeTime;
    }

}