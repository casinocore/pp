package com.azoft.poker.adminmodule.gadget.chart.properties;

import com.azoft.poker.adminmodule.gadget.chart.ImageType;
import org.jfree.chart.axis.DateTickUnit;

/**
 * Week chart properties
 */
public class MonthChartProperties extends ChartProperties {

    private static final int MONTH_XSCALE_TYPE = DateTickUnit.DAY;
    private static final String MONTH_DATE_MASK = "dd/MM";
    private static final Integer MONTH_XSCALE = 3;

    public MonthChartProperties(ImageType imageType) {
        super(imageType);
        setxScaleType(MONTH_XSCALE_TYPE);
        setDateMask(MONTH_DATE_MASK);
        setxScale(MONTH_XSCALE);
    }

}