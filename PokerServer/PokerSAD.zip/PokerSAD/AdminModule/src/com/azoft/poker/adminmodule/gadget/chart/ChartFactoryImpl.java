package com.azoft.poker.adminmodule.gadget.chart;

import com.azoft.poker.adminmodule.gadget.QuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.chart.properties.ChartProperties;
import com.azoft.poker.adminmodule.gadget.chart.properties.MonthChartProperties;
import com.azoft.poker.adminmodule.gadget.chart.properties.WeekChartProperties;
import com.azoft.poker.adminmodule.service.AdminGadgetService;
import com.azoft.poker.adminmodule.service.AdminGadgetServiceImpl;

import java.util.List;

/**
 * Chart factory
 */
public class ChartFactoryImpl {

    public static ChartProperties createChartProperties(ImageType imageType) {
        ChartProperties properties = null;
        if (ImageType.day.equals(imageType)) {
            properties = new ChartProperties(imageType);
        } else if (ImageType.week.equals(imageType)) {
            properties = new WeekChartProperties(imageType);
        } else if (ImageType.month.equals(imageType)) {
            properties = new MonthChartProperties(imageType);
        }
        return properties;
    }

    public static List<QuantityInfoBean> getChartQuantityInfoList(ImageType imageType) {
        List<QuantityInfoBean> quantityInfoList = null;
        AdminGadgetService service = AdminGadgetServiceImpl.getInstance();
        if (ImageType.day.equals(imageType)) {
            quantityInfoList = service.getAdminGadgetBean().getQuantityInfoListForDay();
        } else if (ImageType.week.equals(imageType)) {
            quantityInfoList = service.getAdminGadgetBean().getQuantityInfoListForWeek();
        } else if (ImageType.month.equals(imageType)) {
            quantityInfoList = service.getAdminGadgetBean().getQuantityInfoListForMonth();
        }
        return quantityInfoList;
    }

}
