package com.azoft.poker.adminmodule.gadget.chart;

import com.azoft.poker.adminmodule.exception.AdminModuleException;
import com.azoft.poker.adminmodule.gadget.QuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.chart.properties.ChartProperties;
import org.jfree.chart.ChartUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 * Chart utils
 */
public class ConverterUtils {

    private final static Logger LOGGER = LoggerFactory.getLogger(ConverterUtils.class);

    public ConverterUtils() {
    }

    /**
     * Write chart as PNG.
     *
     * @param out              the out
     * @param quantityInfoList quantity info list
     * @param properties       the properties
     * @throws IOException the IO exception
     */
    public static void writeChartAsPNG(OutputStream out, ChartProperties properties, List<QuantityInfoBean> quantityInfoList)
            throws IOException {
        Chart chart = new Chart(properties);
        chart.formDataset(quantityInfoList);
        try {
            BufferedImage image = chart.generateChartImage();
            ChartUtilities.writeBufferedImageAsPNG(out, image);
        } catch (AdminModuleException e) {
            LOGGER.error("writeChartAsPNG", e);
        }
    }

}
