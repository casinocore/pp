package com.azoft.poker.adminmodule.gadget;

/**
 * Basic quantity info bean for admin gadget
 */
public class BasicQuantityInfoBean extends AbstractAdminGadgetBean {

    private Integer quantityOfRegistrations;
    private Integer quantityOfRegistrationsDay;
    private Integer quantityOfPlayers;

    public BasicQuantityInfoBean() {
        super();
    }

    public BasicQuantityInfoBean(Long lifeTime) {
        super(lifeTime);
    }

    public Integer getQuantityOfRegistrations() {
        return quantityOfRegistrations;
    }

    public void setQuantityOfRegistrations(Integer quantityOfRegistrations) {
        this.quantityOfRegistrations = quantityOfRegistrations;
    }

    public Integer getQuantityOfRegistrationsDay() {
        return quantityOfRegistrationsDay;
    }

    public void setQuantityOfRegistrationsDay(Integer quantityOfRegistrationsDay) {
        this.quantityOfRegistrationsDay = quantityOfRegistrationsDay;
    }

    public Integer getQuantityOfPlayers() {
        return quantityOfPlayers;
    }

    public void setQuantityOfPlayers(Integer quantityOfPlayers) {
        this.quantityOfPlayers = quantityOfPlayers;
    }

}