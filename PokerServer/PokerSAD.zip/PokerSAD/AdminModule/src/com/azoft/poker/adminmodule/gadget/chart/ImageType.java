package com.azoft.poker.adminmodule.gadget.chart;

/**
 * Image type
 */
public enum ImageType {

    day("График за сутки"),
    week("График за неделю"),
    month("График за месяц");

    private String title;

    ImageType(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

}
