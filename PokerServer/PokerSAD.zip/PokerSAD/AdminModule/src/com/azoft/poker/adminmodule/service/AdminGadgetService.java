package com.azoft.poker.adminmodule.service;

import com.azoft.poker.adminmodule.gadget.AdminGadgetBean;
import com.azoft.poker.adminmodule.gadget.chart.ImageType;
import com.azoft.poker.common.service.LifecycleService;
import com.azoft.poker.common.service.ServletService;

/**
 * Admin gadget service interface
 */
public interface AdminGadgetService extends LifecycleService, ServletService {

    String GADGET_DIRECTORY = "gadget/";
    String IMAGE_FILE_NAME_POSTFIX = "Image.png";

    String DAY_CHART_FILE_NAME = ImageType.day.name() + IMAGE_FILE_NAME_POSTFIX;
    String WEEK_CHART_FILE_NAME = ImageType.week.name() + IMAGE_FILE_NAME_POSTFIX;
    String MONTH_CHART_FILE_NAME = ImageType.month.name() + IMAGE_FILE_NAME_POSTFIX;

    /**
     * Initialization info
     */
    public void initializationInfo();

    /**
     * Prepare info
     */
    void prepareInfo();

    /**
     * Get admin gadget bean
     *
     * @return admin gadget bean
     */
    public AdminGadgetBean getAdminGadgetBean();

}
