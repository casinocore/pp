package com.azoft.poker.adminmodule.service;

import java.io.File;
import java.io.IOException;

/**
 * Resources
 */
public class Resources {

    private static String WORK_DIRECTORY = "../work/poker-sn/adminmodule/";

    /**
     * Get resources directory
     *
     * @return resources directory
     * @throws IOException, AdminModuleException io exception
     */
    public static synchronized String getResourcesDirectory() throws IOException {
        mkResourcesDirectory(WORK_DIRECTORY);
        return WORK_DIRECTORY;
    }

    /**
     * Delete resources directory
     *
     * @throws IOException, AdminModuleException io exception
     */
    public static synchronized boolean deleteResourcesDirectory() throws IOException {
        boolean result = false;
        File dir = new File(WORK_DIRECTORY);
        if (dir.exists() && dir.isDirectory()) {
            result = dir.delete();
        }
        return result;
    }

    /**
     * Get resources directory
     *
     * @param path path
     * @return resources directory
     * @throws IOException, AdminModuleException io exception
     */
    public static synchronized String getResourcesDirectory(String path) throws IOException {
        String workPath = getResourcesDirectory();
        String fullPath = workPath + path;
        mkResourcesDirectory(fullPath);
        return fullPath;
    }

    /**
     * Delete resources file
     *
     * @throws IOException, AdminModuleException io exception
     */
    public static synchronized boolean deleteResourcesFile(String path) throws IOException {
        boolean result = false;
        File file = new File(path);
        if (file.exists() && file.isFile()) {
            result = file.delete();
        }
        return result;
    }

    private static void mkResourcesDirectory(String directory) throws IOException {
        File dir = new File(directory);
        if (!(dir.exists() && dir.isDirectory())) {
            boolean result = dir.mkdirs();
            if (!result) {
                throw new IOException("Not created dir: " + directory);
            }
        }
    }

}
