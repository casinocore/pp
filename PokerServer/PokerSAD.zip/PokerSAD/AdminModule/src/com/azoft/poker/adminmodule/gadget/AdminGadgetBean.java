package com.azoft.poker.adminmodule.gadget;

import com.azoft.poker.common.helper.DateHelper;

import java.util.*;

/**
 * Admin gadget bean for admin gadget
 */
public class AdminGadgetBean extends AbstractAdminGadgetBean {

    public static final int DAY_NUMBER_IN_MONTH = 30;
    public static final int DAY_NUMBER_IN_WEEK = 7;
    public static final int HOUR_NUMBER_IN_DAY = 24;

    public static final long BASIC_QUANTITY_INFO_LIFE_TIME = DateHelper.MIN_MSEC * 5;
    public static final long QUANTITY_INFO_TODAY_LIFE_TIME = DateHelper.MIN_MSEC * 5;
    public static final long QUANTITY_INFO_YESTERDAY_LIFE_TIME = DateHelper.MIN_MSEC * 5;

    private BasicQuantityInfoBean basicQuantityInfo;

    private QuantityInfoBean quantityInfoToday;
    private QuantityInfoBean quantityInfoYesterday;
    private QuantityInfoBean quantityInfoRecord;
    private QuantityInfoBean quantityInfoPriorRecord;

    private List<QuantityInfoBean> quantityInfoListForDay = new ArrayList<QuantityInfoBean>();
    private List<QuantityInfoBean> quantityInfoListForWeek = new ArrayList<QuantityInfoBean>();
    private List<QuantityInfoBean> quantityInfoListForMonth = new ArrayList<QuantityInfoBean>();

    public AdminGadgetBean() {
    }

    public BasicQuantityInfoBean getBasicQuantityInfo() {
        return basicQuantityInfo;
    }

    public void setBasicQuantityInfo(BasicQuantityInfoBean basicQuantityInfo) {
        this.basicQuantityInfo = basicQuantityInfo;
    }

    public QuantityInfoBean getQuantityInfoToday() {
        return quantityInfoToday;
    }

    public void setQuantityInfoToday(QuantityInfoBean quantityInfoToday) {
        this.quantityInfoToday = quantityInfoToday;
    }

    public QuantityInfoBean getQuantityInfoYesterday() {
        return quantityInfoYesterday;
    }

    public void setQuantityInfoYesterday(QuantityInfoBean quantityInfoYesterday) {
        this.quantityInfoYesterday = quantityInfoYesterday;
    }

    public QuantityInfoBean getQuantityInfoRecord() {
        return quantityInfoRecord;
    }

    public void setQuantityInfoRecord(QuantityInfoBean quantityInfoRecord) {
        this.quantityInfoRecord = quantityInfoRecord;
    }

    public QuantityInfoBean getQuantityInfoPriorRecord() {
        return quantityInfoPriorRecord;
    }

    public void setQuantityInfoPriorRecord(QuantityInfoBean quantityInfoPriorRecord) {
        this.quantityInfoPriorRecord = quantityInfoPriorRecord;
    }

    public List<QuantityInfoBean> getQuantityInfoListForDay() {
        return quantityInfoListForDay;
    }

    public List<QuantityInfoBean> getQuantityInfoListForWeek() {
        return quantityInfoListForWeek;
    }

    public void addQuantityInfoListForWeek(QuantityInfoBean quantityInfo) {
        quantityInfoListForWeek.add(quantityInfo);
    }

    public List<QuantityInfoBean> getQuantityInfoListForMonth() {
        return quantityInfoListForMonth;
    }

    public boolean isActual() {
        return isActual(Calendar.HOUR_OF_DAY);
    }

    private boolean isActual(int field) {
        boolean result = false;
        if (timestamp != null) {
            Calendar calendar = new GregorianCalendar();
            Calendar timestampCalendar = new GregorianCalendar();
            timestampCalendar.setTime(new Date(timestamp));
            if (calendar.get(field) == timestampCalendar.get(field)) {
                result = true;
            }
        }
        return result;
    }

}