package com.azoft.poker.adminmodule.gadget;

import java.util.Date;

/**
 * Quantity info bean for admin gadget
 */
public class QuantityInfoBean extends AbstractAdminGadgetBean {

    private Date fromDate;
    private Date toDate;

    private Integer quantityOfNewRegistrations;
    private Integer quantityOfActivePlayers;
    private Integer quantityOfPaymentPlayers;
    private Integer quantityOfOnlinePlayers;
    private Date onlinePeakTime;

    public QuantityInfoBean() {
        super();
    }

    public QuantityInfoBean(Long lifeTime) {
        super(lifeTime);
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public Integer getQuantityOfNewRegistrations() {
        return quantityOfNewRegistrations;
    }

    public void setQuantityOfNewRegistrations(Integer quantityOfNewRegistrations) {
        this.quantityOfNewRegistrations = quantityOfNewRegistrations;
    }

    public Integer getQuantityOfActivePlayers() {
        return quantityOfActivePlayers;
    }

    public void setQuantityOfActivePlayers(Integer quantityOfActivePlayers) {
        this.quantityOfActivePlayers = quantityOfActivePlayers;
    }

    public Integer getQuantityOfPaymentPlayers() {
        return quantityOfPaymentPlayers;
    }

    public void setQuantityOfPaymentPlayers(Integer quantityOfPaymentPlayers) {
        this.quantityOfPaymentPlayers = quantityOfPaymentPlayers;
    }

    public Integer getQuantityOfOnlinePlayers() {
        return quantityOfOnlinePlayers;
    }

    public void setQuantityOfOnlinePlayers(Integer quantityOfOnlinePlayers) {
        this.quantityOfOnlinePlayers = quantityOfOnlinePlayers;
    }

    public Date getOnlinePeakTime() {
        return onlinePeakTime;
    }

    public void setOnlinePeakTime(Date onlinePeakTime) {
        this.onlinePeakTime = onlinePeakTime;
    }

}