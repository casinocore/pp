package com.azoft.poker.adminmodule.gadget.chart;

import com.azoft.poker.adminmodule.exception.AdminModuleException;
import com.azoft.poker.adminmodule.gadget.QuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.chart.properties.ChartProperties;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.*;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

/**
 * Chart
 */
public class Chart {

    /**
     * The Constant Y_DATA_FORMAT.
     */
    public static final String Y_DATA_FORMAT = "###,###,###,##0.#;(#)";

    /**
     * Свойства графика
     */
    private ChartProperties properties;

    /**
     * xyDataset данные.
     */
    private XYSeriesCollection xyDataset = new XYSeriesCollection();

    /**
     * Creates a new instance of Chart.
     *
     * @param properties the properties
     */

    public Chart(ChartProperties properties) {
        setProperties(properties);
    }

    /**
     * Gets the properties.
     *
     * @return the properties
     */
    public ChartProperties getProperties() {
        return properties;
    }

    /**
     * Sets the properties.
     *
     * @param properties the properties
     */
    public void setProperties(ChartProperties properties) {
        this.properties = properties;
    }

    /**
     * Формирование графика.
     *
     * @return the jfree chart
     */
    public JFreeChart formChart() {

        //формат подписей для оси X
        SimpleDateFormat sdf = new SimpleDateFormat(properties.getDateMask(), Locale.US);
        DecimalFormat df = new DecimalFormat(Y_DATA_FORMAT);

        StandardXYToolTipGenerator ttg = new StandardXYToolTipGenerator(StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT,
                sdf, NumberFormat.getInstance());

        //создаем график
        DateAxis timeAxis = new DateAxis("");
        timeAxis.setTickLabelsVisible(true);
        //минимальное и максимальное значение по оси X графика
        if (properties.getxMin() != null && properties.getxMax() != null) {
            timeAxis.setRange(properties.getxMin(), properties.getxMax());
        }
        //масштаб изображения по оси X графика
        if (properties.getxScaleType() != null && properties.getxScale() != null) {
            timeAxis.setTickUnit(new DateTickUnit(properties.getxScaleType(), properties.getxScale()));
        }
        //шрифт, используемый для вывода значений по оси X графика
        timeAxis.setTickLabelFont(properties.getAxisFont());
        timeAxis.setTickLabelPaint(properties.getAxisColor());
        //установка формата подписей для оси X
        timeAxis.setDateFormatOverride(sdf);

        NumberAxis valueAxis = new NumberAxis("");
        valueAxis.setTickLabelsVisible(true);
        //минимальное и максимальное значение по оси Y графика
        if (properties.getyMin() != null && properties.getyMax() != null) {
            valueAxis.setRange(properties.getyMin(), properties.getyMax());
        }
        Double сalculationYScale = properties.сalculationYScale();
        if (сalculationYScale != null) {
            //масштаб изображения по оси Y графика
            valueAxis.setTickUnit(new NumberTickUnit(сalculationYScale));
        }
        //шрифт, используемый для вывода значений по оси Y графика
        valueAxis.setTickLabelFont(properties.getAxisFont());
        valueAxis.setTickLabelPaint(properties.getAxisColor());
        //установка формата подписей для оси Y
        valueAxis.setNumberFormatOverride(df);
        //не включать в график линию 0
        valueAxis.setAutoRangeIncludesZero(false);

        StandardXYItemRenderer renderer = new StandardXYItemRenderer(StandardXYItemRenderer.LINES, ttg);

        //установить цвета серий графика
        for (int i = 0; i < properties.getNSeries(); i++) {
            renderer.setSeriesPaint(i, properties.getSeriesColors()[i], false);
        }

        XYPlot plot = new XYPlot(getXyDataset(), timeAxis, valueAxis, renderer);
        plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_RIGHT);
        plot.setDomainAxisLocation(AxisLocation.BOTTOM_OR_RIGHT);

        //толщина (тип) линии сетки графика
        Stroke stroke = new BasicStroke(properties.getLineWidth(), BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0.0f,
                new float[]{2.0f, 0.0f}, 0.0f);

        //горизонтальная линия сетки
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlineStroke(stroke); //тип
        plot.setRangeGridlinePaint(properties.getLineColor()); //цвет

        //вертикальная линия сетки
        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlineStroke(stroke); //тип
        plot.setDomainGridlinePaint(properties.getLineColor()); //цвет

        //DEBUG
        /*
         plot.setRangeCrosshairVisible(true);
         plot.setRangeCrosshairPaint(properties.getLineColor());
         plot.setRangeCrosshairValue(10);
         plot.setRangeCrosshairStroke(stroke);
         
         plot.setDomainCrosshairVisible(true);
         plot.setDomainCrosshairPaint(properties.getLineColor());
         plot.setDomainCrosshairValue(10);
         plot.setDomainCrosshairStroke(stroke);
         
         plot.setRangeZeroBaselineVisible(true);
         plot.setRangeZeroBaselinePaint(properties.getLineColor());
         
         plot.setDomainZeroBaselineVisible(true);
         plot.setDomainZeroBaselinePaint(properties.getLineColor());
         */

        JFreeChart chart = new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, plot, true);
        chart.setBackgroundPaint(properties.getBackColor());
        chart.setTitle(properties.getTextTitle());
        return chart;
    }

    /**
     * Генерация image графика.
     *
     * @return image графика
     * @throws AdminModuleException admin module exception
     */
    public BufferedImage generateChartImage() throws AdminModuleException {
        BufferedImage image = null;
        try {
            JFreeChart chart = formChart();
            image = chart.createBufferedImage(properties.getWidth(), properties.getHeight());
        } catch (Exception e) {
            throw new AdminModuleException(e);
        }
        return image;
    }

    /**
     * Генерация файла графика.
     *
     * @throws AdminModuleException admin module exception
     */
    public void generateChartFile() throws AdminModuleException {
        BufferedImage image = generateChartImage();
        writeChartFile(image);
    }

    /**
     * Запишем график в файл.
     *
     * @param image the image
     * @throws AdminModuleException admin module exception
     */
    private void writeChartFile(BufferedImage image) throws AdminModuleException {
        try {
            File file = new File(properties.getFileName());
            FileOutputStream fos = new FileOutputStream(file);
            ChartUtilities.writeBufferedImageAsPNG(fos, image);
            fos.flush();
        } catch (IOException e) {
            throw new AdminModuleException(e);
        }
    }

    /**
     * Формирование данных.
     *
     * @param quantityInfoList quantity info list
     */
    public void formDataset(List<QuantityInfoBean> quantityInfoList) {
        XYSeriesCollection dataset = new XYSeriesCollection();
        XYSeries newRegistrationsSeries = new XYSeries(ChartProperties.HIT_NEW_REGISTRATIONS);
        XYSeries activePlayersSeries = new XYSeries(ChartProperties.HIT_ACTIVE_PLAYERS);
        XYSeries paymentPlayersSeries = new XYSeries(ChartProperties.HIT_PAYMENT_PLAYERS);
        XYSeries onlinePlayersSeries = new XYSeries(ChartProperties.HIT_ONLINE_PLAYERS);
        for (QuantityInfoBean quantityInfoBean : quantityInfoList) {
            properties.analysisRecord(quantityInfoBean);
            newRegistrationsSeries.add(quantityInfoBean.getToDate().getTime(), quantityInfoBean.getQuantityOfNewRegistrations(), true);
            activePlayersSeries.add(quantityInfoBean.getToDate().getTime(), quantityInfoBean.getQuantityOfActivePlayers(), true);
            paymentPlayersSeries.add(quantityInfoBean.getToDate().getTime(), quantityInfoBean.getQuantityOfPaymentPlayers(), true);
            onlinePlayersSeries.add(quantityInfoBean.getToDate().getTime(), quantityInfoBean.getQuantityOfOnlinePlayers(), true);
        }
        dataset.addSeries(newRegistrationsSeries);
        dataset.addSeries(activePlayersSeries);
        dataset.addSeries(paymentPlayersSeries);
        dataset.addSeries(onlinePlayersSeries);
        this.xyDataset = dataset;
    }

    /**
     * Gets the xy dataset.
     *
     * @return the xy dataset
     */
    public XYSeriesCollection getXyDataset() {
        return xyDataset;
    }

}