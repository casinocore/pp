package com.azoft.poker.adminmodule.service;

import com.azoft.poker.common.service.LifecycleService;
import com.azoft.poker.common.service.LifecycleServiceImpl;
import com.azoft.poker.common.service.ServerServiceImpl;

import java.util.Map;

/**
 * Admin module lifecycle service
 */
public class AdminModuleLifecycleServiceImpl implements LifecycleService {

    private static LifecycleService instance = null;

    public static synchronized LifecycleService getInstance() {
        if (instance == null) {
            instance = new AdminModuleLifecycleServiceImpl();
        }
        return instance;
    }

    private AdminModuleLifecycleServiceImpl() {
        super();
    }

    public void initialization(Map<String, Object> parameters) {
        //Services
        //TODO OFF adminGadgetService
        //LifecycleService adminGadgetService = AdminGadgetServiceImpl.getInstance();
        //adminGadgetService.initialization(null);
        ServerServiceImpl.getInstance();

        //Register lifecycle services
        //TODO OFF adminGadgetService
        //LifecycleServiceImpl.getInstance().registerLifecycleService(adminGadgetService);
    }

    public void shutdown() {
        LifecycleServiceImpl.getInstance().shutdown();
    }

}
