package com.azoft.poker.adminmodule.gadget.chart.properties;

import com.azoft.poker.adminmodule.gadget.QuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.chart.ImageType;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.title.TextTitle;

import java.awt.*;
import java.util.Date;

/**
 * Chart properties (Day chart properties)
 */
public class ChartProperties {

    /**
     * The Constant DEFAULT_FILE_NAME.
     */
    static final String DEFAULT_FILE_NAME = "ImageChart.jpg";

    /**
     * The constants hits
     */
    public static final String HIT_NEW_REGISTRATIONS = "Новых регистраций";
    public static final String HIT_ACTIVE_PLAYERS = "Активных";
    public static final String HIT_PAYMENT_PLAYERS = "Платящих";
    public static final String HIT_ONLINE_PLAYERS = "Онлайн";

    /**
     * The Constant DEFAULT_TITLE_FONT.
     */
    private static final Font DEFAULT_TITLE_FONT = new java.awt.Font("Courier New", java.awt.Font.PLAIN, 12);

    /**
     * The Constant DEFAULT_AXIS_COLOR.
     */
    static final Color DEFAULT_AXIS_COLOR = Color.black; //new Color(137, 138, 142);
    /**
     * The Constant DEFAULT_HTML_WIDTH.
     */
    private static final int DEFAULT_WIDTH = 500;

    /**
     * The Constant DEFAULT_HTML_HEIGHT.
     */
    private static final int DEFAULT_HEIGHT = 275;

    /**
     * The Constant DEFAULT_XSCALE_TYPE.
     */
    private static final int DEFAULT_XSCALE_TYPE = DateTickUnit.HOUR;

    /**
     * The Constant DEFAULT_XSCALE.
     */
    private static final Integer DEFAULT_XSCALE = 1;

    /**
     * The Constant DEFAULT_YSCALE.
     */
    private static final Double DEFAULT_YSCALE = 1d;

    /**
     * The Constant DEFAULT_BACK_COLOR.
     */
    private static final Color DEFAULT_BACK_COLOR = Color.LIGHT_GRAY;// new Color(245, 245, 245);

    /**
     * The Constant DEFAULT_LINE_COLOR.
     */
    private static final Color DEFAULT_LINE_COLOR = new Color(216, 216, 216);

    /**
     * The Constant DEFAULT_LINE_WIDTH.
     */
    private static final Float DEFAULT_LINE_WIDTH = 1f;

    /**
     * The Constant DEFAULT_AXIS_FONT.
     */
    private static final Font DEFAULT_AXIS_FONT = new java.awt.Font("Courier New", java.awt.Font.BOLD, 10);

    /**
     * The Constant DEFAULT_SERIES_COLORS.
     */
    private static final Color[] DEFAULT_SERIES_COLORS = {Color.green, Color.red, Color.blue, Color.magenta};

    /**
     * The Constant DEFAULT_NSERIES.
     */
    private static final int DEFAULT_NSERIES = DEFAULT_SERIES_COLORS.length;

    /**
     * The Constant DEFAULT_DATE_MASK.
     */
    private static final String DEFAULT_DATE_MASK = "HH";

    private ImageType imageType;

    private TextTitle textTitle;

    /**
     * Имя файла графика.
     */
    private String fileName;

    private int width;

    private int height;

    private Font axisFont;

    private Integer xScaleType;

    private Integer xScale;

    private Double yScale;

    private String dateMask;

    /**
     * Значение минимум x данных.
     */
    private Date xMin;

    /**
     * Значение максимум x данных.
     */
    private Date xMax;

    /**
     * Значение минимум y данных.
     */
    private Double yMin;

    /**
     * Значение максимум y данных.
     */
    private Double yMax;

    /**
     * Creates a new instance of ChartProperties.
     */
    public ChartProperties(ImageType imageType) {
        this.imageType = imageType;
        fileName = DEFAULT_FILE_NAME;
        width = DEFAULT_WIDTH;
        height = DEFAULT_HEIGHT;
        axisFont = DEFAULT_AXIS_FONT;
        xScaleType = DEFAULT_XSCALE_TYPE;
        xScale = DEFAULT_XSCALE;
        yScale = DEFAULT_YSCALE;
        dateMask = DEFAULT_DATE_MASK;
        createTextTitle();
    }

    public ImageType getChartType() {
        return imageType;
    }

    public TextTitle getTextTitle() {
        return textTitle;
    }

    private TextTitle createTextTitle() {
        textTitle = new TextTitle(imageType.getTitle());
        textTitle.setFont(DEFAULT_TITLE_FONT);
        return textTitle;
    }

    public void setChartType(ImageType imageType) {
        this.imageType = imageType;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * Получить тип масштаба изображения по осям X графика.
     *
     * @return тип масштаба изображения по осям X графика
     */
    public Integer getxScaleType() {
        return xScaleType;
    }

    public void setxScaleType(Integer xScaleType) {
        this.xScaleType = xScaleType;
    }

    /**
     * Получить масштаб изображения по осям X графика.
     *
     * @return масштаб изображения по осям X графика
     */
    public Integer getxScale() {
        return xScale;
    }

    public void setxScale(Integer xScale) {
        this.xScale = xScale;
    }

    /**
     * Получить масштаб изображения по осям Y графика.
     *
     * @return масштаб изображения по осям Y графика
     */
    public Double getyScale() {
        return yScale;
    }

    public void setyScale(Double yScale) {
        this.yScale = yScale;
    }

    /**
     * Вычислить масштаб изображения по осям Y графика.
     *
     * @return вычисленный масштаб изображения по осям Y графика
     */
    public Double сalculationYScale() {
        Double result = DEFAULT_YSCALE;
        long diff = (long) (yMax - yMin);
        if (diff > 20) {
            if (diff > 100) {
                diff /= 100;
                result = 10d * diff;
            } else {
                diff /= 10;
                result = (double) diff;
            }
        }
        return result;
    }

    /**
     * Получить цвет фона графика.
     *
     * @return цвет фона графика
     */
    public Color getBackColor() {
        return DEFAULT_BACK_COLOR;
    }

    /**
     * Получить цвет линии сетки графика.
     *
     * @return цвет линии сетки графика
     */
    public Color getLineColor() {
        return DEFAULT_LINE_COLOR;
    }

    /**
     * Получить толщину линии сетки графика.
     *
     * @return толщину линии сетки графика
     */
    public Float getLineWidth() {
        return DEFAULT_LINE_WIDTH;
    }

    /**
     * Получить шрифт, используемый для вывода значений по осям X и Y графика.
     *
     * @return шрифт, используемый для вывода значений по осям X и Y графика
     */
    public Font getAxisFont() {
        return axisFont;
    }

    public void setAxisFont(Font axisFont) {
        this.axisFont = axisFont;
    }

    /**
     * Получить цвета серий графика.
     *
     * @return цвета серий графика
     */
    public Color[] getSeriesColors() {
        return DEFAULT_SERIES_COLORS;
    }

    /**
     * Получить количество серий в графике.
     *
     * @return количество серий в графике
     */
    public int getNSeries() {
        return DEFAULT_NSERIES;
    }

    /**
     * Получить формат даты графика.
     *
     * @return формат даты графика
     */
    public String getDateMask() {
        return dateMask;
    }

    public void setDateMask(String dateMask) {
        this.dateMask = dateMask;
    }

    /**
     * Получить имя файла.
     *
     * @return имя файла
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Date getxMin() {
        return xMin;
    }

    public void setxMin(Date xMin) {
        this.xMin = xMin;
    }

    public Date getxMax() {
        return xMax;
    }

    public void setxMax(Date xMax) {
        this.xMax = xMax;
    }

    public Double getyMin() {
        return yMin;
    }

    public void setyMin(Double yMin) {
        this.yMin = yMin;
    }

    public Double getyMax() {
        return yMax;
    }

    public void setyMax(Double yMax) {
        this.yMax = yMax;
    }

    /**
     * Gets the value range for y.
     *
     * @return the value range for y
     */
    public Double getValueRangeForY() {
        return yMax - yMin;
    }

    /**
     * Gets the date range for x.
     *
     * @return the date range for x
     */
    public Date getDateRangeForX() {
        return new Date(xMax.getTime() - xMin.getTime());
    }

    /**
     * Получить диапазон значений по оси X графика.
     *
     * @return диапазон значений по оси X графика
     */
    public Date getXRange() {
        Date ret = new Date(0);
        if (getxMin() != null && getxMax() != null) {
            ret = new Date(getxMax().getTime() - getxMin().getTime());
        }
        return ret;
    }

    /**
     * Получить диапазон значений по оси Y графика.
     *
     * @return диапазон значений по оси Y графика
     */
    public Double getYRange() {
        Double ret = 0d;
        if (getyMin() != null && getyMax() != null) {
            ret = getyMax() - getyMin();
        }
        return ret;
    }

    /**
     * Получить цвет шрифта подписей графика.
     *
     * @return цвет шрифта подписей графика
     */
    public Color getAxisColor() {
        return DEFAULT_AXIS_COLOR;
    }

    /**
     * Анализировать запись данных.
     *
     * @param record запись данных
     */
    public void analysisRecord(QuantityInfoBean record) {
        //анализ минимума x
        if (getxMin() == null || record.getToDate().getTime() < getxMin().getTime()) {
            setxMin(record.getToDate());
        }
        //анализ максимума x
        if (getxMax() == null || record.getToDate().getTime() > getxMax().getTime()) {
            setxMax(record.getToDate());
        }

        //анализ минимума y
        if (getyMin() == null || record.getQuantityOfNewRegistrations() < getyMin().intValue()) {
            setyMin((double) record.getQuantityOfNewRegistrations());
        }
        if (record.getQuantityOfActivePlayers() < getyMin().intValue()) {
            setyMin((double) record.getQuantityOfActivePlayers());
        }
        if (record.getQuantityOfPaymentPlayers() < getyMin().intValue()) {
            setyMin((double) record.getQuantityOfPaymentPlayers());
        }
        if (record.getQuantityOfOnlinePlayers() < getyMin().intValue()) {
            setyMin((double) record.getQuantityOfOnlinePlayers());
        }

        //анализ максимума y
        if (getyMax() == null || record.getQuantityOfNewRegistrations() > getyMax().intValue()) {
            setyMax((double) record.getQuantityOfNewRegistrations());
        }
        if (record.getQuantityOfActivePlayers() > getyMax().intValue()) {
            setyMax((double) record.getQuantityOfActivePlayers());
        }
        if (record.getQuantityOfPaymentPlayers() > getyMax().intValue()) {
            setyMax((double) record.getQuantityOfPaymentPlayers());
        }
        if (record.getQuantityOfOnlinePlayers() > getyMax().intValue()) {
            setyMax((double) record.getQuantityOfOnlinePlayers());
        }
    }

}
