package com.azoft.poker.adminmodule.service;

import com.azoft.poker.adminmodule.exception.AdminModuleException;
import com.azoft.poker.adminmodule.gadget.AdminGadgetBean;
import com.azoft.poker.adminmodule.gadget.BasicQuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.QuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.chart.Chart;
import com.azoft.poker.adminmodule.gadget.chart.ChartFactoryImpl;
import com.azoft.poker.adminmodule.gadget.chart.ImageType;
import com.azoft.poker.adminmodule.gadget.chart.properties.ChartProperties;
import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.persistence.event.EventEntity;
import com.azoft.poker.common.persistence.event.EventEntityManager;
import com.azoft.poker.common.persistence.event.EventEntityManagerImpl;
import com.azoft.poker.common.persistence.event.EventTypeID;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.quantityinfoentity.QuantityInfoEntity;
import com.azoft.poker.common.persistence.quantityinfoentity.QuantityInfoEntityManager;
import com.azoft.poker.common.persistence.quantityinfoentity.QuantityInfoEntityManagerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Admin gadget service
 */
public class AdminGadgetServiceImpl implements AdminGadgetService {

    private final static Logger LOGGER = LoggerFactory.getLogger(AdminGadgetServiceImpl.class);

    /**
     * Service type
     */
    private static final String SERVICE_TYPE = "ADMIN_GADGET";

    /**
     * Admin gadget termination timeout (MINUTES)
     */
    private final static long ADMIN_GADGET_TERMINATION_TIMEOUT = 1;

    /**
     * Scheduler initial delay
     */
    public final static long SCHEDULER_INITIAL_DELAY = 0;

    /**
     * Scheduler period (MINUTES)
     */
    public final static long SCHEDULER_PERIOD = 1;

    /**
     * Person manager
     */
    private final static PersonManager personManager = PersonManagerImpl.getInstance();

    /**
     * Event manager
     */
    private final static EventEntityManager eventManager = EventEntityManagerImpl.getInstance();

    /**
     * Quantity info entity manager
     */
    private final static QuantityInfoEntityManager quantityManager = QuantityInfoEntityManagerImpl.getInstance();

    /**
     * Service type
     */
    private String type = SERVICE_TYPE;

    /**
     * Admin gadget bean
     */
    private AdminGadgetBean adminGadgetBean = new AdminGadgetBean();

    /**
     * Error flag
     */
    private boolean existsError = false;

    /**
     * Current time
     */
    private Date currentTime;

    /**
     * Scheduled executor service
     */
    private ScheduledExecutorService executor;

    private static AdminGadgetService instance = null;

    public static synchronized AdminGadgetService getInstance() {
        if (instance == null) {
            instance = new AdminGadgetServiceImpl();
        }
        return instance;
    }

    private AdminGadgetServiceImpl() {
        super();
        executor = Executors.newSingleThreadScheduledExecutor();
    }

    private void schedule() {
        executor.scheduleAtFixedRate(new SchedulerRunnable(), SCHEDULER_INITIAL_DELAY, SCHEDULER_PERIOD, TimeUnit.MINUTES);
    }

    public AdminGadgetBean getAdminGadgetBean() {
        return adminGadgetBean;
    }

    public boolean isExistsError() {
        return existsError;
    }

    public void initialization(Map<String, Object> parameters) {
        initializationInfo();
        schedule();
    }

    public void shutdown() {
        boolean terminated = false;
        try {
            executor.shutdown();
            terminated = executor.awaitTermination(ADMIN_GADGET_TERMINATION_TIMEOUT, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            LOGGER.error(type + ": shutdown", e);
        }
        LOGGER.info(type + ": shutdown: " + terminated);
    }

    public synchronized void initializationInfo() {
        currentTime = new Date();
        //basic quantity info
        initializationBasicQuantityInfo();
        //quantity info list for month (initialization today and yesterday)
        initializationQuantityInfoListForMonth();
        //quantity info list for week
        initializationQuantityInfoListForWeek();
        //quantity info list for day
        initializationQuantityInfoListForDay();
        //quantity info - record
        initializationQuantityInfoRecord();
        //create images charts
        createCharts();
        adminGadgetBean.resetTimestamp();
    }

    public synchronized void prepareInfo() {
        currentTime = new Date();
        //basic quantity info
        prepareBasicQuantityInfo();
        //quantity info list for month
        prepareQuantityInfoListForMonth();
        //quantity info list for week
        prepareQuantityInfoListForWeek();
        //quantity info list for day
        prepareQuantityInfoListForDay();
        //quantity info - today
        prepareQuantityInfoToday();
        //quantity info - yesterday
        prepareQuantityInfoYesterday();
        //quantity info - record
        prepareQuantityInfoRecord();
    }

    private void initializationBasicQuantityInfo() {
        adminGadgetBean.setBasicQuantityInfo(new BasicQuantityInfoBean());
        adminGadgetBean.getBasicQuantityInfo().setLifeTime(AdminGadgetBean.BASIC_QUANTITY_INFO_LIFE_TIME);
        prepareBasicQuantityInfo();
    }

    private void prepareBasicQuantityInfo() {
        BasicQuantityInfoBean basicQuantityInfo = adminGadgetBean.getBasicQuantityInfo();
        if (!basicQuantityInfo.isActual()) {
            Date fromDate = DateHelper.prepareFromDateTimeForDay(currentTime);
            Date toDate = DateHelper.prepareToDateTimeForDay(currentTime);
            Integer quantityOfRegistrations = personManager.getCountPersons();
            basicQuantityInfo.setQuantityOfRegistrations(quantityOfRegistrations);
            Integer quantityOfRegistrationsDay = personManager.getCountNewPersonsForPeriod(fromDate, toDate);
            basicQuantityInfo.setQuantityOfRegistrationsDay(quantityOfRegistrationsDay);
            Integer quantityOfPlayers = personManager.getCountActivePlayers();
            basicQuantityInfo.setQuantityOfPlayers(quantityOfPlayers);
            basicQuantityInfo.resetTimestamp();
        }
    }

    private void initializationQuantityInfoListForMonth() {
        adminGadgetBean.getQuantityInfoListForMonth().clear();
        Date date;
        QuantityInfoBean quantityInfoYesterday = null;
        for (int i = 0; i < AdminGadgetBean.DAY_NUMBER_IN_MONTH + 1; i++) {
            QuantityInfoBean quantityInfo = new QuantityInfoBean();
            date = new Date(currentTime.getTime() - DateHelper.DAY_MSEC * i);
            Date fromDate = DateHelper.prepareFromDateTimeForDay(date);
            Date toDate = DateHelper.prepareToDateTimeForDay(date);
            prepareQuantityInfo(quantityInfo, fromDate, toDate);
            adminGadgetBean.getQuantityInfoListForMonth().add(quantityInfo);
            if (i == 1) {
                quantityInfoYesterday = new QuantityInfoBean();
                prepareQuantityInfo(quantityInfoYesterday, fromDate, toDate);
            }
        }

        //quantity info - today
        adminGadgetBean.setQuantityInfoToday(adminGadgetBean.getQuantityInfoListForMonth().get(0));
        adminGadgetBean.getQuantityInfoToday().setLifeTime(AdminGadgetBean.QUANTITY_INFO_TODAY_LIFE_TIME);
        //quantity info - yesterday
        adminGadgetBean.setQuantityInfoYesterday(quantityInfoYesterday);
        adminGadgetBean.getQuantityInfoYesterday().setLifeTime(AdminGadgetBean.QUANTITY_INFO_YESTERDAY_LIFE_TIME);
    }

    private void prepareQuantityInfoListForMonth() {
        if (!adminGadgetBean.isActual()) {
            initializationQuantityInfoListForMonth();
        }
    }

    private void initializationQuantityInfoListForWeek() {
        adminGadgetBean.getQuantityInfoListForWeek().clear();
        for (int i = 0; i < AdminGadgetBean.DAY_NUMBER_IN_WEEK + 1; i++) {
            QuantityInfoBean quantityInfo = adminGadgetBean.getQuantityInfoListForMonth().get(i);
            adminGadgetBean.addQuantityInfoListForWeek(quantityInfo);
        }
    }

    private void prepareQuantityInfoListForWeek() {
        if (!adminGadgetBean.isActual()) {
            initializationQuantityInfoListForWeek();
        }
    }

    private void initializationQuantityInfoListForDay() {
        adminGadgetBean.getQuantityInfoListForDay().clear();
        Date date;
        for (int i = 0; i < AdminGadgetBean.HOUR_NUMBER_IN_DAY + 1; i++) {
            QuantityInfoBean quantityInfo = new QuantityInfoBean();
            date = new Date(currentTime.getTime() - DateHelper.HOUR_MSEC * i);
            Date fromDate = DateHelper.prepareFromDateTimeForHour(date);
            Date toDate = DateHelper.prepareToDateTimeForHour(date);
            prepareQuantityInfo(quantityInfo, fromDate, toDate);
            adminGadgetBean.getQuantityInfoListForDay().add(quantityInfo);
        }
    }

    private void prepareQuantityInfoListForDay() {
        if (!adminGadgetBean.isActual()) {
            initializationQuantityInfoListForDay();
            createCharts();
            adminGadgetBean.resetTimestamp();
        }
    }

    private void prepareQuantityInfoToday() {
        QuantityInfoBean quantityInfoToday = adminGadgetBean.getQuantityInfoToday();
        if (!quantityInfoToday.isActual()) {
            Date fromDate = DateHelper.prepareFromDateTimeForDay(currentTime);
            Date toDate = DateHelper.prepareToDateTimeForDay(currentTime);
            prepareQuantityInfo(quantityInfoToday, fromDate, toDate);
        }
    }

    private void prepareQuantityInfoYesterday() {
        QuantityInfoBean quantityInfoYesterday = adminGadgetBean.getQuantityInfoYesterday();
        if (!quantityInfoYesterday.isActual()) {
            Date fromDate = new Date(currentTime.getTime() - DateHelper.DAY_MSEC - 15 * DateHelper.MIN_MSEC / 2);
            Date toDate = new Date(currentTime.getTime() - DateHelper.DAY_MSEC + 15 * DateHelper.MIN_MSEC / 2);
            prepareQuantityOfOnline(quantityInfoYesterday, fromDate, toDate);
        }
    }

    private void prepareQuantityInfo(QuantityInfoBean quantityInfo, Date fromDate, Date toDate) {
        if (!quantityInfo.isActual()) {
            quantityInfo.setFromDate(fromDate);
            quantityInfo.setToDate(toDate);
            Integer quantityOfNewRegistrations = personManager.getCountNewPersonsForPeriod(fromDate, toDate);
            quantityInfo.setQuantityOfNewRegistrations(quantityOfNewRegistrations);
            Integer quantityOfActivePlayers = personManager.getCountActivePlayersForPeriod(fromDate, toDate);
            quantityInfo.setQuantityOfActivePlayers(quantityOfActivePlayers);
            Integer quantityOfPaymentPlayers = personManager.getCountPaymentPlayersForPeriod(fromDate, toDate);
            quantityInfo.setQuantityOfPaymentPlayers(quantityOfPaymentPlayers);
            prepareQuantityOfOnline(quantityInfo, fromDate, toDate);
            quantityInfo.resetTimestamp();
        }
    }

    private void prepareQuantityOfOnline(QuantityInfoBean quantityInfo, Date fromDate, Date toDate) {
        List<EventEntity> eventList = eventManager.getEventEntitiesByReferenceMaxForPeriod(EventTypeID.ONLINE_PERSON, fromDate, toDate);
        if (!eventList.isEmpty()) {
            EventEntity event = eventList.get(eventList.size() - 1);
            quantityInfo.setOnlinePeakTime(event.getTimeStamp());
            quantityInfo.setQuantityOfOnlinePlayers(event.getReferenceId().intValue());
        } else {
            quantityInfo.setQuantityOfOnlinePlayers(0);
        }
    }

    private void initializationQuantityInfoRecord() {
        adminGadgetBean.setQuantityInfoPriorRecord(new QuantityInfoBean());
        adminGadgetBean.setQuantityInfoRecord(new QuantityInfoBean());
        for (QuantityInfoBean quantityInfo : adminGadgetBean.getQuantityInfoListForMonth()) {
            prepareQuantityInfoRecord(quantityInfo);
        }
        updateRecordEntities();
        fromRecordEntities();
    }

    private void fromRecordEntities() {
        //from prior record entity
        QuantityInfoEntity priorRecordEntity = quantityManager.getQuantityInfoEntity(QuantityInfoEntityManager.QUANTITY_INFO_ENTITY_ID_PRIOR_RECORD);
        QuantityInfoBean priorRecord = adminGadgetBean.getQuantityInfoPriorRecord();
        priorRecord.setQuantityOfNewRegistrations(priorRecordEntity.getQuantityOfNewRegistrations());
        priorRecord.setQuantityOfActivePlayers(priorRecordEntity.getQuantityOfActivePlayers());
        priorRecord.setQuantityOfPaymentPlayers(priorRecordEntity.getQuantityOfPaymentPlayers());
        priorRecord.setQuantityOfOnlinePlayers(priorRecordEntity.getQuantityOfOnlinePlayers());

        //from record entity
        QuantityInfoEntity recordEntity = quantityManager.getQuantityInfoEntity(QuantityInfoEntityManager.QUANTITY_INFO_ENTITY_ID_RECORD);
        QuantityInfoBean record = adminGadgetBean.getQuantityInfoRecord();
        if (recordEntity.getQuantityOfNewRegistrations() > record.getQuantityOfNewRegistrations()) {
            record.setQuantityOfNewRegistrations(recordEntity.getQuantityOfNewRegistrations());
        }
        if (recordEntity.getQuantityOfActivePlayers() > record.getQuantityOfActivePlayers()) {
            record.setQuantityOfActivePlayers(recordEntity.getQuantityOfActivePlayers());
        }
        if (recordEntity.getQuantityOfPaymentPlayers() > record.getQuantityOfPaymentPlayers()) {
            record.setQuantityOfPaymentPlayers(recordEntity.getQuantityOfPaymentPlayers());
        }
        if (recordEntity.getQuantityOfOnlinePlayers() > record.getQuantityOfOnlinePlayers()) {
            record.setQuantityOfOnlinePlayers(recordEntity.getQuantityOfOnlinePlayers());
        }
    }

    private void prepareQuantityInfoRecord() {
        prepareQuantityInfoRecord(adminGadgetBean.getQuantityInfoToday());
    }

    private void prepareQuantityInfoRecord(QuantityInfoBean quantityInfo) {
        QuantityInfoBean priorRecord = adminGadgetBean.getQuantityInfoPriorRecord();
        QuantityInfoBean record = adminGadgetBean.getQuantityInfoRecord();
        boolean isChange = false;
        if (quantityInfo.getQuantityOfNewRegistrations() != null
                && (record.getQuantityOfNewRegistrations() == null
                || record.getQuantityOfNewRegistrations() < quantityInfo.getQuantityOfNewRegistrations())) {
            priorRecord.setQuantityOfNewRegistrations(record.getQuantityOfNewRegistrations());
            record.setQuantityOfNewRegistrations(quantityInfo.getQuantityOfNewRegistrations());
            isChange = true;
        }
        if (quantityInfo.getQuantityOfActivePlayers() != null
                && (record.getQuantityOfActivePlayers() == null
                || record.getQuantityOfActivePlayers() < quantityInfo.getQuantityOfActivePlayers())) {
            priorRecord.setQuantityOfActivePlayers(record.getQuantityOfActivePlayers());
            record.setQuantityOfActivePlayers(quantityInfo.getQuantityOfActivePlayers());
            isChange = true;
        }
        if (quantityInfo.getQuantityOfPaymentPlayers() != null
                && (record.getQuantityOfPaymentPlayers() == null
                || record.getQuantityOfPaymentPlayers() < quantityInfo.getQuantityOfPaymentPlayers())) {
            priorRecord.setQuantityOfPaymentPlayers(record.getQuantityOfPaymentPlayers());
            record.setQuantityOfPaymentPlayers(quantityInfo.getQuantityOfPaymentPlayers());
            isChange = true;
        }
        if (quantityInfo.getQuantityOfOnlinePlayers() != null
                && (record.getQuantityOfOnlinePlayers() == null
                || record.getQuantityOfOnlinePlayers() < quantityInfo.getQuantityOfOnlinePlayers())) {
            priorRecord.setQuantityOfOnlinePlayers(record.getQuantityOfOnlinePlayers());
            record.setQuantityOfOnlinePlayers(quantityInfo.getQuantityOfOnlinePlayers());
            record.setOnlinePeakTime(quantityInfo.getOnlinePeakTime());
            isChange = true;
        }
        if (isChange) {
            updateRecordEntities();
        }
    }

    private void updateRecordEntities() {
        QuantityInfoEntity priorRecordEntity = quantityManager.getQuantityInfoEntity(QuantityInfoEntityManager.QUANTITY_INFO_ENTITY_ID_PRIOR_RECORD);
        QuantityInfoEntity recordEntity = quantityManager.getQuantityInfoEntity(QuantityInfoEntityManager.QUANTITY_INFO_ENTITY_ID_RECORD);
        QuantityInfoBean record = adminGadgetBean.getQuantityInfoRecord();
        boolean isChange = false;
        if (record.getQuantityOfNewRegistrations() != null
                && (recordEntity.getQuantityOfNewRegistrations() == null
                || recordEntity.getQuantityOfNewRegistrations() < record.getQuantityOfNewRegistrations())) {
            priorRecordEntity.setQuantityOfNewRegistrations(recordEntity.getQuantityOfNewRegistrations());
            recordEntity.setQuantityOfNewRegistrations(record.getQuantityOfNewRegistrations());
            isChange = true;
        }
        if (record.getQuantityOfActivePlayers() != null
                && (recordEntity.getQuantityOfActivePlayers() == null
                || recordEntity.getQuantityOfActivePlayers() < record.getQuantityOfActivePlayers())) {
            priorRecordEntity.setQuantityOfActivePlayers(recordEntity.getQuantityOfActivePlayers());
            recordEntity.setQuantityOfActivePlayers(record.getQuantityOfActivePlayers());
            isChange = true;
        }
        if (record.getQuantityOfPaymentPlayers() != null
                && (recordEntity.getQuantityOfPaymentPlayers() == null
                || recordEntity.getQuantityOfPaymentPlayers() < record.getQuantityOfPaymentPlayers())) {
            priorRecordEntity.setQuantityOfPaymentPlayers(recordEntity.getQuantityOfPaymentPlayers());
            recordEntity.setQuantityOfPaymentPlayers(record.getQuantityOfPaymentPlayers());
            isChange = true;
        }
        if (record.getQuantityOfOnlinePlayers() != null
                && (recordEntity.getQuantityOfOnlinePlayers() == null
                || recordEntity.getQuantityOfOnlinePlayers() < record.getQuantityOfOnlinePlayers())) {
            priorRecordEntity.setQuantityOfOnlinePlayers(recordEntity.getQuantityOfOnlinePlayers());
            recordEntity.setQuantityOfOnlinePlayers(record.getQuantityOfOnlinePlayers());
            recordEntity.setOnlinePeakTime(record.getOnlinePeakTime());
            isChange = true;
        }
        if (isChange) {
            quantityManager.update(priorRecordEntity);
            quantityManager.update(recordEntity);
        }
    }

    /**
     * Create chart files
     */
    private void createCharts() {
        try {
            createChart(ImageType.day, DAY_CHART_FILE_NAME, adminGadgetBean.getQuantityInfoListForDay());
            createChart(ImageType.week, WEEK_CHART_FILE_NAME, adminGadgetBean.getQuantityInfoListForWeek());
            createChart(ImageType.month, MONTH_CHART_FILE_NAME, adminGadgetBean.getQuantityInfoListForMonth());
        } catch (IOException e) {
            LOGGER.error("createCharts", e);
        }
    }

    private void createChart(ImageType imageType, String fileName, List<QuantityInfoBean> quantityInfoList) throws IOException {
        String pathName = Resources.getResourcesDirectory(GADGET_DIRECTORY) + fileName;
        ChartProperties chartProperties = ChartFactoryImpl.createChartProperties(imageType);
        Chart chart = new Chart(chartProperties);
        chart.getProperties().setFileName(pathName);
        chart.formDataset(quantityInfoList);
        try {
            chart.generateChartFile();
        } catch (AdminModuleException e) {
            LOGGER.error("createChart fileName: " + pathName, e);
        }
    }

    /**
     * Scheduler runnable
     */
    private class SchedulerRunnable implements Runnable {

        public SchedulerRunnable() {
            super();
        }

        public void run() {
            prepareInfo();
        }
    }

}
