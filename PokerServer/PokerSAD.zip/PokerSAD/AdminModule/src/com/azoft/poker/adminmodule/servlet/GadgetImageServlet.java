package com.azoft.poker.adminmodule.servlet;

import com.azoft.poker.adminmodule.gadget.chart.ImageType;
import com.azoft.poker.adminmodule.service.AdminGadgetService;
import com.azoft.poker.adminmodule.service.Resources;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Gadget image servlet
 */
public class GadgetImageServlet extends HttpServlet {

    private final static Logger LOGGER = LoggerFactory.getLogger(GadgetImageServlet.class);

    private static final String CONTENT_TYPE = "image/png";

    private static final String PARAMETER_IMAGE_TYPE = "imageType";

    @Override
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String imageTypeName = request.getParameter(PARAMETER_IMAGE_TYPE);
            ImageType imageType = ImageType.valueOf(imageTypeName);
            String fileName = Resources.getResourcesDirectory(AdminGadgetService.GADGET_DIRECTORY) + imageType.name() + AdminGadgetService.IMAGE_FILE_NAME_POSTFIX;
            FileInputStream fis = new FileInputStream(fileName);
            response.setContentType(CONTENT_TYPE);
            ServletOutputStream sos = response.getOutputStream();
            byte[] data = new byte[fis.available()];
            int result = fis.read(data);
            if (result == data.length) {
                sos.write(data);
            } else {
                LOGGER.warn("Error read " + fileName);
                response.setStatus(HttpServletResponse.SC_NO_CONTENT);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        }
    }

}
