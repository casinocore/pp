package com.azoft.poker.adminmodule.exception;

import com.azoft.poker.common.exception.AbstractException;

/**
 * Admin module exception
 */
public class AdminModuleException extends AbstractException {

    public AdminModuleException(String message) {
        super(message);
    }

    public AdminModuleException(String message, Throwable cause) {
        super(message, cause);
    }

    public AdminModuleException(Throwable cause) {
        super(cause);
    }

}
