package com.azoft.poker.adminmodule.gadget.chart.properties;

import com.azoft.poker.adminmodule.gadget.chart.ImageType;
import org.jfree.chart.axis.DateTickUnit;

/**
 * Week chart properties
 */
public class WeekChartProperties extends ChartProperties {

    private static final int WEEK_XSCALE_TYPE = DateTickUnit.DAY;
    private static final String WEEK_DATE_MASK = "dd/MM";

    public WeekChartProperties(ImageType imageType) {
        super(imageType);
        setxScaleType(WEEK_XSCALE_TYPE);
        setDateMask(WEEK_DATE_MASK);
    }

}
