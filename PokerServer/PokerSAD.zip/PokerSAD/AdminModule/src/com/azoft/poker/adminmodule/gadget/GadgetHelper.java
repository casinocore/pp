package com.azoft.poker.adminmodule.gadget;

/**
 * Gadget helper
 */
public class GadgetHelper {

    public static String formParametersDiff(Integer parameter1, Integer parameter2) {
        String result = "";
        if (parameter1 != null && parameter2 != null) {
            result = "(" + (parameter1 - parameter2) + ")";
        }
        return result;
    }

}
