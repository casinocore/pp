package com.azoft.poker.adminmodule.servlet;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentService;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentServiceManagerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

/**
 * Callbacks payment servlet
 */
public class CallbacksPaymentServlet extends HttpServlet {

    private final static Logger LOGGER = LoggerFactory.getLogger(CallbacksPaymentServlet.class);

    private static final String INVOCATION_ERROR = "invocation-error";

    private static final Object lock = new Object();

    public void service(HttpServletRequest request,
                        HttpServletResponse response)
            throws ServletException, IOException {
        synchronized (lock) {
            call(request, response);
        }
    }

    //SCHOOLMATE
    //http://localhost:8080/adminmodule/callbacksPayment?application_key=123&uid=social_network_id_1&transaction_time=2010-11-23%2017:55:07&transaction_id=20001&product_code=1&product_option=1&amount=1

    //MAILRU
    //http://localhost:8080/adminmodule/callbacksPayment?app_id=567&uid=social_network_id_1&transaction_id=50001&service_id=1&profit=15&other_price=2500


    private void call(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Map parameters = request.getParameterMap();
        try {
            CallbacksPaymentService service =
                    CallbacksPaymentServiceManagerImpl.getInstance().getCallbacksPaymentService(parameters);
            String result = service.methodCallbacksPayment(parameters);
            if (service.isExistsError()) {
                response.setHeader(INVOCATION_ERROR, Boolean.TRUE.toString());
            }
            response.setContentType(service.getContentType());
            PrintWriter writer = response.getWriter();
            writer.println(result);
            writer.close();
        } catch (CommonException e) {
            LOGGER.error("servlet call", e);
        }
    }

}
