package com.azoft.poker.adminmodule;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        com.azoft.poker.adminmodule.gadget.chart.AllTests.class
})
public class AllTests {
}
