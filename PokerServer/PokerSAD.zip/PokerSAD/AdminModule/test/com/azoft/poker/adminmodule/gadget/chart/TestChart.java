package com.azoft.poker.adminmodule.gadget.chart;

import com.azoft.poker.adminmodule.exception.AdminModuleException;
import com.azoft.poker.adminmodule.gadget.QuantityInfoBean;
import com.azoft.poker.adminmodule.gadget.chart.properties.ChartProperties;
import com.azoft.poker.adminmodule.service.AdminGadgetService;
import com.azoft.poker.adminmodule.service.Resources;
import com.azoft.poker.common.helper.DateHelper;
import org.apache.log4j.Logger;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertNotNull;

public class TestChart {

    /**
     * The Constant LOG.
     */
    private static final Logger LOG = Logger.getLogger(TestChart.class);

    /**
     * The chart.
     */
    private static Chart chart = null;
    private static final String IMAGE_CHART_PNG = "ImageChart.png";
    private static final String IMAGE_CHART_WITHOUT_DATA_PNG = "ImageChartWithoutData.png";

    @Before
    public void beforeTests() {
        try {
            chart = new Chart(new ChartProperties(ImageType.day));
        } catch (Exception e) {
            LOG.error("beforeTests()", e);
        }
    }

    @AfterClass
    public static void afterTests() {
//        clear();
    }

    private static void clear() {
        try {
            Resources.deleteResourcesFile(Resources.getResourcesDirectory() + AdminGadgetService.GADGET_DIRECTORY + IMAGE_CHART_WITHOUT_DATA_PNG);
            Resources.deleteResourcesFile(Resources.getResourcesDirectory() + AdminGadgetService.GADGET_DIRECTORY + IMAGE_CHART_PNG);
            Resources.deleteResourcesDirectory();
        } catch (IOException e) {
            LOG.error("clear()", e);
        }
    }

    /**
     * Импорт данных.
     */
    private void importDataset() throws AdminModuleException, ParseException {
        List<QuantityInfoBean> quantityInfoList = new ArrayList<QuantityInfoBean>();
        QuantityInfoBean quantityInfoBean = createquantityInfoBean(11, 145, 175, 212, "2010-05-20 12:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(15, 125, 235, 345, "2010-05-20 14:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(20, 135, 227, 352, "2010-05-20 16:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(18, 122, 244, 255, "2010-05-20 18:14:18");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(45, 145, 156, 198, "2010-05-20 20:07:56");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(115, 97, 177, 262, "2010-05-20 22:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(86, 126, 122, 923, "2010-05-21 00:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(105, 74, 56, 1345, "2010-05-21 02:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(245, 52, 224, 1627, "2010-05-21 04:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(183, 0, 174, 2145, "2010-05-21 06:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(58, 178, 162, 2056, "2010-05-21 08:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(134, 302, 228, 1567, "2010-05-21 10:00:00");
        quantityInfoList.add(quantityInfoBean);
        chart.formDataset(quantityInfoList);
    }

    private void importDataset2() throws AdminModuleException, ParseException {
        List<QuantityInfoBean> quantityInfoList = new ArrayList<QuantityInfoBean>();
        QuantityInfoBean quantityInfoBean = createquantityInfoBean(11, 45, 15, 12, "2010-05-20 12:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(15, 45, 33, 22, "2010-05-20 14:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(20, 35, 27, 52, "2010-05-20 16:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(18, 22, 44, 24, "2010-05-20 18:14:18");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(43, 65, 36, 18, "2010-05-20 20:07:56");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(15, 27, 17, 22, "2010-05-20 22:00:00");
        quantityInfoList.add(quantityInfoBean);
        quantityInfoBean = createquantityInfoBean(34, 2, 28, 47, "2010-05-21 10:00:00");
        quantityInfoList.add(quantityInfoBean);
        chart.formDataset(quantityInfoList);
    }

    private QuantityInfoBean createquantityInfoBean(
            int newRegistrations, int activePlayers, int paymentPlayers, int onlinePlayers, String strDatestamp) throws ParseException {
        QuantityInfoBean quantityInfoBean = new QuantityInfoBean();
        Date date = DateHelper.attributeDateTimeFormat.parse(strDatestamp);
        quantityInfoBean.setToDate(date);
        quantityInfoBean.setQuantityOfNewRegistrations(newRegistrations);
        quantityInfoBean.setQuantityOfActivePlayers(activePlayers);
        quantityInfoBean.setQuantityOfPaymentPlayers(paymentPlayers);
        quantityInfoBean.setQuantityOfOnlinePlayers(onlinePlayers);
        return quantityInfoBean;
    }

    /**
     * Test of generateChartFile method
     */
    @Test
    public void testGenerateChart() {
        LOG.info("testGenerateChart start");
        try {
            importDataset();
            chart.getProperties().setFileName(Resources.getResourcesDirectory(AdminGadgetService.GADGET_DIRECTORY) + IMAGE_CHART_PNG);
            chart.generateChartFile();
        } catch (Exception e) {
            LOG.error("testGenerateChart Exception");
        }
        assertNotNull(chart);
        LOG.info("testGenerateChart stop");
    }

    /**
     * Test of generateChartFile method
     */
    @Test
    public void testGenerateChartWithoutData() {
        LOG.info("testGenerateChartWithoutData start");
        try {
            chart.getProperties().setFileName(Resources.getResourcesDirectory(AdminGadgetService.GADGET_DIRECTORY) + IMAGE_CHART_WITHOUT_DATA_PNG);
            chart.generateChartFile();
        } catch (Exception e) {
            LOG.error("testGenerateChartWithoutData Exception");
        }
        assertNotNull(chart);
        LOG.info("testGenerateChartWithoutData stop");
    }

}
