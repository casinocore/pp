package com.azoft.poker.adminmodule.gadget.chart;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestChart.class
})
public class AllTests {
}
