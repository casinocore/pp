package com.azoft.poker.common.publisher;

/**
 * Application events publisher interface
 *
 * @param <EventType> event type
 */
public interface EventEntityPublisher<EventType> {

    /**
     * Add event subcriber
     *
     * @param subcriber subcriber
     */
    void addSubcriber(EventEntitySubcriber<EventType> subcriber);

    /**
     * Remove event subcriber
     *
     * @param subcriber subcriber
     */
    void removeSubcriber(EventEntitySubcriber<EventType> subcriber);

    /**
     * Notify subcribers
     *
     * @param event event
     */
    void notifySubcribers(EventType event);

}
