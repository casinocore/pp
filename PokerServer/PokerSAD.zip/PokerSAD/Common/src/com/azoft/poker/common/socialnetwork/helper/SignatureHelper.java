package com.azoft.poker.common.socialnetwork.helper;

import org.apache.commons.codec.digest.DigestUtils;

import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Signature helper
 */
public class SignatureHelper {

    private String secretKey;

    public SignatureHelper(String secretKey) {
        this.secretKey = secretKey;
    }

    /**
     * Generate signature
     *
     * @param parameters parameters
     * @return signature
     */
    public String generateSignature(Map<String, String> parameters) {
        SortedMap<String, String> sortedParamMap = new TreeMap<String, String>(parameters);
        String canonicalQS = formCanonicRequestLine(sortedParamMap);
        //LOGGER.debug("canonicalQS: " + canonicalQS + "********SECRET KEY*******");
        canonicalQS += secretKey;
        String md5 = DigestUtils.md5Hex(canonicalQS);
        //LOGGER.debug("MD5: " + md5);
        return md5;
    }

    private static String formCanonicRequestLine(SortedMap<String, String> sortedParamMap) {
        if (sortedParamMap.isEmpty()) {
            return "";
        }

        StringBuffer buffer = new StringBuffer();
        for (Map.Entry<String, String> entry : sortedParamMap.entrySet()) {
            buffer.append(entry.getKey());
            buffer.append("=");
            buffer.append(entry.getValue());
        }
        return buffer.toString();
    }

}
