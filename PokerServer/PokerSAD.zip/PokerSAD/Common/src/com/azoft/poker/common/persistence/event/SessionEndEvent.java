package com.azoft.poker.common.persistence.event;

/**
 * Session end event
 */
public class SessionEndEvent extends EventEntityWrapper {

    public SessionEndEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    public SessionEndEvent(Short eventType, Long referenceId) {
        super(eventType, referenceId);
    }

    public Long getSessionTime() {
        return getLongAttribute(SESSION_TIME);
    }

    public void setSessionTime(Long sessionTime) {
        setLongAttribute(SESSION_TIME, sessionTime);
    }

}