package com.azoft.poker.common.socialnetwork.bean;

import com.azoft.poker.common.jaxp.AbstractBean;

/**
 * Login bean
 */
public class LoginBean extends AbstractBean {

    private String iud;

    private String sessionKey;

    private String sessionSecretKey;

    private String authToken;

    private String apiServer;

    public LoginBean() {
    }

    public String getIud() {
        return iud;
    }

    public void setIud(String iud) {
        this.iud = iud;
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }

    public String getSessionSecretKey() {
        return sessionSecretKey;
    }

    public void setSessionSecretKey(String sessionSecretKey) {
        this.sessionSecretKey = sessionSecretKey;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getApiServer() {
        return apiServer;
    }

    public void setApiServer(String apiServer) {
        this.apiServer = apiServer;
    }

}