package com.azoft.poker.common.persistence.server;

import com.azoft.poker.common.persistence.BaseEntity;

public class Server extends BaseEntity {

    public static final String SERVER_PATH_DELIMITER = ":";

    private short serverType;

    private String serverName;

    private String serverAddress;

    private int serverPort;

    public Server() {
        super();
    }

    public short getServerType() {
        return serverType;
    }

    public void setServerType(short serverType) {
        this.serverType = serverType;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getServerAddress() {
        return serverAddress;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }

    public int getServerPort() {
        return serverPort;
    }

    public void setServerPort(int serverPort) {
        this.serverPort = serverPort;
    }

    public String getServerPath() {
        return serverAddress + SERVER_PATH_DELIMITER + String.valueOf(serverPort);
    }

    @Override
    public String toString() {
        return "Server{" +
                "serverType=" + serverType +
                ", serverName='" + serverName + '\'' +
                ", serverAddress='" + serverAddress + '\'' +
                ", serverPort=" + serverPort +
                '}';
    }
}
