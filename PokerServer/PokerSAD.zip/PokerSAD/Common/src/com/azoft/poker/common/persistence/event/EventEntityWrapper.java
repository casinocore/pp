package com.azoft.poker.common.persistence.event;

import com.azoft.poker.common.persistence.CustomAttributesWrapper;
import com.azoft.poker.common.publisher.Event;

/**
 * Abstract wrapper for event
 */
public abstract class EventEntityWrapper extends CustomAttributesWrapper<EventEntity> implements EventEntityConstants, Event {

    public EventEntityWrapper(EventEntity entity) {
        super(entity);
    }

    public EventEntityWrapper(Short eventType, Long referenceId) {
        super(new EventEntity(eventType, referenceId));
    }

}
