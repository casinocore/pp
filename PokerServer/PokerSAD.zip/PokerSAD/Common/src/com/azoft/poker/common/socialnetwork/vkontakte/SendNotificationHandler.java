package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.socialnetwork.bean.SendNotificationBean;
import org.xml.sax.SAXException;

/**
 * Send notification handler for vkontakte
 */
public class SendNotificationHandler extends BaseSocialNetworkHandler<SendNotificationBean> {

    private SendNotificationBean sendNotificationBean;

    public SendNotificationHandler() {
        super();
        sendNotificationBean = new SendNotificationBean();
        setBean(sendNotificationBean);
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        super.endElement(uri, lName, qName);

        String tag = getTag(lName, qName);
        if (tag.equals("response")) {
            sendNotificationBean.setResponse(text);
            sendNotificationBean.setIfNullProcessingResult(RESULT_SUCCESS);
        }
    }

}
