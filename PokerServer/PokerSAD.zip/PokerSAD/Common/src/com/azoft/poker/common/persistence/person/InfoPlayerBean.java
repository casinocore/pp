package com.azoft.poker.common.persistence.person;

/**
 * Info player bean
 */
public class InfoPlayerBean {

    private Long playerId;

    private Integer ranked;

    private String socialNetworkID;

    private Long balance;

    public InfoPlayerBean() {
    }

    public Long getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Long playerId) {
        this.playerId = playerId;
    }

    public Integer getRanked() {
        return ranked;
    }

    public void setRanked(Integer ranked) {
        this.ranked = ranked;
    }

    public String getSocialNetworkID() {
        return socialNetworkID;
    }

    public void setSocialNetworkID(String socialNetworkID) {
        this.socialNetworkID = socialNetworkID;
    }

    public Long getBalance() {
        return balance;
    }

    public void setBalance(Long balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "InfoPlayerBean{" +
                "playerId=" + playerId +
                ", ranked=" + ranked +
                ", socialNetworkID='" + socialNetworkID + '\'' +
                ", balance=" + balance +
                '}';
    }
    
}
