package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.jaxp.AbstractHandler;

/**
 * Social network handler factory interface
 */
public interface SocialNetworkHandlerFactory {

    /**
     * Create handler for method
     *
     * @param method method
     * @return handler
     */
    AbstractHandler createHandler(String method);

}
