package com.azoft.poker.common.communicator;

public class BaseConstants {

    public static final int LOGIN_SERVER_PORT = 9123;

    public static final String SERVER_ADDRESS = "localhost";

    public static final byte PROTOCOL_VERSION = 4;

}
