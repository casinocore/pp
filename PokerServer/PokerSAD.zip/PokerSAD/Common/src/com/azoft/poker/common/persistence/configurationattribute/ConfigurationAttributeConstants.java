package com.azoft.poker.common.persistence.configurationattribute;

import com.azoft.poker.common.helper.DateHelper;

import java.text.DateFormat;

/**
 * Configuration attribute constants
 */
public class ConfigurationAttributeConstants {

    /**
     * Date time format for configuration attributes
     */
    public static final DateFormat attributeDateTimeFormat = DateHelper.attributeDateTimeFormat;

    /**
     * BonusAttributes
     */
    public static final String DAILY_BONUS = "DAILY_BONUS";
    public static final String FRIEND_BONUS = "FRIEND_BONUS";
    public static final String NEW_FRIEND_BONUS = "NEW_FRIEND_BONUS";
    public static final String MAX_BONUS = "MAX_BONUS";

    /**
     * Product attribute
     */
    public static final String DEFAULT_PRODUCT = "DEFAULT_PRODUCT";

}
