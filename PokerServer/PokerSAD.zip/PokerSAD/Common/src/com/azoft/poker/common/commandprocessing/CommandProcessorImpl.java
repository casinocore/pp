package com.azoft.poker.common.commandprocessing;

import com.azoft.poker.common.commandprocessing.command.Command;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class CommandProcessorImpl extends ThreadPoolExecutor implements LifecycleCommandProcessor {

    private final static Logger LOGGER = LoggerFactory.getLogger(CommandProcessorImpl.class);

    public static final int CORE_POOL_SIZE = 1;

    public static final int MAXIMUM_POOL_SIZE = 1;

    public static final long KEEP_ALIVE_TIME = 0;

    /**
     * Termination timeout
     */
    private long terminationTimeout;

    private CommandProcessorType type;

    public CommandProcessorImpl(CommandProcessorType type, long terminationTimeout) {
        super(CORE_POOL_SIZE,
                MAXIMUM_POOL_SIZE,
                KEEP_ALIVE_TIME,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>());
        this.type = type;
        this.terminationTimeout = terminationTimeout;
    }

    public CommandProcessorType getType() {
        return type;
    }

    public void initialization(Map<String, Object> parameters) {
        getQueue().clear();
        boolean startedFlag = prestartCoreThread();
        LOGGER.info(type.toString() + "; startedFlag: " + startedFlag);
    }

    public void shutdown() {
        boolean terminated = false;
        try {
            super.shutdown();
            terminated = super.awaitTermination(terminationTimeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOGGER.error(type.toString() + ": shutdown", e);
        }
        LOGGER.info(type.toString() + ": shutdown: " + terminated);
    }

    public void putCommand(Command command) throws InterruptedException {
        getQueue().put(command);
        LOGGER.debug(type.toString() + "; put: " + command.toString() + "; commandsSize: " + getQueue().size());
    }

}
