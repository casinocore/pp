package com.azoft.poker.common.persistence.news;

/**
 * News bean
 */
public class NewsBean {

    /**
     * News
     */
    private News news;

    /**
     * News it is read
     */
    private byte read;

    public NewsBean(News news, byte read) {
        this.news = news;
        this.read = read;
    }

    public News getNews() {
        return news;
    }

    public byte getRead() {
        return read;
    }

}
