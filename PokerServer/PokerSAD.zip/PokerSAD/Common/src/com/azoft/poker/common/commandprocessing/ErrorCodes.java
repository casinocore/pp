package com.azoft.poker.common.commandprocessing;

public enum ErrorCodes {

    INTERNAL_ERROR(1),
    VERSION_ERROR(2),
    REGISTER_ERROR_EXISTS_USER(100),
    LOGIN_ERROR_NOT_EXISTS_USER(101),
    PERSON_BALANCE_TOO_LITTLE(103),
    CANT_FIND_APPROPRIATE_TABLE(104),
    PLACE_OCCUPED(105),
    PLAYER_ALREADY_ON_TABLE(106),
    PERSON_BALANCE_TOO_LITTLE_FOR_TOURNAMENT(107),
    TOURNAMENT_BALANCE_NOT_ZERO(108),
    FRIEND_NOT_ADDED(109),
    NOT_ENOUGH_BALANCE(110),
    PLAYER_ALREADY_REGISTERED(111),
    REGISTRATION_ON_MTT_ISNT_ACCESSIBLE(112),
    UNREGISTRATION_ON_MTT_ISNT_ACCESSIBLE(113),
    MTT_ISNT_ACCESSIBLE_TO_GAME(114),
    REBUY_ISNT_ACCESSIBLE(115),
    MTT_NOT_EXISTS(116);
    //TODO

    private int errorCode;

    ErrorCodes(int errorCode) {
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

}
