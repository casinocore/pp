package com.azoft.poker.common.persistence.server;

public enum ServerTypeID {

    ACCESS_SERVER((short) 1),
    LOGIN_SERVER((short) 2),
    LOBBY_SERVER((short) 3),
    ADMIN_SERVER((short) 4);

    private short typeId;

    ServerTypeID(short typeId) {
        this.typeId = typeId;
    }

    public short getTypeId() {
        return typeId;
    }

    public static ServerTypeID valueOf(short typeId) {
        ServerTypeID result = null;
        for (ServerTypeID serverTypeID : ServerTypeID.values()) {
            if (serverTypeID.getTypeId() == typeId) {
                result = serverTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "ServerTypeID{" +
                "name=" + name() +
                "typeId=" + typeId +
                '}';
    }
}
