package com.azoft.poker.common.socialnetwork.bean;

import java.util.Date;

/**
 * User info bean
 */
public class UserInfoBean {

    /**
     * Social network ID (uid)
     */
    private String socialNetworkID;

    /**
     * First name
     */
    private String firstName;

    /**
     * Last name
     */
    private String lastName;

    /**
     * Name
     */
    private String name;

    /**
     * Sex
     */
    private String sex;

    /**
     * Date of birth
     */
    private Date dateOfBirth;

    /**
     * Location
     */
    private String location;


    public UserInfoBean() {
    }

    public String getSocialNetworkID() {
        return socialNetworkID;
    }

    public void setSocialNetworkID(String socialNetworkID) {
        this.socialNetworkID = socialNetworkID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}
