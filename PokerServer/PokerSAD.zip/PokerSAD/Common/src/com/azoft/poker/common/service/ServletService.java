package com.azoft.poker.common.service;

/**
 * Servlet service interface
 */
public interface ServletService {

    /**
     * Get flag exists error
     *
     * @return true if exists error
     */
    boolean isExistsError();

}
