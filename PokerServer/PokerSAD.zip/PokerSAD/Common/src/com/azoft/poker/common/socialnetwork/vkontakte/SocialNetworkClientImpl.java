package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.jaxp.AbstractBean;
import com.azoft.poker.common.socialnetwork.bean.*;
import com.azoft.poker.common.socialnetwork.client.AbstractSocialNetworkClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Social network client for vkontakte
 */
public class SocialNetworkClientImpl extends AbstractSocialNetworkClient {

    private final static Logger LOGGER = LoggerFactory.getLogger(SocialNetworkClientImpl.class);

    /**
     * The period of calls property. Restriction - N calls in a second.
     */
    public static final String PARAM_CALLS_PERIOD = "CALLS_PERIOD";

    private static final int MAX_NUMBER_IDS = 1000;

    private static final int MAX_NUMBER_NOTIFICATIONS = 100;

    private static final String DOUBLE_QUOTES = "\"";

    private static final String DOUBLE_QUOTES_REPLACEMENT = "&#34;";

    private long callsPeriod = Constants.DEFAULT_CALLS_PERIOD;

    private long callTimestamp;

    public SocialNetworkClientImpl() {
        super(new SocialNetworkHandlerFactoryImpl());
    }

    public void initialization(Map<String, Object> parameters) throws CommonException {
        super.initialization(parameters);
        String strCallsPeriod = (String) parameters.get(PARAM_CALLS_PERIOD);
        if (strCallsPeriod != null) {
            try {
                callsPeriod = Long.valueOf(strCallsPeriod);
            } catch (NumberFormatException e) {
                callsPeriod = Constants.DEFAULT_CALLS_PERIOD;
                LOGGER.warn("Not valid " + PARAM_CALLS_PERIOD + " property. Default callsPeriod: " + callsPeriod);
            }
        } else {
            LOGGER.info("Default callsPeriod: " + callsPeriod);
        }
    }

    private Map<String, String> prepareCommonParameters() throws CommonException {
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put(Constants.QUERY_APPLICATION_ID, getApplicationKey());
        parameters.put(Constants.PARAMETER_RANDOM, String.valueOf(incCallId()));
        parameters.put(Constants.QUERY_FORMAT, Constants.QUERY_FORMAT_XML_VALUE);
        parameters.put(Constants.QUERY_VERSION, Constants.API_VERSION);
        parameters.put(Constants.PARAMETER_TIMESTAMP, String.valueOf(System.currentTimeMillis()));
        return parameters;
    }

    public int getMaxNumberForMethodGetUsersInfo() {
        return MAX_NUMBER_IDS;
    }

    public UsersInfoBean methodGetUsersInfo(List<String> socialNetworkIDList) throws CommonException {
        String uids = formSocialNetworkIDParameter(socialNetworkIDList, MAX_NUMBER_IDS);
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_GET_PROFILES);
        parameters.put(Constants.PARAMETER_NAME_UIDS, uids);
        parameters.put(Constants.PARAMETER_NAME_FIELDS, Constants.PARAMETER_VALUE_FIELDS);
        addSignature(parameters);
        return (UsersInfoBean) call(parameters);
    }

    public FriendsBean methodGetFriends(String socialNetworkID) throws CommonException {
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_FRIENDS_GET);
        parameters.put(Constants.PARAMETER_NAME_UID, socialNetworkID);
        addSignature(parameters);
        return (FriendsBean) call(parameters);
    }

    public LoginBean methodLogin(String login, String password, boolean genToken) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodLogin");
    }

    public SocialNetworkMoneyBean methodPayment(String socialNetworkID, long amount, boolean testMode) throws CommonException {
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_WITHDRAW_VOTES);
        parameters.put(Constants.PARAMETER_NAME_UID, socialNetworkID);
        parameters.put(Constants.PARAMETER_VOTES, String.valueOf(amount));
        if (isTestMode() && testMode) {
            parameters.put(Constants.PARAMETER_TEST_MODE, Constants.TEST_MODE);
        }
        addSignature(parameters);
        return (SocialNetworkMoneyBean) call(parameters);
    }

    public SocialNetworkMoneyBean methodGetBalance(String socialNetworkID) throws CommonException {
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_GET_BALANCE);
        parameters.put(Constants.PARAMETER_NAME_UID, socialNetworkID);
        addSignature(parameters);
        return (SocialNetworkMoneyBean) call(parameters);
    }

    public SendNotificationBean methodSendNotification(String socialNetworkIDString, String message)
            throws CommonException {
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_SEND_NOTIFICATION);
        parameters.put(Constants.PARAMETER_NAME_UIDS, socialNetworkIDString);
        message = message.replaceAll(DOUBLE_QUOTES, DOUBLE_QUOTES_REPLACEMENT);
//        message = message.replaceAll("`", "&#39;");
        parameters.put(Constants.PARAMETER_MESSAGE, message);
        addSignature(parameters);
        String utfMessage = null;
        try {
            utfMessage = new String(message.getBytes(UTF8_CHARSET), UTF8_CHARSET);
        } catch (UnsupportedEncodingException e) {
            LOGGER.error("methodSendNotification", e);
            throw new CommonException("methodSendNotification", e);
        }
        parameters.put(Constants.PARAMETER_MESSAGE, utfMessage);
        return (SendNotificationBean) call(parameters);
    }

    public List<SendNotificationBean> methodSendNotifications(List<String> socialNetworkIDList, String message)
            throws CommonException {
        List<SendNotificationBean> result = new ArrayList<SendNotificationBean>();
        int callCount = Math.round(socialNetworkIDList.size() / MAX_NUMBER_NOTIFICATIONS);
        if ((socialNetworkIDList.size() % MAX_NUMBER_NOTIFICATIONS) != 0) {
            callCount++;
        }
        for (int i = 0; i < callCount; i++) {
            int fromIndex = i * MAX_NUMBER_NOTIFICATIONS;
            int toIndex = (i + 1) * MAX_NUMBER_NOTIFICATIONS;
            if (toIndex > socialNetworkIDList.size()) {
                toIndex = socialNetworkIDList.size();
            }
            List<String> uids = socialNetworkIDList.subList(fromIndex, toIndex);
            String socialNetworkIDString = formSocialNetworkIDParameter(uids, MAX_NUMBER_NOTIFICATIONS);
            SendNotificationBean bean = methodSendNotification(socialNetworkIDString, message);
            result.add(bean);
        }
        return result;
    }

    /**
     * Specific call method. Restriction - N calls in a second.
     *
     * @param parameters parameters method
     * @return response bean
     * @throws CommonException call exception
     */
    protected AbstractBean call(Map<String, String> parameters) throws CommonException {
        long stoptime = callsPeriod - (System.currentTimeMillis() - callTimestamp);
        if (stoptime > 0) {
            try {
                //LOGGER.debug("stoptime: " + stoptime);
                Thread.sleep(stoptime);
            } catch (InterruptedException e) {
                LOGGER.error("call: " + parameters, e);
            }
        }
        AbstractBean bean = super.call(parameters);
        callTimestamp = System.currentTimeMillis();
        return bean;
    }

}
