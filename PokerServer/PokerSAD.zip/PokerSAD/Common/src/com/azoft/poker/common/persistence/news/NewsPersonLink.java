package com.azoft.poker.common.persistence.news;

import com.azoft.poker.common.persistence.BaseEntity;
import com.azoft.poker.common.persistence.person.Person;

/**
 * News person link
 */
public class NewsPersonLink extends BaseEntity {

    /**
     * News
     */
    private News news;

    /**
     * Person
     */
    private Person person;

    /**
     * News it is read
     */
    private boolean read;

    public NewsPersonLink() {
        super();
        this.read = false;
    }

    public NewsPersonLink(News news, Person person) {
        super();
        this.news = news;
        this.person = person;
    }

    public News getNews() {
        return news;
    }

    public void setNews(News news) {
        this.news = news;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

}