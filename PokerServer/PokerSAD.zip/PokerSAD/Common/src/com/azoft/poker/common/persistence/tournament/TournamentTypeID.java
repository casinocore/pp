package com.azoft.poker.common.persistence.tournament;

public enum TournamentTypeID {

    SIT_AND_GO_TOURNAMENT((byte) 1, "Sit&Go"),
    TEMPORAL_TOURNAMENT((byte) 2, "TEMPORAL TOURNAMENT"),
    MTT_TOURNAMENT((byte) 3, "MTT TOURNAMENT");

    private byte typeId;
    private String label;

    TournamentTypeID(byte typeId, String label) {
        this.typeId = typeId;
        this.label = label;
    }

    public byte getTypeId() {
        return typeId;
    }

    public String getLabel() {
        return label;
    }

    public static TournamentTypeID valueOf(byte typeId) {
        TournamentTypeID result = null;
        for (TournamentTypeID tournamentTypeID : TournamentTypeID.values()) {
            if (tournamentTypeID.getTypeId() == typeId) {
                result = tournamentTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "TournamentTypeID{" +
                "name=" + name() +
                " typeId=" + typeId +
                '}';
    }

}