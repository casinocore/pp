package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.socialnetwork.bean.LoginBean;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Login handler for schoolmate
 */
public class LoginHandler extends BaseSocialNetworkHandler<LoginBean> {

    private LoginBean loginBean;

    public LoginHandler() {
        super();
        loginBean = new LoginBean();
        setBean(loginBean);
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        super.startElement(uri, lName, qName, attr);
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        super.endElement(uri, lName, qName);

        String tag = getTag(lName, qName);
        if (tag.equals("ns2:auth_login_response")) {
            loginBean.setIfNullProcessingResult(RESULT_SUCCESS);
        } else if (tag.equals("uid")) {
            loginBean.setIud(text);
        } else if (tag.equals("session_key")) {
            loginBean.setSessionKey(text);
        } else if (tag.equals("session_secret_key")) {
            loginBean.setSessionSecretKey(text);
        } else if (tag.equals("auth_token")) {
            loginBean.setAuthToken(text);
        } else if (tag.equals("api_server")) {
            loginBean.setApiServer(text);
        }
    }

}