package com.azoft.poker.common.socialnetwork.bean;

import com.azoft.poker.common.jaxp.AbstractBean;

/**
 * Send notification bean
 */
public class SendNotificationBean extends AbstractBean {

    private String response;

    public SendNotificationBean() {
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

}
