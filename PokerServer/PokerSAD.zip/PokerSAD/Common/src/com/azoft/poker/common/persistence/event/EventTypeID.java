package com.azoft.poker.common.persistence.event;

public enum EventTypeID {

    //System events [0..999]
    TEST_EVENT(999),

    //Login server events [1000..1999]
    BONUS(1002),

    //Session events [3000..3999]
    SESSION_END(3001),
    ONLINE_PERSON(3002),

    //Play events [5000..5999]
    PLAY_START(5000),
    JOIN_TABLE(5002),
    DEAL_FINISHED(5004),
    WINNER(5005),
    ACTIVE_AND_NOT_FOLD(5006),

    //Payment events [6000..6999]
    PAYMENT_OF_CHIPS(6000);

    private short typeId;

    EventTypeID(int typeId) {
        this.typeId = (short) typeId;
    }

    public short getTypeId() {
        return typeId;
    }

    public static EventTypeID valueOf(short typeId) {
        EventTypeID result = null;
        for (EventTypeID serverTypeID : EventTypeID.values()) {
            if (serverTypeID.getTypeId() == typeId) {
                result = serverTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "EventTypeID{" +
                "name=" + name() +
                ", typeId=" + typeId +
                '}';
    }

}
