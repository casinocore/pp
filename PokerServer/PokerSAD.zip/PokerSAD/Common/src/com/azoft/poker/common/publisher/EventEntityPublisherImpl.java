package com.azoft.poker.common.publisher;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Application events publisher
 */
public class EventEntityPublisherImpl implements EventEntityPublisher<Event> {

    private List<EventEntitySubcriber<Event>> subcribers = new CopyOnWriteArrayList<EventEntitySubcriber<Event>>();

    private static EventEntityPublisher<Event> instance;

    public static synchronized EventEntityPublisher<Event> getInstance() {
        if (instance == null) {
            instance = new EventEntityPublisherImpl();
        }
        return instance;
    }

    private EventEntityPublisherImpl() {
    }

    public void addSubcriber(EventEntitySubcriber<Event> subcriber) {
        if (!subcribers.contains(subcriber)) {
            subcribers.add(subcriber);
        }
    }

    public void removeSubcriber(EventEntitySubcriber<Event> subcriber) {
        subcribers.remove(subcriber);
    }

    public void notifySubcribers(Event event) {
        for (EventEntitySubcriber<Event> subcriber : subcribers) {
            subcriber.doEvent(event);
        }
    }

}
