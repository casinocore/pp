package com.azoft.poker.common.persistence;

/**
 * Simple domain object with an id property. Used as a base class for
 * objects needing this property.
 */
public class BaseEntity {

    private Long id;

    public BaseEntity() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public boolean isNew() {
        return (this.id == null);
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof BaseEntity))
            return false;

        BaseEntity that = (BaseEntity) o;

        return !(getId() != null ? !getId().equals(that.getId())
                : that.getId() != null);

    }

    public int hashCode() {
        return (getId() != null ? getId().hashCode() : 0);
    }

    @Override
    public String toString() {
        return "BaseEntity{" +
                "id=" + id +
                '}';
    }

}
