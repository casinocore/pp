package com.azoft.poker.common.socialnetwork.facebook;

import com.google.gson.Gson;

import java.util.Arrays;

public class FBOrderDetailsUpdate {

    private long order_id;

    private long amount;

    private long update_time;

    private long time_placed;

    FBOrderDetailsBean[] items;

    public FBOrderDetailsUpdate() {
    }

    public long getOrder_id() {
        return order_id;
    }

    public void setOrder_id(long order_id) {
        this.order_id = order_id;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public long getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(long update_time) {
        this.update_time = update_time;
    }

    public long getTime_placed() {
        return time_placed;
    }

    public void setTime_placed(long time_placed) {
        this.time_placed = time_placed;
    }

    public FBOrderDetailsBean[] getItems() {
        return items;
    }

    public void setItems(FBOrderDetailsBean[] items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return "FBOrderDetailsUpdate{" +
                "order_id='" + order_id + '\'' +
                ", amount='" + amount + '\'' +
                ", update_time='" + update_time + '\'' +
                ", time_placed='" + time_placed + '\'' +
                ", items=" + (items == null ? null : Arrays.asList(items)) +
                '}';
    }

    public static FBOrderDetailsUpdate createFBOrderDetailsUpdate(String json) {
        Gson gson = new Gson();
        //convert JSON into java object
        return gson.fromJson(json, FBOrderDetailsUpdate.class);
    }

}
