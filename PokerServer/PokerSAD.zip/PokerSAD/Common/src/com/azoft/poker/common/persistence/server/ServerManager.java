package com.azoft.poker.common.persistence.server;

import java.util.Collection;

public interface ServerManager {

    /**
     * Retrieve all <code>Server</code>s from the data store.
     *
     * @return a <code>Collection</code> of <code>Server</code>s
     */
    Collection<Server> getServers();

    /**
     * Retrieve by <code>ServerTypeID</code> <code>Server</code>s from the data store.
     *
     * @return a <code>Collection</code> of <code>Server</code>s
     */
    Collection<Server> getServers(ServerTypeID serverTypeID);

}
