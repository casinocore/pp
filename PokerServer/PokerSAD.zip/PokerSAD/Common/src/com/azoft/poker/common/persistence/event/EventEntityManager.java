package com.azoft.poker.common.persistence.event;

import com.azoft.poker.common.persistence.BatchPersistenceManager;
import com.azoft.poker.common.publisher.EventEntitySubcriber;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Event entity manager interface
 *
 * @param <PersistenceType> persistence event type
 * @param <EventType> event type
 */
public interface EventEntityManager<PersistenceType, EventType>
        extends BatchPersistenceManager<PersistenceType>, EventEntitySubcriber<EventType> {


    void save(PersistenceType persistenceObject);

    void merge(PersistenceType persistenceObject);

    /**
     * Retrieve count of events from <code>fromDate</code> to <code>toDate</code>
     *
     * @param eventTypeID event type ID
     * @param fromDate    from date
     * @param toDate      to date
     * @return a count of events
     */
    Integer getCountEventsForPeriod(EventTypeID eventTypeID, Date fromDate, Date toDate);

    /**
     * Retrieve count of user events
     *
     * @param userId      user id
     * @param eventTypeID event type ID
     * @return a count of user events
     */
    Integer getCountUserEvents(Long userId, EventTypeID eventTypeID);

    /**
     * Retrieve count of user events from <code>fromDate</code> to <code>toDate</code>
     *
     * @param userId      user id
     * @param eventTypeID event type ID
     * @param fromDate    from date
     * @param toDate      to date
     * @return a count of user events
     */
    Integer getCountUserEventsForPeriod(Long userId, EventTypeID eventTypeID, Date fromDate, Date toDate);

    /**
     * User event last time
     *
     * @param userId      user id
     * @param eventTypeID event type ID
     * @return user event last time
     */
    Date getUserEventLastTime(Long userId, EventTypeID eventTypeID);

    /**
     * Retrieve max of user events values
     *
     * @param userId        user id
     * @param eventTypeID   event type ID
     * @param attributeName attribute name
     * @return max of user events values
     */
    BigDecimal getMaxUserEventsValues(Long userId, EventTypeID eventTypeID, String attributeName);

    /**
     * Retrieve sum of events values from <code>fromDate</code> to <code>toDate</code>..
     *
     * @param eventTypeID   event type ID
     * @param fromDate      from date
     * @param toDate        to date
     * @param attributeName attribute name
     * @return a sum of events values
     */
    Double getSumEventsValuesForPeriod(EventTypeID eventTypeID, Date fromDate, Date toDate, String attributeName);

    /**
     * Retrieve user sum of events values
     *
     * @param userId        user id
     * @param eventTypeID   event type ID
     * @param attributeName attribute name
     * @return a sum of events values
     */
    Double getSumUserEventsValues(Long userId, EventTypeID eventTypeID, String attributeName);

    /**
     * Retrieve <code>EventEntity</code> from <code>fromDate</code> to <code>toDate</code>.
     *
     * @param fromDate from date
     * @param toDate   to date
     * @return a <code>List</code> of <code>EventEntity</code>
     */
    List<EventEntity> getEventEntitiesForPeriod(Date fromDate, Date toDate);

    /**
     * Retrieve <code>EventEntity</code> from <code>fromStringDate</code> to <code>toStringDate</code>.
     *
     * @param fromStringDate from date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @param toStringDate   to date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @return a <code>List</code> of <code>EventEntity</code>
     */
    List<EventEntity> getEventEntitiesForPeriod(String fromStringDate, String toStringDate);

    /**
     * Retrieve <code>EventEntity</code> from <code>fromDate</code> to <code>toDate</code>.
     *
     * @param fromDate    from date
     * @param toDate      to date
     * @param eventTypeID event type ID
     * @return a <code>List</code> of <code>EventEntity</code>
     */
    List<EventEntity> getEventEntitiesForPeriod(Date fromDate, Date toDate, EventTypeID eventTypeID);

    /**
     * Retrieve user <code>EventEntity</code>
     *
     * @param userId      user id
     * @param eventTypeID event type ID
     * @return a <code>List</code> of user <code>EventEntity</code>
     */
    List<EventEntity> getUserEventEntities(Long userId, EventTypeID eventTypeID);

    /**
     * Retrieve user <code>EventEntity</code> from <code>fromDate</code> to <code>toDate</code>.
     *
     * @param fromDate from date
     * @param toDate   to date
     * @param userId   user id
     * @return a <code>List</code> of user <code>EventEntity</code>
     */
    List<EventEntity> getUserEventEntitiesForPeriod(Date fromDate, Date toDate, Long userId);

    /**
     * Retrieve user <code>EventEntity</code> from <code>fromStringDate</code> to <code>toStringDate</code>.
     *
     * @param fromStringDate from date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @param toStringDate   to date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @param userId         user id
     * @return a <code>List</code> of user <code>EventEntity</code>
     */
    List<EventEntity> getUserEventEntitiesForPeriod(String fromStringDate, String toStringDate, Long userId);

    /**
     * Retrieve user <code>EventEntity</code>.
     *
     * @param userId user id
     * @return a <code>List</code> of user <code>EventEntity</code>
     */
    List<EventEntity> getUserEventEntities(Long userId);

    /**
     * Retrieve <code>EventEntity</code> from <code>fromDate</code> to <code>toDate</code> by reference max.
     *
     * @param eventTypeID event type ID
     * @param fromDate    from date
     * @param toDate      to date
     * @return a <code>List</code> of user <code>EventEntity</code>
     */
    List<EventEntity> getEventEntitiesByReferenceMaxForPeriod(EventTypeID eventTypeID, Date fromDate, Date toDate);

}
