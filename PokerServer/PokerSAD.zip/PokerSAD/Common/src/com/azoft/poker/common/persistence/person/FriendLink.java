package com.azoft.poker.common.persistence.person;

import com.azoft.poker.common.persistence.BaseEntity;

/**
 * Friend link
 */
public class FriendLink extends BaseEntity {

    private Person person;

    private Person friend;

    public FriendLink() {
        super();
    }

    public FriendLink(Person person, Person friend) {
        super();
        this.person = person;
        this.friend = friend;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Person getFriend() {
        return friend;
    }

    public void setFriend(Person friend) {
        this.friend = friend;
    }

}
