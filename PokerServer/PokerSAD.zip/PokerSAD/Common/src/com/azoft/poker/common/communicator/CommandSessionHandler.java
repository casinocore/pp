package com.azoft.poker.common.communicator;

import com.azoft.poker.common.commandprocessing.CloseSessionListener;
import com.azoft.poker.common.commandprocessing.CommandProcessor;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Command session handler
 */
public class CommandSessionHandler extends IoHandlerAdapter {

    private final static Logger LOGGER = LoggerFactory.getLogger(CommandSessionHandler.class);
    private static final int BOTH_IDLE = 60 * 60; //1 hour
//    private static final int MAX_READ_BUFFER_SIZE = 65536;

    private CommandProcessor commandProcessor;

    private CloseSessionListener listener = null;

    public CloseSessionListener getListener() {
        return listener;
    }

    public void setListener(CloseSessionListener listener) {
        this.listener = listener;
    }

    public CommandSessionHandler(CommandProcessor commandProcessor) {
        super();
        this.commandProcessor = commandProcessor;
    }

    @Override
    public void sessionOpened(IoSession session) {
        // set idle time to 10 seconds
        session.getConfig().setIdleTime(IdleStatus.BOTH_IDLE, BOTH_IDLE);
//        session.getConfig().setMaxReadBufferSize(MAX_READ_BUFFER_SIZE);
    }

    @Override
    public void messageReceived(IoSession session, Object message) {
        Command command = (Command) message;
        LOGGER.debug("Command received: " + command.toString());
        try {
            commandProcessor.putCommand(command);
        } catch (InterruptedException e) {
            LOGGER.error("Put command: " + command.toString(), e);
        }
    }

    @Override
    public void sessionClosed(IoSession session) throws Exception {
        if (listener != null) {
            listener.clearResourcesOnCloseSession(session);
        }
        super.sessionClosed(session);
    }

    private void closeSession(IoSession session) {
        session.close(true);
    }

    @Override
    public void sessionIdle(IoSession
            session, IdleStatus status) {
        LOGGER.warn("Disconnecting the idle.");
        // disconnect an idle client
        session.close(true);
    }

    @Override
    public void exceptionCaught(IoSession session, Throwable cause) {
        // closeSession the connection on exceptional situation
        session.close(true);
    }

    @Override
    public String toString() {
        return "CommandSessionHandler{" +
                "commandProcessor=" + commandProcessor.getClass().getSimpleName() +
                '}';
    }

}
