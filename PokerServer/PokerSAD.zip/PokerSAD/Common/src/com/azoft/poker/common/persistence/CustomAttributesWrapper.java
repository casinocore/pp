package com.azoft.poker.common.persistence;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Abstract wrapper for custom attributes entity
 */
public abstract class CustomAttributesWrapper<EntityType extends CustomAttributesEntity> {

    /**
     * Date time format for custom attributes
     */
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final DateFormat attributeDateTimeFormat = new SimpleDateFormat(
            DATE_TIME_FORMAT);

    private EntityType entity;

    public CustomAttributesWrapper(EntityType entity) {
        this.entity = entity;
    }

    public EntityType getEntity() {
        return entity;
    }

    protected Byte getByteAttribute(String attributeName) {
        Byte result = null;
        if (attributeName != null) {
            try {
                result = Byte.valueOf(getEntity().getAttributeValue(
                        attributeName));
            } catch (NumberFormatException e) {
                result = null;
            }
        }
        return result;
    }

    protected void setByteAttribute(String attributeName, Byte attributeValue) {
        if (attributeValue != null) {
            getEntity().addAttribute(attributeName,
                    String.valueOf(attributeValue));
        } else {
            getEntity().deleteAttribute(attributeName);
        }
    }

    protected Short getShortAttribute(String attributeName) {
        Short result = null;
        if (attributeName != null) {
            try {
                result = Short.valueOf(getEntity().getAttributeValue(
                        attributeName));
            } catch (NumberFormatException e) {
                result = null;
            }
        }
        return result;
    }

    protected void setShortAttribute(String attributeName, Short attributeValue) {
        if (attributeValue != null) {
            getEntity().addAttribute(attributeName,
                    String.valueOf(attributeValue));
        } else {
            getEntity().deleteAttribute(attributeName);
        }
    }

    protected Integer getIntegerAttribute(String attributeName) {
        Integer result = null;
        if (attributeName != null) {
            try {
                result = Integer.valueOf(getEntity().getAttributeValue(
                        attributeName));
            } catch (NumberFormatException e) {
                result = null;
            }
        }
        return result;
    }

    protected void setIntegerAttribute(String attributeName,
            Integer attributeValue) {
        if (attributeValue != null) {
            getEntity().addAttribute(attributeName,
                    String.valueOf(attributeValue));
        } else {
            getEntity().deleteAttribute(attributeName);
        }
    }

    protected Long getLongAttribute(String attributeName) {
        Long result = null;
        if (attributeName != null) {
            try {
                result = Long.valueOf(getEntity().getAttributeValue(
                        attributeName));
            } catch (NumberFormatException e) {
                result = null;
            }
        }
        return result;
    }

    protected void setLongAttribute(String attributeName, Long attributeValue) {
        if (attributeValue != null) {
            getEntity().addAttribute(attributeName,
                    String.valueOf(attributeValue));
        } else {
            getEntity().deleteAttribute(attributeName);
        }
    }

    protected Date getDateAttribute(String attributeName) {
        Date result = null;
        if (attributeName != null) {
            try {
                String value = getEntity().getAttributeValue(attributeName);
                result = value == null ? null : attributeDateTimeFormat
                        .parse(value);
            } catch (Exception e) {
                result = null;
            }
        }
        return result;
    }

    protected void setDateAttribute(String attributeName, Date attributeValue) {
        if (attributeValue != null) {
            getEntity().addAttribute(
                    attributeName,
                    String.valueOf(attributeDateTimeFormat
                            .format(attributeValue)));
        } else {
            getEntity().deleteAttribute(attributeName);
        }
    }

}