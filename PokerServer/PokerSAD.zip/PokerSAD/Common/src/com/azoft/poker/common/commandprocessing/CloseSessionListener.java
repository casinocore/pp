package com.azoft.poker.common.commandprocessing;

import org.apache.mina.core.session.IoSession;

public interface CloseSessionListener {

    public void clearResourcesOnCloseSession(IoSession session);
}
