package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.exception.CommonException;

import java.util.Map;

/**
 * Social network client manager interface
 */
public interface SocialNetworkClientManager {

    /**
     * Create social network client
     *
     * @param parameters parameters
     * @return social network client
     * @throws CommonException CommonException
     */
    SocialNetworkClient createSocialNetworkClient(Map<String, Object> parameters) throws CommonException;

    /**
     * Get social network client
     *
     * @return social network client
     * @throws CommonException CommonException
     */
    SocialNetworkClient getSocialNetworkClient() throws CommonException;

}
