package com.azoft.poker.common.socialnetwork.service;

import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.socialnetwork.SocialNetworkTypeID;

/**
 * Callbacks payment service factory
 */
public class CallbacksPaymentServiceFactory {

    public static CallbacksPaymentService createCallbacksPaymentService(
            SocialNetworkTypeID socialNetworkTypeID, String secretKey) {
        CallbacksPaymentService service = null;
        if (SocialNetworkTypeID.SCHOOLMATE.equals(socialNetworkTypeID)) {
            service = new com.azoft.poker.common.socialnetwork.schoolmate.CallbacksPaymentServiceImpl();
        } else if (SocialNetworkTypeID.MAILRU.equals(socialNetworkTypeID)) {
            service = new com.azoft.poker.common.socialnetwork.mailru.CallbacksPaymentServiceImpl();
        } else if (SocialNetworkTypeID.FACEBOOK.equals(socialNetworkTypeID)) {
            service = new com.azoft.poker.common.socialnetwork.facebook.CallbacksPaymentServiceImpl(secretKey);
        }
        return service;
    }

    public static boolean checkParameter(String[] parameter) {
        return parameter != null && parameter.length == 1 && !StringHelper.isEmpty(parameter[0]);
    }

}