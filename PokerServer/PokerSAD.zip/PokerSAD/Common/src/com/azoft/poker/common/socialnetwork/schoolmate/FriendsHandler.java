package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.socialnetwork.bean.FriendsBean;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Friends handler for schoolmate
 */
public class FriendsHandler extends BaseSocialNetworkHandler<FriendsBean> {

    private FriendsBean friendsBean;

    public FriendsHandler() {
        super();
        friendsBean = new FriendsBean();
        setBean(friendsBean);
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        super.startElement(uri, lName, qName, attr);

        String tag = getTag(lName, qName);
        if (tag.equals("ns2:friends_get_response")) {
            friendsBean.getFriends().clear();
        }
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        super.endElement(uri, lName, qName);

        String tag = getTag(lName, qName);
        if (tag.equals("ns2:friends_get_response")) {
            friendsBean.setIfNullProcessingResult(RESULT_SUCCESS);
        } else if (tag.equals("uid")) {
            friendsBean.addFriend(text);
        }
    }

}
