package com.azoft.poker.common.socialnetwork.facebook;

import com.azoft.poker.common.helper.Base64Helper;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.persistence.event.EventEntityManagerImpl;
import com.azoft.poker.common.persistence.event.EventTypeID;
import com.azoft.poker.common.persistence.event.PaymentOfChipsEvent;
import com.azoft.poker.common.persistence.payment.Payment;
import com.azoft.poker.common.persistence.payment.PaymentManager;
import com.azoft.poker.common.persistence.payment.PaymentManagerImpl;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.product.Product;
import com.azoft.poker.common.persistence.product.ProductManagerImpl;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentService;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentServiceFactory;
import com.google.gson.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Map;

/**
 * Callbacks payment service for facebook
 */
public class CallbacksPaymentServiceImpl implements CallbacksPaymentService {

    private final static Logger LOGGER = LoggerFactory.getLogger(CallbacksPaymentServiceImpl.class);

    private static final String CONTENT_TYPE = "application/json; charset=utf-8";

    private static final String HMAC_SHA256 = "HmacSHA256";

    private static final String POINT_REGEX = "\\Q.\\E";

    private boolean existsError = false;

    private String secretKey;

    public CallbacksPaymentServiceImpl(String secretKey) {
        this.secretKey = secretKey;
    }

    public boolean isExistsError() {
        return existsError;
    }

    public String getContentType() {
        return CONTENT_TYPE;
    }

/*
<?php
// Copyright 2004-2011 Facebook. All Rights Reserved.

* You should reference http://developers.facebook.com/docs/creditsapi as you
* familiarize yourself with callback.php. In particular, read all the steps
* under "Callback Flow in Detail".
*
* Your application needs the following inputs and outputs
*
* @param int order_id
* @param string status
* @param string method
* @param array order_details (JSON-encoded)
*
* @return array A JSON-encoded array with order_id, next_state (optional: error code, comments)

// Enter your app information below
$api_key = '<api key>';
$secret = '<secret>';

include_once 'facebook.php';

// prepare the return data array
$data = array('content' => array());

// parse signed data
$request = parse_signed_request($_REQUEST['signed_request'], $secret);

if ($request == null) {
  // handle an unauthenticated request here
}

$payload = $request['credits'];

// retrieve all params passed in
$func = $_REQUEST['method'];
$order_id = $payload['order_id'];

if ($func == 'payments_status_update') {
  $status = $payload['status'];

  // write your logic here, determine the state you wanna move to
  if ($status == 'placed') {
    $next_state = 'settled';
    $data['content']['status'] = $next_state;
  }
  // compose returning data array_change_key_case
  $data['content']['order_id'] = $order_id;

} else if ($func == 'payments_get_items') {

  // remove escape characters
  $order_info = stripcslashes($payload['order_info']);
  if (is_string($order_info)) {

     // Per the credits api documentation, you should pass in an item reference
     // and then query your internal DB for the proper information. Then set
     // the item information here to be returned to facebook then shown to the
     // user for confirmation.
     $item['title'] = 'BFF Locket';
     $item['price'] = 1;
     $item['description'] = 'This is a BFF Locket...';
     $item['image_url'] = 'http://www.facebook.com/images/gifts/21.png';
     $item['product_url'] = 'http://www.facebook.com/images/gifts/21.png';
  } else {

    // In the sample credits application we allow the developer to enter the
    // information for easy testing. Please note that this information can be
    // modified by the user if not verified by your callback. When using
    // credits in a production environment be sure to pass an order ID and
    // contruct item information in the callback, rather than passing it
    // from the parent call in order_info.
    $item = json_decode($order_info, true);
    $item['price'] = (int)$item['price'];

    // for url fields, if not prefixed by http://, prefix them
    $url_key = array('product_url', 'image_url');
    foreach ($url_key as $key) {
      if (substr($item[$key], 0, 7) != 'http://') {
        $item[$key] = 'http://'.$item[$key];
      }
    }

    // prefix test-mode
    if (isset($payload['test_mode'])) {
       $update_keys = array('title', 'description');
       foreach ($update_keys as $key) {
         $item[$key] = '[Test Mode] '.$item[$key];
       }
     }
  }

  // Put the associate array of item details in an array, and return in the
  // 'content' portion of the callback payload.
  $data['content'] = array($item);
}

// required by api_fetch_response()
$data['method'] = $func;

// send data back
echo json_encode($data);
*/

    public String methodCallbacksPayment(Map parameters) {
        String result = null;
        boolean check = true;

        String[] method = (String[]) parameters.get(Constants.QUERY_METHOD);
        check = check && CallbacksPaymentServiceFactory.checkParameter(method);
        if (!check) {
            String errorMsg = "Method: " + method[0];
            result = createCanceledResult(null, errorMsg);
//            result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
            existsError = true;
            return result;
        }
        LOGGER.debug("0) method[0]: " + method[0]);

        String[] signedRequest = (String[]) parameters.get(Constants.PARAMETER_SIGNED_REQUEST);
        check = check && CallbacksPaymentServiceFactory.checkParameter(signedRequest);
        if (!check) {
            String errorMsg = "signedRequest: " + signedRequest[0];
            result = createCanceledResult(null, errorMsg);
//            result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
            existsError = true;
            return result;
        }
        LOGGER.debug("0) signedRequest[0]: " + signedRequest[0]);

        FBRequest parseSignedRequest = parseSignedRequest(signedRequest[0], secretKey);
        if (parseSignedRequest == null) {
            String errorMsg = "parseSignedRequest: " + signedRequest[0];
            result = createCanceledResult(parseSignedRequest, errorMsg);
//            result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
            existsError = true;
            return result;
        }
        LOGGER.info("parseSignedRequest: " + parseSignedRequest);

        FBRequestBean credits = parseSignedRequest.getCredits();
        if (credits == null) {
            String errorMsg = "Data not exists";
            result = createCanceledResult(parseSignedRequest, errorMsg);
//            result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
            existsError = true;
            return result;
        }
        LOGGER.debug("0) credits: " + credits);

        String transactionId = String.valueOf(credits.getOrder_id());
        if (StringHelper.isEmpty(transactionId)) {
            String errorMsg = "transactionId: " + transactionId;
            result = createCanceledResult(parseSignedRequest, errorMsg);
//            result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
            existsError = true;
            return result;
        }
        LOGGER.debug("0) transactionId: " + transactionId);

        if (Constants.METHOD_PAYMENTS_STATUS_UPDATE.equals(method[0]) && !Constants.FB_PAYMENT_STATUS_PLACED.equals(credits.getStatus())) {
            String msg = "Status: " + credits.getStatus() + " for order: " + credits.getOrder_id();
            LOGGER.info(msg + ". parseSignedRequest: " + parseSignedRequest);
            return result;
        }

        if (Constants.METHOD_PAYMENTS_GET_ITEMS.equals(method[0])) {
            LOGGER.debug("1) payments_get_items. parameters.size(): " + parameters.size() + "; parseSignedRequest: " + parseSignedRequest);
            String orderInfo = credits.getOrder_info();
            if (!StringHelper.isEmpty(orderInfo)) {
                FBOrderDetailsBean orderInfoBean = FBOrderDetailsBean.createFBOrderDetailsBean(orderInfo);
                LOGGER.debug("1) orderInfoBean: " + orderInfoBean);
                Product product = ProductManagerImpl.getInstance().getProduct(String.valueOf(orderInfoBean.getItem_id()));
                LOGGER.debug("1) Item_id (productCode): " + orderInfoBean.getItem_id() + "; product: " + product);
                if (product == null) {
                    String errorMsg = "Product not found. orderInfo: " + orderInfo;
                    result = createCanceledResult(parseSignedRequest, errorMsg);
//                    result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
                    existsError = true;
                    return result;
                }
                if (orderInfoBean.getDescription() == null) {
                    orderInfoBean.setDescription(orderInfoBean.getTitle());
                }
                if (orderInfoBean.getImage_url() == null) {
                    orderInfoBean.setImage_url(orderInfoBean.getProduct_url());
                }
                FBOrderDetails giResponse = new FBOrderDetails();
                giResponse.setMethod(method[0]);
                giResponse.setContent(new FBOrderDetailsBean[]{orderInfoBean});
                LOGGER.debug("1) giResponse: " + giResponse + "; giResponse.getContent()[0]: " + giResponse.getContent()[0]);
                //responseMap.put(transactionId, giResponse);
                result = giResponse.toJson();
                LOGGER.info(Constants.METHOD_PAYMENTS_GET_ITEMS + "; product: " + product
                        + "; parseSignedRequest: " + parseSignedRequest + "; result: " + result);
            } else {
                String errorMsg = "orderInfo: " + orderInfo;
                result = createCanceledResult(parseSignedRequest, errorMsg);
//                result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
                existsError = true;
                return result;
            }
        } else if (Constants.METHOD_PAYMENTS_STATUS_UPDATE.equals(method[0])) {
            result = Constants.FB_PAYMENT_STATUS_CANCELED;
            LOGGER.debug("2) payments_status_update. parameters.size(): " + parameters.size() + "; parseSignedRequest: " + parseSignedRequest);
            String errorMsg;
            FBOrderDetailsUpdate orderDetails = FBOrderDetailsUpdate.createFBOrderDetailsUpdate(credits.getOrder_details());
            LOGGER.debug("2) orderDetails: " + orderDetails);
            if (orderDetails.getItems() != null && orderDetails.getItems().length > 0) {
                FBOrderDetailsBean item = orderDetails.getItems()[0];
                String socialNetworkID = StringHelper.makeEmpty(parseSignedRequest.getUser_id());
                PersonManager personManager = PersonManagerImpl.getInstance();
                Person person = personManager.getPersonBySNID(socialNetworkID);
                LOGGER.debug("2) parseSignedRequest.getUser_id(): " + parseSignedRequest.getUser_id() + "; person: " + person);
                if (person != null) {
                    String productCode = String.valueOf(item.getItem_id());
                    LOGGER.debug("2) productCode: " + productCode);
                    String productOption = "";
                    long amount = item.getPrice();
                    LOGGER.debug("2) amount: " + amount);
                    if (check) {
                        PaymentManager<Payment> paymentManager = PaymentManagerImpl.getInstance();
                        Payment existsPayment = paymentManager.getPayment(transactionId);
                        LOGGER.debug("2) existsPayment: " + existsPayment);
                        if (existsPayment == null) { //is not exists payment - store payment
                            try {
                                Product product = ProductManagerImpl.getInstance().getProduct(productCode);
                                LOGGER.debug("2) product: " + product);
                                if (product != null) {
                                    if (amount == product.getAmount()) {
                                        Payment payment = new Payment();
                                        payment.setSocialNetworkID(socialNetworkID);
                                        payment.setTransactionTime(new Date());
                                        payment.setTransactionId(transactionId);
                                        payment.setProductCode(productCode);
                                        if (!StringHelper.isEmptyTrimmed(productOption)) {
                                            payment.setProductOption(productOption);
                                        }
                                        payment.setAmount(amount);
                                        LOGGER.debug("2) payment: " + payment);
                                        person.setBalance(person.getBalance() + product.getBalance());
                                        personManager.storePerson(person);
                                        paymentManager.save(payment);

                                        PaymentOfChipsEvent event = new PaymentOfChipsEvent(EventTypeID.PAYMENT_OF_CHIPS.getTypeId(), person.getId());
                                        event.setAccountRevenue(product.getAmount());
                                        event.setAccountChips(product.getBalance());
                                        EventEntityManagerImpl.getInstance().save(event.getEntity());

                                        result = createOkResult(parseSignedRequest, payment);
                                    } else {
                                        check = false;
                                        errorMsg = "Not equals amount for product code: " + productCode;
                                        result = createCanceledResult(parseSignedRequest, errorMsg);
                                        //result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
                                    }
                                } else {
                                    check = false;
                                    errorMsg = "Not exists product for product code: " + productCode;
                                    result = createCanceledResult(parseSignedRequest, errorMsg);
                                    //result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.name() + ". " + errorMsg);
                                }
                            } catch (Exception e) {
                                check = false;
                                //result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.getErrorCode(), "Service temporary unavailable");
                                result = createCanceledResult(parseSignedRequest, "Service temporary unavailable: " + e.getMessage());
                            }
                        } else { //is exists payment
                            check = false;
                            errorMsg = "Exists payment with transaction id: " + transactionId;
                            result = createCanceledResult(parseSignedRequest, errorMsg);
                            //result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.name() + ". " + errorMsg);
                        }
                    }
                } else {
                    check = false;
                    errorMsg = "Not exists user: " + socialNetworkID;
                    result = createCanceledResult(parseSignedRequest, errorMsg);
                    //result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.name() + ". " + errorMsg);
                }
            } else {
                check = false;
                errorMsg = "Not exists items";
                result = createCanceledResult(parseSignedRequest, errorMsg);
                //result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_APP_ERROR_RESPONSE.name() + ". " + errorMsg);
            }
        }

        if (!check && result == null) {
            String errorMsg = "Not valid parameter(s): " + parameters;
            result = createCanceledResult(parseSignedRequest, errorMsg);
            //result = getErrorResult(ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.getErrorCode(), ErrorCodes.API_EC_PAYMENTS_INVALID_PARAM.name() + ". " + errorMsg);
        }
        existsError = !check;
        return result;
    }

    private String createOkResult(FBRequest parseSignedRequest, Payment payment) {
        String result;
        FBRequestBean credits = parseSignedRequest.getCredits();
        FBRequestUpdate requestUpdate = new FBRequestUpdate();
        requestUpdate.getContent().setOrder_id(credits.getOrder_id());
        requestUpdate.getContent().setTest_mode(credits.getTest_mode());
        requestUpdate.getContent().setStatus(Constants.FB_PAYMENT_STATUS_SETTLED);
        requestUpdate.setMethod(Constants.METHOD_PAYMENTS_STATUS_UPDATE);
        result = requestUpdate.toJson();
        LOGGER.info(Constants.METHOD_PAYMENTS_STATUS_UPDATE + "; payment: " + payment
                + "; parseSignedRequest: " + parseSignedRequest + "; result: " + result);
        return result;
    }

    private String createCanceledResult(FBRequest parseSignedRequest, String errorMsg) {
        String result;
        if (parseSignedRequest != null) {
            FBRequestBean credits = parseSignedRequest.getCredits();
            FBRequestUpdate requestUpdate = new FBRequestUpdate();
            requestUpdate.getContent().setOrder_id(credits.getOrder_id());
            requestUpdate.getContent().setTest_mode(credits.getTest_mode());
            requestUpdate.getContent().setStatus(Constants.FB_PAYMENT_STATUS_CANCELED);
            requestUpdate.setMethod(Constants.METHOD_PAYMENTS_STATUS_UPDATE);
            result = requestUpdate.toJson();
            LOGGER.warn("Payment canceled for order: " + credits.getOrder_id() + ". " + errorMsg + ". parseSignedRequest: " + parseSignedRequest);
        } else {
            LOGGER.error("Payment error. " + errorMsg);
            result = "";
        }
        return result;
    }

/*
// you can find the following functions and more details
// on http://developers.facebook.com/docs/authentication/canvas
function parse_signed_request($signed_request, $secret) {
  list($encoded_sig, $payload) = explode('.', $signed_request, 2);

  // decode the data
  $sig = base64_url_decode($encoded_sig);
  $data = json_decode(base64_url_decode($payload), true);

  if (strtoupper($data['algorithm']) !== 'HMAC-SHA256') {
    error_log('Unknown algorithm. Expected HMAC-SHA256');
    return null;
  }

  // check signature
  $expected_sig = hash_hmac('sha256', $payload, $secret, $raw = true);
  if ($sig !== $expected_sig) {
    error_log('Bad Signed JSON signature!');
    return null;
  }

  return $data;
}
*/

    public static FBRequest parseSignedRequest(String signedRequest, String secret) {
        FBRequest parameters = null;
        String[] list = signedRequest.split(POINT_REGEX);
        LOGGER.debug("3) parseSignedRequest method. list.length: " + list.length);
        if (list.length == 2) {
            // decode the data
            try {
                LOGGER.debug("3) parseSignedRequest method. list[0]: " + list[0] + "; list[1]: " + list[1]);
                String sig = list[0];
                String payload = list[1].trim();
                LOGGER.debug("3) parseSignedRequest method. sig: " + sig + "; payload: " + payload);

                String strPayload = Base64Helper.decode(Base64Helper.replaceBeforeDecode(payload));
                LOGGER.debug("3) parseSignedRequest method. strPayload: " + strPayload);
                parameters = FBRequest.createFBRequest(strPayload);
                LOGGER.debug("3) parseSignedRequest method. parameters: " + parameters);

                String algorithm = parameters.getAlgorithm().toUpperCase();
                LOGGER.debug("3) parseSignedRequest method. algorithm: " + algorithm);
                if (!"HMAC-SHA256".equals(algorithm.toUpperCase())) {
                    LOGGER.error("Unknown algorithm. Expected HMAC-SHA256");
                    return null;
                }

                // check signature
                byte[] expectedSig = Base64Helper.byteDecode(Base64Helper.replaceBeforeDecode(sig));
                String strExpectedSig = new String(expectedSig).trim();
                byte[] actualSig = getActualSig(secret, payload);
                String strActualSig = new String(actualSig).trim();
                LOGGER.debug("3) parseSignedRequest method. parameters: " + parameters
                        + "; expectedSig: " + strExpectedSig + "; actualSig  : " + strActualSig
                        + "; sig.equals(expectedSig): " + String.valueOf(strActualSig.equals(strExpectedSig)));
                if (expectedSig == null || actualSig == null || !strActualSig.equals(strExpectedSig)) {
                    LOGGER.error("parseSignedRequest method. parameters: " + parameters + ". Bad Signed JSON signature!");
                }
            } catch (IOException e) {
                LOGGER.error("parseSignedRequest method. parameters: " + parameters, e);
            } catch (JsonParseException e) {
                LOGGER.error("parseSignedRequest method. parameters: " + parameters, e);
            }
        }
        LOGGER.debug("3) parameters: " + parameters);
        return parameters;
    }

    public static byte[] getActualSig(String secret, String payload) throws UnsupportedEncodingException {
        byte[] actualSig = null;
        SecretKeySpec secretKeySpec = new SecretKeySpec(secret.getBytes(), HMAC_SHA256);
        try {
            Mac mac = Mac.getInstance(HMAC_SHA256);
            mac.init(secretKeySpec);
            actualSig = mac.doFinal(payload.getBytes());
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("parseSignedRequest method. payload: " + payload, e);
        } catch (InvalidKeyException e) {
            LOGGER.error("parseSignedRequest method. payload: " + payload, e);
        }
        return actualSig;
    }

}