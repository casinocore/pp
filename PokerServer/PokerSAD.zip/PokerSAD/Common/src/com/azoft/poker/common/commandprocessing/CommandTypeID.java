package com.azoft.poker.common.commandprocessing;

public enum CommandTypeID {

    //System command types
    ACCESS_SERVER_COMMAND((short) 15472),      //access server command
    EXIT_FROM_LOGIN((short) 2000),      //login command
    EXIT_FROM_LOBBY((short) 1000),      //lobby command
    BACK_TO_LOBBY((short) 1100),        //lobby command

    //Login command types
    REGISTER((short) 1),
    LOGIN((short) 2),

    //Lobby command types
    REGISTER_ON_SERVER((short) 3),
    GET_LOBBY_CASH((short) 4),
    GET_TOURNAMENTS_LOBBY((short) 5),
    JOIN_TABLE((short) 6),
    PLAY_NOW((short) 7),
    PLAY_TOURNAMENT((short) 8),
    GET_TABLE_PLAYERS((short) 9),
    GET_TOP_PLAYERS((short) 10, CommandProcessor.SECONDARY_PROCESSOR_INDEX),
    GET_USER_GAME_PROFILE((short) 11, CommandProcessor.SECONDARY_PROCESSOR_INDEX),
    GET_TABLES_WITH_FRIENDS((short) 12),
    GET_BALANCE((short) 13),
    GET_TOP_INVITED_FRIENDS((short) 14, CommandProcessor.SECONDARY_PROCESSOR_INDEX),
    GET_TOURNAMENT((short) 15),
    TOURNAMENT_PAYMENT_AND_REGISTER((short) 16),
    TOURNAMENT_RESULT((short) 17),
    GET_TOURNAMENT_PLAYERS((short) 18, CommandProcessor.SECONDARY_PROCESSOR_INDEX),
    ADD_FRIEND((short) 19, CommandProcessor.SECONDARY_PROCESSOR_INDEX),
    GET_NEWS((short) 20, CommandProcessor.SECONDARY_PROCESSOR_INDEX),

    GET_PRODUCTS((short) 100),
    PAYMENT((short) 101),
    MARK_NEWS_AS_READ((short) 1101, CommandProcessor.SECONDARY_PROCESSOR_INDEX),

    //SngCommands
    GET_SNG_TABLES((short) 41),


    //Game command types
    SIT((short) 1001),
    NOTIFY_ABOUT_NEW_PLAYER((short) 1002),
    HAND_OUT_DEALER_BUTTON((short) 1003),
    HAND_OUT_CARDS((short) 1004),
    LEAD((short) 1005),
    NOTIFY_ABOUT_THE_LEAD((short) 1006),
    DEAL_OUT((short) 1007),
    DEAL_FINISHED((short) 1008),
    GET_UP((short) 1009),
    NOTIFY_ABOUT_PLAYER_EXIT((short) 1010),
    SEND_MESSAGE((short) 1011),
    NOTIFY_ABOUT_SENDING_MESSAGE((short) 1012),
    NOTIFY_TOURNAMENT_FINISHED((short) 1015),
    NEW_ACTIVE_USER((short) 1016),
    NOTIFY_EXIT_USER((short) 1017),
    NOTIFY_TABLE_CLOSED((short) 1018),
    NOTIFY_BANK_READY((short) 1013),
    NOTIFY_COMBINATION((short) 1014),

    //SngCommands
    NOTIFY_BLINDS_CHANGED((short) 1050),
    INCREASE_BLINDS_COMMAND((short) 1097),
    NOTIFY_SITOUT((short) 1051),
    NOTIFY_BACK((short) 1052),
    NOTIFY_SNG_FINISHED((short) 1053),

    TIMER_COMMAND((short) 1099),

    //MTT commands
    MTT_REGISTER((short) 3001),
    MTT_UNREGISTER((short) 3002),
    MTT_PLAY((short) 3003),
    MTT_REBUY((short) 3004),

    MTT_NOTIFY_BEFORE_START((short) 3101),
    MTT_NOTIFY_BREAK_START((short) 3102),
    MTT_NOTIFY_REBUY_OR_EXIT((short) 3103),
    MTT_NOTIFY_TABLE_CHANGED((short) 3104),
    MTT_NOTIFY_SYNCHRONISM_START((short) 3105),
    MTT_NOTIFY_SYNCHRONISM_FINISHED((short) 3106),
    MTT_NOTIFY_RATING((short) 3107),
    MTT_NOTIFY_EXIT((short) 3108),
    MTT_NOTIFY_REBUY((short) 3109),

    //System MTT commands
    S_MTT_START((short) 3201),
    S_MTT_BREAK((short) 3202),
    S_MTT_NOTIFY_BEFORE_START((short) 3203),
    S_MTT_NOTIFY_START_DEAL_TABLE((short) 3205),
    S_MTT_NOTIFY_FINISHED_DEAL_TABLE((short) 3206),
    S_MTT_INCREASE_BLINDS((short) 3207);

    public static final int LOGIN_COMMAND_MAX = 2;
    public static final int LOBBY_COMMAND_RANGE1_MAX = 1000;
    public static final int LOBBY_COMMAND_RANGE2_MIN = 1100;
    public static final int LOBBY_COMMAND_RANGE2_MAX = 1999;
    public static final int MTT_COMMAND_MIN = 3001;

    private short typeId;

    private int processorIndex;

    public short getTypeId() {
        return typeId;
    }

    public int getProcessorIndex() {
        return processorIndex;
    }

    CommandTypeID(short typeId) {
        this.typeId = typeId;
        this.processorIndex = CommandProcessor.PRIMARY_PROCESSOR_INDEX;
    }

    CommandTypeID(short typeId, int processorIndex) {
        this.typeId = typeId;
        this.processorIndex = processorIndex;
    }

    public static CommandTypeID valueOf(short typeId) {
        CommandTypeID result = null;
        for (CommandTypeID commandTypeID : CommandTypeID.values()) {
            if (commandTypeID.getTypeId() == typeId) {
                result = commandTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "CommandTypeID{" +
                "name=" + name() +
                ", typeId=" + typeId +
                '}';
    }
}
