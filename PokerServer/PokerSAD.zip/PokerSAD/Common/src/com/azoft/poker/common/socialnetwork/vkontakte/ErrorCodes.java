package com.azoft.poker.common.socialnetwork.vkontakte;

/**
 * Error codes for vkontakte
 */
public enum ErrorCodes {

    UNKNOWN(1),
    APPLICATION_IS_DISABLED(2),
    INCORRECT_SIGNATURE(4),
    USER_AUTHORIZATION_FAILED(5),
    TOO_MANY_REQUESTS(6),
    PERMISSION_IS_DENIED_BY_USER(7),
    INVALID_REQUEST(8),
    INVALID_USER_ID(113),
    INVALID_MESSAGE(120),
    INVALID_VOTES(151),
    PERMISSION_DENIED(500),
    NOT_ENOUGH_VOTES(502);

    private long errorCode;

    ErrorCodes(long errorCode) {
        this.errorCode = errorCode;
    }

    public long getErrorCode() {
        return errorCode;
    }

}