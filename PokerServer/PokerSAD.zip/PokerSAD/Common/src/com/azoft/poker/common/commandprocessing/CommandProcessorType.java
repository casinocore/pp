package com.azoft.poker.common.commandprocessing;

/**
 * Command processor type
 */
public enum CommandProcessorType {

    LOGIN_PROCESSOR,
    LOBBY_PROCESSOR,
    MTT_LOBBY_PROCESSOR,
    MTT_PROCESSOR,
    GAME_PROCESSOR,
    BOT_PROCESSOR;

    CommandProcessorType() {
    }

    public String toString() {
        return name();
    }
}
