package com.azoft.poker.common.bean;

public class SynchronousHand implements Comparable<SynchronousHand> {

    private Long startNumber;
    private Long finishedNumber;

    public SynchronousHand(Long startNumber, Long finishedNumber) {
        this.startNumber = startNumber;
        this.finishedNumber = finishedNumber;
    }

    public Long getStartNumber() {
        return startNumber;
    }

    public Long getFinishedNumber() {
        return finishedNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SynchronousHand hand = (SynchronousHand) o;

        if (!finishedNumber.equals(hand.finishedNumber)) return false;
        if (!startNumber.equals(hand.startNumber)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = startNumber.hashCode();
        result = 31 * result + finishedNumber.hashCode();
        return result;
    }

    public int compareTo(SynchronousHand synchronousHand) {
        return (synchronousHand.startNumber).compareTo(startNumber);
    }

    @Override
    public String toString() {
        return "SynchronousHand[startNumber = " + startNumber + ", finishedNumber = " + finishedNumber + "]";
    }

}
