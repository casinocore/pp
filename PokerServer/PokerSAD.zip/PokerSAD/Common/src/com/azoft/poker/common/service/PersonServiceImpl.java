package com.azoft.poker.common.service;

import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.personcache.PersonCacheManagerImpl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PersonServiceImpl implements PersonService {

    /**
     * Persons register (key: {@link com.azoft.poker.common.persistence.person.Person} id; value: username)
     */
    private final static Map<Long, String> personsRegister = new ConcurrentHashMap<Long, String>();

    private static PersonService instance = null;

    public static synchronized PersonService getInstance() {
        if (instance == null) {
            instance = new PersonServiceImpl();
        }
        return instance;
    }

    private PersonServiceImpl() {
    }

    public void initialization(Map<String, Object> parameters) {
        PersonCacheManagerImpl.getInstance().moveGameBalanceToBalance();
    }

    public void shutdown() {
        //empty
    }

    public void registerOnServer(Person person) {
        personsRegister.put(person.getId(), person.getUsername());
    }

    public void unregisterOnServer(Long userId) {
        personsRegister.remove(userId);
    }

    public boolean isExistsRegister(Long userId) {
        return personsRegister.containsKey(userId);
    }

}
