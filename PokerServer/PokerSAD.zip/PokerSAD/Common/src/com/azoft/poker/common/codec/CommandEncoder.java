package com.azoft.poker.common.codec;

import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.apache.mina.filter.codec.demux.MessageEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A {@link CommandEncoder} forwards the encoding to a command.
 */
public class CommandEncoder implements MessageEncoder<Command> {

    private final static Logger LOGGER = LoggerFactory.getLogger(CommandEncoder.class);

    public CommandEncoder() {
    }

    public void encode(IoSession session, Command command, ProtocolEncoderOutput out) throws Exception {
        IoBuffer buffer = command.encode();
        buffer.flip();
        out.write(buffer);
        out.flush();
    }
}