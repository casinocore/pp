package com.azoft.poker.common.persistence.configurationattribute;

/**
 * Configuration attribute type ID
 */
public enum ConfigurationAttributeTypeID {

    ACCESS_SERVER_ATTRIBUTE((short) 1),
    LOGIN_SERVER_ATTRIBUTE((short) 2),
    LOBBY_SERVER_ATTRIBUTE((short) 3),
    ADMIN_SERVER_ATTRIBUTE((short) 4);

    private short typeId;

    ConfigurationAttributeTypeID(short typeId) {
        this.typeId = typeId;
    }

    public short getTypeId() {
        return typeId;
    }

    public static ConfigurationAttributeTypeID valueOf(short typeId) {
        ConfigurationAttributeTypeID result = null;
        for (ConfigurationAttributeTypeID typeID : ConfigurationAttributeTypeID.values()) {
            if (typeID.getTypeId() == typeId) {
                result = typeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "ConfigurationAttributeTypeID{" +
                "name=" + name() +
                "typeId=" + typeId +
                '}';
    }
}