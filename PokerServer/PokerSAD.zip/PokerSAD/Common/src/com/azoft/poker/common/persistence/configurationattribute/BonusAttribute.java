package com.azoft.poker.common.persistence.configurationattribute;

/**
 * Bonus attribute
 */
public class BonusAttribute extends ConfigurationAttributeWrapper {

    public BonusAttribute(ConfigurationAttribute attribute) {
        super(attribute);
    }

    public Long getBonus() {
        return getLongAttribute();
    }

    public void setBonus(Long bonus) {
        setLongAttribute(bonus);
    }

}
