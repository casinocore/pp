package com.azoft.poker.common.persistence.event;

import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.persistence.BatchPersistenceManagerImpl;
import com.azoft.poker.common.publisher.Event;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Event entity manager
 */
public class EventEntityManagerImpl
        extends BatchPersistenceManagerImpl<EventEntity> implements EventEntityManager<EventEntity, Event> {

    private static final String MANAGER_TYPE = "EVENT_ENTITY";

    private static final String PARAMETER_FROM_DATE = "fromDate";
    private static final String PARAMETER_TO_DATE = "toDate";
    private static final String PARAMETER_REFERENCE_ID = "referenceId";
    private static final String PARAMETER_EVENT_TYPE_ID = "eventTypeId";
    private static final String PARAMETER_ATTRIBUTE_NAME = "name";

    private static final String FIELD_ID = "ee.id";
    private static final String FIELD_TIME_STAMP = "ee.time_stamp";
    private static final String FIELD_REFERENCE_ID = "ee.reference_id";

    private static final String QUERY_COUNT_BY_EVENT_FOR_PERIOD = "select count(ee.id) from event_entity ee" +
            " where ee.event_type = :" + PARAMETER_EVENT_TYPE_ID +
            " and ee.time_stamp between :" + PARAMETER_FROM_DATE + " and :" + PARAMETER_TO_DATE;
    private static final String QUERY_COUNT_USER_EVENTS = "select count(ee.id) from event_entity ee" +
            " where ee.reference_id = :" + PARAMETER_REFERENCE_ID +
            "   and ee.event_type = :" + PARAMETER_EVENT_TYPE_ID;
    private static final String QUERY_COUNT_USER_EVENTS_FOR_PERIOD = "select count(ee.id) from event_entity ee" +
            " where ee.reference_id = :" + PARAMETER_REFERENCE_ID +
            "   and ee.event_type = :" + PARAMETER_EVENT_TYPE_ID +
            " and ee.time_stamp between :" + PARAMETER_FROM_DATE + " and :" + PARAMETER_TO_DATE;
    private static final String QUERY_GET_USER_EVENT_LAST_TIME = "select max(ee.time_stamp) from event_entity ee" +
            " where ee.reference_id = :" + PARAMETER_REFERENCE_ID +
            "   and ee.event_type = :" + PARAMETER_EVENT_TYPE_ID;
    private static final String QUERY_MAX_BY_USER_EVENTS_VALUES = "select max(convert(if(eec.value!='null', eec.value, '0'), DECIMAL)) from event_entity ee" +
            " left join event_entity_ca eec on (eec.event_entity_id = ee.id and eec.name = :" + PARAMETER_ATTRIBUTE_NAME + ")" +
            " where ee.reference_id = :" + PARAMETER_REFERENCE_ID +
            "   and ee.event_type = :" + PARAMETER_EVENT_TYPE_ID;
    private static final String QUERY_SUM_BY_EVENTS_VALUES_FOR_PERIOD = "select sum(eec.value) from event_entity ee" +
            " left join event_entity_ca eec on (eec.event_entity_id = ee.id and eec.name = :" + PARAMETER_ATTRIBUTE_NAME + ")" +
            " where ee.event_type = :" + PARAMETER_EVENT_TYPE_ID +
            " and ee.time_stamp between :" + PARAMETER_FROM_DATE + " and :" + PARAMETER_TO_DATE;
    private static final String QUERY_SUM_BY_USER_EVENTS_VALUES = "select sum(eec.value) from event_entity ee" +
            " left join event_entity_ca eec on (eec.event_entity_id = ee.id and eec.name = :" + PARAMETER_ATTRIBUTE_NAME + ")" +
            " where ee.reference_id = :" + PARAMETER_REFERENCE_ID +
            "   and ee.event_type = :" + PARAMETER_EVENT_TYPE_ID;
    private static final String QUERY_GET_EVENT_FOR_PERIOD =
            "from EventEntity event where event.timeStamp between :fromDate and :toDate order by event.timeStamp";
    private static final String QUERY_GET_EVENT_TYPE_FOR_PERIOD =
            "from EventEntity event where event.eventType = :eventTypeId " +
                    "and event.timeStamp between :fromDate and :toDate order by event.timeStamp";
    private static final String QUERY_GET_USER_EVENT_TYPE =
            "from EventEntity event where event.referenceId = :referenceId and event.eventType = :eventTypeId";
    private static final String QUERY_GET_USER_EVENT_FOR_PERIOD =
            "from EventEntity event where event.referenceId = :referenceId and event.timeStamp between :fromDate and :toDate order by event.timeStamp";
    private static final String QUERY_GET_USER_EVENT =
            "from EventEntity event where event.referenceId = :referenceId order by event.timeStamp";
    private static final String QUERY_GET_EVENTS_BY_REFERENCE_MAX_FOR_PERIOD = "select " + FIELD_ID + ", " + FIELD_TIME_STAMP + ", " + FIELD_REFERENCE_ID + " " +
            "from event_entity ee " +
            "where ee.event_type = :" + PARAMETER_EVENT_TYPE_ID +
            " and " + FIELD_TIME_STAMP + " between :" + PARAMETER_FROM_DATE + " and :" + PARAMETER_TO_DATE +
            " and " + FIELD_REFERENCE_ID + " = (select max(ee2.reference_id) from event_entity ee2 " +
            "where ee2.event_type = :" + PARAMETER_EVENT_TYPE_ID +
            " and ee2.time_stamp between :" + PARAMETER_FROM_DATE + " and :" + PARAMETER_TO_DATE + ") " +
            "order by " + FIELD_TIME_STAMP;

    private final static Logger LOGGER = LoggerFactory.getLogger(EventEntityManagerImpl.class);

    private static EventEntityManager<EventEntity, Event> instance = null;

    public static synchronized EventEntityManager<EventEntity, Event> getInstance() {
        if (instance == null) {
            instance = new EventEntityManagerImpl();
        }
        return instance;
    }

    private EventEntityManagerImpl() {
        super(MANAGER_TYPE);
    }

    public void doEvent(Event event) {
        batchStore(event.getEntity());
    }

    @SuppressWarnings("unchecked")
    public Integer getCountEventsForPeriod(EventTypeID eventTypeID, Date fromDate, Date toDate) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(QUERY_COUNT_BY_EVENT_FOR_PERIOD)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setTimestamp(PARAMETER_FROM_DATE, fromDate).setTimestamp(PARAMETER_TO_DATE, toDate).uniqueResult();
        transaction.commit();
        return count.intValue();
    }

    @SuppressWarnings("unchecked")
    public Integer getCountUserEvents(Long userId, EventTypeID eventTypeID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(QUERY_COUNT_USER_EVENTS)
                .setLong(PARAMETER_REFERENCE_ID, userId)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .uniqueResult();
        transaction.commit();
        return count.intValue();
    }

    @SuppressWarnings("unchecked")
    public Integer getCountUserEventsForPeriod(Long userId, EventTypeID eventTypeID, Date fromDate, Date toDate) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(QUERY_COUNT_USER_EVENTS_FOR_PERIOD)
                .setLong(PARAMETER_REFERENCE_ID, userId)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setTimestamp(PARAMETER_FROM_DATE, fromDate).setTimestamp(PARAMETER_TO_DATE, toDate)
                .uniqueResult();
        transaction.commit();
        return count.intValue();
    }

    @SuppressWarnings("unchecked")
    public Date getUserEventLastTime(Long userId, EventTypeID eventTypeID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Date time = (Date) session.createSQLQuery(QUERY_GET_USER_EVENT_LAST_TIME)
                .setLong(PARAMETER_REFERENCE_ID, userId)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .uniqueResult();
        transaction.commit();
        return time;
    }

    @SuppressWarnings("unchecked")
    public BigDecimal getMaxUserEventsValues(Long userId, EventTypeID eventTypeID, String attributeName) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigDecimal count = (BigDecimal) session.createSQLQuery(QUERY_MAX_BY_USER_EVENTS_VALUES)
                .setLong(PARAMETER_REFERENCE_ID, userId)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setString(PARAMETER_ATTRIBUTE_NAME, attributeName)
                .uniqueResult();
        transaction.commit();
        if (count == null) {
            count = BigDecimal.ZERO;
        }
        return count;
    }

    @SuppressWarnings("unchecked")
    public Double getSumEventsValuesForPeriod(EventTypeID eventTypeID, Date fromDate, Date toDate, String attributeName) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Double count = (Double) session.createSQLQuery(QUERY_SUM_BY_EVENTS_VALUES_FOR_PERIOD)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setTimestamp(PARAMETER_FROM_DATE, fromDate).setTimestamp(PARAMETER_TO_DATE, toDate)
                .setString(PARAMETER_ATTRIBUTE_NAME, attributeName)
                .uniqueResult();
        transaction.commit();
        if (count == null) {
            count = 0d;
        }
        return count;
    }

    @SuppressWarnings("unchecked")
    public Double getSumUserEventsValues(Long userId, EventTypeID eventTypeID, String attributeName) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Double count = (Double) session.createSQLQuery(QUERY_SUM_BY_USER_EVENTS_VALUES)
                .setLong(PARAMETER_REFERENCE_ID, userId)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setString(PARAMETER_ATTRIBUTE_NAME, attributeName)
                .uniqueResult();
        transaction.commit();
        if (count == null) {
            count = 0d;
        }
        return count;
    }

    @SuppressWarnings("unchecked")
    public List<EventEntity> getEventEntitiesForPeriod(Date fromDate, Date toDate) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<EventEntity> list = session.createQuery(QUERY_GET_EVENT_FOR_PERIOD)
                .setTimestamp(PARAMETER_FROM_DATE, fromDate).setTimestamp(PARAMETER_TO_DATE, toDate).list();
        transaction.commit();
        return list;
    }

    public List<EventEntity> getEventEntitiesForPeriod(String fromStringDate, String toStringDate) {
        List<EventEntity> list = null;
        fromStringDate = DateHelper.prepareFromStringDateTime(fromStringDate);
        toStringDate = DateHelper.prepareToStringDateTime(toStringDate);
        Date fromDate = null;
        Date toDate = null;
        try {
            fromDate = DateHelper.attributeDateTimeFormat.parse(fromStringDate);
            toDate = DateHelper.attributeDateTimeFormat.parse(toStringDate);
            list = getEventEntitiesForPeriod(fromDate, toDate);
        } catch (ParseException e) {
            list = new ArrayList<EventEntity>();
            LOGGER.error("Invalid format fromStringDate or toStringDateTime");
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<EventEntity> getEventEntitiesForPeriod(Date fromDate, Date toDate, EventTypeID eventTypeID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<EventEntity> list = session.createQuery(QUERY_GET_EVENT_TYPE_FOR_PERIOD)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setTimestamp(PARAMETER_FROM_DATE, fromDate).setTimestamp(PARAMETER_TO_DATE, toDate).list();
        transaction.commit();
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<EventEntity> getUserEventEntities(Long userId, EventTypeID eventTypeID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<EventEntity> list = session.createQuery(QUERY_GET_USER_EVENT_TYPE)
                .setLong(PARAMETER_REFERENCE_ID, userId).setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .list();
        transaction.commit();
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<EventEntity> getUserEventEntitiesForPeriod(Date fromDate, Date toDate, Long userId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<EventEntity> list = session.createQuery(QUERY_GET_USER_EVENT_FOR_PERIOD)
                .setLong(PARAMETER_REFERENCE_ID, userId).setTimestamp(PARAMETER_FROM_DATE, fromDate).setTimestamp(PARAMETER_TO_DATE, toDate).list();
        transaction.commit();
        return list;
    }

    public List<EventEntity> getUserEventEntitiesForPeriod(String fromStringDate, String toStringDate, Long userId) {
        List<EventEntity> list = null;
        fromStringDate = DateHelper.prepareFromStringDateTime(fromStringDate);
        toStringDate = DateHelper.prepareToStringDateTime(toStringDate);
        Date fromDate = null;
        Date toDate = null;
        try {
            fromDate = DateHelper.attributeDateTimeFormat.parse(fromStringDate);
            toDate = DateHelper.attributeDateTimeFormat.parse(toStringDate);
            list = getUserEventEntitiesForPeriod(fromDate, toDate, userId);
        } catch (ParseException e) {
            list = new ArrayList<EventEntity>();
            LOGGER.error("Invalid format fromStringDate or toStringDateTime");
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<EventEntity> getUserEventEntities(Long userId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<EventEntity> list = session.createQuery(QUERY_GET_USER_EVENT)
                .setLong(PARAMETER_REFERENCE_ID, userId).list();
        transaction.commit();
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<EventEntity> getEventEntitiesByReferenceMaxForPeriod(EventTypeID eventTypeID, Date fromDate, Date toDate) {
        List<EventEntity> list = new ArrayList<EventEntity>();
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<Object[]> objects = session.createSQLQuery(QUERY_GET_EVENTS_BY_REFERENCE_MAX_FOR_PERIOD)
                .addScalar(FIELD_ID, Hibernate.LONG)
                .addScalar(FIELD_REFERENCE_ID, Hibernate.LONG)
                .addScalar(FIELD_TIME_STAMP, Hibernate.TIMESTAMP)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setTimestamp(PARAMETER_FROM_DATE, fromDate).setTimestamp(PARAMETER_TO_DATE, toDate)
                .list();
        transaction.commit();
        for (Object[] object : objects) {
            EventEntity event = new EventEntity(eventTypeID.getTypeId(), (Long) object[1]);
            event.setId((Long) (object[0]));
            event.setTimeStamp((Date) (object[2]));
            list.add(event);
        }
        return list;
    }

}
