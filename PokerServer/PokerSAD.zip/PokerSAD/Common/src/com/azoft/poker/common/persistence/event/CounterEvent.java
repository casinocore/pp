package com.azoft.poker.common.persistence.event;

import java.util.List;

/**
 * Counter event
 */
public class CounterEvent extends EventEntityWrapper {

    public CounterEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    public CounterEvent(Short eventType, Long referenceId) {
        super(eventType, referenceId);
    }

    public Long getCounter() {
        return getLongAttribute(COUNTER);
    }

    public void setCounter(Long counter) {
        setLongAttribute(COUNTER, counter);
    }

    public void incCounter() {
        Long counter = getCounter();
        if (counter == null) {
            counter = 1L;
        } else {
            counter++;
        }
        setCounter(counter);
    }

    public static void incCounterEvent(EventEntityManager eventEntityManager, Long personId, EventTypeID eventType) {
        List<EventEntity> events = eventEntityManager.getUserEventEntities(personId, eventType);
        CounterEvent event;
        if (events.isEmpty()) {
            event = new CounterEvent(eventType.getTypeId(), personId);
        } else {
            event = new CounterEvent(events.get(events.size() - 1));
        }
        event.incCounter();
        eventEntityManager.merge(event.getEntity());
    }

}
