package com.azoft.poker.common.socialnetwork.facebook;

import com.google.gson.Gson;

public class FBRequestUpdate {

    private String method;

    private FBRequestUpdateContent content;

    public FBRequestUpdate() {
        content = new FBRequestUpdateContent();
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public FBRequestUpdateContent getContent() {
        return content;
    }

    public void setContent(FBRequestUpdateContent content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "FBRequestBean{" +
                "method='" + method + '\'' +
                ", content=" + content +
                '}';
    }

    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

}

class FBRequestUpdateContent {

    private long order_id;

    private String status;

    private String test_mode;

    public FBRequestUpdateContent() {
    }

    public long getOrder_id() {
        return order_id;
    }

    public void setOrder_id(long order_id) {
        this.order_id = order_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTest_mode() {
        return test_mode;
    }

    public void setTest_mode(String test_mode) {
        this.test_mode = test_mode;
    }

    @Override
    public String toString() {
        return "FBRequestUpdateContent{" +
                "order_id=" + order_id +
                ", status='" + status + '\'' +
                ", test_mode='" + test_mode + '\'' +
                '}';
    }

    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

}
