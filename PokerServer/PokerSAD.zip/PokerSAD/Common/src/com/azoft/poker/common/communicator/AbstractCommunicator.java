package com.azoft.poker.common.communicator;

import com.azoft.poker.common.codec.AbstractCommandDecoder;
import com.azoft.poker.common.persistence.event.EventTypeID;
import com.azoft.poker.common.service.LifecycleService;
import org.apache.mina.core.service.IoHandlerAdapter;

import java.io.IOException;
import java.util.Map;

/**
 * Abstract communicator
 */
public abstract class AbstractCommunicator implements LifecycleService {

    public final static String SERVER_PORT_PARAMETER = "SERVER_PORT";
    public final static String HANDLER_ADAPTER_PARAMETER = "HANDLER_ADAPTER";
    public final static String COMMAND_DECODER_PARAMETER = "COMMAND_DECODER";

    private int serverPort;
    private IoHandlerAdapter handlerAdapter;
    private Class<? extends AbstractCommandDecoder> commandDecoder;

    public AbstractCommunicator() {
    }

    public int getServerPort() {
        return serverPort;
    }

    public IoHandlerAdapter getHandlerAdapter() {
        return handlerAdapter;
    }

    public Class<? extends AbstractCommandDecoder> getCommandDecoder() {
        return commandDecoder;
    }

    public void initialization(Map<String, Object> parameters) {
        initParameters(parameters);
    }

    protected void initParameters(Map<String, Object> parameters) {
        serverPort = (Integer) parameters.get(SERVER_PORT_PARAMETER);
        handlerAdapter = (IoHandlerAdapter) parameters.get(HANDLER_ADAPTER_PARAMETER);
        commandDecoder = (Class<? extends AbstractCommandDecoder>) parameters.get(COMMAND_DECODER_PARAMETER);
    }

    public abstract void open(Map<String, Object> parameters) throws IOException;

    public abstract void shutdown();

}
