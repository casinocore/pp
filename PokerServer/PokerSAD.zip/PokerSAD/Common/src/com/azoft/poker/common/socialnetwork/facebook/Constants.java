package com.azoft.poker.common.socialnetwork.facebook;

/**
 * Constants for facebook
 */
public class Constants {

    /**
     * Payment status - settled
     */
    public static final String FB_PAYMENT_STATUS_PLACED = "placed";

    /**
     * Payment status - settled
     */
    public static final String FB_PAYMENT_STATUS_SETTLED = "settled";

    /**
     * Payment status - canceled
     */
    public static final String FB_PAYMENT_STATUS_CANCELED = "canceled";

    /**
     * Payment status - canceled
     */
    public static final String FB_PAYMENT_STATUS_REFUNDED = "refunded";

    /**
     * Query method
     */
    public static final String QUERY_METHOD = "method";

    /**
     * Secret key
     */
    public static final String QUERY_SIG = "fb_sig";

    /**
     * 'payments_get_items' method
     */
    public static final String METHOD_PAYMENTS_GET_ITEMS = "payments_get_items";

    /**
     * 'payments_status_update' method
     */
    public static final String METHOD_PAYMENTS_STATUS_UPDATE = "payments_status_update";

    /**
     * 'signed_request' parameter name
     */
    public static final String PARAMETER_SIGNED_REQUEST = "signed_request";

    /**
     * 'order_id' parameter name
     */
    public static final String PARAMETER_ORDER_ID = "order_id";

    /**
     * 'order_info' parameter name.
     */
    public static final String PARAMETER_ORDER_INFO = "order_info";

    /**
     * 'item_id' parameter name
     */
    public static final String PARAMETER_ITEM_ID = "item_id";

    /**
     * 'title' parameter name
     */
    public static final String PARAMETER_TITLE = "title";

    /**
     * 'description' parameter name
     */
    public static final String PARAMETER_DESCRIPTION = "description";

    /**
     * 'image_url' parameter name
     */
    public static final String PARAMETER_IMAGE_URL = "image_url";

    /**
     * 'product_url' parameter name
     */
    public static final String PARAMETER_PRODUCT_URL = "product_url";

    /**
     * 'price' parameter name
     */
    public static final String PARAMETER_PRICE = "price";

    /**
     * 'data' parameter name
     */
    public static final String PARAMETER_DATA = "data";

    /**
     * 'status' parameter name
     */
    public static final String PARAMETER_STATUS = "status";

    /**
     * 'order_details' parameter name
     */
    public static final String PARAMETER_ORDER_DETAILS = "order_details";

}
