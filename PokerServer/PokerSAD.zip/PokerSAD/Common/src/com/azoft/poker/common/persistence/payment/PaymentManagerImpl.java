package com.azoft.poker.common.persistence.payment;

import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * Payment manager
 */
public class PaymentManagerImpl extends PersistenceManagerImpl<Payment> implements PaymentManager<Payment> {

    private static final String PARAMETER_TRANSACTION_ID = "transactionId";
    private static final String QUERY_GET_PAYMENT_BY_TRANSACTION_ID =
            "from Payment payment where payment.transactionId = :" + PARAMETER_TRANSACTION_ID;

    private static PaymentManager<Payment> instance = null;

    public static synchronized PaymentManager<Payment> getInstance() {
        if (instance == null) {
            instance = new PaymentManagerImpl();
        }
        return instance;
    }

    private PaymentManagerImpl() {
        super();
    }

    public Payment getPayment(String transactionId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Payment payment = (Payment) session.createQuery(QUERY_GET_PAYMENT_BY_TRANSACTION_ID)
                .setString(PARAMETER_TRANSACTION_ID, transactionId).uniqueResult();
        transaction.commit();
        return payment;
    }

}
