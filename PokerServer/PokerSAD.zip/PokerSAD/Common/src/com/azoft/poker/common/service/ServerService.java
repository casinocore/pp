package com.azoft.poker.common.service;

import com.azoft.poker.common.persistence.server.Server;

/**
 * Server service
 */
public interface ServerService {

    /**
     * Get access server
     *
     * @return access server
     */
    Server getAccessServer();

    /**
     * Get login server
     *
     * @return login server
     */
    Server getLoginServer();

    /**
     * Get admin server
     *
     * @return admin server
     */
    Server getAdminServer();

    /**
     * Get free lobby server
     *
     * @return free lobby server
     */
    Server getFreeLobbyServer();

}
