package com.azoft.poker.common.service;

import com.azoft.poker.common.persistence.tournament.TournamentManagerImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * Medalist service
 */
public class MedalistServiceImpl implements MedalistService {

    private static MedalistService instance = null;

    public static synchronized MedalistService getInstance() {
        if (instance == null) {
            instance = new MedalistServiceImpl();
        }
        return instance;
    }

    private MedalistServiceImpl() {
    }

    public List<MedalTypeID> getPlayerMedals(Long personId) {
        List<MedalTypeID> medals = new ArrayList<MedalTypeID>();
        Integer countTournamentWinner = TournamentManagerImpl.getInstance().getCountTournamentWinner(personId);
        if (countTournamentWinner > 0) {
            medals.add(MedalTypeID.GOLD_MEDAL);
        }
        return medals;
    }

}
