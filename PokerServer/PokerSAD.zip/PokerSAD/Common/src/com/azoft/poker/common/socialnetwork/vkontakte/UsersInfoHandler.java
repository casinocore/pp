package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.socialnetwork.bean.UserInfoBean;
import com.azoft.poker.common.socialnetwork.bean.UsersInfoBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import java.text.ParseException;
import java.util.Date;


/**
 * Users info handler for vkontakte
 */
public class UsersInfoHandler extends BaseSocialNetworkHandler<UsersInfoBean> {

    private final static Logger LOGGER = LoggerFactory.getLogger(UsersInfoHandler.class);

    private static final String LOCATION_DELIMITER = ", ";

    private UsersInfoBean usersInfoBean;
    private UserInfoBean userInfoBean;

    public UsersInfoHandler() {
        super();
        usersInfoBean = new UsersInfoBean();
        setBean(usersInfoBean);
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        super.startElement(uri, lName, qName, attr);

        String tag = getTag(lName, qName);
        if (tag.equals("response")) {
            usersInfoBean.getUsersInfo().clear();
        } else if (tag.equals("user")) {
            userInfoBean = new UserInfoBean();
        }
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        super.endElement(uri, lName, qName);

        String tag = getTag(lName, qName);
        if (tag.equals("response")) {
            usersInfoBean.setIfNullProcessingResult(RESULT_SUCCESS);
        } else if (tag.equals("user")) {
            usersInfoBean.addUserInfoBean(userInfoBean);
        } else if (tag.equals("uid")) {
            userInfoBean.setSocialNetworkID(text);
        } else if (tag.equals("first_name")) {
            userInfoBean.setFirstName(text);
        } else if (tag.equals("last_name")) {
            userInfoBean.setLastName(text);
        } else if (tag.equals("nickname")) {
            userInfoBean.setName(text);
        } else if (tag.equals("sex")) {
            userInfoBean.setSex(text);
        } else if (tag.equals("bdate")) {
            try {
                Date birthday = Constants.dateFormat.parse(text);
                userInfoBean.setDateOfBirth(birthday);
            } catch (ParseException e) {
                try {
                    Date birthday = Constants.shortDateFormat.parse(text);
                    userInfoBean.setDateOfBirth(birthday);
                } catch (ParseException ex) {
                    bean.setProcessingResult(RESULT_FAILURE);
                    LOGGER.error("Invalid format 'birthday': '" + text + "'");
                }
            }
        } else if (tag.equals("country")) {
            if (StringHelper.isEmpty(userInfoBean.getLocation())) {
                userInfoBean.setLocation(text);
            } else {
                userInfoBean.setLocation(text + LOCATION_DELIMITER + userInfoBean.getLocation());
            }
        } else if (tag.equals("city")) {
            if (StringHelper.isEmpty(userInfoBean.getLocation())) {
                userInfoBean.setLocation(text);
            } else {
                userInfoBean.setLocation(userInfoBean.getLocation() + LOCATION_DELIMITER + text);
            }
        }
    }

}