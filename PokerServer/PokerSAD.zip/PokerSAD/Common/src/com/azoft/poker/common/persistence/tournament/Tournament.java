package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.persistence.CustomAttributesEntity;

import java.util.Date;

public class Tournament extends CustomAttributesEntity {

    private static final long TIME_BEFORE_START_FOR_CANCELED = -1L;

    /*
      * Tournament name
      */
    private String name;

    private Byte type;

    private Byte status;

    private Long minPlayersCount;

    private Long maxPlayersCount;

    /*
      * tournament participation fee
      */
    private Long fee;

    private Byte winnerCount;

    /*
      * A number of chips on start of the tournament
      */
    private Long startChipsCount;

    private Date fromDate;

    private Date toDate;

    private String descriptor;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Long getMinPlayersCount() {
        return minPlayersCount;
    }

    public void setMinPlayersCount(Long minPlayersCount) {
        this.minPlayersCount = minPlayersCount;
    }

    public Long getMaxPlayersCount() {
        return maxPlayersCount;
    }

    public void setMaxPlayersCount(Long maxPlayersCount) {
        this.maxPlayersCount = maxPlayersCount;
    }

    public Long getFee() {
        return fee;
    }

    public void setFee(Long fee) {
        this.fee = fee;
    }

    public Byte getWinnerCount() {
        return winnerCount;
    }

    public void setWinnerCount(Byte winnerCount) {
        this.winnerCount = winnerCount;
    }

    public Long getStartChipsCount() {
        return startChipsCount;
    }

    public void setStartChipsCount(Long startChipsCount) {
        this.startChipsCount = startChipsCount;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getDescriptor() {
        return descriptor;
    }

    public void setDescriptor(String descriptor) {
        this.descriptor = descriptor;
    }

    public long calculateTimeBeforeStart() {
        long result = 0L;
        if (status == TournamentStatusID.CANCELED.getTypeId()) {
            result = TIME_BEFORE_START_FOR_CANCELED;
        } else {
            if (getFromDate() != null) {
                long timeBeforeStart = getFromDate().getTime() - System.currentTimeMillis();
                if (timeBeforeStart > 0) {
                    result = timeBeforeStart;
                }
            }
        }
        return result;
    }

    public long calculateTimeBeforeEnd() {
        long result = 0L;
        if (getToDate() != null) {
            long timeBeforeEnd = getToDate().getTime() - System.currentTimeMillis();
            if (timeBeforeEnd > 0) {
                result = timeBeforeEnd;
            }
        }
        return result;
    }

    public Tournament() {
        super();
    }

    public Tournament(TournamentTypeID tournamentTypeID, String name, Long fee, Long startChipsCount) {
        super();
        this.type = tournamentTypeID.getTypeId();
        this.name = name;
        this.fee = fee;
        this.startChipsCount = startChipsCount;
    }

    @Override
    public String toString() {
        return "Tournament{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", status=" + status +
                ", minPlayersCount=" + minPlayersCount +
                ", maxPlayersCount=" + maxPlayersCount +
                ", fee=" + fee +
                ", winnerCount=" + winnerCount +
                ", startChipsCount=" + startChipsCount +
                ", fromDate=" + fromDate +
                ", toDate=" + toDate +
                "} > " + super.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (this.getId() == null) return false;
        if (!(o instanceof Tournament)) return false;
        return this.getId().equals(((Tournament) o).getId());
    }


}
