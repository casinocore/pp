package com.azoft.poker.common.persistence.event;

import org.apache.mina.core.session.IoSession;

import java.util.Date;

/**
 * Factory event impl
 */
public class FactoryEventImpl {

    public static void sessionStart(IoSession session) {
        session.setAttribute(EventEntityConstants.SESSION_TIME, new Date());
    }

    public static EventEntity createSessionEndEvent(IoSession session, Long userId) {
        SessionEndEvent event = new SessionEndEvent(EventTypeID.SESSION_END.getTypeId(), userId);
        Date startSession = (Date) session.getAttribute(EventEntityConstants.SESSION_TIME);
        if (startSession != null) {
            Long sessionTime = event.getEntity().getTimeStamp().getTime() - startSession.getTime();
            event.setSessionTime(sessionTime);
        }
        return event.getEntity();
    }

}
