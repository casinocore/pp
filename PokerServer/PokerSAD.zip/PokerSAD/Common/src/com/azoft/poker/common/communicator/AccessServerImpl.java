package com.azoft.poker.common.communicator;

import com.azoft.poker.common.persistence.server.ServerTypeID;
import com.azoft.poker.common.service.LifecycleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Access server for flush client
 */
public class AccessServerImpl implements LifecycleService {

    private final static Logger LOGGER = LoggerFactory.getLogger(AccessServerImpl.class);

    private static final int BUFFER_SIZE = 1024;

    private final static String type = ServerTypeID.ACCESS_SERVER.name();

    public final static String SERVER_PORT_PARAMETER = "SERVER_PORT";

    public final static String ACCESS_RESPONSE = "<cross-domain-policy>" +
            "  <site-control permitted-cross-domain-policies='master-only'/>" +
            "  <allow-access-from domain='*' to-ports='*' />" +
            "</cross-domain-policy>";

    /**
     * Access processor termination timeout
     */
    private final static long ACCESS_PROCESSOR_TERMINATION_TIMEOUT = 1000;

    private int serverPort;

    private ServerSocket ss;

    private final ExecutorService executor;

    private final AccessServerRunnable accessServerRunnable;

    private volatile boolean startedFlag = false;

    public AccessServerImpl() {
        executor = Executors.newSingleThreadExecutor();
        accessServerRunnable = new AccessServerRunnable();
    }

    public void initialization(Map<String, Object> parameters) {
        serverPort = (Integer) parameters.get(SERVER_PORT_PARAMETER);
        try {
            ss = new ServerSocket(serverPort);
            startedFlag = true;
            executor.execute(accessServerRunnable);
            LOGGER.info(type + "; startedFlag: " + startedFlag);
            LOGGER.info("Access server listening on port " + serverPort);
        } catch (IOException e) {
            LOGGER.info("Access server", e);
        }
    }

    public void shutdown() {
        try {
            if (startedFlag) {
                ss.close();
            }
        } catch (IOException e) {
            LOGGER.error("Access server shutdown", e);
        } finally {
            if (startedFlag) {
                LOGGER.info("Shutdown port: " + serverPort);
            }
        }
        boolean terminated = false;
        try {
            accessServerRunnable.cancel();
            executor.shutdown();
            terminated = executor.awaitTermination(ACCESS_PROCESSOR_TERMINATION_TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOGGER.error(type + ": shutdown", e);
        }
        LOGGER.info(type + ": shutdown: " + terminated);
    }

    private void execute() {
        try {
            Socket s = ss.accept();
            new ConnectionHandler(s);
        } catch (IOException e) {
            LOGGER.error("Access server run", e);
        } finally {
        }
    }

    /**
     * Access server runnable
     */
    private class AccessServerRunnable implements Runnable {

        private volatile boolean cancelled = false;

        public AccessServerRunnable() {
            super();
        }

        public void cancel() {
            cancelled = true;
        }

        public void run() {
            while (!cancelled) {
                if (startedFlag) {
                    execute();
                }
            }
        }
    }


    class ConnectionHandler implements Runnable {
        private Socket socket;

        public ConnectionHandler(Socket socket) {
            this.socket = socket;

            Thread t = new Thread(this);
            t.start();
        }

        public void run() {
            OutputStream os = null;
            try {
                os = socket.getOutputStream();
                InputStream is = socket.getInputStream();

                byte[] bf = new byte[BUFFER_SIZE];
                int readed = is.read(bf);
                if (readed != -1 && readed > 0) {
                    LOGGER.debug("readed " + readed + " : " + new String(bf, 0, readed));
                } else {
                    LOGGER.debug("empty readed");
                }

                byte[] buf = ACCESS_RESPONSE.getBytes();
                os.write(buf, 0, buf.length);
                os.flush();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (os != null) {
                    try {
                        os.close();
                    } catch (IOException e) {
                        //empty
                    }
                }
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                }
            }
        }
    }

}
