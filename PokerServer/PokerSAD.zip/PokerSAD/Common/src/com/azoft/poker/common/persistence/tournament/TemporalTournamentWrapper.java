package com.azoft.poker.common.persistence.tournament;

/**
 * Temporal tournament wrapper
 */
public class TemporalTournamentWrapper extends TournamentWrapper {

    public TemporalTournamentWrapper(Tournament tournament) {
        super(tournament);
    }

}
