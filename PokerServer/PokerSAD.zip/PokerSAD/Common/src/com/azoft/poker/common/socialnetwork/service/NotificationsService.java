package com.azoft.poker.common.socialnetwork.service;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.service.LifecycleService;
import com.azoft.poker.common.socialnetwork.client.SocialNetworkClient;

import java.util.Map;

/**
 * Notifications service interface
 */
public interface NotificationsService extends LifecycleService {

    /**
     * Create social network client
     *
     * @param parameters parameters
     * @return social network client
     * @throws CommonException CommonException
     */
    SocialNetworkClient createSocialNetworkClient(Map<String, Object> parameters) throws CommonException;

    boolean isFlagON();

    int getBatchMax();

    /**
     * Send notifications by person table
     *
     * @param message notification
     */
    void sendNotifications(String message);

}
