package com.azoft.poker.common.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public abstract class RequestCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(RequestCommand.class);

    /**
     * Body content содержит информацию которую необходимо отпроцессить.
     */
    private static final byte NOT_EXISTS_ERROR = 0;

    private static final byte EXISTS_ERROR = 1;

    /**
     * Empty value
     */
    protected static final int EMPTY_VALUE = -1;

    /**
     * Command body, Command ID - Уникальный идентификатор команды
     */
    private int commandID;

    /**
     * Command body, Error flag
     * 0 – Body content содержит информацию которую необходимо отпроцессить.
     * 1 – Body content содержит информацию об ошибке
     */
    private byte errorFlag = NOT_EXISTS_ERROR;

    /**
     * Error code
     */
    private int errorCode;

    public RequestCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public int getCommandID() {
        return commandID;
    }

    public void setCommandID(int commandID) {
        this.commandID = commandID;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
        this.errorFlag = EXISTS_ERROR;
    }

    public boolean isExistsError() {
        return errorFlag == EXISTS_ERROR;
    }

    @Override
    public String toString() {
        return super.toString() + " - RequestCommand{" +
                "commandID=" + commandID +
                ", errorFlag=" + errorFlag +
                ", errorCode=" + errorCode +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        commandID = dis.readInt();
        errorFlag = dis.readByte();
        if (isExistsError()) {
            errorCode = dis.readInt();
        }
    }

    public void encodeBody(DataOutputStream dos) throws IOException {
        //prepare body content
        dos.writeInt(commandID);
        dos.writeByte(errorFlag);
        if (isExistsError()) {
            dos.writeInt(errorCode);
        }
    }

}
