package com.azoft.poker.common.persistence.person;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.persistence.BatchPersistenceManager;

/**
 * Person manager interface
 */
public interface PersonManager extends BatchPersistenceManager<Person> {

    /**
     * Retrieve all <code>Person</code>s from the data store.
     * 
     * @return a <code>List</code> of <code>Person</code>s
     */
    List<Person> getPersons();

    /**
     * Retrieve by query <code>Person</code>s from the data store.
     * 
     * @return a <code>List</code> of <code>Person</code>s
     */
    List<Person> getPersons(String query);

    List<Person> getPersons(PersonSearchParams params, Long start, Integer count);

    int getPersonCount(PersonSearchParams params);

    /**
     * Retrieve count of <code>Person</code>s from the data store.
     * 
     * @return a count of <code>Person</code>s
     */
    Integer getCountPersons();

    /**
     * Retrieve count of active players (<code>Person</code>s) from the data
     * store.
     * 
     * @return a count of active players (<code>Person</code>s)
     */
    Integer getCountActivePlayers();

    /**
     * Retrieve count of active players (<code>Person</code>s) from
     * <code>fromDate</code> to <code>toDate</code>..
     * 
     * @param fromDate
     *            from date
     * @param toDate
     *            to date
     * @return a count of active players (<code>Person</code>s)
     */
    Integer getCountActivePlayersForPeriod(Date fromDate, Date toDate);

    /**
     * Retrieve count of active new players (<code>Person</code>s) from
     * <code>fromDate</code> to <code>toDate</code>..
     * 
     * @param fromDate
     *            from date
     * @param toDate
     *            to date
     * @return a count of active new players (<code>Person</code>s)
     */
    Integer getCountActiveNewPlayersForPeriod(Date fromDate, Date toDate);

    /**
     * Retrieve count of payment players (<code>Person</code>s) from
     * <code>fromDate</code> to <code>toDate</code>..
     * 
     * @param fromDate
     *            from date
     * @param toDate
     *            to date
     * @return a count of payment players (<code>Person</code>s)
     */
    Integer getCountPaymentPlayersForPeriod(Date fromDate, Date toDate);

    /**
     * Retrieve count of payment new players (<code>Person</code>s) from
     * <code>fromDate</code> to <code>toDate</code>..
     * 
     * @param fromDate
     *            from date
     * @param toDate
     *            to date
     * @return a count of payment new players (<code>Person</code>s)
     */
    Integer getCountPaymentNewPlayersForPeriod(Date fromDate, Date toDate);

    /**
     * Retrieve new <code>Person</code>s from <code>fromDate</code> to
     * <code>toDate</code>.
     * 
     * @param fromDate
     *            from date
     * @param toDate
     *            to date
     * @return a <code>List</code> of new <code>Person</code>s
     */
    List<Person> getNewPersonsForPeriod(Date fromDate, Date toDate);

    /**
     * Retrieve new <code>Person</code>s from <code>fromStringDate</code> to
     * <code>toStringDate</code>.
     * 
     * @param fromStringDate
     *            from date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @param toStringDate
     *            to date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @return a <code>List</code> of new <code>Person</code>s
     */
    List<Person> getNewPersonsForPeriod(String fromStringDate,
            String toStringDate);

    /**
     * Retrieve count of new <code>Person</code>s from <code>fromDate</code> to
     * <code>toDate</code>.
     * 
     * @param fromDate
     *            from date
     * @param toDate
     *            to date
     * @return a count of new <code>Person</code>s
     */
    Integer getCountNewPersonsForPeriod(Date fromDate, Date toDate);

    /**
     * Retrieve count of new <code>Person</code>s from
     * <code>fromStringDate</code> to <code>toStringDate</code>.
     * 
     * @param fromStringDate
     *            from date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @param toStringDate
     *            to date (format "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss")
     * @return a count of new <code>Person</code>s
     */
    Integer getCountNewPersonsForPeriod(String fromStringDate,
            String toStringDate);

    /**
     * Retrieve <code>Person</code> from the data store by person name
     * 
     * @param personName
     *            person name to search for
     * @return a <code>personName</code> of collection <code>Person</code> (or
     *         null if none found)
     */
    Collection<Person> findPersons(String personName);

    /**
     * Retrieve <code>Person</code> from the data store by username
     * 
     * @param username
     *            username to search for
     * @return the <code>Person</code> if found if not found null
     */
    Person getPerson(String username);

    /**
     * Retrieve an <code>Person</code> from the data store by id.
     * 
     * @param personId
     *            the id to search for person
     * @return the <code>Person</code> if found if not found
     */
    Person loadPerson(long personId);

    /**
     * Get an <code>Person</code> from the data store by id.
     * 
     * @param personId
     *            the id to search for person
     * @return the <code>Person</code> if found if not found
     */
    Person getPerson(long personId);

    /**
     * Save an <code>Person</code> to the data store, either inserting or
     * updating it.
     * 
     * @param person
     *            the <code>Person</code> to save
     */
    void storePerson(Person person);

    /**
     * Delete <code>Person</code>.
     * 
     * @param person
     *            the <code>Person</code> to delete
     */
    Person deletePerson(Person person);

    /**
     * Get an <code>Person</code>s from the data store by socialNetworkIDs list
     * 
     * @param socialNetworkIDs
     *            socialNetworkID list
     * @return persons list
     */
    List<Person> getPersonsBySNIDs(List<String> socialNetworkIDs);

    /**
     * Get an <code>Person</code> from the data store by socialNetworkID
     * 
     * @param socialNetworkID
     *            socialNetworkID
     * @return person
     */
    Person getPersonBySNID(String socialNetworkID);

    /**
     * Get top players
     * 
     * @param topNumber
     *            top number
     * @return top players list
     */
    List<InfoPlayerBean> getTopPlayers(int topNumber);

    /**
     * Get top invited friends
     * 
     * @param topNumber
     *            top number
     * @return top invited friends list
     */
    List<InvitedFriendsBean> getTopInvitedFriends(int topNumber);

    /**
     * Get player rank by balance
     * 
     * @param totalBalance
     *            total balance
     * @return player rank by balance
     */
    Long getRankByBalance(Long totalBalance);

    /**
     * Get player rank by invited friends
     * 
     * @param invitedFriendsCount
     *            total balance
     * @return player rank by invited friends
     */
    Long getRankByInvitedFriends(Integer invitedFriendsCount);

    /**
     * Get count invited friends
     * 
     * @param personId
     *            person id
     * @return count invited friends
     */
    Integer getCountInvitedFriends(long personId);

    /**
     * Add inner friend
     * 
     * @param personId
     *            person id
     * @param friendId
     *            friend person id
     */
    void addFriend(long personId, long friendId) throws CommonException;

    /**
     * Delete inner friend
     * 
     * @param personId
     *            person id
     * @param friendId
     *            friend person id
     */
    void deleteFriend(long personId, long friendId) throws CommonException;

    /**
     * Get friend link
     * 
     * @param personId
     *            person id
     * @param friendId
     *            friend id
     * @return friend link
     */
    FriendLink getFriendLink(long personId, long friendId);

    /**
     * Retrieve by person id friends from the data store.
     * 
     * @param personId
     *            person id
     * @return friends list
     */
    List<Person> getFriends(long personId);

    /**
     * Get count active invited friends.
     * 
     * @param personId
     *            person id
     * @param fromDate
     *            from date
     * @param toDate
     *            to date
     * @return count active invited friends
     */
    public Integer getCountActiveInvitedFriends(long personId, Date fromDate,
            Date toDate);

    /**
     * Get count new invited friends.
     * 
     * @param personId
     *            person id
     * @return count new invited friends
     */
    public Integer getCountNewInvitedFriends(long personId);

    /**
     * Set not exists new invited friends.
     * 
     * @param personId
     *            person id
     * @return count
     */
    public int setNotExistsNewInvitedFriends(long personId);

    void addChips(Long personId, Long value);

}
