package com.azoft.poker.common.socialnetwork.facebook;

import com.google.gson.Gson;

public class FBRequestBean {

    private long order_id;

    private String status;

    private String order_info;

    private String test_mode;

    private String order_details;

    public FBRequestBean() {
    }

    public long getOrder_id() {
        return order_id;
    }

    public void setOrder_id(long order_id) {
        this.order_id = order_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrder_info() {
        return order_info;
    }

    public void setOrder_info(String order_info) {
        this.order_info = order_info;
    }

    public String getTest_mode() {
        return test_mode;
    }

    public void setTest_mode(String test_mode) {
        this.test_mode = test_mode;
    }

    public String getOrder_details() {
        return order_details;
    }

    public void setOrder_details(String order_details) {
        this.order_details = order_details;
    }

    @Override
    public String toString() {
        return "FBRequestBean{" +
                "order_id=" + order_id +
                ", status='" + status + '\'' +
                ", order_info='" + order_info + '\'' +
                ", test_mode='" + test_mode + '\'' +
                ", order_details='" + order_details + '\'' +
                '}';
    }

    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

}
