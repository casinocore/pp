package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.jaxp.AbstractHandler;
import com.azoft.poker.common.socialnetwork.client.SocialNetworkHandlerFactory;

/**
 * Social network handler factory for schoolmate
 */
public class SocialNetworkHandlerFactoryImpl implements SocialNetworkHandlerFactory {

    public SocialNetworkHandlerFactoryImpl() {
    }

    public AbstractHandler createHandler(String method) {
        AbstractHandler handler = null;
        if (Constants.METHOD_USERS_GET_INFO.equals(method)) {
            handler = new UsersInfoHandler();
        } else if (Constants.METHOD_FRIENDS_GET.equals(method)) {
            handler = new FriendsHandler();
        } else if (Constants.METHOD_AUTH_LOGIN.equals(method)) {
            handler = new LoginHandler();
        } else if (Constants.METHOD_NOTIFICATIONS_SEND_SIMPLE.equals(method)) {
            handler = new SendNotificationHandler();
        }
        return handler;
    }

}
