package com.azoft.poker.common.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import org.apache.mina.core.session.IoSession;

import java.io.DataOutputStream;
import java.io.IOException;

public class EmptyCommand extends Command {

    public EmptyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
    }

}
