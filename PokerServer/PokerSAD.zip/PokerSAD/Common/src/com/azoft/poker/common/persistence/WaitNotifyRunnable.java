package com.azoft.poker.common.persistence;

/**
 * Wait-notify event runnable
 */
public abstract class WaitNotifyRunnable implements Runnable {

    private final WaitNotify waitNotify = new WaitNotify();

    private volatile boolean cancelled = false;

    public WaitNotifyRunnable() {
        super();
    }

    public void cancel() {
        cancelled = true;
    }

    public WaitNotify getWaitNotify() {
        return waitNotify;
    }

    /**
     * Run
     */
    public void run() {
        while (!cancelled) {
            runBody();
            waitNotify.doWait();
        }
        shutdown();
    }

    /**
     * Run body
     */
    public abstract void runBody();

    /**
     * Shutdown
     */
    public abstract void shutdown();

}
