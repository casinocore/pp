package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.exception.CommonException;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.Map;

/**
 * Abstract XML http client
 */
public abstract class AbstractHttpClient {

    private final static Logger LOGGER = LoggerFactory.getLogger(AbstractHttpClient.class);

    public static final String UTF8_CHARSET = "UTF-8";
    private static final int ONE_CONNECTOR = 1;
    public static final int SOCKET_TIMEOUT = 15 * 60 * 1000; // 15 min
    public static final int DEFAULT_CONNECT_TIMEOUT = 60 * 60 * 1000; // 1 hour
    private static final int DEFAULT_BUFFER_SIZE = 1024;

    private String serverUri;

    private int maxConnection;

    private HttpClient client;

    public AbstractHttpClient() {
    }

    public String getServerUri() {
        return serverUri;
    }

    public int getMaxConnection() {
        return maxConnection;
    }

    public void initialization(String serverUri) throws CommonException {
        this.serverUri = serverUri;
        this.maxConnection = ONE_CONNECTOR;
        client = new HttpClient();
        initializationParams();
    }

    public void initialization(String serverUri, int maxConnection) throws CommonException {
        this.serverUri = serverUri;
        this.maxConnection = maxConnection;
        MultiThreadedHttpConnectionManager multiThreadedHttpConnectionManager =
                new MultiThreadedHttpConnectionManager();
        HttpConnectionManagerParams params = new HttpConnectionManagerParams();
        params.setDefaultMaxConnectionsPerHost(maxConnection);
        multiThreadedHttpConnectionManager.setParams(params);
        client = new HttpClient(multiThreadedHttpConnectionManager);
        initializationParams();
    }

    private void initializationParams() {
        client.getParams().setSoTimeout(SOCKET_TIMEOUT);
        client.getParams().setParameter("http.connection.timeout", DEFAULT_CONNECT_TIMEOUT);
    }

    protected void verifyParameters() throws CommonException {
        if (serverUri == null) {
            throw new CommonException("Parameters for connection was not set. " +
                    "Must be set 'serverUri'");
        }
    }

    public HttpMethod formPostMethod(Map<String, String> params) throws CommonException {
        //LOGGER.debug("Post method URI: '" + serverUri + "'" + "; params: '" + params + "'");
        PostMethod method = new PostMethod(serverUri);
        method.getParams().setContentCharset(UTF8_CHARSET);
        for (Map.Entry<String, String> entry : params.entrySet()) {
            method.addParameter(entry.getKey(), entry.getValue());
        }
        return method;
    }

    protected HttpMethod formGetMethod(Map<String, String> params) throws CommonException {
        StringBuffer url = new StringBuffer("");
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (url.length() > 0) {
                url.append("&");
            }
            url.append(entry.getKey()).append("=").append(entry.getValue());
        }
        if (url.length() > 0) {
            url.insert(0, "?");
        }
        url.insert(0, serverUri);
        LOGGER.debug("Get method URI: '" + url.toString() + "'");
        GetMethod method = new GetMethod(url.toString());
        method.getParams().setContentCharset(UTF8_CHARSET);
        return method;
    }

    protected InputStream executeMethod(HttpMethod method) throws CommonException {
        InputStream is;
        try {
            int statusCode = client.executeMethod(method);
            if (statusCode != HttpStatus.SC_OK) {
                throw new CommonException("Error response. Http status line: " + method.getStatusLine().toString());
            }
            is = method.getResponseBodyAsStream();
        } catch (HttpException ex) {
            throw new CommonException("http error", ex);
        } catch (IOException ex) {
            throw new CommonException("io error", ex);
        }
        return is;
    }

    protected String executePostMethod(Map<String, String> params) throws CommonException {
        HttpMethod method = formPostMethod(params);
        InputStream is = executeMethod(method);
        return convertStreamToString(is);
    }

    protected String executeGetMethod(Map<String, String> params) throws CommonException {
        HttpMethod method = formGetMethod(params);
        InputStream is = executeMethod(method);
        return convertStreamToString(is);
    }

    private String convertStreamToString(InputStream is)
            throws CommonException {
        /*
         * To convert the InputStream to String we use the
         * Reader.read(char[] buffer) method. We iterate until the
         * Reader return -1 which means there's no more data to
         * read. We use the StringWriter class to produce the string.
         */
        if (is != null) {
            Writer writer = new StringWriter();

            char[] buffer = new char[DEFAULT_BUFFER_SIZE];
            try {
                try {
                    Reader reader = new BufferedReader(
                            new InputStreamReader(is, UTF8_CHARSET));
                    int n;
                    while ((n = reader.read(buffer)) != -ONE_CONNECTOR) {
                        writer.write(buffer, 0, n);
                    }
                } finally {
                    is.close();
                }
            } catch (IOException e) {
                throw new CommonException("convertStreamToString", e);
            }
            return writer.toString();
        } else {
            return "";
        }
    }

    protected String executePostMethodString(Map<String, String> params) throws CommonException {
        String response;
        HttpMethod method = formPostMethod(params);
        try {
            int statusCode = client.executeMethod(method);
            if (statusCode != HttpStatus.SC_OK) {
                throw new CommonException("Error response. Http status line: " + method.getStatusLine().toString());
            }
            response = method.getResponseBodyAsString();
            LOGGER.debug("executeMethod response: '" + response + "'");
        } catch (HttpException ex) {
            throw new CommonException("http error", ex);
        } catch (IOException ex) {
            throw new CommonException("io error", ex);
        }
        return response;
    }

}
