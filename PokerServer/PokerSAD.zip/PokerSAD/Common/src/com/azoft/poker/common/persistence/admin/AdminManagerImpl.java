package com.azoft.poker.common.persistence.admin;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.azoft.poker.common.persistence.PersistenceManagerImpl;

public class AdminManagerImpl extends PersistenceManagerImpl<Admin> implements
		AdminManager {

	private static final String ENTITY_NAME = "Admin";
	private static final String FIELD_LOGIN = "login";
	private static final String QUERY_GET_BY_LOGIN = "from " + ENTITY_NAME
			+ " a where a." + FIELD_LOGIN + " = :" + FIELD_LOGIN;

	private static AdminManager instance = null;

	public static synchronized AdminManager getInstance() {
		if (instance == null) {
			instance = new AdminManagerImpl();
		}
		return instance;
	}

	private AdminManagerImpl() {

	}

	public Admin findPersonByLogin(String login) {
		Session session = getSession();
		Transaction transaction = session.beginTransaction();
		transaction.begin();
		Admin admin = (Admin) session.createQuery(QUERY_GET_BY_LOGIN)
				.setString(FIELD_LOGIN, login).uniqueResult();
		transaction.commit();
		return admin;
	}

}
