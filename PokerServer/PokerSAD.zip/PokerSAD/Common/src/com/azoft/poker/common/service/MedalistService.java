package com.azoft.poker.common.service;

import java.util.List;

/**
 * Medalist service interface
 */
public interface MedalistService {

    List<MedalTypeID> getPlayerMedals(Long personId);

}
