package com.azoft.poker.common.service;

import com.azoft.poker.common.persistence.person.Person;

public interface PersonService extends LifecycleService {

    void registerOnServer(Person person);

    void unregisterOnServer(Long userId);

    boolean isExistsRegister(Long userId);

}
