package com.azoft.poker.common.persistence.person;

/**
 * Invited friends bean
 */
public class InvitedFriendsBean extends InfoPlayerBean {

    private Integer invitedFriendsCount;

    public InvitedFriendsBean() {
    }

    public Integer getInvitedFriendsCount() {
        return invitedFriendsCount;
    }

    public void setInvitedFriendsCount(Integer invitedFriendsCount) {
        this.invitedFriendsCount = invitedFriendsCount;
    }

}
