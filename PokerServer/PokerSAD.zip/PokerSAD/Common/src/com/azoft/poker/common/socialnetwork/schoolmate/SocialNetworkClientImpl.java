package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.socialnetwork.bean.*;
import com.azoft.poker.common.socialnetwork.client.AbstractSocialNetworkClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Social network client for schoolmate
 */
public class SocialNetworkClientImpl extends AbstractSocialNetworkClient {

    private final static Logger LOGGER = LoggerFactory.getLogger(SocialNetworkClientImpl.class);

    private static final int MAX_NUMBER_IDS = 100;

    public SocialNetworkClientImpl() {
        super(new SocialNetworkHandlerFactoryImpl());
    }

    private Map<String, String> prepareCommonParameters() throws CommonException {
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put(Constants.QUERY_APPLICATION_KEY, getApplicationKey());
        parameters.put(Constants.QUERY_CALL_ID, String.valueOf(incCallId()));
        parameters.put(Constants.QUERY_FORMAT, Constants.QUERY_FORMAT_XML_VALUE);
        return parameters;
    }

    public int getMaxNumberForMethodGetUsersInfo() {
        return MAX_NUMBER_IDS;
    }

    public UsersInfoBean methodGetUsersInfo(List<String> socialNetworkIDList) throws CommonException {
        String uids = formSocialNetworkIDParameter(socialNetworkIDList, MAX_NUMBER_IDS);
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_USERS_GET_INFO);
        parameters.put(Constants.PARAMETER_NAME_UIDS, uids);
        parameters.put(Constants.PARAMETER_NAME_FIELDS, Constants.PARAMETER_VALUE_FIELDS);
        addSignature(parameters);
        return (UsersInfoBean) call(parameters);
    }

    public FriendsBean methodGetFriends(String socialNetworkID) throws CommonException {
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_FRIENDS_GET);
        parameters.put(Constants.PARAMETER_NAME_UID, socialNetworkID);
        addSignature(parameters);
        return (FriendsBean) call(parameters);
    }

    public LoginBean methodLogin(String login, String password, boolean genToken) throws CommonException {
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_AUTH_LOGIN);
        parameters.put(Constants.PARAMETER_USER_NAME, login);
        parameters.put(Constants.PARAMETER_PASSWORD, password);
        parameters.put(Constants.PARAMETER_GEN_TOKEN, String.valueOf(genToken));
        addSignature(parameters);
        return (LoginBean) call(parameters);
    }

    public SocialNetworkMoneyBean methodPayment(String socialNetworkID, long amount, boolean testMode) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodPayment");
    }

    public SocialNetworkMoneyBean methodGetBalance(String socialNetworkID) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodGetBalance");
    }

    public SendNotificationBean methodSendNotification(String socialNetworkIDString, String message)
            throws CommonException {
        Map<String, String> parameters = prepareCommonParameters();
        parameters.put(Constants.QUERY_METHOD, Constants.METHOD_NOTIFICATIONS_SEND_SIMPLE);
        parameters.put(Constants.PARAMETER_NAME_UID, socialNetworkIDString);
        parameters.put(Constants.PARAMETER_TEXT, message);
        addSignature(parameters);
        return (SendNotificationBean) call(parameters);
    }

    public List<SendNotificationBean> methodSendNotifications(List<String> socialNetworkIDList, String message)
            throws CommonException {
        List<SendNotificationBean> result = new ArrayList<SendNotificationBean>();
        for (String socialNetworkID : socialNetworkIDList) {
            SendNotificationBean bean = methodSendNotification(socialNetworkID, message);
/*
            String logMessage = "socialNetworkID: " + socialNetworkID + "; " + bean.getProcessingResult();
            if (!bean.isSuccessResult()) {
                logMessage += bean.getErrorMessage();    
            }
            LOGGER.debug(logMessage);
*/
            result.add(bean);
        }
        return result;
    }

}
