package com.azoft.poker.common.persistence.server;

import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Collection;
import java.util.List;

public class ServerManagerImpl extends PersistenceManagerImpl implements ServerManager {

    private static final String QUERY_GET_SERVERS = "from Server server order by server.serverType";
    private static final String SERVER_TYPE_PARAMETER = "serverType";
    private static final String QUERY_GET_SERVERS_BY_TYPE = "from Server server where server.serverType = :" + SERVER_TYPE_PARAMETER;

    private static ServerManager instance = null;

    public static synchronized ServerManager getInstance() {
        if (instance == null) {
            instance = new ServerManagerImpl();
        }
        return instance;
    }

    private ServerManagerImpl() {
        super();
    }

    @SuppressWarnings("unchecked")
    public Collection<Server> getServers() {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<Server> list = (List<Server>) session.createQuery(QUERY_GET_SERVERS).list();
        transaction.commit();
        return list;
    }

    @SuppressWarnings("unchecked")
    public Collection<Server> getServers(ServerTypeID serverTypeID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<Server> list = (List<Server>) session.createQuery(QUERY_GET_SERVERS_BY_TYPE).setShort(SERVER_TYPE_PARAMETER, serverTypeID.getTypeId()).list();
        transaction.commit();
        return list;
    }
}
