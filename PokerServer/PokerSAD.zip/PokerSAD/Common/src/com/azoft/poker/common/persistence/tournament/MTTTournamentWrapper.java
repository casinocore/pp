package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.bean.AscBlindComparator;
import com.azoft.poker.common.bean.Blind;
import com.azoft.poker.common.bean.SynchronousHand;
import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * MTT tournament wrapper
 */
public class MTTTournamentWrapper extends TournamentWrapper {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(MTTTournamentWrapper.class);

    /**
     * Empty value
     */
    protected static final int EMPTY_VALUE = -1;

    public static final long DEFAULT_MIN_PLAYERS_COUNT = 2;
    private static final int BUYIN_FEE_NUMBER = 1;
    private static final int REBUY_FEE_NUMBER = 2;

    public static final String mttStartRegistration = "mttStartRegistration";
    public static final String mttCancelRegistrationIsAccessible = "mttCancelRegistrationIsAccessible";
    public static final String mttCancelRegistrationPeriod = "mttCancelRegistrationPeriod";
    public static final String mttLateRegistrationPeriod = "mttLateRegistrationPeriod";
    public static final String mttBeforeStartNotificationPeriod = "mttBeforeStartNotificationPeriod";
    public static final String mttRebuyIsAccessible = "mttRebuyIsAccessible";
    public static final String mttRebuyPeriod = "mttRebuyPeriod";
    public static final String mttBlindPeriod = "mttBlindPeriod";
    public static final String mttSmallBlind_PREFIX = "mttSmallBlind_";
    public static final String mttBigBlind_PREFIX = "mttBigBlind_";
    public static final String mttBreakPeriod = "mttBreakPeriod";
    public static final String mttBreakTime = "mttBreakTime";
    public static final String mttSynchronousHandStart_PREFIX = "mttSynchronousHandStart_";
    public static final String mttSynchronousHandFinished_PREFIX = "mttSynchronousHandFinished_";

    private List<Blind> blinds = new ArrayList<Blind>();

    private List<SynchronousHand> synchronousHands = new ArrayList<SynchronousHand>();

    public MTTTournamentWrapper(Tournament tournament) {
        super(tournament);
        initialization();
    }

    public Date getStartRegistration() {
        return getDateAttribute(mttStartRegistration);
    }

    public void setStartRegistration(Date value) {
        setDateAttribute(mttStartRegistration, value);
    }

    public Byte getCancelRegistrationIsAccessible() {
        return getByteAttribute(mttCancelRegistrationIsAccessible);
    }

    public void setCancelRegistrationIsAccessible(Byte value) {
        setByteAttribute(mttCancelRegistrationIsAccessible, value);
    }

    public Boolean getCancelRegistrationAccessible() {
        return getCancelRegistrationIsAccessible() != 0;
    }

    public void setCancelRegistrationAccessible(
            Boolean cancelRegistrationAccessible) {
        if (!cancelRegistrationAccessible) {
            setCancelRegistrationIsAccessible(null);
            setCancelRegistrationPeriod(null);
        } else {
            setCancelRegistrationIsAccessible((byte) 1);
        }
    }

    public Short getCancelRegistrationPeriod() {
        return getShortAttribute(mttCancelRegistrationPeriod);
    }

    public void setCancelRegistrationPeriod(Short value) {
        setShortAttribute(mttCancelRegistrationPeriod, value);
    }

    public Short getLateRegistrationPeriod() {
        return getShortAttribute(mttLateRegistrationPeriod);
    }

    public void setLateRegistrationPeriod(Short value) {
        setShortAttribute(mttLateRegistrationPeriod, value);
    }

    public Short getBeforeStartNotificationPeriod() {
        return getShortAttribute(mttBeforeStartNotificationPeriod);
    }

    public void setBeforeStartNotificationPeriod(Short value) {
        setShortAttribute(mttBeforeStartNotificationPeriod, value);
    }

    public Byte getRebuyIsAccessible() {
        return getByteAttribute(mttRebuyIsAccessible);
    }

    public void setRebuyIsAccessible(Byte value) {
        setByteAttribute(mttRebuyIsAccessible, value);
    }

    public Boolean getRebuyAccessible() {
        return getRebuyIsAccessible() != 0;
    }

    public void setRebuyAccessible(Boolean rebuyAccessible) {
        if (!rebuyAccessible) {
            setRebuyIsAccessible(null);
            setRebuy(null);
            setRebuyPeriod(null);
        } else {
            setRebuyIsAccessible((byte) 1);
        }
    }

    public Short getRebuyPeriod() {
        return getShortAttribute(mttRebuyPeriod);
    }

    public void setRebuyPeriod(Short value) {
        setShortAttribute(mttRebuyPeriod, value);
    }

    public Short getBlindPeriod() {
        return getShortAttribute(mttBlindPeriod);
    }

    public void setBlindPeriod(Short value) {
        setShortAttribute(mttBlindPeriod, value);
    }

    public Integer getSmallBlind(Short blindNumber) {
        return getIntegerAttribute(mttSmallBlind_PREFIX + blindNumber);
    }

    public void setSmallBlind(Short blindNumber, Integer value) {
        setIntegerAttribute(mttSmallBlind_PREFIX + blindNumber, value);
    }

    public Integer getBigBlind(Short blindNumber) {
        return getIntegerAttribute(mttBigBlind_PREFIX + blindNumber);
    }

    public void setBigBlind(Short blindNumber, Integer value) {
        setIntegerAttribute(mttBigBlind_PREFIX + blindNumber, value);
    }

    public Short getBreakPeriod() {
        return getShortAttribute(mttBreakPeriod);
    }

    public void setBreakPeriod(Short value) {
        setShortAttribute(mttBreakPeriod, value);
    }

    public Short getBreakTime() {
        return getShortAttribute(mttBreakTime);
    }

    public void setBreakTime(Short value) {
        setShortAttribute(mttBreakTime, value);
    }

    public Long getSynchronousHandStart(Short synchronousHandNumber) {
        return getLongAttribute(mttSynchronousHandStart_PREFIX
                + synchronousHandNumber);
    }

    public void setSynchronousHandStart(Short synchronousHandNumber, Long value) {
        setLongAttribute(
                mttSynchronousHandStart_PREFIX + synchronousHandNumber, value);
    }

    public Long getSynchronousHandFinished(Short synchronousHandNumber) {
        return getLongAttribute(mttSynchronousHandFinished_PREFIX
                + synchronousHandNumber);
    }

    public void setSynchronousHandFinished(Short synchronousHandNumber,
                                           Long value) {
        setLongAttribute(mttSynchronousHandFinished_PREFIX
                + synchronousHandNumber, value);
    }

    public Long getBuyIn() {
        return getLongAttribute(FEE_PREFIX + BUYIN_FEE_NUMBER);
    }

    public void setBuyIn(Long value) {
        setLongAttribute(FEE_PREFIX + BUYIN_FEE_NUMBER, value);
    }

    public Long getRebuy() {
        return getLongAttribute(FEE_PREFIX + REBUY_FEE_NUMBER);
    }

    public void setRebuy(Long value) {
        setLongAttribute(FEE_PREFIX + REBUY_FEE_NUMBER, value);
    }

    public List<Blind> getBlinds() {
        return blinds;
    }

    public List<SynchronousHand> getSynchronousHands() {
        return synchronousHands;
    }

    public boolean isActive() {
        return getEntity().getStatus() == TournamentStatusID.ACTIVE.getTypeId();
    }

    public boolean isPlanned() {
        return getEntity().getStatus() == TournamentStatusID.PLANNED
                .getTypeId();
    }

    public boolean isCanceled() {
        return getEntity().getStatus() == TournamentStatusID.CANCELED
                .getTypeId();
    }

    public boolean isClosed() {
        return getEntity().getStatus() == TournamentStatusID.CLOSED.getTypeId();
    }

    public long getBeforeStartRegistration() {
        long result = EMPTY_VALUE;
        if (!isClosed() && !isCanceled()) {
            long currentTime = System.currentTimeMillis();
            Date startRegistration = getStartRegistration();
            if (startRegistration != null) {
                long beforeStartRegistration = startRegistration.getTime()
                        - currentTime;
                Short lateRegistrationPeriod = getLateRegistrationPeriod();
                Date fromDate = getEntity().getFromDate();
                if (beforeStartRegistration > 0) {
                    result = beforeStartRegistration;
                } else if (fromDate != null) {
                    if (lateRegistrationPeriod != null
                            && lateRegistrationPeriod > 0
                            && currentTime < (fromDate.getTime() + TimeUnit.MINUTES
                            .toMillis(lateRegistrationPeriod))) {
                        result = 0;
                    } else if ((lateRegistrationPeriod == null
                            || lateRegistrationPeriod <= 0)
                            && currentTime < fromDate.getTime()) {
                        result = 0;
                    }
                }
            }
        }
        return result;
    }

    public boolean isExistsCancelRegistration() {
        boolean result = false;
        if (isPlanned()) {
            Byte cancelRegistrationIsAccessible = getCancelRegistrationIsAccessible();
            Short cancelRegistrationPeriod = getCancelRegistrationPeriod();
            if (cancelRegistrationIsAccessible != null
                    && cancelRegistrationPeriod != null
                    && cancelRegistrationIsAccessible == PersistenceManagerImpl.TRUE_VALUE) {
                Date fromDate = getEntity().getFromDate();
                if (fromDate != null) {
                    result = System.currentTimeMillis() < (fromDate.getTime() - TimeUnit.MINUTES
                            .toMillis(cancelRegistrationPeriod));
                }
            }
        }
        return result;
    }

    public boolean isExistsBeforeStartNotificationPeriod() {
        boolean result = false;
        if (!isClosed()) {
            Short beforeStartNotificationPeriod = getBeforeStartNotificationPeriod();
            if (beforeStartNotificationPeriod != null) {
                Date fromDate = getEntity().getFromDate();
                if (fromDate != null) {
                    result = System.currentTimeMillis() > (fromDate.getTime() - TimeUnit.MINUTES
                            .toMillis(beforeStartNotificationPeriod));
                }
            }
        }
        return result;
    }

    public boolean isExistsRebuy() {
        boolean result = false;
        if (isActive()) {
            Byte rebuyIsAccessible = getRebuyIsAccessible();
            Short rebuyPeriod = getRebuyPeriod();
            if (rebuyIsAccessible != null && rebuyPeriod != null
                    && rebuyIsAccessible == PersistenceManagerImpl.TRUE_VALUE) {
                Date fromDate = getEntity().getFromDate();
                if (fromDate != null) {
                    long currentTime = System.currentTimeMillis();
                    result = currentTime > fromDate.getTime()
                            && currentTime < (fromDate.getTime() + TimeUnit.MINUTES
                            .toMillis(rebuyPeriod));
                }
            }
        }
        return result;
    }

    private void initialization() {
        initializationBlinds();
        initializationSynchronousHand();
    }

    public boolean validation() {
        boolean result = getStartRegistration() != null;
        Long startChipsCount = getEntity().getStartChipsCount();
        result = result && startChipsCount != null && startChipsCount > 0;
        result = result && getBlindPeriod() != null && getBlindPeriod() > 0;
        result = result && !getBlinds().isEmpty();
        Long minPlayersCount = getEntity().getMinPlayersCount();
        result = result && minPlayersCount != null
                && minPlayersCount >= DEFAULT_MIN_PLAYERS_COUNT;
        Byte rebuyIsAccessible = getRebuyIsAccessible();
        if (rebuyIsAccessible != null
                && rebuyIsAccessible == PersistenceManagerImpl.TRUE_VALUE) {
            Long rebuy = getRebuy();
            result = result && rebuy != null && rebuy > 0;
        }
        return result;
    }

    private void initializationBlinds() {
        short counter = 1;
        Integer bigBlind = getBigBlind(counter);
        Integer smallBlind = getSmallBlind(counter);
        while (bigBlind != null && smallBlind != null) {
            if (smallBlind < bigBlind) {
                addBlind(smallBlind, bigBlind);
            }
            counter++;
            bigBlind = getBigBlind(counter);
            smallBlind = getSmallBlind(counter);
        }
        Collections.sort(blinds, new AscBlindComparator());
    }

    private void initializationSynchronousHand() {
        short counter = 1;
        Long synchronousHandFinished = getSynchronousHandFinished(counter);
        Long synchronousHandStart = getSynchronousHandStart(counter);
        while (synchronousHandStart != null && synchronousHandFinished != null) {
            if (synchronousHandStart > synchronousHandFinished) {
                addSynchronousHand(synchronousHandStart,
                        synchronousHandFinished);
            }
            counter++;
            synchronousHandStart = getSynchronousHandStart(counter);
            synchronousHandFinished = getSynchronousHandFinished(counter);
        }
        Collections.sort(synchronousHands);
    }

    private void addBlind(Integer smallBlind, Integer bigBlind) {
        blinds.add(new Blind(smallBlind, bigBlind));
    }

    private void addSynchronousHand(Long synchronousHandStart,
                                    Long synchronousHandFinished) {
        synchronousHands.add(new SynchronousHand(synchronousHandStart,
                synchronousHandFinished));
    }

    protected SynchronousHand checkSynchronousHand(long activePlayerCount) {
        SynchronousHand result = null;
        for (SynchronousHand synchronousHand : synchronousHands) {
            if (activePlayerCount <= synchronousHand.getStartNumber()
                    && activePlayerCount > synchronousHand.getFinishedNumber()) {
                result = synchronousHand;
                break;
            }
        }
        return result;
    }

}
