package com.azoft.poker.common.persistence.person;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.persistence.BatchPersistenceManagerImpl;
import com.azoft.poker.common.persistence.event.EventTypeID;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.*;
import java.util.Map.Entry;

/**
 * Person manager
 */
public class PersonManagerImpl extends BatchPersistenceManagerImpl<Person>
        implements PersonManager {

    private static final String MANAGER_TYPE = "PERSON";

    private final static Logger LOGGER = LoggerFactory
            .getLogger(PersonManagerImpl.class);

    public static final String TABLE_PERSON = "person";
    private static final String QUERY_GET_PERSONS = "from Person person order by person.lastName, person.firstName";
    private static final String PARAMETER_EVENT_TYPE_ID = "eventTypeId";
    private static final String PARAMETER_FROM_DATE = "fromDate";
    private static final String PARAMETER_TO_DATE = "toDate";
    private static final String QUERY_COUNT_BY_EVENT = "select count(p.id) from person p"
            + " where exists (select ee.id from event_entity ee where ee.reference_id = p.id and ee.event_type = :"
            + PARAMETER_EVENT_TYPE_ID + ")";

    private static final String QUERY_COUNT_BY_EVENT_FOR_PERIOD = "select count(distinct ee.reference_id) from event_entity ee"
            + " where ee.event_type = :"
            + PARAMETER_EVENT_TYPE_ID
            + " and ee.time_stamp between :"
            + PARAMETER_FROM_DATE
            + " and :"
            + PARAMETER_TO_DATE;

    private static final String QUERY_COUNT_NEW_BY_EVENT_FOR_PERIOD = "select count(distinct ee.reference_id) from event_entity ee, person p"
            + "  where ee.event_type = :"
            + PARAMETER_EVENT_TYPE_ID
            + "  and ee.time_stamp between :"
            + PARAMETER_FROM_DATE
            + " and :"
            + PARAMETER_TO_DATE
            + "  and p.id = ee.reference_id"
            + "  and p.registration_date between :"
            + PARAMETER_FROM_DATE
            + " and :" + PARAMETER_TO_DATE;

    private static final String QUERY_COUNT_ACTIVE_PLAYERS_FOR_PERIOD = "select count(s.reference_id) from"
            + " (select reference_id, count(reference_id) as num from "
            + " ((select distinct e1.reference_id from event_entity e1 where e1.event_type = :"
            + PARAMETER_EVENT_TYPE_ID
            + " and e1.time_stamp between :"
            + PARAMETER_FROM_DATE
            + " and :"
            + PARAMETER_TO_DATE
            + ")"
            + " union all"
            + " (select distinct reference_id from event_entity where event_type = :"
            + PARAMETER_EVENT_TYPE_ID
            + " and time_stamp < :"
            + PARAMETER_FROM_DATE
            + ")) as e1 "
            + " group by e1.reference_id) as s" + " where s.num>=2";

    private static final String QUERY_COUNT_ACTIVE_NEW_PLAYERS_FOR_PERIOD = "select count(s.reference_id) from"
            + "  (select reference_id, count(reference_id) as num from"
            + "   (select e1.reference_id from event_entity e1 where e1.event_type = :"
            + PARAMETER_EVENT_TYPE_ID
            + " and e1.time_stamp between :"
            + PARAMETER_FROM_DATE
            + " and :"
            + PARAMETER_TO_DATE
            + ")"
            + "       as e1"
            + "  group by e1.reference_id) as s, person p"
            + "  where s.num>=2"
            + "   and p.id = s.reference_id"
            + "   and p.registration_date between :"
            + PARAMETER_FROM_DATE
            + " and :" + PARAMETER_TO_DATE;

    private static final String QUERY_GET_NEW_PERSONS_FOR_PERIOD = "from Person person where person.registrationDate between :"
            + PARAMETER_FROM_DATE
            + " and :"
            + PARAMETER_TO_DATE
            + " order by person.registrationDate";
    private static final String QUERY_COUNT_NEW_PERSONS_FOR_PERIOD = "select count(person.id) from person where person.registration_date between :"
            + PARAMETER_FROM_DATE + " and :" + PARAMETER_TO_DATE;
    private static final String QUERY_FIND_PERSONS = "from Person person where person.lastName like :personName or person.firstName like :personName";
    private static final String PERSON_NAME_PARAMETER = "personName";
    private static final String QUERY_GET_PERSON = "from Person person where person.username = :username";
    private static final String PERSON_USERNAME_PARAMETER = "username";
    private static final String QUERY_GET_PERSON_BY_SN_ID = "from Person person where person.socialNetworkID = :personSNid";
    private static final String PERSON_SN_ID_PARAMETER = "personSNid";

    private static final String PARAMETER_TOP_NUMBER = "topNumber";
    private static final String PARAMETER_TOTAL_BALANCE = "totalBalance";
    private static final String PARAMETER_INVITED_FRIENDS_COUNT = "invitedFriendsCount";
    private static final String PARAMETER_PERSON_ID = "personId";
    private static final String PARAMETER_FRIEND_ID = "friendId";
    private static final String FIELD_PLAYER_ID = "player_id";
    private static final String FIELD_SOCIAL_NETWORK_ID = "socialNetworkID";
    private static final String FIELD_TOTAL_BALANCE = "total_balance";
    private static final String FIELD_INVITED_FRIENDS_COUNT = "invited_friends_count";
    private static final String QUERY_GET_TOP_PERSON = "select" + "   p.id "
            + FIELD_PLAYER_ID + "," + "   p.social_network_id "
            + FIELD_SOCIAL_NETWORK_ID + "," + "   b." + FIELD_TOTAL_BALANCE
            + " from person p," + "   (select a.id " + FIELD_PLAYER_ID
            + ", sum(a.balance) " + FIELD_TOTAL_BALANCE + " from" + "       ("
            + "       select id, balance from person" + "       union all"
            + "       select person_id id, game_balance balance"
            + "           from person_cache where tournament_id = 0"
            + "       ) a group by a.id " + "   order by "
            + FIELD_TOTAL_BALANCE + " desc" + "   limit :"
            + PARAMETER_TOP_NUMBER + "   ) b" + "   where p.id = b."
            + FIELD_PLAYER_ID;

    private static final String QUERY_GET_TOP_INVITED_FRIENDS = "select"
            + "   ip.parent_id as "
            + FIELD_PLAYER_ID
            + ","
            + "   p.social_network_id as "
            + FIELD_SOCIAL_NETWORK_ID
            + ","
            + "   p.balance + ifnull(pc.game_balance, 0) as "
            + FIELD_TOTAL_BALANCE
            + ","
            + "   count(ip.parent_id) as "
            + FIELD_INVITED_FRIENDS_COUNT
            + " from person ip"
            + "   inner join person p on (p.id = ip.parent_id)"
            + "   left join person_cache pc on (pc.person_id = p.id and pc.tournament_id = 0)"
            + " group by ip.parent_id" + " order by "
            + FIELD_INVITED_FRIENDS_COUNT + " desc" + " limit :"
            + PARAMETER_TOP_NUMBER;

    private static final String QUERY_GET_RANK_BY_BALANCE = "select count(p.id) + 1 as rank from person p"
            + "   left join person_cache pc on"
            + "       (pc.person_id = p.id and pc.tournament_id = 0) "
            + "   where "
            + "       (p.balance + ifnull(pc.game_balance, 0)) > :"
            + PARAMETER_TOTAL_BALANCE;

    private static final String QUERY_GET_RANK_BY_INVITED_FRIENDS_COUNT = "select count(cnt) + 1 as rank"
            + " from ("
            + "  select count(ip.parent_id) cnt"
            + "  from person ip"
            + "    inner join person p on (p.id = ip.parent_id)"
            + "  group by ip.parent_id"
            + "  having count(ip.parent_id) > :"
            + PARAMETER_INVITED_FRIENDS_COUNT + " ) as count_table";

    private static final String QUERY_GET_COUNT_INVITED_FRIENDS = "select count(ip.parent_id) as "
            + FIELD_INVITED_FRIENDS_COUNT
            + "  from person ip"
            + "    inner join person p on (p.id = ip.parent_id)"
            + "  where ip.parent_id =  :"
            + PARAMETER_PERSON_ID
            + "  group by ip.parent_id";

    private static final String QUERY_GET_FRIENDS = "select fl.friend from FriendLink fl"
            + " where fl.person.id = :" + PARAMETER_PERSON_ID;
    private static final String QUERY_GET_FRIEND = "from FriendLink fl"
            + " where fl.person.id = :" + PARAMETER_PERSON_ID
            + " and fl.friend.id = :" + PARAMETER_FRIEND_ID;

    private static final String QUERY_COUNT_ACTIVE_INVITED_FRIENDS = "select count(p.id) from person p"
            + " inner join event_entity ee on (ee.reference_id = p.id"
            + "   and ee.event_type = :"
            + PARAMETER_EVENT_TYPE_ID
            + "   and ee.time_stamp between :"
            + PARAMETER_FROM_DATE
            + " and :"
            + PARAMETER_TO_DATE
            + ")"
            + " where p.parent_id = :"
            + PARAMETER_PERSON_ID;

    private static final String QUERY_COUNT_NEW_INVITED_FRIENDS = "select count(p.parent_id) from person p"
            + " where p.parent_id = :"
            + PARAMETER_PERSON_ID
            + " and exists_parent_bonus = " + TRUE_VALUE;

    private static final String QUERY_SET_NOT_EXISTS_NEW_INVITED_FRIENDS = "update person p set exists_parent_bonus = "
            + FALSE_VALUE
            + " where p.parent_id = :"
            + PARAMETER_PERSON_ID
            + " and exists_parent_bonus = " + TRUE_VALUE;

    private static final String WHERE_STATEMENT_PREFIX = " where 1 != 1 ";
    private static final String OR_STATEMENT = " or ";
    private static final String AND_STATEMENT = " and ";
    private static final String EQUALS_STATEMENT = " = ";
    private static final String LIKE_STATEMENT = " like ";
    private static final String ORDER_BY_STATEMENT = " order by ";
    private static final String FIELD_ID = "id";
    private static final String FIELD_FIRST_NAME = "firstName";
    private static final String FIELD_LAST_NAME = "lastName";
    private static final String PARAMETER_ID = FIELD_ID;
    private static final String PARAMETER_FIRST_NAME = FIELD_FIRST_NAME;
    private static final String PARAMETER_LAST_NAME = FIELD_LAST_NAME;

    private static PersonManager instance = null;

    public static synchronized PersonManager getInstance() {
        if (instance == null) {
            instance = new PersonManagerImpl();
        }
        return instance;
    }

    private PersonManagerImpl() {
        super(MANAGER_TYPE);
    }

    @SuppressWarnings("unchecked")
    public List<Person> getPersons() {
        return getPersons(QUERY_GET_PERSONS);
    }

    public List<Person> getPersons(String query) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<Person> list = (List<Person>) session.createQuery(query).list();
        transaction.commit();
        return list;
    }

    @SuppressWarnings("unchecked")
    public Integer getCountPersons() {
        return getCount(TABLE_PERSON).intValue();
    }

    @SuppressWarnings("unchecked")
    public Integer getCountActivePlayers() {
        return getCountByEvent(EventTypeID.PLAY_START);
    }

    @SuppressWarnings("unchecked")
    private Integer getCountByEvent(EventTypeID eventTypeID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_COUNT_BY_EVENT)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .uniqueResult();
        transaction.commit();
        return count.intValue();
    }

    @SuppressWarnings("unchecked")
    public Integer getCountActivePlayersForPeriod(Date fromDate, Date toDate) {
        return getCountByEventForPeriod(QUERY_COUNT_ACTIVE_PLAYERS_FOR_PERIOD,
                EventTypeID.PLAY_START, fromDate, toDate);
    }

    @SuppressWarnings("unchecked")
    public Integer getCountActiveNewPlayersForPeriod(Date fromDate, Date toDate) {
        return getCountByEventForPeriod(
                QUERY_COUNT_ACTIVE_NEW_PLAYERS_FOR_PERIOD,
                EventTypeID.PLAY_START, fromDate, toDate);
    }

    @SuppressWarnings("unchecked")
    public Integer getCountPaymentPlayersForPeriod(Date fromDate, Date toDate) {
        return getCountByEventForPeriod(QUERY_COUNT_BY_EVENT_FOR_PERIOD,
                EventTypeID.PAYMENT_OF_CHIPS, fromDate, toDate);
    }

    @SuppressWarnings("unchecked")
    public Integer getCountPaymentNewPlayersForPeriod(Date fromDate, Date toDate) {
        return getCountByEventForPeriod(QUERY_COUNT_NEW_BY_EVENT_FOR_PERIOD,
                EventTypeID.PAYMENT_OF_CHIPS, fromDate, toDate);
    }

    @SuppressWarnings("unchecked")
    private Integer getCountByEventForPeriod(String query,
                                             EventTypeID eventTypeID, Date fromDate, Date toDate) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(query)
                .setShort(PARAMETER_EVENT_TYPE_ID, eventTypeID.getTypeId())
                .setTimestamp(PARAMETER_FROM_DATE, fromDate)
                .setTimestamp(PARAMETER_TO_DATE, toDate).uniqueResult();
        transaction.commit();
        return count.intValue();
    }

    @SuppressWarnings("unchecked")
    public List<Person> getNewPersonsForPeriod(Date fromDate, Date toDate) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<Person> list = session
                .createQuery(QUERY_GET_NEW_PERSONS_FOR_PERIOD)
                .setTimestamp(PARAMETER_FROM_DATE, fromDate)
                .setTimestamp(PARAMETER_TO_DATE, toDate).list();
        transaction.commit();
        return list;
    }

    public List<Person> getNewPersonsForPeriod(String fromStringDate,
                                               String toStringDate) {
        List<Person> list = null;
        fromStringDate = DateHelper.prepareFromStringDateTime(fromStringDate);
        toStringDate = DateHelper.prepareToStringDateTime(toStringDate);
        Date fromDate = null;
        Date toDate = null;
        try {
            fromDate = DateHelper.attributeDateTimeFormat.parse(fromStringDate);
            toDate = DateHelper.attributeDateTimeFormat.parse(toStringDate);
            list = getNewPersonsForPeriod(fromDate, toDate);
        } catch (ParseException e) {
            list = new ArrayList<Person>();
            LOGGER.error("Invalid format fromStringDate or toStringDateTime");
        }
        return list;
    }

    public Integer getCountNewPersonsForPeriod(Date fromDate, Date toDate) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_COUNT_NEW_PERSONS_FOR_PERIOD)
                .setTimestamp(PARAMETER_FROM_DATE, fromDate)
                .setTimestamp(PARAMETER_TO_DATE, toDate).uniqueResult();
        transaction.commit();
        return count.intValue();
    }

    public Integer getCountNewPersonsForPeriod(String fromStringDate,
                                               String toStringDate) {
        Integer count = null;
        fromStringDate = DateHelper.prepareFromStringDateTime(fromStringDate);
        toStringDate = DateHelper.prepareToStringDateTime(toStringDate);
        Date fromDate = null;
        Date toDate = null;
        try {
            fromDate = DateHelper.attributeDateTimeFormat.parse(fromStringDate);
            toDate = DateHelper.attributeDateTimeFormat.parse(toStringDate);
            count = getCountNewPersonsForPeriod(fromDate, toDate);
        } catch (ParseException e) {
            LOGGER.error("Invalid format fromStringDate or toStringDateTime");
        }
        return count;
    }

    public List<Person> getPersonsBySNIDs(List<String> socialNetworkIDs) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();

        List<Person> result = new ArrayList<Person>();
        for (String id : socialNetworkIDs) {
            Person person = (Person) session
                    .createQuery(QUERY_GET_PERSON_BY_SN_ID)
                    .setString(PERSON_SN_ID_PARAMETER, id).uniqueResult();
            if (null != person) {
                result.add(person);
            }
        }

        transaction.commit();
        return result;
    }

    public Person getPersonBySNID(String socialNetworkID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Person person = (Person) session.createQuery(QUERY_GET_PERSON_BY_SN_ID)
                .setString(PERSON_SN_ID_PARAMETER, socialNetworkID)
                .uniqueResult();
        transaction.commit();
        return person;
    }

    @SuppressWarnings("unchecked")
    public Collection<Person> findPersons(String personName) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List list = session.createQuery(QUERY_FIND_PERSONS)
                .setString(PERSON_NAME_PARAMETER, personName).list();
        transaction.commit();
        return list;
    }

    public Person getPerson(String username) {
        Person person = null;
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        person = (Person) session.createQuery(QUERY_GET_PERSON)
                .setString(PERSON_USERNAME_PARAMETER, username).uniqueResult();
        transaction.commit();
        return person;
    }

    public Person loadPerson(long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Person person = (Person) session.load(Person.class, personId);
        transaction.commit();
        return person;
    }

    public Person getPerson(long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Person person = (Person) session.get(Person.class, personId);
        transaction.commit();
        return person;
    }

    public void storePerson(Person person) {
        merge(person);
    }

    public Person deletePerson(Person person) {
        return delete(person);
    }

    public List<InfoPlayerBean> getTopPlayers(int topNumber) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        @SuppressWarnings("unchecked")
        List<Object[]> objects = session.createSQLQuery(QUERY_GET_TOP_PERSON)
                .addScalar(FIELD_PLAYER_ID, Hibernate.LONG)
                .addScalar(FIELD_SOCIAL_NETWORK_ID, Hibernate.STRING)
                .addScalar(FIELD_TOTAL_BALANCE, Hibernate.LONG)
                .setInteger(PARAMETER_TOP_NUMBER, topNumber).list();
        transaction.commit();
        return boxingTopPlayersByBalance(objects);
    }

    public List<InvitedFriendsBean> getTopInvitedFriends(int topNumber) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        @SuppressWarnings("unchecked")
        List<Object[]> objects = session
                .createSQLQuery(QUERY_GET_TOP_INVITED_FRIENDS)
                .addScalar(FIELD_PLAYER_ID, Hibernate.LONG)
                .addScalar(FIELD_SOCIAL_NETWORK_ID, Hibernate.STRING)
                .addScalar(FIELD_TOTAL_BALANCE, Hibernate.LONG)
                .addScalar(FIELD_INVITED_FRIENDS_COUNT, Hibernate.INTEGER)
                .setInteger(PARAMETER_TOP_NUMBER, topNumber).list();
        transaction.commit();
        return boxingTopPlayersByInvitedFriends(objects);
    }

    /**
     * Boxing top players by balance
     *
     * @param objects query objects
     * @return top players list
     */
    public static List<InfoPlayerBean> boxingTopPlayersByBalance(
            List<Object[]> objects) {
        List<InfoPlayerBean> list = new ArrayList<InfoPlayerBean>();
        int rank = 0;
        int rankDelta = 0;
        Long priorBalance = null;
        for (Object[] object : objects) {
            InfoPlayerBean player = new InfoPlayerBean();
            player.setPlayerId((Long) (object[0]));
            player.setSocialNetworkID((String) (object[1]));
            player.setBalance((Long) (object[2]));
            if (priorBalance == null || priorBalance > player.getBalance()) {
                priorBalance = player.getBalance();
                rank += rankDelta + 1;
                rankDelta = 0;
            } else {
                rankDelta++;
            }
            player.setRanked(rank);
            list.add(player);
        }
        return list;
    }

    /**
     * Boxing top players by leaving time
     *
     * @param objects query objects
     * @param list    InfoPlayerBean list
     * @return top players list
     */
    public static List<InfoPlayerBean> boxingTopPlayersByLeavingTime(
            List<Object[]> objects, List<InfoPlayerBean> list) {
        int rank = list.size();
        int rankDelta = 0;
        Date priorLeavingTime = null;
        for (Object[] object : objects) {
            InfoPlayerBean player = new InfoPlayerBean();
            player.setPlayerId((Long) (object[0]));
            player.setSocialNetworkID((String) (object[1]));
            player.setBalance(0L);
            Date leavingTime = (Date) (object[2]);
            if (priorLeavingTime == null || priorLeavingTime.compareTo(leavingTime) > 0) {
                priorLeavingTime = leavingTime;
                rank += rankDelta + 1;
                rankDelta = 0;
            } else {
                rankDelta++;
            }
            player.setRanked(rank);
            list.add(player);
        }
        return list;
    }

    /**
     * Boxing top players by invited friends
     *
     * @param objects query objects
     * @return top players list
     */
    public static List<InvitedFriendsBean> boxingTopPlayersByInvitedFriends(
            List<Object[]> objects) {
        List<InvitedFriendsBean> list = new ArrayList<InvitedFriendsBean>();
        int rank = 0;
        int rankDelta = 0;
        Integer priorInvitedFriendsCount = null;
        for (Object[] object : objects) {
            InvitedFriendsBean player = new InvitedFriendsBean();
            player.setPlayerId((Long) (object[0]));
            player.setSocialNetworkID((String) (object[1]));
            player.setBalance((Long) (object[2]));
            player.setInvitedFriendsCount((Integer) (object[3]));
            if (priorInvitedFriendsCount == null
                    || priorInvitedFriendsCount > player
                    .getInvitedFriendsCount()) {
                priorInvitedFriendsCount = player.getInvitedFriendsCount();
                rank += rankDelta + 1;
                rankDelta = 0;
            } else {
                rankDelta++;
            }
            player.setRanked(rank);
            list.add(player);
        }
        return list;
    }

    public Long getRankByBalance(Long totalBalance) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_GET_RANK_BY_BALANCE)
                .setLong(PARAMETER_TOTAL_BALANCE, totalBalance).uniqueResult();
        transaction.commit();
        return count.longValue();
    }

    public Long getRankByInvitedFriends(Integer invitedFriendsCount) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_GET_RANK_BY_INVITED_FRIENDS_COUNT)
                .setInteger(PARAMETER_INVITED_FRIENDS_COUNT,
                        invitedFriendsCount).uniqueResult();
        transaction.commit();
        return count.longValue();
    }

    public Integer getCountInvitedFriends(long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_GET_COUNT_INVITED_FRIENDS)
                .setLong(PARAMETER_PERSON_ID, personId).uniqueResult();
        transaction.commit();
        if (count == null) {
            count = BigInteger.ZERO;
        }
        return count.intValue();
    }

    public void addFriend(long personId, long friendId) throws CommonException {
        Person person = getPerson(personId);
        checkObjectNotNull(person, "Not exists personId: " + personId);
        Person friend = getPerson(friendId);
        checkObjectNotNull(friend, "Not exists friend with personId: "
                + friendId);
        FriendLink friendLink = getFriendLink(person.getId(), friend.getId());
        if (friendLink == null) {
            friendLink = new FriendLink(person, friend);
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            session.save(friendLink);
            transaction.commit();
        } else {
            throw new CommonException("Friend not added");
        }
    }

    public void deleteFriend(long personId, long friendId)
            throws CommonException {
        Person person = getPerson(personId);
        checkObjectNotNull(person, "Not exists personId: " + personId);
        Person friend = getPerson(friendId);
        checkObjectNotNull(friend, "Not exists friend with personId: "
                + friendId);
        FriendLink friendLink = getFriendLink(person.getId(), friend.getId());
        if (friendLink != null) {
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            session.delete(friendLink);
            transaction.commit();
        }
    }

    public FriendLink getFriendLink(long personId, long friendId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        FriendLink friendLink = (FriendLink) session
                .createQuery(QUERY_GET_FRIEND)
                .setLong(PARAMETER_PERSON_ID, personId)
                .setLong(PARAMETER_FRIEND_ID, friendId).uniqueResult();
        transaction.commit();
        return friendLink;
    }

    public List<Person> getFriends(long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        @SuppressWarnings("unchecked")
        List<Person> list = session.createQuery(QUERY_GET_FRIENDS)
                .setLong(PARAMETER_PERSON_ID, personId).list();
        transaction.commit();
        return list;
    }

    public Integer getCountActiveInvitedFriends(long personId, Date fromDate,
                                                Date toDate) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_COUNT_ACTIVE_INVITED_FRIENDS)
                .setShort(PARAMETER_EVENT_TYPE_ID,
                        EventTypeID.PLAY_START.getTypeId())
                .setTimestamp(PARAMETER_FROM_DATE, fromDate)
                .setTimestamp(PARAMETER_TO_DATE, toDate)
                .setLong(PARAMETER_PERSON_ID, personId).uniqueResult();
        transaction.commit();
        if (count == null) {
            count = BigInteger.ZERO;
        }
        return count.intValue();
    }

    public Integer getCountNewInvitedFriends(long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_COUNT_NEW_INVITED_FRIENDS)
                .setLong(PARAMETER_PERSON_ID, personId).uniqueResult();
        transaction.commit();
        if (count == null) {
            count = BigInteger.ZERO;
        }
        return count.intValue();
    }

    public int setNotExistsNewInvitedFriends(long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        int count = session
                .createSQLQuery(QUERY_SET_NOT_EXISTS_NEW_INVITED_FRIENDS)
                .setLong(PARAMETER_PERSON_ID, personId).executeUpdate();
        transaction.commit();
        LOGGER.debug("setNotExistsNewInvitedFriends: " + count);
        return count;
    }

    public List<Person> getPersons(PersonSearchParams params, Long start,
                                   Integer count) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Map<String, Object> queryParams = new HashMap<String, Object>();
        Query query = session.createQuery("from Person "
                + createWhereStatement(params, queryParams)
                + ORDER_BY_STATEMENT + FIELD_ID);
        for (Entry<String, Object> entry : queryParams.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        query.setFirstResult(start.intValue());
        query.setMaxResults(count);
        @SuppressWarnings("unchecked")
        List<Person> list = query.list();
        transaction.commit();
        return list;
    }

    public int getPersonCount(PersonSearchParams params) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Map<String, Object> queryParams = new HashMap<String, Object>();
        Query query = session.createQuery("select count(*) from Person "
                + createWhereStatement(params, queryParams));
        for (Entry<String, Object> entry : queryParams.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }

        Long count = (Long) query.uniqueResult();
        transaction.commit();
        if (count == null) {
            count = 0L;
        }
        return count.intValue();
    }

    private String createWhereStatement(PersonSearchParams params,
                                        Map<String, Object> queryParams) {
        StringBuilder builder = new StringBuilder("");
        if (params.getIdPattern() != null) {
            if (builder.length() == 0) {
                builder.append(WHERE_STATEMENT_PREFIX);
            }
            builder.append(OR_STATEMENT);
            builder.append(FIELD_ID);
            builder.append(EQUALS_STATEMENT);
            builder.append(":");
            builder.append(PARAMETER_ID);
            queryParams.put(PARAMETER_ID, params.getIdPattern());
        }
        if (!StringHelper.isEmpty(params.getFirstName())
                || !StringHelper.isEmpty(params.getLastName())) {
            if (builder.length() == 0) {
                builder.append(WHERE_STATEMENT_PREFIX);
            }
            builder.append(OR_STATEMENT + " ( 1 = 1 ");
            if (!StringHelper.isEmpty(params.getFirstName())) {

                builder.append(AND_STATEMENT);
                builder.append(FIELD_FIRST_NAME);
                builder.append(LIKE_STATEMENT);
                builder.append(":");
                builder.append(PARAMETER_FIRST_NAME);
                queryParams.put(PARAMETER_FIRST_NAME, params.getFirstName());
            }
            if (!StringHelper.isEmpty(params.getLastName())) {
                if (builder.length() == 0) {
                    builder.append(WHERE_STATEMENT_PREFIX);
                }
                builder.append(AND_STATEMENT);
                builder.append(FIELD_LAST_NAME);
                builder.append(LIKE_STATEMENT);
                builder.append(":");
                builder.append(PARAMETER_LAST_NAME);
                queryParams.put(PARAMETER_LAST_NAME, params.getLastName());
            }
            builder.append(" ) ");
        }
        return builder.toString();
    }

    public void addChips(Long personId, Long value) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Query query = session
                .createSQLQuery("update person set balance = balance + :value where id = :personId");
        query.setLong("personId", personId);
        query.setLong("value", value);
        query.executeUpdate();
        transaction.commit();
    }
}
