package com.azoft.poker.common.socialnetwork.service;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.helper.PropertiesLoader;
import com.azoft.poker.common.socialnetwork.Constants;
import com.azoft.poker.common.socialnetwork.SocialNetworkTypeID;
import com.azoft.poker.common.socialnetwork.client.SocialNetworkClient;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Callbacks payment service manager
 */
public class CallbacksPaymentServiceManagerImpl implements CallbacksPaymentServiceManager {

    /**
     * Callbacks payment services (key: {@link com.azoft.poker.common.socialnetwork.SocialNetworkTypeID}; value: {@link CallbacksPaymentService})
     */
    private static final Map<SocialNetworkTypeID, CallbacksPaymentService> callbacksPaymentServices =
            new ConcurrentHashMap<SocialNetworkTypeID, CallbacksPaymentService>();

    private static CallbacksPaymentServiceManager instance = null;

    private static String secretKeyProperty = null;

    public static synchronized CallbacksPaymentServiceManager getInstance() {
        if (instance == null) {
            instance = new CallbacksPaymentServiceManagerImpl();
        }
        return instance;
    }

    private CallbacksPaymentServiceManagerImpl() {
    }

    public static synchronized String getSecretKeyProperty() throws CommonException {
        if (secretKeyProperty == null) {
            Map<String, Object> properties = PropertiesLoader.loadProperties(Constants.ADMINMODULE_PROPERTIES);
            secretKeyProperty = (String) properties.get(SocialNetworkClient.PARAM_SECRET_KEY);
            if (secretKeyProperty == null) {
                throw new CommonException("Not exists " + SocialNetworkClient.PARAM_SECRET_KEY + " property");
            }
        }
        return secretKeyProperty;
    }

    public CallbacksPaymentService getCallbacksPaymentService(Map parameters) throws CommonException {
        CallbacksPaymentService service = null;
        SocialNetworkTypeID socialNetworkTypeID = null;
        String[] parameter = (String[]) parameters.get(com.azoft.poker.common.socialnetwork.schoolmate.Constants.QUERY_APPLICATION_KEY);
        String secretKey = null; //only for FACEBOOK
        if (CallbacksPaymentServiceFactory.checkParameter(parameter)) {
            socialNetworkTypeID = SocialNetworkTypeID.SCHOOLMATE;
        } else {
            parameter = (String[]) parameters.get(com.azoft.poker.common.socialnetwork.mailru.Constants.QUERY_APPLICATION_ID);
            if (CallbacksPaymentServiceFactory.checkParameter(parameter)) {
                socialNetworkTypeID = SocialNetworkTypeID.MAILRU;
            } else {
                parameter = (String[]) parameters.get(com.azoft.poker.common.socialnetwork.facebook.Constants.PARAMETER_SIGNED_REQUEST);
                if (CallbacksPaymentServiceFactory.checkParameter(parameter)) {
                    socialNetworkTypeID = SocialNetworkTypeID.FACEBOOK;
                    secretKey = getSecretKeyProperty();
                }
            }
        }
        if (socialNetworkTypeID != null) {
            service = callbacksPaymentServices.get(socialNetworkTypeID);
            if (service == null) {
                service = CallbacksPaymentServiceFactory.createCallbacksPaymentService(socialNetworkTypeID, secretKey);
                if (service != null) {
                    callbacksPaymentServices.put(socialNetworkTypeID, service);
                }
            }
        }
        if (service == null) {
            throw new CommonException("Not exists CallbacksPaymentService for request with parameters: " + parameters);
        }
        return service;
    }

}