package com.azoft.poker.common.persistence.payment;

/**
 * Payment manager interface
 */
public interface PaymentManager<PersistenceType> {

    void save(PersistenceType persistenceObject);

    Payment getPayment(String transactionId);

}
