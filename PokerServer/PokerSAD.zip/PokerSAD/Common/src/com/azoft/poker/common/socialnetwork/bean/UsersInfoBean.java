package com.azoft.poker.common.socialnetwork.bean;

import com.azoft.poker.common.jaxp.AbstractBean;
import com.azoft.poker.common.socialnetwork.bean.UserInfoBean;

import java.util.HashMap;
import java.util.Map;

/**
 * Users info bean
 */
public class UsersInfoBean extends AbstractBean {

    /**
     * Get users info - map (key: SocialNetworkID, value: UserInfoBean)
     */
    private Map<String, UserInfoBean> usersInfo = new HashMap<String, UserInfoBean>();

    public UsersInfoBean() {
    }

    /**
     * Get users info
     *
     * @return users info - map (key: SocialNetworkID, value: UserInfoBean)
     */
    public Map<String, UserInfoBean> getUsersInfo() {
        return usersInfo;
    }

    /**
     * Add user info bean
     *
     * @param userInfoBean user info bean
     */
    public void addUserInfoBean(UserInfoBean userInfoBean) {
        usersInfo.put(userInfoBean.getSocialNetworkID(), userInfoBean);
    }

}
