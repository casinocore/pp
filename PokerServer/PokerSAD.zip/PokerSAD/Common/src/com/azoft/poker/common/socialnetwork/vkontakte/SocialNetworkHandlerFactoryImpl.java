package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.jaxp.AbstractHandler;
import com.azoft.poker.common.socialnetwork.client.SocialNetworkHandlerFactory;

/**
 * Social network handler factory for vkontakte
 */
public class SocialNetworkHandlerFactoryImpl implements SocialNetworkHandlerFactory {

    public SocialNetworkHandlerFactoryImpl() {
    }

    public AbstractHandler createHandler(String method) {
        AbstractHandler handler = null;
        if (Constants.METHOD_WITHDRAW_VOTES.equals(method)) {
            handler = new SocialNetworkMoneyHandler(SocialNetworkMoneyHandler.ELEMENT_NAME_TRANSFERRED);
        } else if (Constants.METHOD_GET_BALANCE.equals(method)) {
            handler = new SocialNetworkMoneyHandler(SocialNetworkMoneyHandler.ELEMENT_NAME_BALANCE);
        } else if (Constants.METHOD_GET_PROFILES.equals(method)) {
            handler = new UsersInfoHandler();
        } else if (Constants.METHOD_FRIENDS_GET.equals(method)) {
            handler = new FriendsHandler();
        } else if (Constants.METHOD_SEND_NOTIFICATION.equals(method)) {
            handler = new SendNotificationHandler();
        }
        return handler;
    }

}
