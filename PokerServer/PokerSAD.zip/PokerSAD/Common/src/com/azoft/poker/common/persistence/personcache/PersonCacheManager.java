package com.azoft.poker.common.persistence.personcache;

import com.azoft.poker.common.persistence.person.Person;

/**
 * Person cache manager interface
 */
public interface PersonCacheManager<PersistenceType> {

    Long NO_TOURNAMENT = 0L;

    void update(PersistenceType persistenceObject);

    /**
     * Get an <code>PersonCache</code> from the data store by person id
     *
     * @param personId     person id
     * @param tournamentId tournament id
     * @return person cache
     */
    PersonCache getPersonCache(Long personId, Long tournamentId);

    /**
     * Move balance delta from balance to game balance
     *
     * @param person       person
     * @param tournamentId tournament id
     * @param balanceDelta balance delta
     */
    void moveBalanceToGameBalance(Person person, Long tournamentId, Long balanceDelta);

    /**
     * Move game balance to balance
     *
     * @param person       person
     * @param tournamentId tournament id
     */
    void moveGameBalanceToBalance(Person person, Long tournamentId);

    /**
     * Add balance delta to balance and zero game balance
     *
     * @param person       person
     * @param tournamentId tournament id
     * @param balanceDelta balance delta
     */
    void addBalanceAndZeroGameBalance(Person person, Long tournamentId, Long balanceDelta);

    /**
     * Batch move game balance to balance
     */
    void moveGameBalanceToBalance();

    /**
     * Total balance sum
     *
     * @return total balance sum
     */
    Long getTotalBalanceSum();

    /**
     * Total balance
     *
     * @param person person
     * @return total balance
     */
    Long getTotalBalance(Person person);

}
