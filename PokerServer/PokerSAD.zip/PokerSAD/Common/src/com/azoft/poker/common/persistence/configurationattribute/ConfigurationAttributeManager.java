package com.azoft.poker.common.persistence.configurationattribute;

import java.util.List;

/**
 * Configuration attribute manager interface
 */
public interface ConfigurationAttributeManager<PersistenceType> {

    void save(PersistenceType persistenceObject);

    /**
     * Retrieve all <code>ConfigurationAttribute</code>s from the data store.
     *
     * @return a <code>List</code> of <code>ConfigurationAttribute</code>s
     */
    List<ConfigurationAttribute> getConfigurationAttributes();

    /**
     * Retrieve by <code>ConfigurationAttributeTypeID</code> <code>ConfigurationAttribute</code>s from the data store.
     *
     * @param configurationAttributeTypeID configuration attribute ID
     * @return a <code>List</code> of <code>ConfigurationAttribute</code>s
     */
    List<ConfigurationAttribute> getConfigurationAttributes(ConfigurationAttributeTypeID configurationAttributeTypeID);

    /**
     * Retrieve by <code>ConfigurationAttributeTypeID</code> and name <code>ConfigurationAttribute</code> from the data store.
     *
     * @param name                         parameter name
     * @param configurationAttributeTypeID configuration attribute ID
     * @return configuration attribute
     */
    ConfigurationAttribute getConfigurationAttribute(ConfigurationAttributeTypeID configurationAttributeTypeID, String name);

}