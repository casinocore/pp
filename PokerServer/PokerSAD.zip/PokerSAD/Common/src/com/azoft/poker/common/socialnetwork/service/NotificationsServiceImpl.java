package com.azoft.poker.common.socialnetwork.service;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.persistence.HibernateUtil;
import com.azoft.poker.common.persistence.WaitNotify;
import com.azoft.poker.common.socialnetwork.client.SocialNetworkClient;
import com.azoft.poker.common.socialnetwork.client.SocialNetworkClientFactory;
import org.hibernate.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.*;

/**
 * Notifications service
 */
public class NotificationsServiceImpl implements NotificationsService {

    private final static Logger LOGGER = LoggerFactory.getLogger(NotificationsServiceImpl.class);

    private static final String SERVICE_TYPE = "NOTIFICATIONS_SERVICE";

    /**
     * 'NOTIFICATIONS_SERVICE_ON' property. true - ON service, false - OFF service.
     */
    public static final String PROPERTY_NOTIFICATIONS_SERVICE_ON = "NOTIFICATIONS_SERVICE_ON";

    /**
     * 'NOTIFICATIONS_SERVICE_BATCH_MAX' property. Integer.
     */
    public static final String PROPERTY_NOTIFICATIONS_SERVICE_BATCH_MAX = "NOTIFICATIONS_SERVICE_BATCH_MAX";

    /**
     * 'NOTIFICATIONS_SERVICE_MAX_THREAD' property. Integer.
     */
    public static final String PROPERTY_NOTIFICATIONS_SERVICE_MAX_THREAD = "NOTIFICATIONS_SERVICE_MAX_THREAD";

    /**
     * Default batch max
     */
    private final static int DEFAULT_BATCH_MAX = 1000;

    /**
     * Batch process termination timeout
     */
    private final static long PROCESS_TERMINATION_TIMEOUT = 1000 * 10;

    private static final int CORE_POOL_SIZE = 1;

    private static final int DEFAULT_MAXIMUM_POOL_SIZE = 1;

    private static final long KEEP_ALIVE_TIME = 0;

    private static final String QUERY_GET_SOCIAL_NETWORK_ID_LIST = "SELECT social_network_id FROM person";

    private int batchMax = DEFAULT_BATCH_MAX;

    /**
     * Manager type
     */
    private String type = SERVICE_TYPE;

    private static SocialNetworkClient socialNetworkClient;

    private Queue<String> queue;

    private final BatchRunnable batchRunnable;

    private final ExecutorService executor;

    private long notificationsRunnableNumber = 0;

    private int maximumPoolSize = DEFAULT_MAXIMUM_POOL_SIZE;

    private ThreadPoolExecutor senderExecutor;

    private Semaphore available = new Semaphore(DEFAULT_MAXIMUM_POOL_SIZE, true);

    private boolean flagON = false;

    private static NotificationsService instance = null;

    public static synchronized NotificationsService getInstance() {
        if (instance == null) {
            instance = new NotificationsServiceImpl();
        }
        return instance;
    }

    protected NotificationsServiceImpl() {
        super();
        queue = new LinkedBlockingQueue<String>();
        batchRunnable = new BatchRunnable();
        executor = Executors.newSingleThreadExecutor();
        senderExecutor = new ThreadPoolExecutor(CORE_POOL_SIZE,
                DEFAULT_MAXIMUM_POOL_SIZE,
                KEEP_ALIVE_TIME,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>());
    }

    public boolean isFlagON() {
        return flagON;
    }

    public int getBatchMax() {
        return batchMax;
    }

    public SocialNetworkClient createSocialNetworkClient(Map<String, Object> parameters) throws CommonException {
        socialNetworkClient = SocialNetworkClientFactory.createSocialNetworkClient(parameters);
        return socialNetworkClient;
    }

    public void initialization(Map<String, Object> parameters) {
        String strFlagON = (String) parameters.get(PROPERTY_NOTIFICATIONS_SERVICE_ON);
        flagON = Boolean.valueOf(strFlagON);
        LOGGER.info(type + ". " + PROPERTY_NOTIFICATIONS_SERVICE_ON + " property: " + flagON);
        if (flagON) {
            if (socialNetworkClient != null) {
                String strMaximumPoolSize = (String) parameters.get(PROPERTY_NOTIFICATIONS_SERVICE_MAX_THREAD);
                try {
                    maximumPoolSize = Integer.valueOf(strMaximumPoolSize);
                    LOGGER.info(type + ". Set maximumPoolSize: " + maximumPoolSize);
                } catch (NumberFormatException e) {
                    maximumPoolSize = DEFAULT_MAXIMUM_POOL_SIZE;
                    LOGGER.warn(type + ". Not valid " + PROPERTY_NOTIFICATIONS_SERVICE_MAX_THREAD
                            + " property. Set default maximumPoolSize: " + maximumPoolSize);
                }
                String strBatchMax = (String) parameters.get(PROPERTY_NOTIFICATIONS_SERVICE_BATCH_MAX);
                try {
                    batchMax = Integer.valueOf(strBatchMax);
                    LOGGER.info(type + ". Set batchMax: " + batchMax);
                } catch (NumberFormatException e) {
                    batchMax = DEFAULT_BATCH_MAX;
                    LOGGER.warn(type + ". Not valid " + PROPERTY_NOTIFICATIONS_SERVICE_BATCH_MAX
                            + " property. Set default batchMax: " + batchMax);
                }

                available = new Semaphore(maximumPoolSize, true);
                senderExecutor.setMaximumPoolSize(maximumPoolSize);
                senderExecutor.setCorePoolSize(maximumPoolSize);
                senderExecutor.getQueue().clear();
                int startedFlag = senderExecutor.prestartAllCoreThreads();
                LOGGER.info(type + " - senderExecutor startedFlag: " + startedFlag);
                executor.execute(batchRunnable);
                LOGGER.info(type + " - executor start");
            } else {
                flagON = false;
                LOGGER.info(type + ". SocialNetworkClient not created. "
                        + PROPERTY_NOTIFICATIONS_SERVICE_ON + " property: " + flagON);
            }
        }
    }

    public void shutdown() {
        batchRunnable.cancel();
        batchRunnable.getWaitNotify().doNotify();
        boolean terminated = false;
        try {
            executor.shutdown();
            terminated = executor.awaitTermination(PROCESS_TERMINATION_TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOGGER.error(type + " - shutdown", e);
        }
        LOGGER.info(type + " - shutdown: " + terminated);

        boolean senderExecutorTerminated = false;
        try {
            senderExecutor.shutdown();
            senderExecutorTerminated =
                    senderExecutor.awaitTermination(PROCESS_TERMINATION_TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOGGER.error(type + " - senderExecutor shutdown", e);
        }
        LOGGER.info(type + " - senderExecutor shutdown: " + senderExecutorTerminated);
    }

    protected Session getSession() {
        return HibernateUtil.getSessionFactory().getCurrentSession();
    }

    public void sendNotifications(String message) {
        if (flagON) {
            queue.add(message);
            LOGGER.debug(type + " - call sendNotifications: " + message);
            batchRunnable.getWaitNotify().doNotify();
        }
    }

    private class BatchRunnable implements Runnable {

        private static final int BATCH_RUNNABLE_SLEEP = 1000;

        public BatchRunnable() {
            super();
        }

        private final WaitNotify waitNotify = new WaitNotify();

        private volatile boolean cancelled = false;

        public void cancel() {
            cancelled = true;
        }

        public WaitNotify getWaitNotify() {
            return waitNotify;
        }

        /**
         * Run
         */
        public void run() {
            while (!cancelled) {
                while (queue.peek() != null) {
                    String message = queue.poll();
                    if (message != null) {
                        LOGGER.debug(type + " - start for notification: " + message);
                        Session session = getSession();
                        Transaction tx = session.beginTransaction();
                        Query query = session.createSQLQuery(QUERY_GET_SOCIAL_NETWORK_ID_LIST);
                        ScrollableResults socialNetworkIDs = query
                                .setCacheMode(CacheMode.IGNORE)
                                .scroll(ScrollMode.FORWARD_ONLY);
                        List<String> socialNetworkIDList = new ArrayList<String>();
                        int count = 0;
                        try {
                            while (socialNetworkIDs.next()) {
                                String socialNetworkID = (String) socialNetworkIDs.get(0);
                                socialNetworkIDList.add(socialNetworkID);
                                if (++count % batchMax == 0) {
                                    //flush a batch of updates and release memory:
                                    session.flush();
                                    session.clear();
                                    addNotificationsToQueue(socialNetworkIDList, message, count);
                                    socialNetworkIDList = new ArrayList<String>();
                                    try {
                                        Thread.sleep(BATCH_RUNNABLE_SLEEP);
                                    } catch (InterruptedException e) {
                                        LOGGER.error(type + " - BatchRunnable sleep: " + BATCH_RUNNABLE_SLEEP, e);
                                    }
                                }
                            }
                            if (!socialNetworkIDList.isEmpty()) {
                                addNotificationsToQueue(socialNetworkIDList, message, count);
                            }
                        } catch (CommonException e) {
                            LOGGER.error(type + " - break for notification: " + message, e);
                        }
                        tx.commit();
                        //session.close();
                        LOGGER.info(type + " - added completed, total count: " + count
                                + " for notification: " + message);
                    }
                }
                LOGGER.debug(type + " - call waitNotify.doWait()");
                waitNotify.doWait();
            }
            shutdown();
        }

        private void addNotificationsToQueue(List<String> socialNetworkIDList, String message, int count)
                throws CommonException {
            NotificationsRunnable notificationsRunnable =
                    new NotificationsRunnable(notificationsRunnableNumber++, socialNetworkIDList, message);
            try {
                LOGGER.debug(getLogAddNotificationsToQueue(notificationsRunnable, count, "wait"));
                available.acquire();
                senderExecutor.getQueue().add(notificationsRunnable);
                LOGGER.debug(getLogAddNotificationsToQueue(notificationsRunnable, count, "added"));
            } catch (InterruptedException e) {
                LOGGER.error(getLogAddNotificationsToQueue(notificationsRunnable, count, ""), e);
                throw new CommonException(e);
            } finally {
                available.release();
            }
        }

        private String getLogAddNotificationsToQueue(
                NotificationsRunnable notificationsRunnable, int count, String label) {
            return type + " - addNotificationsToQueue: " + notificationsRunnable.getNumber()
                    + " " + label
                    + ", size: " + notificationsRunnable.getSocialNetworkIDListSize()
                    + ", count: " + count
                    + " for notification: " + notificationsRunnable.getMessage();
        }

        public void shutdown() {
            LOGGER.info(type + " - stopped. Messages aren't sent: " + queue);
        }
    }

    private class NotificationsRunnable implements Runnable {

        private long number;

        private List<String> socialNetworkIDList;

        private String message;

        private NotificationsRunnable(long number, List<String> socialNetworkIDList, String message) {
            this.number = number;
            this.socialNetworkIDList = socialNetworkIDList;
            this.message = message;
        }

        public long getNumber() {
            return number;
        }

        public int getSocialNetworkIDListSize() {
            return socialNetworkIDList.size();
        }

        public String getMessage() {
            return message;
        }

        public void run() {
            try {
                LOGGER.debug(getLogMethodSendNotifications("wait"));
                available.acquire();
                LOGGER.debug(getLogMethodSendNotifications("start"));
                socialNetworkClient.methodSendNotifications(socialNetworkIDList, message);
                LOGGER.debug(getLogMethodSendNotifications("completed"));
            } catch (InterruptedException e) {
                LOGGER.error(getLogMethodSendNotifications(""), e);
            } catch (CommonException e) {
                LOGGER.error(getLogMethodSendNotifications(""), e);
            } catch (Throwable e) {
                LOGGER.error(getLogMethodSendNotifications(""), e);
            } finally {
                available.release();
            }
        }

        private String getLogMethodSendNotifications(String label) {
            return type + " - NotificationsRunnable: " + getNumber()
                    + " " + label
                    + " size: " + getSocialNetworkIDListSize()
                    + " for notification: " + getMessage();
        }

    }

}
