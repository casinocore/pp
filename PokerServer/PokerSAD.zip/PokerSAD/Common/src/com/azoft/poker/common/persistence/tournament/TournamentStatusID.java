package com.azoft.poker.common.persistence.tournament;

public enum TournamentStatusID {

    PLANNED((byte) 1),
    ACTIVE((byte) 3),
    CANCELED((byte) 8),
    CLOSED((byte) 9);

    private byte typeId;

    TournamentStatusID(byte typeId) {
        this.typeId = typeId;
    }

    public byte getTypeId() {
        return typeId;
    }

    public static TournamentStatusID valueOf(short typeId) {
        TournamentStatusID result = null;
        for (TournamentStatusID tournamentStatusID : TournamentStatusID.values()) {
            if (tournamentStatusID.getTypeId() == typeId) {
                result = tournamentStatusID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "TournamentStatusID{" +
                "name=" + name() +
                " typeId=" + typeId +
                '}';
    }

}