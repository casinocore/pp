package com.azoft.poker.common.socialnetwork;

public enum SocialNetworkTypeID {

    SCHOOLMATE((short) 1),
    VKONTAKTE((short) 2),
    MAILRU((short) 3),
    FACEBOOK((short) 4);

    public static final String PROPERTY_TYPE_ID = "TYPE_ID";

    private short typeId;

    SocialNetworkTypeID(short typeId) {
        this.typeId = typeId;
    }

    public short getTypeId() {
        return typeId;
    }

    public static SocialNetworkTypeID valueOf(short typeId) {
        SocialNetworkTypeID result = null;
        for (SocialNetworkTypeID socialNetworkTypeID : SocialNetworkTypeID.values()) {
            if (socialNetworkTypeID.getTypeId() == typeId) {
                result = socialNetworkTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "SocialNetworkTypeID{" +
                "name=" + name() +
                ", typeId=" + typeId +
                '}';
    }
}