package com.azoft.poker.common.socialnetwork.vkontakte;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Constants for vkontakte
 */
public class Constants extends com.azoft.poker.common.socialnetwork.Constants {

    /**
     * API version
     */
    public static final String API_VERSION = "3.0";

    /**
     * API version query
     */
    public static final String QUERY_VERSION = "v";

    /**
     * The default period of calls. Restriction - 5 calls in a second.
     */
    public static final int DEFAULT_CALLS_PERIOD = 200;

    /**
     * The application id associated with the calling application.
     */
    public static final String QUERY_APPLICATION_ID = "api_id";

    private static final String DATE_FORMAT = "dd.M.yyyy";

    private static final String SHORT_DATE_FORMAT = "dd.M";

    /**
     * Date format
     */
    public static final DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);

    /**
     * Short date format
     */
    public static final DateFormat shortDateFormat = new SimpleDateFormat(SHORT_DATE_FORMAT);

    /**
     * 'secure.withdrawVotes' method
     */
    public static final String METHOD_WITHDRAW_VOTES = "secure.withdrawVotes";

    /**
     * 'secure.getBalance' method
     */
    public static final String METHOD_GET_BALANCE = "secure.getBalance";

    /**
     * 'getProfiles' method
     */
    public static final String METHOD_GET_PROFILES = "getProfiles";

    /**
     * 'friends.get' method
     */
    public static final String METHOD_FRIENDS_GET = "friends.get";

    /**
     * 'secure.sendNotification' method
     */
    public static final String METHOD_SEND_NOTIFICATION = "secure.sendNotification";

    /**
     * 'timestamp' parameter name
     */
    public static final String PARAMETER_TIMESTAMP = "timestamp";

    /**
     * 'random' parameter name
     */
    public static final String PARAMETER_RANDOM = "random";

    /**
     * 'test_mode' parameter value
     */
    public static final String TEST_MODE = "1";

    /**
     * 'test_mode' parameter name
     */
    public static final String PARAMETER_TEST_MODE = "test_mode";

    /**
     * 'uid' parameter name
     */
    public static final String PARAMETER_NAME_UID = "uid";

    /**
     * 'votes' parameter name
     */
    public static final String PARAMETER_VOTES = "votes";

    /**
     * 'fields' parameter value
     */
    public static final String PARAMETER_VALUE_FIELDS = "uid,first_name,last_name,nickname,sex,bdate,city,country";

    /**
     * 'message' parameter name
     */
    public static final String PARAMETER_MESSAGE = "message";

}
