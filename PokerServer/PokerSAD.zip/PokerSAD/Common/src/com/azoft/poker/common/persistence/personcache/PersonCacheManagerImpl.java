package com.azoft.poker.common.persistence.personcache;

import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.tournament.TournamentManagerImpl;
import com.azoft.poker.common.persistence.tournament.TournamentPersonStatus;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

/**
 * Person cache manager
 */
public class PersonCacheManagerImpl extends PersistenceManagerImpl implements PersonCacheManager {

    private final static Logger LOGGER = LoggerFactory.getLogger(PersonCacheManagerImpl.class);

    private static final String PERSON_ID_PARAMETER = "personId";
    private static final String TOURNAMENT_ID_PARAMETER = "tournamentId";
    private static final String QUERY_GET_PERSON_CACHE =
            "from PersonCache pc where pc.personId = :" + PERSON_ID_PARAMETER + " and pc.tournamentId = :" + TOURNAMENT_ID_PARAMETER;

    private static final String QUERY_MOVE_GAME_BALACE_FOR_CASH_GAME =
            "update person p" +
                    " set p.balance = ifnull((" +
                    "  select p.balance + pc.game_balance" +
                    "  from person_cache pc" +
                    "  where pc.person_id = p.id" +
                    "   and pc.tournament_id = " + NO_TOURNAMENT +
                    "  ), p.balance)";

    private static final String QUERY_ZERO_GAME_BALANCE_FOR_CASH_GAME =
            "update person_cache pc" +
                    " set pc.game_balance = 0" +
                    " where pc.tournament_id = " + NO_TOURNAMENT;

    private static final String QUERY_MOVE_GAME_BALACE_FOR_TOURNAMENT_GAME =
            "update tournament_person_status tps" +
                    " set tps.tournament_balance = ifnull((" +
                    "  select tps.tournament_balance + pc.game_balance" +
                    "  from person_cache pc" +
                    "  where pc.person_id = tps.person_id" +
                    "   and pc.tournament_id = tps.tournament_id" +
                    "  ), tps.tournament_balance)";

    private static final String QUERY_DELETE_GAME_BALANCE_FOR_TOURNAMENT_GAME =
            "delete from person_cache" +
                    " where person_cache.tournament_id != " + NO_TOURNAMENT;

    private static final String QUERY_GET_TOTAL_BALANCE_SUM =
            "select sum(p.balance + ifnull(pc.game_balance, 0)) from person p" +
                    " left join person_cache pc on (pc.person_id = p.id and pc.tournament_id = " + NO_TOURNAMENT + ")";

    private static PersonCacheManager instance = null;

    public static synchronized PersonCacheManager getInstance() {
        if (instance == null) {
            instance = new PersonCacheManagerImpl();
        }
        return instance;
    }

    private PersonCacheManagerImpl() {
        super();
    }

    @SuppressWarnings("unchecked")
    public PersonCache getPersonCache(Long personId, Long tournamentId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        PersonCache personCache = (PersonCache) session.createQuery(QUERY_GET_PERSON_CACHE)
                .setLong(PERSON_ID_PARAMETER, personId)
                .setLong(TOURNAMENT_ID_PARAMETER, getTournamentId(tournamentId))
                .uniqueResult();
        transaction.commit();
        return personCache;
    }

    private Long getTournamentId(Long tournamentId) {
        Long result = NO_TOURNAMENT;
        if (tournamentId != null) {
            result = tournamentId;
        }
        return result;
    }

    private PersonCache createPersonCache(Long tournamentId, Long personId) {
        PersonCache personCache = new PersonCache();
        personCache.setPersonId(personId);
        personCache.setGameBalance(0L);
        personCache.setTournamentId(getTournamentId(tournamentId));
        return personCache;
    }

    @SuppressWarnings("unchecked")
    public void moveBalanceToGameBalance(Person person, Long tournamentId, Long balanceDelta) {
        if (balanceDelta != null && balanceDelta > 0) {
            PersonCache personCache = getPersonCache(person.getId(), tournamentId);
            if (personCache == null) {
                personCache = createPersonCache(tournamentId, person.getId());
            }
            TournamentPersonStatus tpStatus = null;
            if (tournamentId == null) {
                person.setBalance(person.getBalance() - balanceDelta);
            } else {
                tpStatus = TournamentManagerImpl.getInstance().getTournamentPersonStatus(tournamentId, person.getId());
                tpStatus.setTournamentBalance(tpStatus.getTournamentBalance() - balanceDelta);
            }
            personCache.setGameBalance(personCache.getGameBalance() + balanceDelta);
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            transaction.begin();
            if (tournamentId == null) {
                session.update(person);
            } else {
                session.update(tpStatus);
            }
            session.merge(personCache);
            transaction.commit();
        }
    }

    @SuppressWarnings("unchecked")
    public void moveGameBalanceToBalance(Person person, Long tournamentId) {
        PersonCache personCache = getPersonCache(person.getId(), tournamentId);
        if (personCache != null && personCache.getGameBalance() != 0) {
            TournamentPersonStatus tpStatus = null;
            if (tournamentId == null) {
                person.setBalance(person.getBalance() + personCache.getGameBalance());
            } else {
                tpStatus = TournamentManagerImpl.getInstance().getTournamentPersonStatus(tournamentId, person.getId());
                tpStatus.setTournamentBalance(tpStatus.getTournamentBalance() + personCache.getGameBalance());
            }
            personCache.setGameBalance(0L);
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            transaction.begin();
            if (tournamentId == null) {
                session.update(person);
            } else {
                session.update(tpStatus);
            }
            session.update(personCache);
            transaction.commit();
        }
    }

    @SuppressWarnings("unchecked")
    public void addBalanceAndZeroGameBalance(Person person, Long tournamentId, Long balanceDelta) {
        LOGGER.debug("addBalanceAndZeroGameBalance. personId: " + person
                + "; tournamentId: " + tournamentId + "; balanceDelta: " + balanceDelta);
        PersonCache personCache = getPersonCache(person.getId(), tournamentId);
        TournamentPersonStatus tpStatus = null;
        if (tournamentId == null) {
            person.setBalance(person.getBalance() + balanceDelta);
        } else {
            tpStatus = TournamentManagerImpl.getInstance().getTournamentPersonStatus(tournamentId, person.getId());
            tpStatus.setTournamentBalance(tpStatus.getTournamentBalance() + balanceDelta);
        }
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        if (tournamentId == null) {
            session.update(person);
        } else {
            session.update(tpStatus);
        }
        if (personCache != null && personCache.getGameBalance() != 0) {
            personCache.setGameBalance(0L);
            session.update(personCache);
            LOGGER.debug("addBalanceAndZeroGameBalance. session.update(personCache) personId: " + person
                    + "; tournamentId: " + tournamentId + "; balanceDelta: " + balanceDelta);
        }
        transaction.commit();
    }

    @SuppressWarnings("unchecked")
    public void moveGameBalanceToBalance() {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        int moveCount = session.createSQLQuery(QUERY_MOVE_GAME_BALACE_FOR_CASH_GAME).executeUpdate();
        int zeroCount = session.createSQLQuery(QUERY_ZERO_GAME_BALANCE_FOR_CASH_GAME).executeUpdate();
        LOGGER.debug("moveGameBalanceToBalance for cache games - moveCount: " + moveCount + "; zeroCount: " + zeroCount);
        moveCount = session.createSQLQuery(QUERY_MOVE_GAME_BALACE_FOR_TOURNAMENT_GAME).executeUpdate();
        zeroCount = session.createSQLQuery(QUERY_DELETE_GAME_BALANCE_FOR_TOURNAMENT_GAME).executeUpdate();
        LOGGER.debug("moveGameBalanceToBalance for tournaments - moveCount: " + moveCount + "; zeroCount: " + zeroCount);
        transaction.commit();
    }

    @SuppressWarnings("unchecked")
    public Long getTotalBalanceSum() {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigDecimal sum = (BigDecimal) session.createSQLQuery(QUERY_GET_TOTAL_BALANCE_SUM).uniqueResult();
        transaction.commit();
        if (sum == null) {
            sum = BigDecimal.ZERO;
        }
        return sum.longValue();
    }

    public Long getTotalBalance(Person person) {
        long totalBalance = person.getBalance();
        PersonCache personCache = getPersonCache(person.getId(), NO_TOURNAMENT);
        if (personCache != null) {
            totalBalance += personCache.getGameBalance();
        }
        return totalBalance;
    }

}