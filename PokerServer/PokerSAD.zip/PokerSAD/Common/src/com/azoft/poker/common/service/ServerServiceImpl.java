package com.azoft.poker.common.service;

import com.azoft.poker.common.persistence.server.Server;
import com.azoft.poker.common.persistence.server.ServerManager;
import com.azoft.poker.common.persistence.server.ServerManagerImpl;
import com.azoft.poker.common.persistence.server.ServerTypeID;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ServerServiceImpl implements ServerService {

    private Server accessServer;
    private Server loginServer;
    private Server adminServer;
    private List<Server> lobbyServers = new CopyOnWriteArrayList<Server>();

    private static ServerService instance = null;

    public static synchronized ServerService getInstance() {
        if (instance == null) {
            instance = new ServerServiceImpl();
        }
        return instance;
    }

    private ServerServiceImpl() {
        ServerManager manager = ServerManagerImpl.getInstance();
        accessServer = getFirstServer(manager.getServers(ServerTypeID.ACCESS_SERVER));
        loginServer = getFirstServer(manager.getServers(ServerTypeID.LOGIN_SERVER));
        adminServer = getFirstServer(manager.getServers(ServerTypeID.ADMIN_SERVER));
        lobbyServers.addAll(manager.getServers(ServerTypeID.LOBBY_SERVER));
    }

    public Server getAccessServer() {
        return accessServer;
    }

    public Server getLoginServer() {
        return loginServer;
    }

    public Server getAdminServer() {
        return adminServer;
    }

    public Server getFreeLobbyServer() {
        Server server = null;
        server = getFirstServer(lobbyServers);
        return server;
    }

    private Server getFirstServer(Collection<Server> servers) {
        Server server = null;
        Iterator<Server> serverIterator = servers.iterator();
        if (serverIterator.hasNext()) {
            server = serverIterator.next();
        }
        return server;
    }

}
