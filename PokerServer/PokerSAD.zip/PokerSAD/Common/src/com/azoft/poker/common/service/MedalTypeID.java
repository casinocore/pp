package com.azoft.poker.common.service;

/**
 * Medal type ID
 */
public enum MedalTypeID {

    GOLD_MEDAL((byte) 1);

    private byte typeId;

    MedalTypeID(byte typeId) {
        this.typeId = typeId;
    }

    public byte getTypeId() {
        return typeId;
    }

    public static MedalTypeID valueOf(byte typeId) {
        MedalTypeID result = null;
        for (MedalTypeID medalTypeID : MedalTypeID.values()) {
            if (medalTypeID.getTypeId() == typeId) {
                result = medalTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "MedalTypeID{" +
                "name=" + name() +
                ", typeId=" + typeId +
                '}';
    }

}