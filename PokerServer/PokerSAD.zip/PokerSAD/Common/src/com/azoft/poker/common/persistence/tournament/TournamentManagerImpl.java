package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import com.azoft.poker.common.persistence.person.InfoPlayerBean;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.personcache.PersonCache;
import com.azoft.poker.common.persistence.personcache.PersonCacheManagerImpl;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigInteger;
import java.util.*;

public class TournamentManagerImpl extends PersistenceManagerImpl<Tournament>
        implements TournamentManager {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(TournamentManagerImpl.class);

    private static final long NOT_EXIST_RANK = 0L;

    private static final String PARAMETER_PERSON_ID = "personId";
    private static final String PARAMETER_TOURNAMENT_ID = "tournamentId";
    private static final String PARAMETER_TOP_NUMBER = "topNumber";
    private static final String PARAMETER_TOTAL_BALANCE = "totalBalance";
    private static final String PARAMETER_FROM_DATE = "from";
    private static final String PARAMETER_TO_DATE = "to";
    private static final String PARAMETER_TYPE = "type";
    private static final String PARAMETER_EXCLUSIVE_ID = "exId";

    private static final String FROM_TOURNAMENT = "from Tournament t";
    private static final String FROM_TOURNAMENT_PERSON_STATUS = "from TournamentPersonStatus tps";
    public static final String TABLE_TOURNAMENT = "tournament";
    private static final String QUERY_TOURNAMENT_PERSON_STATUS_COUNT = "select count(tps.id) from tournament_person_status tps"
            + " where tps.tournament_id = :" + PARAMETER_TOURNAMENT_ID;
    private static final String QUERY_REPARTICIPANTS_TOURNAMENT_PERSON_STATUS_COUNT = "select count(tps.id) from tournament_person_status tps"
            + " where tps.tournament_id = :"
            + PARAMETER_TOURNAMENT_ID
            + " and tps.payments_number > 1";
    private static final String QUERY_PERSON_TOURNAMENTS_COUNT = "select count(tps.id) from tournament_person_status tps"
            + " where tps.person_id = :" + PARAMETER_PERSON_ID;
    private static final String QUERY_GET_TOURNAMENT_PERSON_STATUS = FROM_TOURNAMENT_PERSON_STATUS
            + " where tps.person.id = :"
            + PARAMETER_PERSON_ID
            + " and tps.tournament.id = :" + PARAMETER_TOURNAMENT_ID;

    private static final String FIELD_PLAYER_ID = "player_id";
    private static final String FIELD_SOCIAL_NETWORK_ID = "socialNetworkID";
    private static final String FIELD_TOTAL_BALANCE = "total_balance";
    private static final String FIELD_LEAVING_TIME = "leaving_time";

    private static final String QUERY_GET_TOURNAMENT_PLAYERS = "select"
            + "  tps.person_id as " + FIELD_PLAYER_ID + ","
            + "  b." + FIELD_TOTAL_BALANCE + ","
            + "  p.social_network_id as " + FIELD_SOCIAL_NETWORK_ID
            + " from tournament_person_status tps, person p,"
            + " (select a.id " + FIELD_PLAYER_ID + ", sum(a.balance) " + FIELD_TOTAL_BALANCE
            + " from"
            + "  ("
            + "  select tps1.person_id id, tps1.tournament_balance balance"
            + "    from tournament_person_status tps1 where tps1.tournament_id = :" + PARAMETER_TOURNAMENT_ID
            + "  union all"
            + "  select person_id id, game_balance balance"
            + "    from person_cache where tournament_id = :" + PARAMETER_TOURNAMENT_ID
            + "  ) a"
            + "  group by a.id"
            + "  order by " + FIELD_TOTAL_BALANCE + " desc"
            + "  limit :" + PARAMETER_TOP_NUMBER
            + " ) b"
            + " where tps.person_id = b." + FIELD_PLAYER_ID
            + " and tps.tournament_id = :" + PARAMETER_TOURNAMENT_ID + " and p.id = " + FIELD_PLAYER_ID;

    private static final String QUERY_GET_MTT_PLAYERS_BY_BALANCE = "select"
            + "  tps.person_id as " + FIELD_PLAYER_ID + ","
            + "  b." + FIELD_TOTAL_BALANCE + ","
            + "  p.social_network_id as " + FIELD_SOCIAL_NETWORK_ID
            + " from tournament_person_status tps, person p,"
            + " (select a.id " + FIELD_PLAYER_ID + ", sum(a.balance) " + FIELD_TOTAL_BALANCE
            + " from"
            + "  ("
            + "  select tps1.person_id id, tps1.tournament_balance balance, tps1.leaving_time leavingTime"
            + "    from tournament_person_status tps1 where tps1.tournament_id = :" + PARAMETER_TOURNAMENT_ID
            + "  union all"
            + "  select person_id id, game_balance balance, null leavingTime"
            + "    from person_cache where tournament_id = :" + PARAMETER_TOURNAMENT_ID
            + "  ) a"
            + "  where a.leavingTime is null"
            + "  group by a.id"
            + "  having not " + FIELD_TOTAL_BALANCE + " is null"
            + "  order by " + FIELD_TOTAL_BALANCE + " desc"
            + "  limit :" + PARAMETER_TOP_NUMBER
            + " ) b"
            + " where tps.person_id = b." + FIELD_PLAYER_ID
            + " and tps.tournament_id = :" + PARAMETER_TOURNAMENT_ID + " and p.id = " + FIELD_PLAYER_ID
            + " and tps.leaving_time is null";

    private static final String QUERY_GET_MTT_PLAYERS_BY_LEAVING_TIME = "select"
            + " tps.person_id as " + FIELD_PLAYER_ID + ","
            + " p.social_network_id as " + FIELD_SOCIAL_NETWORK_ID + ","
            + " tps.leaving_time as " + FIELD_LEAVING_TIME
            + " FROM tournament_person_status tps, person p"
            + "   where tps.tournament_id = :" + PARAMETER_TOURNAMENT_ID
            + "    and p.id = tps.person_id"
            + "    and not tps.leaving_time is null"
            + " order by leaving_time desc"
            + " limit :" + PARAMETER_TOP_NUMBER;

    private static final String QUERY_GET_RANK_BY_BALANCE = "select count(tps.id) + 1 as rank from tournament_person_status tps"
            + "   left join person_cache pc on"
            + "       (pc.person_id = tps.person_id and pc.tournament_id = tps.tournament_id) "
            + "   where "
            + "       tps.tournament_id =:" + PARAMETER_TOURNAMENT_ID
            + "       and (tps.tournament_balance + ifnull(pc.game_balance, 0)) > :" + PARAMETER_TOTAL_BALANCE;

    private static final String QUERY_GET_RANK_BY_LEAVING_TIME = "select"
            + " count(tps.id) + 1 as rank from tournament_person_status tps"
            + "  left join tournament_person_status ptps on ptps.person_id =:" + PARAMETER_PERSON_ID
            + "    and ptps.tournament_id = tps.tournament_id"
            + "  where tps.tournament_id =:" + PARAMETER_TOURNAMENT_ID
            + "    and tps.leaving_time > ifnull(ptps.leaving_time, '1980-01-01 00:00:00')";

    private static final String QUERY_GET_COUNT_ACTIVE_MTT_PLAYERS = "select count(tps.id)"
            + " from tournament_person_status tps"
            + "   where tps.tournament_id =:" + PARAMETER_TOURNAMENT_ID
            + "    and tps.leaving_time is null";

    private static final String QUERY_GET_TOURNAMENT_PERSONS = "select tps.person from TournamentPersonStatus tps"
            + " where tps.tournament.id = :" + PARAMETER_TOURNAMENT_ID;

    private static final String QUERY_GET_COUNT_TOURNAMENT_WINNER = "select count(tps.tournament_id)"
            + "  from tournament_person_status tps"
            + "  left join tournament t on t.id = tps.tournament_id"
            + "  where"
            + "       tps.person_id = :"
            + PARAMETER_PERSON_ID
            + "    and"
            + "       t.status = "
            + TournamentStatusID.CLOSED.getTypeId()
            + "    and"
            + "       tps.tournament_balance = "
            + "   ("
            + "    select max(tps2.tournament_balance) as max_balance2"
            + "    from tournament_person_status tps2"
            + "    where tps2.tournament_id = tps.tournament_id" + "    )";

    private static final String QUERY_GET_EXISTING_TOURNAMENTS_COUNT = "select count(*) from tournament t "
            + "where (not((t.to_date < :from) or (t.from_date > :to))) and (t.type = :type)";

    public static final Long DEFAULT_TOURNAMENT_FEE = 300L;
    public static final Long DEFAULT_TOURNAMENT_START_CHIPS_COUNT = 1000L;

    private static TournamentManager instance = null;

    public static synchronized TournamentManager getInstance() {
        if (instance == null) {
            instance = new TournamentManagerImpl();
        }
        return instance;
    }

    private TournamentManagerImpl() {
        super();
    }

    public void updateTournament(Tournament tournament) {
        update(tournament);
    }

    public Tournament getTournament(long tournamentId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Tournament tournament = (Tournament) session.get(Tournament.class,
                tournamentId);
        transaction.commit();
        return tournament;
    }

    public Tournament getCurrentTournament(TournamentTypeID tournamentTypeID) {
        Tournament tournament = null;
        List<Tournament> tournaments = getActiveTournaments(tournamentTypeID);
        if (!tournaments.isEmpty()) {
            tournament = tournaments.get(0);
        }
        return tournament;
    }

    public List<Tournament> getActiveTournaments(
            TournamentTypeID tournamentTypeID) {
        return getTournaments(tournamentTypeID, TournamentStatusID.ACTIVE);
    }

    public List<Tournament> getTournaments() {
        return getTournaments(null, null);
    }

    @SuppressWarnings("unchecked")
    public List<Tournament> getTournaments(TournamentTypeID tournamentTypeID,
                                           TournamentStatusID tournamentStatusID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        StringBuffer strWhere = new StringBuffer("");
        if (tournamentTypeID != null) {
            strWhere.append(" t.type = ").append(tournamentTypeID.getTypeId());
        }
        if (tournamentStatusID != null) {
            if (strWhere.length() > 0) {
                strWhere.append(" and");
            }
            strWhere.append(" t.status = ").append(
                    tournamentStatusID.getTypeId());
        }
        if (strWhere.length() > 0) {
            strWhere.insert(0, " where");
        }
        StringBuffer strQuery = new StringBuffer(FROM_TOURNAMENT);
        strQuery.append(strWhere);
        strQuery.append(" order by t.status, t.type");
        Query query = session.createQuery(strQuery.toString());
        List<Tournament> list = query.list();
        transaction.commit();
        return list;
    }

    public Tournament createTournament(TournamentTypeID tournamentTypeID) {
        Tournament t = new Tournament(tournamentTypeID,
                tournamentTypeID.getLabel(), DEFAULT_TOURNAMENT_FEE,
                DEFAULT_TOURNAMENT_START_CHIPS_COUNT);
        t.setStatus(TournamentStatusID.PLANNED.getTypeId());
        save(t);
        return t;
    }

    public Tournament createTournament(Tournament tournament) {
        Tournament t = new Tournament(TournamentTypeID.valueOf(tournament
                .getType()), tournament.getName(), tournament.getFee(),
                tournament.getStartChipsCount());
        t.setMinPlayersCount(tournament.getMinPlayersCount());
        t.setMaxPlayersCount(tournament.getMaxPlayersCount());
        t.setWinnerCount(tournament.getWinnerCount());
        t.setDescriptor(tournament.getDescriptor());
        Map<String, String> attributes = new HashMap<String, String>(
                tournament.getAttributes());
        t.getAttributes().putAll(attributes);
        t.setStatus(TournamentStatusID.PLANNED.getTypeId());
        save(t);
        return t;
    }

    public void saveTournament(Tournament tournament) {
        tournament.setStatus(TournamentStatusID.PLANNED.getTypeId());
        save(tournament);
    }

    public void changeTournamentStatus(Tournament tournament,
                                       TournamentStatusID tournamentStatusID) {
        tournament.setStatus(tournamentStatusID.getTypeId());
        update(tournament);
    }

    public Long getTournamentsCount() {
        return getCount(TABLE_TOURNAMENT).longValue();
    }

    public Long getFee(Tournament tournament, short paymentsNumber) {
        Long result = null;
        try {
            TournamentWrapper tw = TournamentFactoryImpl
                    .createTournamentWrapper(tournament);
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            transaction.begin();
            result = tw.getFee(paymentsNumber);
            transaction.commit();
        } catch (CommonException e) {
            LOGGER.error("getFee", e);
        }
        return result;
    }

    public TournamentPersonStatus addPlayerToTournament(Long tournamentId, Person person, boolean isInitializationTournamentBalance) {
        Tournament tournament = getTournament(tournamentId);
        return addPlayerToTournament(tournament, person, isInitializationTournamentBalance);
    }

    public TournamentPersonStatus addPlayerToTournament(Tournament tournament, Person person, boolean isInitializationTournamentBalance) {
        TournamentPersonStatus status = getTournamentPersonStatus(
                tournament.getId(), person.getId());
        if (status == null) {
            status = new TournamentPersonStatus();
            status.setTournamentBalance(0L);
            status.setPerson(person);
            status.setTournament(tournament);
        }
        storeTournamentPersonStatus(status, person, isInitializationTournamentBalance);
        return status;
    }

    public Long removePlayerFromTournament(Long tournamentId, Person person) {
        Long returnFee = null;
        TournamentPersonStatus status = getTournamentPersonStatus(
                tournamentId, person.getId());
        if (status != null) {
            try {
                TournamentWrapper tw = TournamentFactoryImpl.createTournamentWrapper(status.getTournament());
                Session session = getSession();
                Transaction transaction = session.beginTransaction();
                transaction.begin();

                returnFee = tw.getFee(status.getPaymentsNumber());
                long personBalance = person.getBalance() + returnFee;
                person.setBalance(personBalance);
                session.delete(status);
                session.merge(person);

                transaction.commit();
            } catch (CommonException e) {
                LOGGER.error("removePlayerFromTournament", e);
            }
        }
        return returnFee;
    }

    private void storeTournamentPersonStatus(TournamentPersonStatus status,
                                             Person person, boolean isInitializationTournamentBalance) {
        try {
            TournamentWrapper tw = TournamentFactoryImpl.createTournamentWrapper(status.getTournament());
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            transaction.begin();

            Long fee = tw.getFee(status.incPaymentsNumber());
            long personBalance = person.getBalance() - fee;
            person.setBalance(personBalance);
            if (isInitializationTournamentBalance) {
                Long tournamentBalance = status.getTournament().getStartChipsCount();
                status.setTournamentBalance(tournamentBalance);
            }
            session.merge(status);
            session.merge(person);

            transaction.commit();
        } catch (CommonException e) {
            LOGGER.error("storeTournamentPersonStatus", e);
        }
    }

    public TournamentPersonStatus getTournamentPersonStatus(Long tournamentId,
                                                            Long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        TournamentPersonStatus tournament = (TournamentPersonStatus) session
                .createQuery(QUERY_GET_TOURNAMENT_PERSON_STATUS)
                .setLong(PARAMETER_PERSON_ID, personId)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId).uniqueResult();
        transaction.commit();
        return tournament;
    }

    public void updateTournamentPersonStatus(TournamentPersonStatus tournamentPersonStatus) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.update(tournamentPersonStatus);
        transaction.commit();
    }

    public Long getTournamentPersonStatusCount(Long tournamentId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_TOURNAMENT_PERSON_STATUS_COUNT)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId).uniqueResult();
        transaction.commit();
        return count.longValue();
    }

    public Long getReParticipantsTournamentPersonStatusCount(Long tournamentId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(
                        QUERY_REPARTICIPANTS_TOURNAMENT_PERSON_STATUS_COUNT)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId).uniqueResult();
        transaction.commit();
        return count.longValue();
    }

    public Long getTournamentsCount(Long userId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_PERSON_TOURNAMENTS_COUNT)
                .setLong(PARAMETER_PERSON_ID, userId).uniqueResult();
        transaction.commit();
        return count.longValue();
    }

    public List<InfoPlayerBean> getTournamentPlayers(Long tournamentId,
                                                     int topNumber) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        @SuppressWarnings("unchecked")
        List<Object[]> objects = session
                .createSQLQuery(QUERY_GET_TOURNAMENT_PLAYERS)
                .addScalar(FIELD_PLAYER_ID, Hibernate.LONG)
                .addScalar(FIELD_SOCIAL_NETWORK_ID, Hibernate.STRING)
                .addScalar(FIELD_TOTAL_BALANCE, Hibernate.LONG)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId)
                .setInteger(PARAMETER_TOP_NUMBER, topNumber).list();
        transaction.commit();
        return PersonManagerImpl.boxingTopPlayersByBalance(objects);
    }

    public List<InfoPlayerBean> getMTTPlayersByBalance(Long tournamentId, int topNumber) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        @SuppressWarnings("unchecked")
        List<Object[]> objects = session
                .createSQLQuery(QUERY_GET_MTT_PLAYERS_BY_BALANCE)
                .addScalar(FIELD_PLAYER_ID, Hibernate.LONG)
                .addScalar(FIELD_SOCIAL_NETWORK_ID, Hibernate.STRING)
                .addScalar(FIELD_TOTAL_BALANCE, Hibernate.LONG)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId)
                .setInteger(PARAMETER_TOP_NUMBER, topNumber).list();
        transaction.commit();
        return PersonManagerImpl.boxingTopPlayersByBalance(objects);
    }

    public List<InfoPlayerBean> getMTTPlayersByLeavingTime(Long tournamentId, int topNumber,
                                                           List<InfoPlayerBean> list) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        @SuppressWarnings("unchecked")
        List<Object[]> objects = session
                .createSQLQuery(QUERY_GET_MTT_PLAYERS_BY_LEAVING_TIME)
                .addScalar(FIELD_PLAYER_ID, Hibernate.LONG)
                .addScalar(FIELD_SOCIAL_NETWORK_ID, Hibernate.STRING)
                .addScalar(FIELD_LEAVING_TIME, Hibernate.TIMESTAMP)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId)
                .setInteger(PARAMETER_TOP_NUMBER, topNumber - list.size()).list();
        transaction.commit();
        return PersonManagerImpl.boxingTopPlayersByLeavingTime(objects, list);
    }

    public List<InfoPlayerBean> getMTTPlayersByLeavingTime(Long tournamentId, int topNumber) {
        List<InfoPlayerBean> list = new ArrayList<InfoPlayerBean>();
        return getMTTPlayersByLeavingTime(tournamentId, topNumber, list);
    }

    public List<Person> getTournamentPersons(Long tournamentId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        @SuppressWarnings("unchecked")
        List<Person> list = session.createQuery(QUERY_GET_TOURNAMENT_PERSONS)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId).list();
        transaction.commit();
        return list;
    }

    public Long getTournamentRank(Tournament tournament, Long personId, Long totalBalance) {
        Long rank = NOT_EXIST_RANK;
        if (tournament.getType() == TournamentTypeID.MTT_TOURNAMENT.getTypeId()) {
            if (tournament.getStatus() == TournamentStatusID.ACTIVE.getTypeId()) {
                TournamentPersonStatus tps = getTournamentPersonStatus(tournament.getId(), personId);
                if (tps != null) {
                    if (tps.getLeavingTime() == null) {
                        rank = getTournamentRankByBalance(tournament.getId(), totalBalance);
                    } else {
                        rank = getCountActiveMTTPlayers(tournament.getId());
                        rank += getTournamentRankByLeavingTime(tournament.getId(), personId);
                    }
                }
            } else if (tournament.getStatus() == TournamentStatusID.CLOSED.getTypeId()) {
                rank = getTournamentRankByLeavingTime(tournament.getId(), personId);
            }
        } else {
            if (tournament.getStatus() != TournamentStatusID.PLANNED.getTypeId()) {
                rank = getTournamentRankByBalance(tournament.getId(), totalBalance);
            }
        }
        return rank;
    }

    private Long getTournamentRankByBalance(Long tournamentId, Long totalBalance) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(QUERY_GET_RANK_BY_BALANCE)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId)
                .setLong(PARAMETER_TOTAL_BALANCE, totalBalance).uniqueResult();
        transaction.commit();
        return count.longValue();
    }

    private Long getTournamentRankByLeavingTime(Long tournamentId, Long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(QUERY_GET_RANK_BY_LEAVING_TIME)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId)
                .setLong(PARAMETER_PERSON_ID, personId).uniqueResult();
        transaction.commit();
        return count.longValue();
    }

    public Long getCountActiveMTTPlayers(Long tournamentId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_GET_COUNT_ACTIVE_MTT_PLAYERS)
                .setLong(PARAMETER_TOURNAMENT_ID, tournamentId)
                .uniqueResult();
        transaction.commit();
        if (count == null) {
            count = BigInteger.ZERO;
        }
        return count.longValue();
    }

    public Long getTotalTournamentBalance(Long tournamentId, Long userId) {
        Long balance = null;
        TournamentPersonStatus tournamentPersonStatus = getTournamentPersonStatus(
                tournamentId, userId);
        if (tournamentPersonStatus != null) {
            balance = tournamentPersonStatus.getTournamentBalance();
            PersonCache personCache = PersonCacheManagerImpl.getInstance()
                    .getPersonCache(userId, tournamentId);
            if (personCache != null && personCache.getGameBalance() != null) {
                balance += personCache.getGameBalance();
            }
        }
        return balance;
    }

    public Integer getCountTournamentWinner(Long personId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session
                .createSQLQuery(QUERY_GET_COUNT_TOURNAMENT_WINNER)
                .setLong(PARAMETER_PERSON_ID, personId).uniqueResult();
        transaction.commit();
        if (count == null) {
            count = BigInteger.ZERO;
        }
        return count.intValue();
    }

    public Integer getExistingTournamentsCount(Date from, Date to, Byte type,
                                               Long exclusiveId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        Query query = session
                .createSQLQuery(
                        exclusiveId == null ? QUERY_GET_EXISTING_TOURNAMENTS_COUNT
                                : QUERY_GET_EXISTING_TOURNAMENTS_COUNT
                                + " and (t.id != :exId)")
                .setTimestamp(PARAMETER_FROM_DATE, from)
                .setTimestamp(PARAMETER_TO_DATE, to)
                .setByte(PARAMETER_TYPE, type);
        if (exclusiveId != null) {
            query.setLong(PARAMETER_EXCLUSIVE_ID, exclusiveId);
        }
        BigInteger count = (BigInteger) query.uniqueResult();
        transaction.commit();
        if (count == null) {
            count = BigInteger.ZERO;
        }
        return count.intValue();
    }

}