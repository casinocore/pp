package com.azoft.poker.common.socialnetwork.bean;

import com.azoft.poker.common.jaxp.AbstractBean;

/**
 * Social network money
 */
public class SocialNetworkMoneyBean extends AbstractBean {

    /**
     * Social network money
     */
    private Long socialNetworkMoney;

    public SocialNetworkMoneyBean() {
    }

    public Long getSocialNetworkMoney() {
        return socialNetworkMoney;
    }

    public void setSocialNetworkMoney(Long socialNetworkMoney) {
        this.socialNetworkMoney = socialNetworkMoney;
    }

}
