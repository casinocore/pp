package com.azoft.poker.common.helper;

import java.util.Comparator;

/**
 * Desc byte comparator
 */
public class DescByteComparator implements Comparator<Byte> {

    public int compare(Byte o1, Byte o2) {
        return o2 - o1;
    }

}
