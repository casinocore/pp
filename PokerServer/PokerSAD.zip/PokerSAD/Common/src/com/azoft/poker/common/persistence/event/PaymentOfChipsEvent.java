package com.azoft.poker.common.persistence.event;

/**
 * Payment of chips event
 */
public class PaymentOfChipsEvent extends EventEntityWrapper {

    public PaymentOfChipsEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    public PaymentOfChipsEvent(Short eventType, Long referenceId) {
        super(eventType, referenceId);
    }

    public Long getAccountRevenue() {
        return getLongAttribute(ACCOUNT_REVENUE);
    }

    public void setAccountRevenue(Long accountRevenue) {
        setLongAttribute(ACCOUNT_REVENUE, accountRevenue);
    }

    public Long getAccountChips() {
        return getLongAttribute(ACCOUNT_CHIPS);
    }

    public void setAccountChips(Long accountChips) {
        setLongAttribute(ACCOUNT_CHIPS, accountChips);
    }

}
