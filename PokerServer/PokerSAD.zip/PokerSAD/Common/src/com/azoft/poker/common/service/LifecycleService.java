package com.azoft.poker.common.service;

import java.util.Map;

/**
 * Lifecycle service interface
 */
public interface LifecycleService {

    /**
     * Initialization
     *
     * @param parameters parameters (map - key: name, value: value)
     */
    void initialization(Map<String, Object> parameters);

    /**
     * Shutdown
     */
    void shutdown();

}
