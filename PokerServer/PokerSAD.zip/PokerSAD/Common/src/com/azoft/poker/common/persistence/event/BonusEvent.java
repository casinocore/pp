package com.azoft.poker.common.persistence.event;

/**
 * Bonus event
 */
public class BonusEvent extends EventEntityWrapper {

    public BonusEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    public BonusEvent(Short eventType, Long referenceId) {
        super(eventType, referenceId);
    }

    public Long getBonus() {
        return getLongAttribute(BONUS);
    }

    public void setBonus(Long bonus) {
        setLongAttribute(BONUS, bonus);
    }

}