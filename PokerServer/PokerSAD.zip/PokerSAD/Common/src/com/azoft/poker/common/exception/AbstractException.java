package com.azoft.poker.common.exception;

/**
 * Abstract exception for Poker SAD project
 */
public abstract class AbstractException extends Exception {

    /**
     * Constructs a new exception with <code>null</code> as its detail message.
     */
    public AbstractException() {
        super();
    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message message
     */
    public AbstractException(String message) {
        super(message);
    }

    /**
     * Constructs a new exception with the specified detail message and cause.
     *
     * @param message message
     * @param cause   the intercepted exception
     */
    public AbstractException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new exception with cause.
     *
     * @param cause the intercepted exception
     */
    public AbstractException(Throwable cause) {
        super(cause);
    }

}