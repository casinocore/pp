package com.azoft.poker.common.persistence;

import com.azoft.poker.common.helper.StringHelper;

import java.util.HashMap;
import java.util.Map;

/**
 * Simple domain object with an custom attributes.
 */
public class CustomAttributesEntity extends BaseEntity {

    /**
     * Length of table.name field
     */
    public static final int MAX_ATTRIBUTE_NAME_LENGTH = 255;

    /**
     * Length of table_ca.value field
     */
    public static final int MAX_ATTRIBUTE_VALUE_LENGTH = 4000;

    /**
     * Attributes (key: name, value: value)
     */
    private Map<String, String> attributes = new HashMap<String, String>();

    public CustomAttributesEntity() {
    }

    /**
     * This method intended for usage by hibernate only<br>
     * Please <b>DON'T use it</b> in application directly.
     *
     * @return map containing attributes
     */
    public Map<String, String> getAttributes() {
        return attributes;
    }

    /**
     * This method intended for usage by hibernate only<br>
     * Please <b>DON'T use it</b> in application directly.
     *
     * @param attributes attributes
     */
    protected void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    /**
     * Get attribute value by attribute name
     *
     * @param name attribute name
     * @return attribute value or null if attribute not found
     */
    public String getAttributeValue(String name) {
        return attributes.get(name);
    }

    /**
     * Add attribute.
     * If attribute value is <code>null</code> or empty string then attribute will be removed.
     *
     * @param name  attribute name
     * @param value attribute value
     * @throws NullPointerException     if either <code>name</code> is <code>null</code> or empty string
     * @throws IllegalArgumentException if length of <code>name</code> or <code>value</code> greater than allowed maximum
     */
    public void addAttribute(String name, String value) {
        if (StringHelper.isEmpty(name)) {
            throw new NullPointerException("EventEntity: addAttribute: invalid name=" + name + " in persistence object " + this);
        } else if (MAX_ATTRIBUTE_NAME_LENGTH < name.length()) {
            throw new IllegalArgumentException("EventEntity: addAttribute: exceed maximum " + MAX_ATTRIBUTE_NAME_LENGTH
                    + " of name length=" + name.length() + " for name=" + name + " in in persistence object " + this);
        }

        if (StringHelper.isEmptyTrimmed(value)) {
            deleteAttribute(name);
            return;
        }

        if (MAX_ATTRIBUTE_VALUE_LENGTH < value.length()) {
            throw new IllegalArgumentException("EventEntity: addAttribute: exceed maximum " + MAX_ATTRIBUTE_VALUE_LENGTH
                    + " of value length=" + value.length() + " for name=" + name + " in in persistence object " + this);
        }

        attributes.put(name, value);
    }

    /**
     * Delete attribute.
     *
     * @param name attribute name
     */
    public void deleteAttribute(String name) {
        if (!attributes.containsKey(name)) {
            return;
        }
        attributes.remove(name);
    }

    @Override
    public String toString() {
        return "CustomAttributesEntity{" +
                "attributes=" + attributes +
                "} > " + super.toString();
    }

}