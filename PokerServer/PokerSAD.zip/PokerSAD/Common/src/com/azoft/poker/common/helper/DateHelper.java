package com.azoft.poker.common.helper;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateHelper implements DateHelperConstants {

    private static final String DATE_TIME_DELIMITER = " ";
    private static final String START_TIME = "00:00:00";
    private static final String END_TIME = "23:59:59";

    /**
     * Prepare fromStringDateTime
     *
     * @param fromStringDate fromStringDate
     * @return fromStringDateTime
     */
    public static String prepareFromStringDateTime(String fromStringDate) {
        if (fromStringDate.length() < DATE_TIME_FORMAT.length()) {
            fromStringDate += DATE_TIME_DELIMITER + START_TIME;
        }
        return fromStringDate;
    }

    /**
     * Prepare toStringDateTime
     *
     * @param toStringDate toStringDate
     * @return toStringDateTime
     */
    public static String prepareToStringDateTime(String toStringDate) {
        if (toStringDate.length() < DATE_TIME_FORMAT.length()) {
            toStringDate += DATE_TIME_DELIMITER + END_TIME;
        }
        return toStringDate;
    }

    /**
     * Prepare from date time for day
     *
     * @param date date
     * @return fromDateTime
     */
    public static Date prepareFromDateTimeForDay(Date date) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     * Prepare to date time for day
     *
     * @param date date
     * @return toDateTime
     */
    public static Date prepareToDateTimeForDay(Date date) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime();
    }

    /**
     * Prepare from date time for hour
     *
     * @param date date
     * @return fromDateTime
     */
    public static Date prepareFromDateTimeForHour(Date date) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     * Prepare to date time for hour
     *
     * @param date date
     * @return toDateTime
     */
    public static Date prepareToDateTimeForHour(Date date) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime();
    }

}
