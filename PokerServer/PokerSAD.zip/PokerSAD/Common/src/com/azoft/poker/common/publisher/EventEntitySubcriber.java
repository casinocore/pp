package com.azoft.poker.common.publisher;

import java.util.EventListener;

/**
 * Application events subcriber interface
 *
 * @param <EventType> event type
 */
public interface EventEntitySubcriber<EventType> extends EventListener {

    /**
     * Do event
     *
     * @param event event
     */
    void doEvent(EventType event);

}
