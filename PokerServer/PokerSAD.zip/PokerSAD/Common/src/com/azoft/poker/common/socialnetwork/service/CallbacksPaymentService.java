package com.azoft.poker.common.socialnetwork.service;

import com.azoft.poker.common.service.ServletService;

import java.util.Map;

/**
 * Callbacks payment service interface
 */
public interface CallbacksPaymentService extends ServletService {

    /**
     * Get content type
     *
     * @return content type
     */
    String getContentType();

    /**
     * Callbacks payment
     *
     * @param parameters parameters
     * @return response
     */
    String methodCallbacksPayment(Map parameters);

}
