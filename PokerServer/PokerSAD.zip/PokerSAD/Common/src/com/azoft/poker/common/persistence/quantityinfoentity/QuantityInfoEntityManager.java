package com.azoft.poker.common.persistence.quantityinfoentity;

/**
 * Quantity info entity manager interface
 */
public interface QuantityInfoEntityManager<PersistenceType> {

    /**
     * QuantityInfoEntity id for record
     */
    long QUANTITY_INFO_ENTITY_ID_RECORD = 1;

    /**
     * QuantityInfoEntity id for prior record
     */
    long QUANTITY_INFO_ENTITY_ID_PRIOR_RECORD = 2;

    void update(PersistenceType persistenceObject);

    /**
     * Get an <code>QuantityInfoEntity</code> from the data store by id.
     *
     * @param quantityInfoEntityId the id to search for QuantityInfoEntity
     * @return the <code>QuantityInfoEntity</code> if found
     *         if not found
     */
    QuantityInfoEntity getQuantityInfoEntity(long quantityInfoEntityId);

}