package com.azoft.poker.common.persistence.configurationattribute;

import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

/**
 * Configuration attribute manager
 */
public class ConfigurationAttributeManagerImpl extends PersistenceManagerImpl implements ConfigurationAttributeManager {

    private static final String TYPE_PARAMETER = "type";
    private static final String NAME_PARAMETER = "name";
    private static final String QUERY_GET_CONFIGURATION_PARAMETERS =
            "from ConfigurationAttribute cp order by cp.type, cp.name";
    private static final String QUERY_GET_CONFIGURATION_PARAMETERS_BY_TYPE =
            "from ConfigurationAttribute cp where cp.type = :" + TYPE_PARAMETER;
    private static final String QUERY_GET_CONFIGURATION_PARAMETER_BY_TYPE_AND_NAME =
            "from ConfigurationAttribute cp" +
                    " where cp.type = :" + TYPE_PARAMETER + " and cp.name = :" + NAME_PARAMETER;

    private static ConfigurationAttributeManager instance = null;

    public static synchronized ConfigurationAttributeManager getInstance() {
        if (instance == null) {
            instance = new ConfigurationAttributeManagerImpl();
        }
        return instance;
    }

    private ConfigurationAttributeManagerImpl() {
        super();
    }

    @SuppressWarnings("unchecked")
    public List<ConfigurationAttribute> getConfigurationAttributes() {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<ConfigurationAttribute> list = (List<ConfigurationAttribute>) session.createQuery(QUERY_GET_CONFIGURATION_PARAMETERS).list();
        transaction.commit();
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<ConfigurationAttribute> getConfigurationAttributes(ConfigurationAttributeTypeID configurationAttributeTypeID) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<ConfigurationAttribute> list = (List<ConfigurationAttribute>) session.createQuery(QUERY_GET_CONFIGURATION_PARAMETERS_BY_TYPE)
                .setShort(TYPE_PARAMETER, configurationAttributeTypeID.getTypeId()).list();
        transaction.commit();
        return list;
    }

    public ConfigurationAttribute getConfigurationAttribute(ConfigurationAttributeTypeID configurationAttributeTypeID, String name) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        ConfigurationAttribute attribute = (ConfigurationAttribute) session.createQuery(QUERY_GET_CONFIGURATION_PARAMETER_BY_TYPE_AND_NAME)
                .setShort(TYPE_PARAMETER, configurationAttributeTypeID.getTypeId())
                .setString(NAME_PARAMETER, name)
                .uniqueResult();
        transaction.commit();
        return attribute;
    }

}