package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.socialnetwork.bean.SocialNetworkMoneyBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Social network money handler
 */
public class SocialNetworkMoneyHandler extends BaseSocialNetworkHandler<SocialNetworkMoneyBean> {

    private final static Logger LOGGER = LoggerFactory.getLogger(SocialNetworkMoneyHandler.class);

    static final String ELEMENT_NAME_TRANSFERRED = "transferred";

    static final String ELEMENT_NAME_BALANCE = "balance";

    private String socialNetworkMoneyElementName;

    private SocialNetworkMoneyBean socialNetworkMoneyBean;

    public SocialNetworkMoneyHandler(String socialNetworkMoneyElementName) {
        super();
        this.socialNetworkMoneyElementName = socialNetworkMoneyElementName;
        socialNetworkMoneyBean = new SocialNetworkMoneyBean();
        setBean(socialNetworkMoneyBean);
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        super.startElement(uri, lName, qName, attr);
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        super.endElement(uri, lName, qName);

        String tag = getTag(lName, qName);
        if (tag.equals("response")) {
            socialNetworkMoneyBean.setIfNullProcessingResult(RESULT_SUCCESS);
        } else if (tag.equals(socialNetworkMoneyElementName)) {
            try {
                Long code = Long.parseLong(text);
                socialNetworkMoneyBean.setSocialNetworkMoney(code);
            } catch (NumberFormatException e) {
                bean.setProcessingResult(RESULT_FAILURE);
                LOGGER.error("Invalid format '" + socialNetworkMoneyElementName + "': " + text + "'");
            }
        }
    }

}
