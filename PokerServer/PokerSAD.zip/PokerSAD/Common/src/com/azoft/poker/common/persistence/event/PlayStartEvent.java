package com.azoft.poker.common.persistence.event;

/**
 * Play start event
 */
public class PlayStartEvent extends EventEntityWrapper {

    public PlayStartEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    public PlayStartEvent(Short eventType, Long referenceId) {
        super(eventType, referenceId);
    }

    public Long getBalance() {
        return getLongAttribute(BALANCE);
    }

    public void setBalance(Long balance) {
        setLongAttribute(BALANCE, balance);
    }

}