package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.jaxp.AbstractBean;
import com.azoft.poker.common.jaxp.AbstractHandler;
import com.azoft.poker.common.socialnetwork.Constants;
import org.apache.commons.httpclient.HttpMethod;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/**
 * Abstract XML http client
 */
public abstract class AbstractXMLHttpClient extends AbstractHttpClient {

    private SocialNetworkHandlerFactory handlerFactory;

    public AbstractXMLHttpClient(SocialNetworkHandlerFactory handlerFactory) {
        super();
        this.handlerFactory = handlerFactory;
    }

    /**
     * Handle XML document.
     *
     * @param handler handler
     * @param from    input stream
     * @throws CommonException on error
     */
    private void handle(AbstractHandler handler, InputStream from)
            throws CommonException {
        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse(new InputSource(from));
        } catch (IOException ex) {
            throw new CommonException("Unable to read the response stream: " + ex.getMessage(), ex);
        } catch (SAXException ex) {
            throw new CommonException("Unable to parse the response stream: " + ex.getMessage(), ex);
        } finally {
            if (from != null) {
                try {
                    from.close();
                } catch (IOException ex) {
                    // null
                }
            }
        }
    }

    /**
     * Call method
     *
     * @param parameters parameters method
     * @return response bean
     * @throws CommonException call exception
     */
    protected AbstractBean call(Map<String, String> parameters) throws CommonException {
        String methodName = parameters.get(Constants.QUERY_METHOD);
        AbstractHandler handler = handlerFactory.createHandler(methodName);
        if (handler == null) {
            throw new CommonException("Not exists handler for method: '" + methodName + "'");
        }
        HttpMethod method = formPostMethod(parameters);
        try {
            InputStream is = executeMethod(method);
            if (is == null) {
                throw new CommonException("Not exists the response stream for method: '" + methodName + "'");
            }
            handle(handler, is);
        } finally {
            method.releaseConnection();
        }
        return (AbstractBean) handler.getBean();
    }

}
