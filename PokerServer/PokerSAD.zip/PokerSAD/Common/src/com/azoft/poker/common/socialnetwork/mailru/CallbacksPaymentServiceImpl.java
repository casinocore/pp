package com.azoft.poker.common.socialnetwork.mailru;

import com.azoft.poker.common.persistence.event.EventEntityManagerImpl;
import com.azoft.poker.common.persistence.event.EventTypeID;
import com.azoft.poker.common.persistence.event.PaymentOfChipsEvent;
import com.azoft.poker.common.persistence.payment.Payment;
import com.azoft.poker.common.persistence.payment.PaymentManager;
import com.azoft.poker.common.persistence.payment.PaymentManagerImpl;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.product.Product;
import com.azoft.poker.common.persistence.product.ProductManagerImpl;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentService;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentServiceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.Map;

/**
 * Callbacks payment service for schoolmate
 */
public class CallbacksPaymentServiceImpl implements CallbacksPaymentService {

    private final static Logger LOGGER = LoggerFactory.getLogger(CallbacksPaymentServiceImpl.class);

    private static final String CONTENT_TYPE = "application/json; charset=utf-8";

    private static final int SUCCESSFUL_STATUS = 1;

    private static final int ERROR_STATUS = 2;

    private String getSuccessfulResult() {
        return getResult(SUCCESSFUL_STATUS, null);
    }

    private String getErrorResult(Integer errorCode) {
        return getResult(ERROR_STATUS, errorCode);
    }

    private String getResult(int status, Integer errorCode) {
        StringBuffer result = new StringBuffer("");
        result.append("{");
        result.append("\"status\" : \"").append(String.valueOf(status)).append("\"");
        if (errorCode != null) {
            result.append(",");
            result.append("\"error_code\" : \"").append(String.valueOf(errorCode)).append("\"");
        }
        result.append("}");
        return result.toString();
    }

    public boolean isExistsError() {
        return false;
    }

    public String getContentType() {
        return CONTENT_TYPE;
    }

    public String methodCallbacksPayment(Map parameters) {
        String result = null;
        boolean check = true;

        String[] debug = (String[]) parameters.get(Constants.PARAMETER_DEBUG);
        boolean debugMode = CallbacksPaymentServiceFactory.checkParameter(debug) && Constants.DEBUG_MODE.equals(debug[0]);
        if (!debugMode) {
            //read payment
            Person person = null;
            String[] socialNetworkID = (String[]) parameters.get(Constants.PARAMETER_NAME_UID);
            check = check && CallbacksPaymentServiceFactory.checkParameter(socialNetworkID);
            if (check) {
                PersonManager personManager = PersonManagerImpl.getInstance();
                person = personManager.getPersonBySNID(socialNetworkID[0]);
                if (person != null) {
                    String[] strTransactionId = (String[]) parameters.get(Constants.PARAMETER_TRANSACTION_ID);
                    check = check && CallbacksPaymentServiceFactory.checkParameter(strTransactionId);
                    //serviceId equals productCode
                    String[] serviceId = (String[]) parameters.get(Constants.PARAMETER_SERVICE_ID);
                    check = check && CallbacksPaymentServiceFactory.checkParameter(serviceId);
                    //profit equals amount
                    String[] strProfit = (String[]) parameters.get(Constants.PARAMETER_PROFIT);
                    Long profit = null;
                    String errorMsg = "Not valid 'profit' parameter";
                    if (check) {
                        check = check && CallbacksPaymentServiceFactory.checkParameter(strProfit);
                        if (check) {
                            try {
                                profit = Long.valueOf(strProfit[0]);
                            } catch (NumberFormatException e) {
                                check = false;
                                result = getErrorResult(ErrorCodes.OTHER_ERROR.getErrorCode());
                                LOGGER.error(errorMsg, e);
                            }
                        } else {
                            result = getErrorResult(ErrorCodes.OTHER_ERROR.getErrorCode());
                            LOGGER.warn(errorMsg);
                        }
                    }
                    //price equals productOption
                    String[] price = (String[]) parameters.get(Constants.PARAMETER_OTHER_PRICE);
                    if (!CallbacksPaymentServiceFactory.checkParameter(price)) {
                        price = (String[]) parameters.get(Constants.PARAMETER_SMS_PRICE);
                    }
                    if (check) {
                        String transactionId = strTransactionId[0];
                        PaymentManager<Payment> paymentManager = PaymentManagerImpl.getInstance();
                        Payment existsPayment = paymentManager.getPayment(transactionId);
                        if (existsPayment == null) { //is not exists payment - store payment
                            try {
                                Product product = ProductManagerImpl.getInstance().getProduct(serviceId[0]);
                                if (product != null) {
                                    Payment payment = new Payment();
                                    payment.setSocialNetworkID(socialNetworkID[0]);
                                    payment.setTransactionTime(new Date());
                                    payment.setTransactionId(transactionId);
                                    payment.setProductCode(serviceId[0]);
                                    if (CallbacksPaymentServiceFactory.checkParameter(price)) {
                                        payment.setProductOption(price[0]);
                                    }
                                    payment.setAmount(profit);

                                    person.setBalance(person.getBalance() + product.getBalance());
                                    personManager.storePerson(person);
                                    paymentManager.save(payment);
                                    PaymentOfChipsEvent event = new PaymentOfChipsEvent(EventTypeID.PAYMENT_OF_CHIPS.getTypeId(), person.getId());
                                    event.setAccountRevenue(product.getAmount());
                                    event.setAccountChips(product.getBalance());
                                    EventEntityManagerImpl.getInstance().save(event.getEntity());
                                } else {
                                    check = false;
                                    errorMsg = "Not exists product for service id: " + serviceId[0];
                                    result = getErrorResult(ErrorCodes.SERVICE_NOT_FOUND.getErrorCode());
                                    LOGGER.warn(errorMsg);
                                }
                            } catch (Exception e) {
                                check = false;
                                result = getErrorResult(ErrorCodes.OTHER_ERROR.getErrorCode());
                                LOGGER.error("methodCallbacksPayment", e);
                            }
                        } else { //is exists payment
                            check = false;
                            errorMsg = "Exists payment with transaction id: " + transactionId;
                            result = getErrorResult(ErrorCodes.OTHER_ERROR.getErrorCode());
                            LOGGER.warn(errorMsg);
                        }
                    }
                } else {
                    check = false;
                    String errorMsg = "Not exists user: " + socialNetworkID[0];
                    result = getErrorResult(ErrorCodes.USER_NOT_FOUND.getErrorCode());
                    LOGGER.warn(errorMsg);
                }
            }
        } else {
            check = false;
            result = getErrorResult(ErrorCodes.OTHER_ERROR.getErrorCode());
            LOGGER.debug("Debug mode request with parameters: " + parameters);
        }
        if (check) {
            result = getSuccessfulResult();
        } else if (result == null) {
            String errorMsg = "Not valid parameter(s): " + parameters;
            result = getErrorResult(ErrorCodes.OTHER_ERROR.getErrorCode());
            LOGGER.warn(errorMsg);
        }
        return result;
    }

}