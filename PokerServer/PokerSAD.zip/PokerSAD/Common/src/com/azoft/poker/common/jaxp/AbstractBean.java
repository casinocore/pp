package com.azoft.poker.common.jaxp;

import java.util.HashMap;
import java.util.Map;

/**
 * Abstract bean for XML data
 */
public abstract class AbstractBean {

    private String processingResult;
    private Map<Long, String> errorMessages = new HashMap<Long, String>();

    public AbstractBean() {
    }

    public String getProcessingResult() {
        return processingResult;
    }

    public void setProcessingResult(String processingResult) {
        this.processingResult = processingResult;
    }

    public boolean isSuccessResult() {
        return AbstractHandler.RESULT_SUCCESS.equals(processingResult);
    }

    public void setIfNullProcessingResult(String processingResult) {
        if (this.processingResult == null) {
            this.processingResult = processingResult;
        }
    }

    public Map<Long, String> getErrorMessages() {
        return errorMessages;
    }

    public void addErrorMessage(Long errorCode, String errorMessage) {
        this.errorMessages.put(errorCode, errorMessage);
    }

    public String toString() {
        StringBuffer result = new StringBuffer();
        result.append("processingResult: ").append(processingResult);
        if (!errorMessages.isEmpty()) {
            result.append("; number of errors: ").append(errorMessages.size());
        }
        return result.toString();
    }

    public String getErrorMessage() {
        StringBuffer errorMessage = new StringBuffer("");
        errorMessage.append("Error(s) for ").append(getClass().getSimpleName());
        for (Map.Entry<Long, String> entry : errorMessages.entrySet()) {
            errorMessage.append("; ");
            errorMessage.append(entry.getKey()).append(": ").append(entry.getValue());
        }
        return errorMessage.toString();
    }

}
