package com.azoft.poker.common.jaxp;

import org.xml.sax.helpers.DefaultHandler;

/**
 * Abstract XML document handler
 */
public abstract class AbstractHandler<BeanType> extends DefaultHandler {

    /**
     * Success response
     */
    public static final String RESULT_SUCCESS = "Success";

    /**
     * Error response
     */
    public static final String RESULT_ERROR = "Error";

    /**
     * Failure processing
     */
    public static final String RESULT_FAILURE = "Failure";

    protected BeanType bean;

    protected String text;

    public AbstractHandler() {
    }

    public BeanType getBean() {
        return bean;
    }

    public void setBean(BeanType bean) {
        this.bean = bean;
    }

    public void characters(char[] buf, int from, int qnt) {
        text += new String(buf, from, qnt);
    }

    protected String getTag(String lName, String qName) {
        return qName != null ? qName : lName;
    }

}
