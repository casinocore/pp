package com.azoft.poker.common.codec;

import com.azoft.poker.common.commandprocessing.CommandFactory;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.common.exception.CommonException;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.apache.mina.filter.codec.demux.MessageDecoder;
import org.apache.mina.filter.codec.demux.MessageDecoderResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.DataInputStream;
import java.io.InputStream;

/**
 * A {@link AbstractCommandDecoder} that decodes message header and forwards
 * the decoding of body to a command.
 */
public abstract class AbstractCommandDecoder implements MessageDecoder {

    private final static Logger LOGGER = LoggerFactory.getLogger(AbstractCommandDecoder.class);

    private CommandFactory commandFactory;
    private boolean readHeader = false;
    private short commandTypeID;
    private int bodySize = Integer.MAX_VALUE;
    private Command command = null;

    protected AbstractCommandDecoder() {
    }

    protected void setCommandFactory(CommandFactory commandFactory) {
        this.commandFactory = commandFactory;
    }

    public MessageDecoderResult decodable(IoSession session, IoBuffer in) {
        // Return NEED_DATA if the whole header is not read yet.
        int inDataSize = in.remaining();
        if (!readHeader) {
            if (inDataSize < Command.HEADER_SIZE) {
                return MessageDecoderResult.NEED_DATA;
            }
        } else {
            if (inDataSize < bodySize) {
                return MessageDecoderResult.NEED_DATA;
            }
        }

        return MessageDecoderResult.OK;
    }

    public MessageDecoderResult decode(IoSession session, IoBuffer in,
                                       ProtocolDecoderOutput out) throws Exception {
        // Try to skip header if not read.
        if (!readHeader) {
            DataInputStream dis = getDataInputStream(in);
            commandTypeID = dis.readShort();
            byte protocolVersion = dis.readByte();
            bodySize = dis.readInt();
            readHeader = true;

            try {
                if (bodySize > Command.BODY_SIZE_MAX) {
                    throw new CommonException("Body size is exceeded: " + bodySize);
                }
                command = commandFactory.createCommand(session, commandTypeID);
                int inDataSize = in.remaining();
                if (inDataSize < bodySize) {
                    return MessageDecoderResult.NEED_DATA;
                }
            } catch (Exception e) {
                LOGGER.error("Closed session for command: '" + commandTypeID + "' by exception: " + e.getMessage());
                session.close(true);
            }
        }
        if (command != null) {
            int inDataSize = in.remaining();
            if (inDataSize < bodySize) {
                return MessageDecoderResult.NEED_DATA;
            }
            try {
                DataInputStream dis = getDataInputStream(in);
                command.decodeBody(dis);
            } catch (Exception e) {
                LOGGER.error("in data size: " + inDataSize);
                LOGGER.error("body size: " + bodySize);
                LOGGER.error("Command decode class: " + command.getClass().toString(), e);
                LOGGER.error("Command decode: " + command.toString(), e);
                return MessageDecoderResult.NEED_DATA;
            }

            reset();

            out.write(command);
        } else {
            LOGGER.debug("The command isn't created: " + commandTypeID);
//            throw new CommonException("The command isn't created: " + commandTypeID);
        }
        return MessageDecoderResult.OK;
    }

    /**
     * Reset for the next decode
     */
    private void reset() {
        bodySize = Integer.MAX_VALUE;
        readHeader = false;
    }

    public void finishDecode(IoSession session, ProtocolDecoderOutput out)
            throws Exception {
    }

    private DataInputStream getDataInputStream(IoBuffer buf) {
        InputStream is = buf.asInputStream();
        return new DataInputStream(is);
    }

}