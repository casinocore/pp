package com.azoft.poker.common.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Date helper constants
 */
public interface DateHelperConstants {

    String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    String DATE_FORMAT = "yyyy-MM-dd";

    String TIME_FORMAT = "HH:mm:ss";
    /**
     * Date time format
     */
    DateFormat attributeDateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT);

    /**
     * Date format
     */
    DateFormat attributeDateFormat = new SimpleDateFormat(DATE_FORMAT);

    /**
     * Time format
     */
    DateFormat attributeTimeFormat = new SimpleDateFormat(TIME_FORMAT);

    long SEC_MSEC = 1000;
    long MIN_MSEC = 60 * SEC_MSEC;
    long HOUR_MSEC = 60 * MIN_MSEC;
    long DAY_MSEC = 24 * HOUR_MSEC;
    long YEAR_MSEC = 365 * DAY_MSEC;

}
