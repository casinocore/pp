package com.azoft.poker.common.publisher;

import com.azoft.poker.common.persistence.event.EventEntity;

/**
 * Application event
 */
public interface Event {

    /**
     * Get persistence application event
     *
     * @return persistence application event
     */
    EventEntity getEntity();

}
