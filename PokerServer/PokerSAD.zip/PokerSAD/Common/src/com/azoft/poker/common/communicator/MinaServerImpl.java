package com.azoft.poker.common.communicator;

import com.azoft.poker.common.codec.CommandProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.SocketAcceptor;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Map;

/**
 * Mina server communicator
 */
public class MinaServerImpl extends AbstractCommunicator {

    private final static Logger LOGGER = LoggerFactory.getLogger(MinaServerImpl.class);

    private SocketAcceptor acceptor;

    public MinaServerImpl() {
        super();
    }

    @Override
    public void initialization(Map<String, Object> parameters) {
        super.initialization(parameters);

        acceptor = new NioSocketAcceptor();

        // Prepare the service configuration.
        acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new CommandProtocolCodecFactory(getCommandDecoder())));
        acceptor.getFilterChain().addLast("logger", new LoggingFilter());

        // Disable the disconnection of the clients on unbind
        acceptor.setCloseOnDeactivation(false);
        // Allow the port to be reused even if the socket is in TIME_WAIT state
        acceptor.setReuseAddress(true);
        // No Nagle's algorithm
        acceptor.getSessionConfig().setTcpNoDelay(true);
        acceptor.setHandler(getHandlerAdapter());
    }

    @Override
    protected void initParameters(Map<String, Object> parameters) {
        super.initParameters(parameters);
    }

    @Override
    public void open(Map<String, Object> parameters) throws IOException {
        acceptor.bind(new InetSocketAddress(getServerPort()));
        LOGGER.info("Listening on port " + getServerPort());
    }

    @Override
    public void shutdown() {
        acceptor.unbind();
        acceptor.dispose();
        LOGGER.info("Shutdown port: " + getServerPort());
    }

}
