package com.azoft.poker.common.socialnetwork.facebook;

import com.google.gson.Gson;

public class FBRequest {

    private String algorithm;

    private String user_id;

    private FBRequestBean credits;

    public FBRequest() {
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public FBRequestBean getCredits() {
        return credits;
    }

    public void setCredits(FBRequestBean credits) {
        this.credits = credits;
    }

    @Override
    public String toString() {
        return "FBRequest{" +
                "algorithm='" + algorithm + '\'' +
                ", user_id='" + user_id + '\'' +
                ", credits=" + credits +
                '}';
    }

    public static FBRequest createFBRequest(String json) {
        Gson gson = new Gson();
        //convert JSON into java object
        return gson.fromJson(json, FBRequest.class);
    }

}
