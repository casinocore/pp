package com.azoft.poker.common.communicator;

import com.azoft.poker.common.codec.CommandProtocolCodecFactory;
import org.apache.mina.core.RuntimeIoException;
import org.apache.mina.core.future.CloseFuture;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.util.Map;

/**
 * Mina client communicator
 */
public class MinaClientImpl extends AbstractCommunicator {

    private final static Logger LOGGER = LoggerFactory.getLogger(MinaClientImpl.class);

    /**
     * Connect timeout
     */
    private static final long CONNECT_TIMEOUT = 1000;

    /**
     * Sleep millis on open exception
     */
    private static final long SLEEP_MILLIS = 5000;

    /**
     * Mina client termination timeout
     */
    private final static long MINA_CLIENT_TERMINATION_TIMEOUT = 1000;

    public final static String SERVER_ADDRESS_PARAMETER = "SERVER_ADDRESS";

    private String serverAddress;
    private NioSocketConnector connector;
    private IoSession session;
    private long errorCount;

    public MinaClientImpl() {
        super();
    }

    public String getServerAddress() {
        return serverAddress;
    }

    public IoSession getSession() {
        return session;
    }

    @Override
    public void initialization(Map<String, Object> parameters) {
        super.initialization(parameters);

        connector = new NioSocketConnector();

        // Configure the service.
        connector.setConnectTimeoutMillis(CONNECT_TIMEOUT);
        connector.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(new CommandProtocolCodecFactory(getCommandDecoder())));
        connector.getFilterChain().addLast("logger", new LoggingFilter());
        connector.setHandler(getHandlerAdapter());
        InetSocketAddress address = new InetSocketAddress(getServerAddress(), getServerPort());
        connector.setDefaultRemoteAddress(address);
    }

    @Override
    protected void initParameters(Map<String, Object> parameters) {
        super.initParameters(parameters);
        serverAddress = (String) parameters.get(SERVER_ADDRESS_PARAMETER);
    }

    @Override
    public void open(Map<String, Object> parameters) {
        try {
            ConnectFuture future = connector.connect();
            future.awaitUninterruptibly();
            session = future.getSession();
            for (Map.Entry<String, Object> entry : parameters.entrySet()) {
                session.setAttribute(entry.getKey(), entry.getValue());
            }
        } catch (RuntimeIoException e) {
            errorCount++;
            LOGGER.error("Failed to connect", e);
            try {
                Thread.sleep(SLEEP_MILLIS);
            } catch (InterruptedException e1) {
                LOGGER.error("body_sleep", e.getMessage());
            }
        }
    }

    @Override
    public void shutdown() {
        // wait until the summation is done
        boolean isClosed = true;
        if (session != null) {
            CloseFuture closeFuture = session.close(true);
            closeFuture.awaitUninterruptibly(MINA_CLIENT_TERMINATION_TIMEOUT);
            isClosed = closeFuture.isClosed();
            session = null;
        }
        connector.dispose();
        LOGGER.info("Shutdown port: " + getServerPort() + ". Session is closed: " + isClosed);
    }

}
