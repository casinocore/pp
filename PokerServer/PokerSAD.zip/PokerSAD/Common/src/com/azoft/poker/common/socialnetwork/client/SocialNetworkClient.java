package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.socialnetwork.bean.*;

import java.util.List;
import java.util.Map;

/**
 * Social network client interface
 */
public interface SocialNetworkClient {

    /**
     * SocialNetworkTypeID parameter
     */
    String PARAM_TYPE_ID = "TYPE_ID";

    /**
     * Social network API URI
     */
    String PARAM_API_URI = "API_URI";

    /**
     * Application key parameter
     */
    String PARAM_APPLICATION_KEY = "APPLICATION_KEY";

    /**
     * Secret key parameter
     */
    String PARAM_SECRET_KEY = "SECRET_KEY";

    /**
     * Test mode parameter
     */
    String PARAM_TEST_MODE = "TEST_MODE";

    /**
     * Max connector parameter
     */
    String PARAM_MAX_CONNECTION = "MAX_CONNECTION";

    /**
     * Initialization client
     *
     * @param parameters initialization parameters
     * @throws CommonException initialization exception
     */
    void initialization(Map<String, Object> parameters) throws CommonException;

    /**
     * Get test mode
     *
     * @return test mode (true if test mode)
     */
    public boolean isTestMode();

    /**
     * Set test mode
     *
     * @param testMode true if test mode
     */
    public void setTestMode(boolean testMode);

    /**
     * Get max number for method methodGetUsersInfo (if not limit - return 0)
     *
     * @return get max number for method methodGetUsersInfo (if not limit - return 0)
     */
    int getMaxNumberForMethodGetUsersInfo();

    /**
     * Call get users info method
     *
     * @param socialNetworkIDList social network ID list (max number IDs - int getMaxNumberForMethodGetUsersInfo())
     * @return users info bean
     * @throws CommonException method exception
     */
    UsersInfoBean methodGetUsersInfo(List<String> socialNetworkIDList) throws CommonException;

    /**
     * Call get friends method
     *
     * @param socialNetworkID current social network ID
     * @return friends bean
     * @throws CommonException method exception
     */
    FriendsBean methodGetFriends(String socialNetworkID) throws CommonException;

    /**
     * Call login method
     *
     * @param login    login
     * @param password password
     * @param genToken gen token
     * @return login bean
     * @throws CommonException method exception
     */
    LoginBean methodLogin(String login, String password, boolean genToken) throws CommonException;

    /**
     * Call payment method
     *
     * @param socialNetworkID current social network ID
     * @param amount          social network amount
     * @param testMode        test mode (true if test mode)
     * @return social network money bean
     * @throws CommonException method exception
     */
    SocialNetworkMoneyBean methodPayment(String socialNetworkID, long amount, boolean testMode) throws CommonException;

    /**
     * Call get balance
     *
     * @param socialNetworkID current social network ID
     * @return social network money bean
     * @throws CommonException method exception
     */
    SocialNetworkMoneyBean methodGetBalance(String socialNetworkID) throws CommonException;

    /**
     * Call send notification method
     *
     * @param socialNetworkIDString social network ID string
     * @param message               message
     * @return send notification bean
     * @throws CommonException method exception
     */
    SendNotificationBean methodSendNotification(String socialNetworkIDString, String message)
            throws CommonException;

    /**
     * Call send notifications method
     *
     * @param socialNetworkIDList social network ID list
     * @param message             message
     * @return send notification bean list
     * @throws CommonException method exception
     */
    List<SendNotificationBean> methodSendNotifications(List<String> socialNetworkIDList, String message)
            throws CommonException;

}
