package com.azoft.poker.common.jaxp;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;

/**
 * Abstract XML loader
 */
public abstract class AbstractXMLLoader {

    public AbstractXMLLoader() {
    }

    /**
     * Load
     *
     * @param xmlDocument xml document
     * @param handler     xml handler
     * @throws SAXException                 SAX exception
     * @throws ParserConfigurationException parser configuration exception
     * @throws IOException                  io exception
     */
    protected void load(String xmlDocument, DefaultHandler handler)
            throws SAXException, ParserConfigurationException, IOException {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser saxParser = factory.newSAXParser();
        saxParser.parse(xmlDocument, handler);
    }

    /**
     * Load
     */
    public abstract void load();

}
