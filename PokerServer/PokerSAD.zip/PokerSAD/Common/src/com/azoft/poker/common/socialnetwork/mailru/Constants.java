package com.azoft.poker.common.socialnetwork.mailru;

/**
 * Constants for mailru
 */
public class Constants extends com.azoft.poker.common.socialnetwork.Constants {

    /**
     * The application id associated with the calling application.
     */
    public static final String QUERY_APPLICATION_ID = "app_id";

    /**
     * 'transaction_id' parameter name
     */
    public static final String PARAMETER_TRANSACTION_ID = "transaction_id";

    /**
     * 'service_id' parameter name
     */
    public static final String PARAMETER_SERVICE_ID = "service_id";

    /**
     * 'sms_price' parameter name
     */
    public static final String PARAMETER_SMS_PRICE = "sms_price";

    /**
     * 'other_price' parameter name
     */
    public static final String PARAMETER_OTHER_PRICE = "other_price";

    /**
     * 'profit' parameter name
     */
    public static final String PARAMETER_PROFIT = "profit";

    /**
     * 'debug' parameter name
     */
    public static final String PARAMETER_DEBUG = "debug";

    /**
     * 'debug' parameter value
     */
    public static final String DEBUG_MODE = "1";

}
