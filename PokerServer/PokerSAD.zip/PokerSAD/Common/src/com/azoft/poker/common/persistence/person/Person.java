package com.azoft.poker.common.persistence.person;

import com.azoft.poker.common.persistence.BaseEntity;

import java.util.Date;

public class Person extends BaseEntity {

    /**
     * Not defined sex
     */
    public static final short NOT_DEFINED_SEX = 0;

    /**
     * Male
     */
    public static final short MALE_SEX = 1;

    /**
     * Female
     */
    public static final short FEMALE_SEX = 2;

    /**
     * Логин пользователя
     */
    private String username;

    /**
     * Account type
     * 1 (REAL), 2 (TEST), 3 (BOT)
     */
    private short accountType;

    /**
     * Social network ID
     */
    private String socialNetworkID;

    /**
     * Имя пользователя
     */
    private String firstName;

    /**
     * Фамилия пользователя
     */
    private String lastName;

    /**
     * Текущий баланс Клиента
     */
    private long balance;

    /**
     * Registration date
     */
    private Date registrationDate;

    /**
     * Date of birth
     */
    private Date dateOfBirth;

    /**
     * Sex
     * 1 (MALE), 2 (FEMALE)
     */
    private short sex;

    /**
     * Location
     */
    private String location;

    /**
     * Session start date
     */
    private Date sessionStartDate;

    /**
     * Parent
     */
    private Person parent;

    /**
     * Exists parent bonus
     */
    private boolean existsParentBonus;

    public Person() {
        super();
        this.accountType = AccountTypeID.REAL_ACCOUNT.getTypeId();
        this.sex = NOT_DEFINED_SEX;
        this.existsParentBonus = false;
        if (isNew()) {
            this.registrationDate = new Date();
        }
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public short getAccountType() {
        return accountType;
    }

    public void setAccountType(short accountType) {
        this.accountType = accountType;
    }

    public String getSocialNetworkID() {
        return socialNetworkID;
    }

    public void setSocialNetworkID(String socialNetworkID) {
        this.socialNetworkID = socialNetworkID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public long getBalance() {
        return balance;
    }

    public void setBalance(long balance) {
        this.balance = balance;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public short getSex() {
        return sex;
    }

    public void setSex(short sex) {
        this.sex = sex;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getSessionStartDate() {
        return sessionStartDate;
    }

    public void setSessionStartDate(Date sessionStartDate) {
        this.sessionStartDate = sessionStartDate;
    }

    public Person getParent() {
        return parent;
    }

    public void setParent(Person parent) {
        this.parent = parent;
    }

    public boolean isExistsParentBonus() {
        return existsParentBonus;
    }

    public void setExistsParentBonus(boolean existsParentBonus) {
        this.existsParentBonus = existsParentBonus;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (this.getId() == null) return false;
        if (!(o instanceof Person)) return false;
        return this.getId().equals(((Person) o).getId());
    }

    @Override
    public String toString() {
        return "Person{" +
                "username='" + username + '\'' +
                ", accountType=" + accountType +
                ", socialNetworkID='" + socialNetworkID + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", balance=" + balance +
                ", registrationDate=" + registrationDate +
                ", dateOfBirth=" + dateOfBirth +
                ", sex=" + sex +
                ", location='" + location + '\'' +
                ", sessionStartDate='" + sessionStartDate + '\'' +
                ", parentId='" + (parent != null ? String.valueOf(parent.getId()) : "") + '\'' +
                ", existsParentBonus='" + existsParentBonus + '\'' +
                '}';
    }
}
