package com.azoft.poker.common.service;

import com.azoft.poker.common.persistence.event.EventEntity;
import com.azoft.poker.common.persistence.event.EventEntityManager;
import com.azoft.poker.common.persistence.event.EventEntityManagerImpl;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.server.ServerManagerImpl;
import com.azoft.poker.common.publisher.Event;
import com.azoft.poker.common.publisher.EventEntityPublisher;
import com.azoft.poker.common.publisher.EventEntityPublisherImpl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class LifecycleServiceImpl implements LifecycleService {

    private List<LifecycleService> lifecycleServices = new CopyOnWriteArrayList<LifecycleService>();

    private static LifecycleServiceImpl instance = null;

    public static synchronized LifecycleServiceImpl getInstance() {
        if (instance == null) {
            instance = new LifecycleServiceImpl();
        }
        return instance;
    }

    private LifecycleServiceImpl() {
        super();
    }

    /**
     * Register lifecycle service
     *
     * @param lifecycleService lifecycle service
     */
    public void registerLifecycleService(LifecycleService lifecycleService) {
        if (!lifecycleServices.contains(lifecycleService)) {
            lifecycleServices.add(lifecycleService);
        }
    }

    /**
     * Prepare shutdown hook
     */
/*
    private void prepareShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                for (LifecycleService lifecycleService : lifecycleServices) {
                    lifecycleService.shutdown();
                }
                getInstance().shutdown();
            }
        });
    }
*/
    public void initialization(Map<String, Object> parameters) {
        //TODO Common**ManagerImpl.getInstance();

        //Managers initialization
        EventEntityManager<EventEntity, Event> eventEntityManager = EventEntityManagerImpl.getInstance();
        eventEntityManager.initialization(null);
        ServerManagerImpl.getInstance();
        PersonManager personManager = PersonManagerImpl.getInstance();
        personManager.initialization(null);

        //Services initialization
        ServerServiceImpl.getInstance();
        PersonService personService = PersonServiceImpl.getInstance();
        personService.initialization(null);

        //Listeners initialization
        EventEntityPublisher<Event> eventEntityPublisher = EventEntityPublisherImpl.getInstance();
        eventEntityPublisher.addSubcriber(eventEntityManager);

        //Register lifecycle services
        registerLifecycleService(personManager);
        registerLifecycleService(eventEntityManager);

        //Prepare shutdown hook
        //prepareShutdownHook();
    }

    public void shutdown() {
        for (LifecycleService lifecycleService : lifecycleServices) {
            lifecycleService.shutdown();
        }
    }

}
