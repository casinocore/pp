package com.azoft.poker.common.commandprocessing.handler;

import com.azoft.poker.common.commandprocessing.command.EmptyCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExitHandler extends Handler<EmptyCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ExitHandler.class);

    public ExitHandler() {
        super();
    }

    public void execute(EmptyCommand command) {
        command.getSession().close(true);
        LOGGER.debug("Session for userId: " + command.getUserId() + " closed by command: " + command.toString());
    }

}