package com.azoft.poker.common.exception;

/**
 * Common exception
 */
public class CommonException extends AbstractException {

    public CommonException(String message) {
        super(message);
    }

    public CommonException(String message, Throwable cause) {
        super(message, cause);
    }

    public CommonException(Throwable cause) {
        super(cause);
    }

}