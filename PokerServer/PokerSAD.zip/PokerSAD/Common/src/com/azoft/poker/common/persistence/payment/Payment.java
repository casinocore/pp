package com.azoft.poker.common.persistence.payment;

import com.azoft.poker.common.persistence.BaseEntity;

import java.util.Date;

/**
 * Payment
 */
public class Payment extends BaseEntity {

    /**
     * Social network ID
     */
    private String socialNetworkID;

    /**
     * Transaction time
     */
    private Date transactionTime;

    /**
     * Transaction id
     */
    private String transactionId;

    /**
     * Product code
     */
    private String productCode;

    /**
     * Product option
     */
    private String productOption;

    /**
     * Amount
     */
    private Long amount;

    public Payment() {
        super();
    }

    public String getSocialNetworkID() {
        return socialNetworkID;
    }

    public void setSocialNetworkID(String socialNetworkID) {
        this.socialNetworkID = socialNetworkID;
    }

    public Date getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Date transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductOption() {
        return productOption;
    }

    public void setProductOption(String productOption) {
        this.productOption = productOption;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "socialNetworkID='" + socialNetworkID + '\'' +
                ", transactionTime=" + transactionTime +
                ", transactionId='" + transactionId + '\'' +
                ", productCode='" + productCode + '\'' +
                ", productOption='" + productOption + '\'' +
                ", amount=" + amount +
                "} > " + super.toString();
    }

}
