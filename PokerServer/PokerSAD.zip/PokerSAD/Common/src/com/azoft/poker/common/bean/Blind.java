package com.azoft.poker.common.bean;

public class Blind implements Comparable<Blind> {
    private Integer bigBlind;
    private Integer smallBlind;

    public Blind(Integer smallBlind, Integer bigBlind) {
        this.bigBlind = bigBlind;
        this.smallBlind = smallBlind;
    }

    public Integer getBigBlind() {
        return bigBlind;
    }

    public void setBigBlind(Integer bigBlind) {
        this.bigBlind = bigBlind;
    }

    public Integer getSmallBlind() {
        return smallBlind;
    }

    public void setSmallBlind(Integer smallBlind) {
        this.smallBlind = smallBlind;
    }

    public int compareTo(Blind blind) {
        return (blind.bigBlind).compareTo(bigBlind);
    }

    public String toString() {
        return "Blind[big = " + bigBlind + ", small = " + smallBlind + "]";
    }

}
