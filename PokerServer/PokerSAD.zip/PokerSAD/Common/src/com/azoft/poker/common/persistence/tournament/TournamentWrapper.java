package com.azoft.poker.common.persistence.tournament;

import java.util.Date;
import java.util.Map;

import com.azoft.poker.common.persistence.CustomAttributesWrapper;

/**
 * Abstract wrapper for tournament
 */
public abstract class TournamentWrapper extends
        CustomAttributesWrapper<Tournament> {

    public static final String FEE_PREFIX = "FEE_";

    public TournamentWrapper(Tournament tournament) {
        super(tournament);
    }

    public Long getFee(Short paymentsNumber) {
        Long result = null;
        short i = paymentsNumber;
        while (result == null && i > 0) {
            result = getLongAttribute(FEE_PREFIX + i);
            i--;
        }
        if (result == null) {
            result = getEntity().getFee();
        }
        return result;
    }

    public Long getId() {
        return getEntity().getId();
    }

    /* Tournament fields delegation */

    public String getName() {
        return getEntity().getName();
    }

    public void setName(String name) {
        getEntity().setName(name);
    }

    public Byte getType() {
        return getEntity().getType();
    }

    public void setType(Byte type) {
        getEntity().setType(type);
    }

    public Byte getStatus() {
        return getEntity().getStatus();
    }

    public void setStatus(Byte status) {
        getEntity().setStatus(status);
    }

    public Long getMinPlayersCount() {
        return getEntity().getMinPlayersCount();
    }

    public void setMinPlayersCount(Long minPlayersCount) {
        getEntity().setMinPlayersCount(minPlayersCount);
    }

    public Long getMaxPlayersCount() {
        return getEntity().getMaxPlayersCount();
    }

    public void setMaxPlayersCount(Long maxPlayersCount) {
        getEntity().setMaxPlayersCount(maxPlayersCount);
    }

    public Long getFee() {
        return getEntity().getFee();
    }

    public void setFee(Long fee) {
        getEntity().setFee(fee);
    }

    public Byte getWinnerCount() {
        return getEntity().getWinnerCount();
    }

    public void setWinnerCount(Byte winnerCount) {
        getEntity().setWinnerCount(winnerCount);
    }

    public Long getStartChipsCount() {
        return getEntity().getStartChipsCount();
    }

    public void setStartChipsCount(Long startChipsCount) {
        getEntity().setStartChipsCount(startChipsCount);
    }

    public Date getFromDate() {
        return getEntity().getFromDate();
    }

    public void setFromDate(Date fromDate) {
        getEntity().setFromDate(fromDate);
    }

    public Date getToDate() {
        return getEntity().getToDate();
    }

    public void setToDate(Date toDate) {
        getEntity().setToDate(toDate);
    }

    public String getDescriptor() {
        return getEntity().getDescriptor();
    }

    public void setDescriptor(String descriptor) {
        getEntity().setDescriptor(descriptor);
    }

    public Map<String, String> getAttributes() {
        return getEntity().getAttributes();
    }

    public void addAttribute(String name, String value) {
        getEntity().addAttribute(name, value);
    }

}