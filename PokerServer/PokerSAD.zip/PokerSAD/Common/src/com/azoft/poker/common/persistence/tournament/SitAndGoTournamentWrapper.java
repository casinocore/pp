package com.azoft.poker.common.persistence.tournament;

/**
 * Sit&Go tournament wrapper
 */
public class SitAndGoTournamentWrapper extends TournamentWrapper {

    public SitAndGoTournamentWrapper(Tournament tournament) {
        super(tournament);
    }

}