package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.persistence.BaseEntity;
import com.azoft.poker.common.persistence.person.Person;

import java.util.Date;

public class TournamentPersonStatus extends BaseEntity {

    private Person person;

    private Tournament tournament;

    private Long tournamentBalance;

    /**
     * Number of payments
     */
    private Short paymentsNumber;

    private Date leavingTime;

    public TournamentPersonStatus() {
        super();
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Long getTournamentBalance() {
        return tournamentBalance;
    }

    public void setTournamentBalance(Long tournamentBalance) {
        this.tournamentBalance = tournamentBalance;
    }

    public Short getPaymentsNumber() {
        return paymentsNumber;
    }

    public void setPaymentsNumber(Short paymentsNumber) {
        this.paymentsNumber = paymentsNumber;
    }

    public Date getLeavingTime() {
        return leavingTime;
    }

    public void setLeavingTime(Date leavingTime) {
        this.leavingTime = leavingTime;
    }

    public Short incPaymentsNumber() {
        if (paymentsNumber == null) {
            paymentsNumber = 1;
        } else {
            paymentsNumber++;
        }
        return paymentsNumber;
    }

    public Tournament getTournament() {
        return tournament;
    }

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
    }

    @Override
    public String toString() {
        return "TournamentPersonStatus{" +
                "person=" + person +
                ", tournamentBalance=" + tournamentBalance +
                ", paymentsNumber=" + paymentsNumber +
                ", leavingTime=" + leavingTime +
                ", tournamentId=" + tournament.getId() +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        TournamentPersonStatus status = (TournamentPersonStatus) o;

        if (!person.equals(status.person)) return false;
        if (!tournament.equals(status.tournament)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + person.hashCode();
        result = 31 * result + tournament.hashCode();
        return result;
    }

}
