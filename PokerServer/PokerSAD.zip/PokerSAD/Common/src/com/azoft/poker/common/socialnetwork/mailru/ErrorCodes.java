package com.azoft.poker.common.socialnetwork.mailru;

/**
 * Error codes for mailru
 */
public enum ErrorCodes {

    OTHER_ERROR(700),
    USER_NOT_FOUND(701),
    SERVICE_NOT_FOUND(702),
    INCORRECT_PRICE(703);

    private int errorCode;

    ErrorCodes(int errorCode) {
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

}