package com.azoft.poker.common.commandprocessing;

import com.azoft.poker.common.service.LifecycleService;

/**
 * Lifecycle command processor interface
 */
public interface LifecycleCommandProcessor extends LifecycleService, CommandProcessor {
}
