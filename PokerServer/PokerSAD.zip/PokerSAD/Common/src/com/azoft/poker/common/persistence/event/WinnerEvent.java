package com.azoft.poker.common.persistence.event;

import java.util.List;

/**
 * Deal finished event
 */
public class WinnerEvent extends CounterEvent {

    public WinnerEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    public WinnerEvent(Short eventType, Long referenceId) {
        super(eventType, referenceId);
    }

    public Long getWinPrize() {
        return getLongAttribute(WIN_PRIZE);
    }

    public void setWinPrize(Long winsPrize) {
        setLongAttribute(WIN_PRIZE, winsPrize);
    }

    public Long getBalance() {
        return getLongAttribute(BALANCE);
    }

    public void setBalance(Long balance) {
        setLongAttribute(BALANCE, balance);
    }

    public Short getPokerHandTypeID() {
        return getShortAttribute(POKER_HAND_TYPE_ID);
    }

    public void setPokerHandTypeID(Short pokerHandTypeID) {
        setShortAttribute(POKER_HAND_TYPE_ID, pokerHandTypeID);
    }

    public static void incWinnerEvent(EventEntityManager eventEntityManager, Long personId, Long winPrize, Long balance, Short pokerHandTypeID) {
        List<EventEntity> events = eventEntityManager.getUserEventEntities(personId, EventTypeID.WINNER);
        WinnerEvent event;
        if (events.isEmpty()) {
            event = new WinnerEvent(EventTypeID.WINNER.getTypeId(), personId);
            event.setWinPrize(winPrize);
            event.setBalance(balance);
            event.setPokerHandTypeID(pokerHandTypeID);
        } else {
            event = new WinnerEvent(events.get(events.size() - 1));
            Long storeWinPrize = event.getWinPrize();
            if (winPrize != null && (storeWinPrize == null || winPrize > storeWinPrize)) {
                event.setWinPrize(winPrize);
            }
            Long storeBalance = event.getBalance();
            if (balance != null && (storeBalance == null || balance > storeBalance)) {
                event.setBalance(balance);
            }
            Short storePokerHandTypeID = event.getPokerHandTypeID();
            if (pokerHandTypeID != null && (storePokerHandTypeID == null || pokerHandTypeID > storePokerHandTypeID)) {
                event.setPokerHandTypeID(pokerHandTypeID);
            }
        }
        event.incCounter();
        eventEntityManager.merge(event.getEntity());
    }

}