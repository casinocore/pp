package com.azoft.poker.common.socialnetwork.facebook;

import com.google.gson.Gson;

import java.util.Arrays;

public class FBOrderDetails {

    private FBOrderDetailsBean[] content;

    private String method;

    public FBOrderDetails() {
        FBOrderDetailsBean content = new FBOrderDetailsBean();
        this.content = new FBOrderDetailsBean[1];
        this.content[0] = content;
        this.method = Constants.METHOD_PAYMENTS_GET_ITEMS;
    }

    public FBOrderDetailsBean[] getContent() {
        return content;
    }

    public void setContent(FBOrderDetailsBean[] content) {
        this.content = content;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    @Override
    public String toString() {
        return "FBOrderDetails{" +
                "content=" + (content == null ? null : Arrays.asList(content)) +
                ", method='" + method + '\'' +
                '}';
    }

    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    public static FBOrderDetails createFBOrderDetails(String json) {
        Gson gson = new Gson();
        //convert JSON into java object
        return gson.fromJson(json, FBOrderDetails.class);
    }

}
