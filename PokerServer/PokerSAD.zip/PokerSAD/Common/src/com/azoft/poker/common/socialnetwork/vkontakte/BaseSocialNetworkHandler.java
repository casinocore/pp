package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.jaxp.AbstractBean;
import com.azoft.poker.common.jaxp.AbstractHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Base social network handler for vkontakte
 */
public abstract class BaseSocialNetworkHandler<BeanType extends AbstractBean> extends AbstractHandler<BeanType> {

    private final static Logger LOGGER = LoggerFactory.getLogger(BaseSocialNetworkHandler.class);

    private CodeMessageEntry entry = new CodeMessageEntry();

    protected BaseSocialNetworkHandler() {
        super();
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        text = "";
        String tag = getTag(lName, qName);
        if (tag.equals("error")) {
            bean.getErrorMessages().clear();
            bean.setProcessingResult(RESULT_ERROR);
        }
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        String tag = getTag(lName, qName);
        if (tag.equals("error_code")) {
            try {
                Long code = Long.parseLong(text);
                entry.setCode(code);
            } catch (NumberFormatException e) {
                bean.setProcessingResult(RESULT_FAILURE);
                LOGGER.error("Invalid format 'error_code': " + text + "'");
            }
        } else if (tag.equals("error_msg")) {
            entry.setMessage(text);
        } else if (tag.equals("error")) {
            if (entry.getCode() != null) {
                bean.addErrorMessage(entry.getCode(), entry.getMessage());
            } else {
                bean.addErrorMessage(ErrorCodes.UNKNOWN.getErrorCode(), text);
            }
        }
    }

    class CodeMessageEntry {
        private Long code;
        private String message;

        CodeMessageEntry() {
        }

        public Long getCode() {
            return code;
        }

        public void setCode(Long code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

    }

}