package com.azoft.poker.common.persistence.event;

public interface EventEntityConstants {

    //TODO Sample attribute name
    String SESSION_START = "SESSION_START";

    //BonusEvent
    String BONUS = "BONUS";

    //SessionEndEvent
    String SESSION_TIME = "SESSION_TIME";

    //CounterEvent
    String COUNTER = "COUNTER";

    //WinnerEvent
    String WIN_PRIZE = "WIN_PRIZE";
    String POKER_HAND_TYPE_ID = "POKER_HAND_TYPE_ID";
    //WinnerEvent, PlayStartEvent
    String BALANCE = "BALANCE";

    //PaymentOfChipsEvent
    String ACCOUNT_REVENUE = "ACCOUNT_REVENUE";
    String ACCOUNT_CHIPS = "ACCOUNT_CHIPS";

    //JoinTableEvent
    String BLINDS_NAME = "BLINDS_NAME";

}
