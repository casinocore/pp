package com.azoft.poker.common.persistence.product;

import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

/**
 * Product manager
 */
public class ProductManagerImpl extends PersistenceManagerImpl<Product> implements ProductManager<Product> {

    private static final String QUERY_GET_PRODUCTS = "from Product product order by product.amount";
    private static final String QUERY_GET_PRODUCT_BY_PRODUCT_CODE = "from Product product where product.productCode = :productCode";
    private static final String PRODUCT_CODE_PARAMETER = "productCode";

    private static ProductManager<Product> instance = null;

    public static synchronized ProductManager<Product> getInstance() {
        if (instance == null) {
            instance = new ProductManagerImpl();
        }
        return instance;
    }

    private ProductManagerImpl() {
        super();
    }

    @SuppressWarnings("unchecked")
    public List<Product> getProducts() {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        List<Product> list = (List<Product>) session.createQuery(QUERY_GET_PRODUCTS).list();
        transaction.commit();
        return list;
    }

    public Product getProduct(String productCode) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        Product product = (Product) session.createQuery(QUERY_GET_PRODUCT_BY_PRODUCT_CODE).setString(PRODUCT_CODE_PARAMETER, productCode).uniqueResult();
        transaction.commit();
        return product;
    }

}