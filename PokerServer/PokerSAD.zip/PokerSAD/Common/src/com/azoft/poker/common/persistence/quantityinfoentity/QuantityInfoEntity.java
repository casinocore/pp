package com.azoft.poker.common.persistence.quantityinfoentity;

import com.azoft.poker.common.persistence.BaseEntity;

import java.util.Date;

/**
 * Quantity info entity
 */
public class QuantityInfoEntity extends BaseEntity {

    /**
     * Entity timestamp
     */
    private Date timeStamp;

    private Integer quantityOfNewRegistrations;
    private Integer quantityOfActivePlayers;
    private Integer quantityOfPaymentPlayers;
    private Integer quantityOfOnlinePlayers;
    private Date onlinePeakTime;

    public QuantityInfoEntity() {
        super();
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public Integer getQuantityOfNewRegistrations() {
        return quantityOfNewRegistrations;
    }

    public void setQuantityOfNewRegistrations(Integer quantityOfNewRegistrations) {
        this.quantityOfNewRegistrations = quantityOfNewRegistrations;
    }

    public Integer getQuantityOfActivePlayers() {
        return quantityOfActivePlayers;
    }

    public void setQuantityOfActivePlayers(Integer quantityOfActivePlayers) {
        this.quantityOfActivePlayers = quantityOfActivePlayers;
    }

    public Integer getQuantityOfPaymentPlayers() {
        return quantityOfPaymentPlayers;
    }

    public void setQuantityOfPaymentPlayers(Integer quantityOfPaymentPlayers) {
        this.quantityOfPaymentPlayers = quantityOfPaymentPlayers;
    }

    public Integer getQuantityOfOnlinePlayers() {
        return quantityOfOnlinePlayers;
    }

    public void setQuantityOfOnlinePlayers(Integer quantityOfOnlinePlayers) {
        this.quantityOfOnlinePlayers = quantityOfOnlinePlayers;
    }

    public Date getOnlinePeakTime() {
        return onlinePeakTime;
    }

    public void setOnlinePeakTime(Date onlinePeakTime) {
        this.onlinePeakTime = onlinePeakTime;
    }

}
