package com.azoft.poker.common.socialnetwork.bean;

import com.azoft.poker.common.jaxp.AbstractBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Friends bean
 */
public class FriendsBean extends AbstractBean {

    private List<String> friends = new ArrayList<String>();

    public FriendsBean() {
    }

    /**
     * Get friends (Social network ID list)
     *
     * @return friends (Social network ID list)
     */
    public List<String> getFriends() {
        return friends;
    }

    /**
     * Add friend
     *
     * @param friend social network ID friend
     */
    public void addFriend(String friend) {
        friends.add(friend);
    }

}
