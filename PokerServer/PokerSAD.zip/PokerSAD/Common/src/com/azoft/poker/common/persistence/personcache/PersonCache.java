package com.azoft.poker.common.persistence.personcache;

import com.azoft.poker.common.persistence.BaseEntity;

public class PersonCache extends BaseEntity {

    /**
     * Person id
     */
    private Long personId;

    /**
     * Game balance
     */
    private Long gameBalance;

    /**
     * Tournament id
     */
    private Long tournamentId;

    public PersonCache() {
        super();
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public Long getGameBalance() {
        return gameBalance;
    }

    public void setGameBalance(Long gameBalance) {
        this.gameBalance = gameBalance;
    }

    public Long getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Long tournamentId) {
        this.tournamentId = tournamentId;
    }

}