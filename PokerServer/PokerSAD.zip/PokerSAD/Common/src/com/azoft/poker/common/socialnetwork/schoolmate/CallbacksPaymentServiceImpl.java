package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.persistence.event.EventEntityManagerImpl;
import com.azoft.poker.common.persistence.event.EventTypeID;
import com.azoft.poker.common.persistence.event.PaymentOfChipsEvent;
import com.azoft.poker.common.persistence.payment.Payment;
import com.azoft.poker.common.persistence.payment.PaymentManager;
import com.azoft.poker.common.persistence.payment.PaymentManagerImpl;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.product.Product;
import com.azoft.poker.common.persistence.product.ProductManagerImpl;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentService;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentServiceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;

/**
 * Callbacks payment service for schoolmate
 */
public class CallbacksPaymentServiceImpl implements CallbacksPaymentService {

    private final static Logger LOGGER = LoggerFactory.getLogger(CallbacksPaymentServiceImpl.class);

    private static final String CONTENT_TYPE = "application/xml; charset=utf-8";

    /**
     * Successful result
     */
    public static final String SUCCESSFUL_RESULT = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<callbacks_payment_response xmlns=\"http://api.forticom.com/" +
            Constants.API_VERSION +
            "/\">\n" +
            "true\n" +
            "</callbacks_payment_response>";

    private String getErrorResult(int errorCode, String errorMessage) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<ns2:error_response xmlns:ns2=\"http://api.forticom.com/" +
                Constants.API_VERSION +
                "/\">\n" +
                " <error_code>" +
                errorCode +
                "</error_code>\n" +
                " <error_msg>" +
                errorMessage +
                "</error_msg>\n" +
                "</ns2:error_response>";
    }

    private boolean existsError = false;

    public boolean isExistsError() {
        return existsError;
    }

    public String getContentType() {
        return CONTENT_TYPE;
    }

    public String methodCallbacksPayment(Map parameters) {
        String result = null;
        boolean check = true;

        //read payment
        Person person = null;
        String[] socialNetworkID = (String[]) parameters.get(Constants.PARAMETER_NAME_UID);
        check = check && CallbacksPaymentServiceFactory.checkParameter(socialNetworkID);
        if (check) {
            PersonManager personManager = PersonManagerImpl.getInstance();
            person = personManager.getPersonBySNID(socialNetworkID[0]);
            if (person != null) {
                String[] strTransactionTime = (String[]) parameters.get(Constants.PARAMETER_TRANSACTION_TIME);
                check = check && CallbacksPaymentServiceFactory.checkParameter(strTransactionTime);
                //format 2010-02-23 19:06:55
                Date transactionTime = null;
                String errorMsg = "Not valid 'transaction_time' parameter";
                if (check) {
                    try {
                        transactionTime = DateHelper.attributeDateTimeFormat.parse(strTransactionTime[0]);
                    } catch (ParseException e) {
                        check = false;
                        result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                        LOGGER.error(errorMsg, e);
                    }
                } else {
                    result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                    LOGGER.warn(errorMsg);
                }
                String[] strTransactionId = (String[]) parameters.get(Constants.PARAMETER_TRANSACTION_ID);
                check = check && CallbacksPaymentServiceFactory.checkParameter(strTransactionId);
                String[] productCode = (String[]) parameters.get(Constants.PARAMETER_PRODUCT_CODE);
                check = check && CallbacksPaymentServiceFactory.checkParameter(productCode);
                String[] productOption = (String[]) parameters.get(Constants.PARAMETER_PRODUCT_OPTION);
                String[] strAmount = (String[]) parameters.get(Constants.PARAMETER_AMOUNT);
                Long amount = null;
                errorMsg = "Not valid 'amount' parameter";
                if (check) {
                    check = check && CallbacksPaymentServiceFactory.checkParameter(strAmount);
                    if (check) {
                        try {
                            amount = Long.valueOf(strAmount[0]);
                        } catch (NumberFormatException e) {
                            check = false;
                            result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                            LOGGER.error(errorMsg, e);
                        }
                    } else {
                        result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                        LOGGER.warn(errorMsg);
                    }
                }
                if (check) {
                    String transactionId = strTransactionId[0];
                    PaymentManager<Payment> paymentManager = PaymentManagerImpl.getInstance();
                    Payment existsPayment = paymentManager.getPayment(transactionId);
                    if (existsPayment == null) { //is not exists payment - store payment
                        try {
                            Product product = ProductManagerImpl.getInstance().getProduct(productOption[0]);
                            if (product != null) {
                                if (amount.equals(product.getAmount())) {
                                    Payment payment = new Payment();
                                    payment.setSocialNetworkID(socialNetworkID[0]);
                                    payment.setTransactionTime(transactionTime);
                                    payment.setTransactionId(transactionId);
                                    payment.setProductCode(productCode[0]);
                                    if (CallbacksPaymentServiceFactory.checkParameter(productOption)) {
                                        payment.setProductOption(productOption[0]);
                                    }
                                    payment.setAmount(amount);

                                    person.setBalance(person.getBalance() + product.getBalance());
                                    personManager.storePerson(person);
                                    paymentManager.save(payment);
                                    PaymentOfChipsEvent event = new PaymentOfChipsEvent(EventTypeID.PAYMENT_OF_CHIPS.getTypeId(), person.getId());
                                    event.setAccountRevenue(product.getAmount());
                                    event.setAccountChips(product.getBalance());
                                    EventEntityManagerImpl.getInstance().save(event.getEntity());
                                } else {
                                    check = false;
                                    errorMsg = "Not equals amount for product code: " + productCode[0];
                                    result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                                    LOGGER.warn(errorMsg);
                                }
                            } else {
                                check = false;
                                errorMsg = "Not exists product for product code: " + productCode[0];
                                result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                                LOGGER.warn(errorMsg);
                            }
                        } catch (Exception e) {
                            check = false;
                            result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), "Service temporary unavailable");
                            LOGGER.error("methodCallbacksPayment", e);
                        }
                    } else { //is exists payment
                        check = false;
                        errorMsg = "Exists payment with transaction id: " + transactionId;
                        result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                        LOGGER.warn(errorMsg);
                    }
                }
            } else {
                check = false;
                String errorMsg = "Not exists user: " + socialNetworkID[0];
                result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
                LOGGER.warn(errorMsg);
            }
        }

        if (check) {
            result = SUCCESSFUL_RESULT;
        } else if (result == null) {
            String errorMsg = "Not valid parameter(s): " + parameters;
            result = getErrorResult(ErrorCodes.CALLBACK_INVALID_PAYMENT.getErrorCode(), ErrorCodes.CALLBACK_INVALID_PAYMENT.name() + ". " + errorMsg);
            LOGGER.warn(errorMsg);
        }
        existsError = !check;
        return result;
    }

}
