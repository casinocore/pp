package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.exception.CommonException;

import java.util.Map;

public class SocialNetworkClientManagerImpl implements SocialNetworkClientManager {

    private static SocialNetworkClient socialNetworkClient;

    private static SocialNetworkClientManager instance = null;

    public static synchronized SocialNetworkClientManager getInstance() {
        if (instance == null) {
            instance = new SocialNetworkClientManagerImpl();
        }
        return instance;
    }

    private SocialNetworkClientManagerImpl() {
    }

    public SocialNetworkClient createSocialNetworkClient(Map<String, Object> parameters) throws CommonException {
        socialNetworkClient = SocialNetworkClientFactory.createSocialNetworkClient(parameters);
        return getSocialNetworkClient();
    }

    public SocialNetworkClient getSocialNetworkClient() throws CommonException {
        if (socialNetworkClient != null) {
            return socialNetworkClient;
        } else {
            throw new CommonException("Not created SocialNetworkClient");
        }
    }

}