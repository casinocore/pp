package com.azoft.poker.common.bean;

import java.util.Comparator;

/**
 * Asc blind comparator
 */
public class AscBlindComparator implements Comparator<Blind> {

    public int compare(Blind o1, Blind o2) {
        return o1.getBigBlind() - o2.getBigBlind();
    }

}
