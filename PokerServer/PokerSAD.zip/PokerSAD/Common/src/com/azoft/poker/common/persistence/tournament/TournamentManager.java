package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.persistence.person.InfoPlayerBean;
import com.azoft.poker.common.persistence.person.Person;

import java.util.Date;
import java.util.List;

public interface TournamentManager {

    void updateTournament(Tournament tournament);

    Tournament getTournament(long tournamentId);

    Tournament getCurrentTournament(TournamentTypeID tournamentTypeID);

    List<Tournament> getActiveTournaments(TournamentTypeID tournamentTypeID);

    List<Tournament> getTournaments();

    List<Tournament> getTournaments(TournamentTypeID tournamentTypeID,
                                    TournamentStatusID tournamentStatusID);

    Long getTournamentsCount();

    Long getFee(Tournament tournament, short paymentsNumber);

    Tournament createTournament(TournamentTypeID tournamentTypeID);

    Tournament createTournament(Tournament tournament);

    void saveTournament(Tournament tournament);

    void changeTournamentStatus(Tournament tournament,
                                TournamentStatusID tournamentStatusID);

    TournamentPersonStatus addPlayerToTournament(Long tournamentId, Person person, boolean isInitializationTournamentBalance);

    TournamentPersonStatus addPlayerToTournament(Tournament tournament, Person person, boolean isInitializationTournamentBalance);

    Long removePlayerFromTournament(Long tournamentId, Person person);

    TournamentPersonStatus getTournamentPersonStatus(Long tournamentId,
                                                     Long personId);

    void updateTournamentPersonStatus(TournamentPersonStatus tournamentPersonStatus);

    Long getTournamentPersonStatusCount(Long tournamentId);

    Long getReParticipantsTournamentPersonStatusCount(Long tournamentId);

    Long getTournamentsCount(Long userId);

    List<InfoPlayerBean> getTournamentPlayers(Long tournamentId, int topNumber);

    List<InfoPlayerBean> getMTTPlayersByBalance(Long tournamentId, int topNumber);

    List<InfoPlayerBean> getMTTPlayersByLeavingTime(Long tournamentId, int topNumber,
                                                    List<InfoPlayerBean> list);

    List<InfoPlayerBean> getMTTPlayersByLeavingTime(Long tournamentId, int topNumber);

    List<Person> getTournamentPersons(Long tournamentId);

    Long getTournamentRank(Tournament tournament, Long personId, Long totalBalance);

    Long getCountActiveMTTPlayers(Long tournamentId);

    Long getTotalTournamentBalance(Long tournamentId, Long userId);

    Integer getCountTournamentWinner(Long personId);

    Integer getExistingTournamentsCount(Date from, Date to, Byte type,
                                        Long exclusiveId);

}
