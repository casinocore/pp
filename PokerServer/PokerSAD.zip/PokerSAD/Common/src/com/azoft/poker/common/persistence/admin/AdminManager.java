package com.azoft.poker.common.persistence.admin;

public interface AdminManager {

	Admin findPersonByLogin(String login);
}
