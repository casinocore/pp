package com.azoft.poker.common.socialnetwork.facebook;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.socialnetwork.bean.*;
import com.azoft.poker.common.socialnetwork.client.AbstractSocialNetworkClient;

import java.util.List;

/**
 * Social network client stub for facebook
 */
public class SocialNetworkClientImpl extends AbstractSocialNetworkClient {

    public SocialNetworkClientImpl() {
        super(null);
    }

    public int getMaxNumberForMethodGetUsersInfo() {
        return 0;
    }

    public UsersInfoBean methodGetUsersInfo(List<String> socialNetworkIDList) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodGetUsersInfo");
    }

    public FriendsBean methodGetFriends(String socialNetworkID) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodGetFriends");
    }

    public LoginBean methodLogin(String login, String password, boolean genToken) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodLogin");
    }

    public SocialNetworkMoneyBean methodPayment(String socialNetworkID, long amount, boolean testMode) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodPayment");
    }

    public SocialNetworkMoneyBean methodGetBalance(String socialNetworkID) throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodGetBalance");
    }

    public SendNotificationBean methodSendNotification(String socialNetworkIDString, String message)
            throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodSendNotification");
    }

    public List<SendNotificationBean> methodSendNotifications(List<String> socialNetworkIDList, String message)
            throws CommonException {
        throw new UnsupportedOperationException("Unsupported methodSendNotifications");
    }

}