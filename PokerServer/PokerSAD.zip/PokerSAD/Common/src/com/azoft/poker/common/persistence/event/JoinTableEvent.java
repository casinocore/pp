package com.azoft.poker.common.persistence.event;

public class JoinTableEvent extends EventEntityWrapper {

    public JoinTableEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    public JoinTableEvent(Short eventType, Long referenceId) {
        super(eventType, referenceId);
    }

    public String getBlindsName() {
        return getEntity().getAttributeValue(BLINDS_NAME);
    }

    public void setBlindsName(String blindsName) {
        getEntity().addAttribute(BLINDS_NAME, blindsName);
    }

}
