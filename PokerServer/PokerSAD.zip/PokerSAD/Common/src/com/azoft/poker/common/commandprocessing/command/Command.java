package com.azoft.poker.common.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.handler.HandlersRegister;
import com.azoft.poker.common.communicator.BaseConstants;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;

public abstract class Command implements Runnable {

    private final static Logger LOGGER = LoggerFactory.getLogger(Command.class);

    /**
     * Body size maximum for command
     */
    public static final int BODY_SIZE_MAX = 1024 * 1000;

    private final static String USER_ID_ATTRIBUTE = "USER_ID";

    /**
     * Meta info size
     */
    public static final int HEADER_SIZE = 2 + 1 + 4;

    /**
     * IO session
     */
    private IoSession session;

    /**
     * Meta info, Command Type ID - Идентификатор типа команды
     */
    private CommandTypeID commandTypeID;

    /**
     * Meta info, Protocol version - Версия протокола
     */
    private byte protocolVersion;

    /**
     * Meta info, Body size - Размер тела команды
     */
    private int bodySize;

    private static final AtomicLong closedCounter = new AtomicLong(0);

    public Command(IoSession session, CommandTypeID commandTypeID) {
        this.session = session;
        this.commandTypeID = commandTypeID;
        this.protocolVersion = BaseConstants.PROTOCOL_VERSION;
    }

    public IoSession getSession() {
        return session;
    }

    public void setSession(IoSession session) {
        this.session = session;
    }

    public CommandTypeID getCommandTypeID() {
        return commandTypeID;
    }

    public byte getProtocolVersion() {
        return protocolVersion;
    }

    public int getBodySize() {
        return bodySize;
    }

    public void setBodySize(int bodySize) {
        this.bodySize = bodySize;
    }

    public int getFullSize() {
        return bodySize + HEADER_SIZE;
    }

    public Long getUserId() {
        return (Long) session.getAttribute(USER_ID_ATTRIBUTE);
    }

    public void setUserId(Long UserId) {
        session.setAttribute(USER_ID_ATTRIBUTE, UserId);
    }

    @Override
    public String toString() {
        return "Command{" +
                "commandTypeID=" + commandTypeID +
                ", protocolVersion=" + protocolVersion +
                ", bodySize=" + bodySize +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
    }

    public IoBuffer encode() throws IOException {
        //prepare buffer
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode header without body size
        dos.writeShort(commandTypeID.getTypeId());
        dos.writeByte(protocolVersion);
        //encode body size and body
        encodeBody(dos);

        dos.flush();
        byte[] data = baos.toByteArray();
        // data - completed byte array - send it to client
        IoBuffer buf = IoBuffer.allocate(data.length);
        buf.put(data);
        return buf;
    }

    public abstract void encodeBody(DataOutputStream out) throws IOException;

    public void send() {
        if (session != null) {
            if (session.isConnected()) {
                session.write(this);
                LOGGER.debug("Response send: " + this.toString());
            } else {
                session.close(true);
                LOGGER.warn("Response closed: " + this.toString() + "; closedCounter: " + closedCounter.getAndIncrement());
            }
        }
    }

    public void run() {
        try {
            HandlersRegister.getHandler(commandTypeID).execute(this);
        } catch (Throwable e) {
            LOGGER.error("Internal server error", e);
        }
    }

}
