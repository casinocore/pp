package com.azoft.poker.common.persistence.configurationattribute;

import com.azoft.poker.common.persistence.BaseEntity;

/**
 * Configuration attribute
 */
public class ConfigurationAttribute extends BaseEntity {

    private short type;

    private String name;

    private String value;

    public ConfigurationAttribute() {
        super();
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "ConfigurationAttribute{" +
                "type=" + type +
                ", name='" + name + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}