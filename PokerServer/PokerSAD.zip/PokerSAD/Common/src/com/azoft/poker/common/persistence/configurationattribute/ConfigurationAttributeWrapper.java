package com.azoft.poker.common.persistence.configurationattribute;

/**
 * Wrapper for configuration attribute
 */
public class ConfigurationAttributeWrapper {

    private ConfigurationAttribute attribute;

    public ConfigurationAttributeWrapper(ConfigurationAttribute attribute) {
        this.attribute = attribute;
    }

    public ConfigurationAttribute getAttribute() {
        return attribute;
    }

    public Byte getByteAttribute() {
        Byte result = null;
        try {
            result = Byte.valueOf(attribute.getValue());
        } catch (NumberFormatException e) {
            result = null;
        }
        return result;
    }

    public void setByteAttribute(Byte attributeValue) {
        if (attributeValue != null) {
            attribute.setValue(String.valueOf(attributeValue));
        }
    }

    public Short getShortAttribute() {
        Short result = null;
        try {
            result = Short.valueOf(attribute.getValue());
        } catch (NumberFormatException e) {
            result = null;
        }
        return result;
    }

    public void setShortAttribute(Short attributeValue) {
        if (attributeValue != null) {
            attribute.setValue(String.valueOf(attributeValue));
        }
    }

    public Integer getIntegerAttribute() {
        Integer result = null;
        try {
            result = Integer.valueOf(attribute.getValue());
        } catch (NumberFormatException e) {
            result = null;
        }
        return result;
    }

    public void setIntegerAttribute(Integer attributeValue) {
        if (attributeValue != null) {
            attribute.setValue(String.valueOf(attributeValue));
        }
    }

    public Long getLongAttribute() {
        Long result = null;
        try {
            result = Long.valueOf(attribute.getValue());
        } catch (NumberFormatException e) {
            result = null;
        }
        return result;
    }

    public void setLongAttribute(Long attributeValue) {
        if (attributeValue != null) {
            attribute.setValue(String.valueOf(attributeValue));
        }
    }

}