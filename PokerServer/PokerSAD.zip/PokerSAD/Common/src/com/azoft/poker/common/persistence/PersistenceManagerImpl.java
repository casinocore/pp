package com.azoft.poker.common.persistence;

import com.azoft.poker.common.exception.CommonException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.math.BigInteger;

public abstract class PersistenceManagerImpl<PersistenceType> {

    public static final byte FALSE_VALUE = 0;
    public static final byte TRUE_VALUE = 1;

    private static final String QUERY_COUNT_PREFIX = "select count(*) from ";

    protected PersistenceManagerImpl() {
    }

    protected Session getSession() {
        return HibernateUtil.getSessionFactory().getCurrentSession();
    }

    public void save(PersistenceType persistenceObject) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.save(persistenceObject);
        transaction.commit();
    }

    public void merge(PersistenceType persistenceObject) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.merge(persistenceObject);
        transaction.commit();
    }

    public void update(PersistenceType persistenceObject) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.update(persistenceObject);
        transaction.commit();
    }

    public PersistenceType delete(PersistenceType persistenceObject) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        session.delete(persistenceObject);
        transaction.commit();
        return persistenceObject;
    }

    /**
     * Get count
     *
     * @param tableName table name
     * @return count
     */
    public BigInteger getCount(String tableName) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(QUERY_COUNT_PREFIX + tableName).uniqueResult();
        transaction.commit();
        return count;
    }

    public void checkObjectNotNull(Object o, String exceptionMessage) throws CommonException {
        if (o == null) {
            throw new CommonException(exceptionMessage);
        }
    }

}
