package com.azoft.poker.common.commandprocessing.handler;

import com.azoft.poker.common.commandprocessing.CommandTypeID;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HandlersRegister {

    private final static Map<CommandTypeID, Handler> handlerMap = new ConcurrentHashMap<CommandTypeID, Handler>();

    public static Handler getHandler(CommandTypeID commandTypeID) {
        return handlerMap.get(commandTypeID);
    }

    public static void setHandler(CommandTypeID commandTypeID, Handler handler) {
        handlerMap.put(commandTypeID, handler);
    }
}
