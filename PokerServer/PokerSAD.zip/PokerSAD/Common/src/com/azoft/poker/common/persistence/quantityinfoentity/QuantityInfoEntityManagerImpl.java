package com.azoft.poker.common.persistence.quantityinfoentity;

import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * Quantity info entity manager
 */
public class QuantityInfoEntityManagerImpl extends PersistenceManagerImpl<QuantityInfoEntity> implements QuantityInfoEntityManager<QuantityInfoEntity> {

    private static QuantityInfoEntityManager<QuantityInfoEntity> instance = null;

    public static synchronized QuantityInfoEntityManager<QuantityInfoEntity> getInstance() {
        if (instance == null) {
            instance = new QuantityInfoEntityManagerImpl();
        }
        return instance;
    }

    private QuantityInfoEntityManagerImpl() {
        super();
    }

    public QuantityInfoEntity getQuantityInfoEntity(long quantityInfoEntityId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        QuantityInfoEntity quantityInfoEntity = (QuantityInfoEntity) session.get(QuantityInfoEntity.class, quantityInfoEntityId);
        transaction.commit();
        return quantityInfoEntity;
    }


}