package com.azoft.poker.common.persistence.product;

import java.util.List;

/**
 * Product manager interface
 */
public interface ProductManager<PersistenceType> {

    void save(PersistenceType persistenceObject);

    /**
     * Retrieve all <code>Product</code>s from the data store.
     *
     * @return a <code>List</code> of <code>Product</code>s
     */
    List<Product> getProducts();

    /**
     * Get an <code>Product</code> from the data store by product code
     *
     * @param productCode product code
     * @return product
     */
    Product getProduct(String productCode);

}