package com.azoft.poker.common.socialnetwork.service;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.socialnetwork.service.CallbacksPaymentService;

import java.util.Map;

/**
 * Callbacks payment service manager interface
 */
public interface CallbacksPaymentServiceManager {

    /**
     * Get callbacks payment service
     *
     * @param parameters request parameters
     * @return callbacks payment service
     * @throws CommonException CommonException
     */
    public CallbacksPaymentService getCallbacksPaymentService(Map parameters) throws CommonException;

}
