package com.azoft.poker.common.persistence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Wait-notify event lock
 */
public class WaitNotify {

    private final static Logger LOGGER = LoggerFactory.getLogger(WaitNotify.class);

    private final Object lock = new Object();

    private boolean wasSignalled = false;

    /**
     * Wait lock event
     */
    public void doWait() {
        synchronized (lock) {
            if (!wasSignalled) {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    LOGGER.error("doWait error", e);
                }
            }
            //clear signal and continue running.
            wasSignalled = false;
        }
    }

    /**
     * Notify lock event
     */
    public void doNotify() {
        synchronized (lock) {
            wasSignalled = true;
            lock.notify();
        }
    }
}
