package com.azoft.poker.common.commandprocessing;

import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;

public interface CommandFactory {

    public Command createCommand(IoSession session, short typeID) throws Exception;

}
