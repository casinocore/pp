package com.azoft.poker.common.persistence.event;

import com.azoft.poker.common.persistence.CustomAttributesEntity;
import com.azoft.poker.common.publisher.Event;

import java.util.Date;

/**
 * Persistence application event
 */
public class EventEntity extends CustomAttributesEntity implements Event {

    /**
     * Event type
     */
    private Short eventType;

    /**
     * Event timestamp
     */
    private Date timeStamp;

    /**
     * Reference on {@link com.azoft.poker.common.persistence.BaseEntity}.id
     * ( sample: {@link com.azoft.poker.common.persistence.person.Person}.id )
     */
    private Long referenceId;

    public EventEntity() {
        super();
    }

    public EventEntity(Short eventType) {
        super();
        this.eventType = eventType;
        this.timeStamp = new Date();
    }

    public EventEntity(Short eventType, Long referenceId) {
        this(eventType);
        this.referenceId = referenceId;
    }

    public Short getEventType() {
        return eventType;
    }

    public void setEventType(Short eventType) {
        this.eventType = eventType;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public Long getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(Long referenceId) {
        this.referenceId = referenceId;
    }

    @Override
    public String toString() {
        return "EventEntity{" +
                "eventType=" + eventType +
                ", timeStamp=" + timeStamp +
                ", referenceId=" + referenceId +
                "} > " + super.toString();
    }

    public EventEntity getEntity() {
        return this;
    }

}
