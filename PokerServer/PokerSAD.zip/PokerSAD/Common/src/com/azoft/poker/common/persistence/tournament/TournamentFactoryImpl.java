package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.exception.CommonException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Tournament factory
 */
public class TournamentFactoryImpl {

    private final static Logger LOGGER = LoggerFactory.getLogger(TournamentFactoryImpl.class);

    public static TournamentWrapper createTournamentWrapper(Tournament tournament) throws CommonException {
        TournamentWrapper tw = null;
        if (TournamentTypeID.SIT_AND_GO_TOURNAMENT.getTypeId() == tournament.getType()) {
            tw = new SitAndGoTournamentWrapper(tournament);
        } else if (TournamentTypeID.TEMPORAL_TOURNAMENT.getTypeId() == tournament.getType()) {
            tw = new TemporalTournamentWrapper(tournament);
        } else if (TournamentTypeID.MTT_TOURNAMENT.getTypeId() == tournament.getType()) {
            tw = new MTTTournamentWrapper(tournament);
        } else {
            String errorMessage = "Not created tournament wrapper for : " + tournament;
            LOGGER.error(errorMessage);
            throw new CommonException(errorMessage);
        }
        return tw;
    }

    public static MTTTournamentWrapper createMTTTournamentWrapper(Tournament tournament) {
        MTTTournamentWrapper mttTournament = null;
        if (TournamentTypeID.MTT_TOURNAMENT.getTypeId() == tournament.getType()) {
            mttTournament = new MTTTournamentWrapper(tournament);
        } else {
            String errorMessage = "Not created MTT tournament wrapper for : " + tournament;
            LOGGER.error(errorMessage);
        }
        return mttTournament;
    }

}
