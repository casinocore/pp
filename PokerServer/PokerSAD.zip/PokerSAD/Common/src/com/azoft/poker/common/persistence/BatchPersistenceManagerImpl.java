package com.azoft.poker.common.persistence;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Batch persistence manager
 *
 * @param <PersistenceType> persistence type
 */
public abstract class BatchPersistenceManagerImpl<PersistenceType> extends PersistenceManagerImpl<PersistenceType>
        implements BatchPersistenceManager<PersistenceType> {

    private final static Logger LOGGER = LoggerFactory.getLogger(BatchPersistenceManagerImpl.class);

    /**
     * Default batch max
     */
    private final static int DEFAULT_BATCH_MAX = 100;

    /**
     * Batch process termination timeout
     */
    private final static long BATCH_PROCESS_TERMINATION_TIMEOUT = 1000 * 10;

    private AtomicInteger atomicBatchMax = new AtomicInteger(DEFAULT_BATCH_MAX);

    /**
     * Manager type
     */
    private String type;

    private Queue<PersistenceType> queue;

    private final WaitNotifyRunnable batchRunnable;

    private final ExecutorService executor;

    protected BatchPersistenceManagerImpl(String type) {
        super();
        this.type = type;
        queue = new LinkedBlockingQueue<PersistenceType>();
        batchRunnable = new BatchRunnable();
        executor = Executors.newSingleThreadExecutor();
    }

    public void initialization(Map<String, Object> parameters) {
        executor.execute(batchRunnable);
    }

    public void shutdown() {
        batchRunnable.cancel();
        batchRunnable.getWaitNotify().doNotify();
        boolean terminated = false;
        try {
            executor.shutdown();
            terminated = executor.awaitTermination(BATCH_PROCESS_TERMINATION_TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOGGER.error(type + ": shutdown", e);
        }
        LOGGER.info(type + ": shutdown: " + terminated);
    }

    public int getBatchMax() {
        return atomicBatchMax.get();
    }

    public void setBatchMax(int batchMax) {
        this.atomicBatchMax.set(batchMax);
    }

    public void batchStore(PersistenceType persistenceObject) {
        queue.add(persistenceObject);
        if (queue.size() >= getBatchMax()) {
            batchRunnable.getWaitNotify().doNotify();
        }
    }

    public void storePersistenceObjects() {
        batchRunnable.getWaitNotify().doNotify();
    }

    private void storeObjects() {
        int totalCount = 0;
        while (queue.peek() != null) {
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            int count = 0;
            for (int i = 0; i < getBatchMax(); i++) {
                PersistenceType persistenceObject = queue.poll();
                if (persistenceObject != null) {
                    session.merge(persistenceObject);
                    count++;
                } else {
                    break;
                }
            }
            transaction.commit();
            totalCount += count;
            LOGGER.debug(type + ": storeObjects transaction completed - store event count: " + count);
        }
        LOGGER.debug(type + ": storeObjects completed - store event total count: " + totalCount);
    }

    private class BatchRunnable extends WaitNotifyRunnable {

        public BatchRunnable() {
            super();
        }

        @Override
        public void runBody() {
            storeObjects();
        }

        @Override
        public void shutdown() {
            storeObjects();
        }
    }
}
