package com.azoft.poker.common.persistence.product;

import com.azoft.poker.common.persistence.BaseEntity;

/**
 * Product
 */
public class Product extends BaseEntity {

    /**
     * Product code
     */
    private String productCode;

    /**
     * Product descriptor
     */
    private String productDescriptor;

    /**
     * Amount
     */
    private Long amount;

    /**
     * Balance
     */
    private Long balance;

    public Product() {
        super();
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductDescriptor() {
        return productDescriptor;
    }

    public void setProductDescriptor(String productDescriptor) {
        this.productDescriptor = productDescriptor;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Long getBalance() {
        return balance;
    }

    public void setBalance(Long balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productCode='" + productCode + '\'' +
                ", productDescriptor='" + productDescriptor + '\'' +
                ", amount=" + amount +
                ", balance=" + balance +
                "} > " + super.toString();
    }

}