package com.azoft.poker.common.persistence.news;

import com.azoft.poker.common.persistence.BaseEntity;

import java.util.Date;

/**
 * News
 */
public class News extends BaseEntity {

    /**
     * News timestamp
     */
    private Date timeStamp;

    /**
     * News preview
     */
    private String preview;

    /**
     * News body
     */
    private String body;

    /**
     * News private access
     */
    private boolean privateAccess;

    public News() {
        super();
        this.timeStamp = new Date();
        this.privateAccess = false;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public boolean isPrivateAccess() {
        return privateAccess;
    }

    public void setPrivateAccess(boolean privateAccess) {
        this.privateAccess = privateAccess;
    }

}