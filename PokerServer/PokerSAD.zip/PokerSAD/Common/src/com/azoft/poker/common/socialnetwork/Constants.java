package com.azoft.poker.common.socialnetwork;

/**
 * Constants for support social network
 */
public class Constants {

    /**
     * adminmodule properties file
     */
    public static final String ADMINMODULE_PROPERTIES = "adminmodule.properties";

    /**
     * Query method
     */
    public static final String QUERY_METHOD = "method";

    /**
     * An MD5 hash of the current request and your secret key, as described in the Authentication and
     * Authorization section.
     */
    public static final String QUERY_SIG = "sig";

    /**
     * Format of method response, can be JSON ot XML. If not specified, HTTP Accept header will be used to
     * determine the format (application/xml or applcation/json).
     */
    public static final String QUERY_FORMAT = "format";

    /**
     * 'application/xml' format of method response
     */
    public static final String QUERY_FORMAT_XML_VALUE = "XML";

    /**
     * 'uid' parameter name
     */
    public static final String PARAMETER_NAME_UID = "uid";

    /**
     * 'uids' parameter name
     */
    public static final String PARAMETER_NAME_UIDS = "uids";

    /**
     * 'fields' parameter name
     */
    public static final String PARAMETER_NAME_FIELDS = "fields";

}
