package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.socialnetwork.SocialNetworkTypeID;

import java.util.Map;

/**
 * Social network payment client factory
 */
public class SocialNetworkClientFactory {

    public static SocialNetworkClient createSocialNetworkClient(Map<String, Object> parameters) throws CommonException {
        SocialNetworkClient client = null;
        String typeID = (String) parameters.get(SocialNetworkTypeID.PROPERTY_TYPE_ID);
        SocialNetworkTypeID socialNetworkTypeID = SocialNetworkTypeID.valueOf(typeID);
        if (SocialNetworkTypeID.SCHOOLMATE.equals(socialNetworkTypeID)) {
            client = new com.azoft.poker.common.socialnetwork.schoolmate.SocialNetworkClientImpl();
        } else if (SocialNetworkTypeID.VKONTAKTE.equals(socialNetworkTypeID)) {
            client = new com.azoft.poker.common.socialnetwork.vkontakte.SocialNetworkClientImpl();
        } else if (SocialNetworkTypeID.FACEBOOK.equals(socialNetworkTypeID)) {
            client = new com.azoft.poker.common.socialnetwork.facebook.SocialNetworkClientImpl();
        }
        if (client != null) {
            client.initialization(parameters);
        }
        return client;
    }

}
