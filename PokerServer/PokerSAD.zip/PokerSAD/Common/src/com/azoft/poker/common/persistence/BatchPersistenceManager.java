package com.azoft.poker.common.persistence;

import com.azoft.poker.common.service.LifecycleService;

/**
 * Batch persistence manager interface
 *
 * @param <PersistenceType> persistence type
 */
public interface BatchPersistenceManager<PersistenceType> extends LifecycleService {

    int getBatchMax();

    void setBatchMax(int batchMax);

    /**
     * Batch save an <code>PersistenceType</code> to the data store, either inserting or updating it.
     *
     * @param persistenceObject session the <code>PersistenceType</code> to batch save
     */
    void batchStore(PersistenceType persistenceObject);

    /**
     * Batch save cache, either inserting or updating it.
     */
    void storePersistenceObjects();

}
