package com.azoft.poker.common.persistence.person;

/**
 * Account type ID
 */
public enum AccountTypeID {

    REAL_ACCOUNT((short) 1),
    TEST_ACCOUNT((short) 2),
    BOT_ACCOUNT((short) 3);

    private short typeId;

    AccountTypeID(short typeId) {
        this.typeId = typeId;
    }

    public short getTypeId() {
        return typeId;
    }

    public static AccountTypeID valueOf(short typeId) {
        AccountTypeID result = null;
        for (AccountTypeID serverTypeID : AccountTypeID.values()) {
            if (serverTypeID.getTypeId() == typeId) {
                result = serverTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "AccountTypeID{" +
                "name=" + name() +
                "typeId=" + typeId +
                '}';
    }

}
