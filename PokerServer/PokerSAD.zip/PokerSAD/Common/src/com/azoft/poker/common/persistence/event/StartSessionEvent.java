package com.azoft.poker.common.persistence.event;

import java.util.Date;

/**
 * TODO
 * Sample: SESSION_START event
 */
public class StartSessionEvent extends EventEntityWrapper {

    /**
     * StartSession event
     *
     * @param eventEntity persistence event
     */
    public StartSessionEvent(EventEntity eventEntity) {
        super(eventEntity);
    }

    /**
     * StartSession event
     *
     * @param referenceId person id
     */
    public StartSessionEvent(Long referenceId) {
        super(EventTypeID.TEST_EVENT.getTypeId(), referenceId);
    }

    public void setSessionStart(Date dateValue) {
        getEntity().addAttribute(SESSION_START, attributeDateTimeFormat.format(dateValue));
    }

}
