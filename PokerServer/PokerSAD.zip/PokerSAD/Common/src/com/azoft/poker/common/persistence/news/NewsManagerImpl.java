package com.azoft.poker.common.persistence.news;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.persistence.PersistenceManagerImpl;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

/**
 * News manager
 */
public class NewsManagerImpl extends PersistenceManagerImpl<News> implements NewsManager<News> {

    private static final String ENTITY_NEWS = "news";
    private static final String FIELD_IS_READ = "isRead";
    private static final String PARAMETER_PERSON_ID = "personId";
    private static final String PARAMETER_NEWS_NUMBER = "newsNumber";
    private static final String PARAMETER_NEWS_ID = "newsId";

    private static final String QUERY_GET_NEWS =
            "select {news.*}, ifnull(npl.is_read, 0) " + FIELD_IS_READ + " from news {news} " +
                    " left join news_person_link npl on (npl.news_id = news.id)" +
                    " where news.private_access = " + FALSE_VALUE +
                    "   or npl.person_id = :" + PARAMETER_PERSON_ID +
                    " order by {news.timeStamp} desc" +
                    " limit :" + PARAMETER_NEWS_NUMBER;

    private static final String QUERY_GET_ONLY_NOT_READ_NEWS =
            "select {news.*}, ifnull(npl.is_read, 0) " + FIELD_IS_READ + " from news {news} " +
                    " left join news_person_link npl on (npl.news_id = news.id)" +
                    " where (news.private_access = " + FALSE_VALUE +
                    "       and " +
                    "       npl.person_id is null)" +
                    "   or (npl.person_id = :" + PARAMETER_PERSON_ID +
                    "       and npl.is_read = " + FALSE_VALUE + ")" +
                    " order by {news.timeStamp} desc" +
                    " limit :" + PARAMETER_NEWS_NUMBER;

    private static final String QUERY_GET_NEWS_PERSON_LINK =
            "from NewsPersonLink npl"
                    + " where npl.person.id = :" + PARAMETER_PERSON_ID + " and npl.news.id = :" + PARAMETER_NEWS_ID;

    private static NewsManager<News> instance = null;

    public static synchronized NewsManager<News> getInstance() {
        if (instance == null) {
            instance = new NewsManagerImpl();
        }
        return instance;
    }

    private NewsManagerImpl() {
        super();
    }

    public List<NewsBean> getInfoNews(long personId, int newsNumber, boolean onlyNotRead) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        String strQuery;
        if (onlyNotRead) {
            strQuery = QUERY_GET_ONLY_NOT_READ_NEWS;
        } else {
            strQuery = QUERY_GET_NEWS;
        }
        Query query = session.createSQLQuery(strQuery)
                .addEntity(ENTITY_NEWS, News.class)
                .addScalar(FIELD_IS_READ, Hibernate.BYTE)
                .setLong(PARAMETER_PERSON_ID, personId)
                .setInteger(PARAMETER_NEWS_NUMBER, newsNumber);
        @SuppressWarnings("unchecked")
        List<Object[]> list = (List<Object[]>) query.list();
        transaction.commit();
        return boxingNewsBeanList(list);
    }

    private List<NewsBean> boxingNewsBeanList(List<Object[]> list) {
        List<NewsBean> infoNews = new ArrayList<NewsBean>();
        for (Object[] objects : list) {
            infoNews.add(new NewsBean((News) objects[0], (Byte) objects[1]));
        }
        return infoNews;
    }

    public NewsPersonLink addNewsPersonLink(News news, Person person, boolean isRead) {
        NewsPersonLink newsPersonLink = new NewsPersonLink(news, person);
        newsPersonLink.setRead(isRead);
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.save(newsPersonLink);
        transaction.commit();
        return newsPersonLink;
    }

    public void markNewsAsRead(long personId, List<Long> newsIds) throws CommonException {
        PersonManager personManager = PersonManagerImpl.getInstance();
        for (Long newsId : newsIds) {
            NewsPersonLink newsPersonLink = getNewsPersonLink(personId, newsId);
            if (newsPersonLink == null) {
                Person person = personManager.getPerson(personId);
                checkObjectNotNull(person, "Not exists personId: " + personId);
                News news = getNews(newsId);
                checkObjectNotNull(news, "Not exists newsId: " + newsId);
                newsPersonLink = addNewsPersonLink(news, person, true);
            } else {
                newsPersonLink.setRead(true);
            }
            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            session.merge(newsPersonLink);
            transaction.commit();
        }
    }

    private News getNews(long newsId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        News news = (News) session.get(News.class, newsId);
        transaction.commit();
        return news;
    }

    @SuppressWarnings("unchecked")
    private NewsPersonLink getNewsPersonLink(long personId, Long newsId) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        NewsPersonLink newsPersonLink = (NewsPersonLink) session.createQuery(QUERY_GET_NEWS_PERSON_LINK)
                .setLong(PARAMETER_PERSON_ID, personId)
                .setLong(PARAMETER_NEWS_ID, newsId)
                .uniqueResult();
        transaction.commit();
        return newsPersonLink;
    }

}