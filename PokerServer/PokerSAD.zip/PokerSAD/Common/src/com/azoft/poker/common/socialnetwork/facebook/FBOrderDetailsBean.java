package com.azoft.poker.common.socialnetwork.facebook;

import com.google.gson.Gson;

/**
 * Data for 'payments_get_items'
 */
public class FBOrderDetailsBean {

/*
    1. item_id - Your specific identifier, not used by Facebook
    2. title - The name of the product. <= 50 characters.
    3. description - A description of the product. <= 175 characters.
    4. image_url - The URL for the image to display to the user.
    5. product_url - A permalink to the URL where you display the product to the user.
    6. price - The price must be greater than 0 credits.
    7. data - Optional, not used by Facebook, but stored and sent to application with order_details.
*/

    private long item_id;

    private String title;

    private String description;

    private String image_url;

    private String product_url;

    private long price;

    private String data;

    public FBOrderDetailsBean() {
    }

    public long getItem_id() {
        return item_id;
    }

    public void setItem_id(long item_id) {
        this.item_id = item_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getProduct_url() {
        return product_url;
    }

    public void setProduct_url(String product_url) {
        this.product_url = product_url;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "FBOrderDetailsBean{" +
                "item_id=" + item_id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", image_url='" + image_url + '\'' +
                ", product_url='" + product_url + '\'' +
                ", price=" + price +
                ", data='" + data + '\'' +
                '}';
    }

    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    public static FBOrderDetailsBean createFBOrderDetailsBean(String json) {
        Gson gson = new Gson();
        //convert JSON into java object
        return gson.fromJson(json, FBOrderDetailsBean.class);
    }

}
