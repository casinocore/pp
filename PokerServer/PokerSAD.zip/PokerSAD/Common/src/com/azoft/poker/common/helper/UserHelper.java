package com.azoft.poker.common.helper;

/**
 * User helper
 */
public class UserHelper {

    /**
     * Get full name
     *
     * @param firstName first name
     * @param lastName  last name
     * @return full name
     */
    public static String getUserFullName(String firstName, String lastName) {
        StringBuffer result = new StringBuffer("");
        result.append(StringHelper.makeEmpty(firstName));
        if (result.length() > 0) {
            result.append(" ");
        }
        result.append(StringHelper.makeEmpty(lastName));
        return result.toString();
    }

}
