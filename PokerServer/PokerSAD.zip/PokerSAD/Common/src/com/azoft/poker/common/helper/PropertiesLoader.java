package com.azoft.poker.common.helper;

import com.azoft.poker.common.exception.CommonException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Properties loader
 */
public class PropertiesLoader {

    private final static Logger LOGGER = LoggerFactory.getLogger(PropertiesLoader.class);

    private static final String PROPERTIES_SOCIAL_NETWORK_PREFIX = "SOCIAL_NETWORK_";

    public static Map<String, Object> loadProperties(String propertiesFileName) throws CommonException {
        Map<String, Object> parameters = new HashMap<String, Object>();
        LOGGER.info("Properties file name: " + propertiesFileName);
        Properties properties = new Properties();
        InputStream in = null;
        try {
            try {
                in = PropertiesLoader.class.getClassLoader().getResourceAsStream(propertiesFileName);
                properties.load(in);
                for (Map.Entry<Object, Object> entry : properties.entrySet()) {
                    String key = ((String) entry.getKey()).replace(PROPERTIES_SOCIAL_NETWORK_PREFIX, "");
                    parameters.put(key, entry.getValue());
                }
                LOGGER.debug("Properties: " + parameters);
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e) {
                        LOGGER.error("Properties in.close", e);
                    }
                }
            }
        } catch (IOException e) {
            throw new CommonException("loadProperties", e);
        }
        return parameters;
    }

}
