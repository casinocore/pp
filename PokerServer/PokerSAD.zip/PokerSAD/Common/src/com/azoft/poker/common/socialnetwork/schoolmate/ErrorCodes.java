package com.azoft.poker.common.socialnetwork.schoolmate;

/**
 * Error codes for schoolmate
 */
public enum ErrorCodes {

    UNKNOWN(1),
    SERVICE(2),
    METHOD(3),
    REQUEST(4),
    PERMISSION_DENIED(10),
    LIMIT_REACHED(11),
    PARAM(100),
    PARAM_API_KEY(101),
    PARAM_SESSION_EXPIRED(102),
    PARAM_SESSION_KEY(103),
    PARAM_SIGNATURE(104),
    PARAM_USER_ID(110),
    PARAM_PERMISSION(200),
    PARAM_APPLICATION_DISABLED(210),
    AUTH_LOGIN(401),
    SESSION_REQUIRED(453),
    NO_SUCH_APP(900),
    SYSTEM(9999),
    CALLBACK_INVALID_PAYMENT(1001);

    private int errorCode;

    ErrorCodes(int errorCode) {
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

}
