package com.azoft.poker.common.commandprocessing.handler;

public abstract class Handler<CommandType> {

    public Handler() {
    }

    public abstract void execute(CommandType command);

}
