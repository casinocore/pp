package com.azoft.poker.common.commandprocessing;

import com.azoft.poker.common.commandprocessing.command.Command;

/**
 * Command processor
 */
public interface CommandProcessor {

    /**
     * Primary processor index
     */
    int PRIMARY_PROCESSOR_INDEX = 0;

    /**
     * Secondary processor index
     */
    int SECONDARY_PROCESSOR_INDEX = 1;

    /**
     * Put command in queue
     *
     * @param command command
     * @throws InterruptedException put exception
     */
    void putCommand(Command command) throws InterruptedException;

}
