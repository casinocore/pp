package com.azoft.poker.common.helper;

public class StringHelper {

    private StringHelper() {
    }

    public static String trim(String s) {
        return s == null ? null : s.trim();
    }

    /**
     * Check if string is empty
     *
     * @param s string
     * @return true if string is null, or empty
     */
    public static boolean isEmpty(String s) {
        return s == null || s.length() == 0;
    }

    /**
     * Check if string is empty
     *
     * @param s string
     * @return true if string is null, empty or contains spaces only
     */
    public static boolean isEmptyTrimmed(String s) {
        return s == null || s.trim().length() == 0;
    }

    /**
     * Return original string or empty string if original was null
     *
     * @param s string
     * @return not null string
     */
    public static String makeEmpty(String s) {
        if (s == null) {
            return "";
        }
        return s;
    }

    /**
     * Return trimmed original string or empty string if original was null
     *
     * @param s string
     * @return not null string
     */
    public static String makeEmptyTrimmed(String s) {
        if (s == null) {
            return "";
        }
        return s.trim();
    }

    public static String makeNull(String s) {
        if (s != null && s.length() == 0) {
            return null;
        }
        return s;
    }

    public static String makeNullTrimmed(String s) {
        if (s == null) {
            return null;
        }
        s = s.trim();
        if (s.length() == 0) {
            return null;
        }
        return s;
    }

}
