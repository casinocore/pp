package com.azoft.poker.common.socialnetwork.schoolmate;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Constants for schoolmate
 */
public class Constants extends com.azoft.poker.common.socialnetwork.Constants {

    /**
     * API version
     */
    public static final String API_VERSION = "1.0";

    /**
     * The application key associated with the calling application. If you specify the API key in your client, you
     * don't need to pass it with every call.
     */
    public static final String QUERY_APPLICATION_KEY = "application_key";

    /**
     * The request's sequence number.
     */
    public static final String QUERY_CALL_ID = "call_id";

    private static final String DATE_FORMAT = "yyyy-MM-dd";

    /**
     * Date format
     */
    public static final DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);

    /**
     * 'users.getInfo' method
     */
    public static final String METHOD_USERS_GET_INFO = "users.getInfo";

    /**
     * 'friends.get' method
     */
    public static final String METHOD_FRIENDS_GET = "friends.get";

    /**
     * 'auth.login' method
     */
    public static final String METHOD_AUTH_LOGIN = "auth.login";

    /**
     * 'notifications.sendSimple' method
     */
    public static final String METHOD_NOTIFICATIONS_SEND_SIMPLE = "notifications.sendSimple";

    /**
     * 'fields' parameter value
     */
    public static final String PARAMETER_VALUE_FIELDS = "uid,first_name,last_name,name,gender,birthday,location";

    /**
     * 'user_name' parameter name
     */
    public static final String PARAMETER_USER_NAME = "user_name";

    /**
     * 'password' parameter name
     */
    public static final String PARAMETER_PASSWORD = "password";

    /**
     * 'gen_token' parameter name
     */
    public static final String PARAMETER_GEN_TOKEN = "gen_token";

    /**
     * 'transaction_time' parameter name
     */
    public static final String PARAMETER_TRANSACTION_TIME = "transaction_time";

    /**
     * 'transaction_id' parameter name
     */
    public static final String PARAMETER_TRANSACTION_ID = "transaction_id";

    /**
     * 'product_code' parameter name
     */
    public static final String PARAMETER_PRODUCT_CODE = "product_code";

    /**
     * 'product_option' parameter name
     */
    public static final String PARAMETER_PRODUCT_OPTION = "product_option";

    /**
     * 'amount' parameter name
     */
    public static final String PARAMETER_AMOUNT = "amount";

    /**
     * 'text' parameter name
     */
    public static final String PARAMETER_TEXT = "text";

}
