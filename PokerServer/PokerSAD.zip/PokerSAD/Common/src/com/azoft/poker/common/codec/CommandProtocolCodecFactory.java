package com.azoft.poker.common.codec;

import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.filter.codec.demux.DemuxingProtocolCodecFactory;

/**
 * A {@link CommandProtocolCodecFactory} that provides a protocol codec for Command protocol.
 */
public class CommandProtocolCodecFactory extends DemuxingProtocolCodecFactory {

    public CommandProtocolCodecFactory(Class<? extends AbstractCommandDecoder> commandDecoder) {
        super.addMessageDecoder(commandDecoder);
        super.addMessageEncoder(Command.class, CommandEncoder.class);
    }
}