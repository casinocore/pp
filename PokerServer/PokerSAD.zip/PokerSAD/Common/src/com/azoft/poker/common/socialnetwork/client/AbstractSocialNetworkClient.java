package com.azoft.poker.common.socialnetwork.client;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.socialnetwork.helper.SignatureHelper;
import com.azoft.poker.common.socialnetwork.schoolmate.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * Abstract social network client
 */
public abstract class AbstractSocialNetworkClient extends AbstractXMLHttpClient implements SocialNetworkClient {

    private final static Logger LOGGER = LoggerFactory.getLogger(AbstractSocialNetworkClient.class);

    private static final String SOCIAL_NETWORK_ID_DELIMITER = ",";

    private String applicationKey;

    private String secretKey;

    private long callId;

    private boolean testMode;

    public AbstractSocialNetworkClient(SocialNetworkHandlerFactory handlerFactory) {
        super(handlerFactory);
    }

    public String getApplicationKey() {
        return applicationKey;
    }

    public long incCallId() {
        return ++callId;
    }

    public boolean isTestMode() {
        return testMode;
    }

    public void setTestMode(boolean testMode) {
        this.testMode = testMode;
    }

    public void initialization(Map<String, Object> parameters) throws CommonException {
        String apiUri = (String) parameters.get(PARAM_API_URI);
        String strMaxConnection = (String) parameters.get(PARAM_MAX_CONNECTION);
        Integer maxConnection = null;
        if (!StringHelper.isEmpty(strMaxConnection)) {
            try {
                maxConnection = Integer.valueOf(strMaxConnection);
            } catch (NumberFormatException e) {
                maxConnection = null;
            }
        }
        if (maxConnection == null || maxConnection < 1) {
            throw new CommonException("Not valid parameter " + PARAM_MAX_CONNECTION + " for connection.");
        }
        if (maxConnection == 1) {
            super.initialization(apiUri);
        } else {
            super.initialization(apiUri, maxConnection);
        }
        applicationKey = (String) parameters.get(PARAM_APPLICATION_KEY);
        secretKey = (String) parameters.get(PARAM_SECRET_KEY);
        if (parameters.containsKey(PARAM_TEST_MODE)) {
            testMode = Boolean.valueOf((String) parameters.get(PARAM_TEST_MODE));
        } else {
            testMode = false;
        }
        verifyParameters();
    }

    protected void verifyParameters() throws CommonException {
        super.verifyParameters();
        if (applicationKey == null || secretKey == null) {
            throw new CommonException("Parameters for social network connection was not set. " +
                    "Must be set '" + PARAM_APPLICATION_KEY + "', '" + PARAM_SECRET_KEY + "'.");
        }
    }

    protected void addSignature(Map<String, String> parameters) {
        SignatureHelper apiSignatureHelper = new SignatureHelper(secretKey);
        String signature = apiSignatureHelper.generateSignature(parameters);
        parameters.put(Constants.QUERY_SIG, signature);
    }

    protected String formSocialNetworkIDParameter(List<String> socialNetworkIDList, int maxNumberIds) {
        StringBuffer result = new StringBuffer("");
        if (!socialNetworkIDList.isEmpty()) {
            result.append(socialNetworkIDList.get(0));
            int socialNetworkIDListSize = socialNetworkIDList.size();
            if (maxNumberIds != 0 && socialNetworkIDListSize > maxNumberIds) {
                socialNetworkIDListSize = maxNumberIds;
                LOGGER.warn("The max number of IDs is " + maxNumberIds);
            }
            for (int i = 1; i < socialNetworkIDListSize; i++) {
                String id = socialNetworkIDList.get(i);
                if (!StringHelper.isEmptyTrimmed(id)) {
                    result.append(SOCIAL_NETWORK_ID_DELIMITER).append(socialNetworkIDList.get(i));
                }
            }
        }
        return result.toString();
    }

}
