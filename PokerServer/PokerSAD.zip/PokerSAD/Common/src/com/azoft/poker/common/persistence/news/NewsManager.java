package com.azoft.poker.common.persistence.news;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.persistence.person.Person;

import java.util.List;

/**
 * News manager interface
 */
public interface NewsManager<PersistenceType> {

    void save(PersistenceType persistenceObject);

    /**
     * Retrieve <code>NewsBean</code> (or only not read news) from the data store.
     *
     * @param personId    person Id
     * @param newsNumber  news number
     * @param onlyNotRead only not read
     * @return a <code>List</code> of <code>NewsBean</code>
     */
    List<NewsBean> getInfoNews(long personId, int newsNumber, boolean onlyNotRead);

    /**
     * Add news person link
     *
     * @param news   news
     * @param person person
     * @param isRead is read
     * @return news person link
     */
    NewsPersonLink addNewsPersonLink(News news, Person person, boolean isRead);

    /**
     * Mark news as read
     *
     * @param personId person Id
     * @param newsIds  news ids
     * @throws CommonException CommonException
     */
    void markNewsAsRead(long personId, List<Long> newsIds) throws CommonException;

}