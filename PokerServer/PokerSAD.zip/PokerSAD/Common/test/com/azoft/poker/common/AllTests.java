package com.azoft.poker.common;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        com.azoft.poker.common.bean.AllTests.class,
        com.azoft.poker.common.helper.AllTests.class,
        com.azoft.poker.common.commandprocessing.command.AllTests.class,
        com.azoft.poker.common.socialnetwork.facebook.AllTests.class,
        com.azoft.poker.common.socialnetwork.schoolmate.AllTests.class,
        com.azoft.poker.common.socialnetwork.vkontakte.AllTests.class,
        com.azoft.poker.common.persistence.AllTests.class,
        com.azoft.poker.common.socialnetwork.AllTests.class
})
public class AllTests {
}
