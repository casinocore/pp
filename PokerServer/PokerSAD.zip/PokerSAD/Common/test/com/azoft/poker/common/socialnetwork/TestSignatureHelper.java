package com.azoft.poker.common.socialnetwork;

import com.azoft.poker.common.socialnetwork.helper.SignatureHelper;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class TestSignatureHelper {

    @Test
    public void testGenerateSignature() {
        //sig = md5("api_id=4method=getFriendsv=3.0api_secret")
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("api_id", "4");
        parameters.put("method", "getFriends");
        parameters.put("v", "3.0");

        SignatureHelper signatureHelper = new SignatureHelper("api_secret");
        assertEquals("fbd3bc00725799ecd835bf661391ac34", signatureHelper.generateSignature(parameters));

        //api_id=2017128format=XMLmethod=secure.withdrawVotesrandom=1test_mode=1timestamp=1289808894932uid=41494592v=3.0votes=10********SECRET KEY*******
        //http://api.vkontakte.ru/api.php?api_id=2017128&format=XML&method=secure.withdrawVotes&random=1&test_mode=1&timestamp=1289808894932&uid=41494592&v=3.0&votes=10&sig=89e2ea45e8c4d62217de5424a3ba4c6a
        parameters.clear();
        parameters.put("api_id", "2017128");
        parameters.put("method", "secure.withdrawVotes");
        parameters.put("v", "3.0");
        parameters.put("format", "XML");
        parameters.put("random", "1");
        parameters.put("test_mode", "1");
        parameters.put("timestamp", "1289808894932");
        parameters.put("uid", "41494592");
        parameters.put("votes", "10");

        signatureHelper = new SignatureHelper("J25aUMdAkXwIWfv9xVDR");
        assertEquals("89e2ea45e8c4d62217de5424a3ba4c6a", signatureHelper.generateSignature(parameters));
    }

    @Test
    public void testSendNotificationMessage() {
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("message", "test message");

        SignatureHelper signatureHelper = new SignatureHelper("J25aUMdAkXwIWfv9xVDR");
        assertEquals("04ca89797c246225a67b8581651c6b6e", signatureHelper.generateSignature(parameters));

        parameters.clear();
        parameters.put("message", "я в игре");
        signatureHelper = new SignatureHelper("J25aUMdAkXwIWfv9xVDR");
        //assertEquals("a67e08d70eea739d620726f6fa940724", signatureHelper.generateSignature(parameters));
    }

    @Test
    public void testSendNotification() {
        //http://api.vkontakte.ru/api.php?api_id=2017128&format=XML&method=secure.sendNotification&random=1&timestamp=1290507914748&uids=41494592,736445&v=3.0&message=test message&sig=029d34dea6aa61c222f3c8a114cedf8f
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("api_id", "2017128");
        parameters.put("method", "secure.sendNotification");
        parameters.put("v", "3.0");
        parameters.put("format", "XML");
        parameters.put("random", "1");
        parameters.put("timestamp", "1290507914748");
        parameters.put("uids", "41494592,736445");
        parameters.put("message", "test message");

        SignatureHelper signatureHelper = new SignatureHelper("J25aUMdAkXwIWfv9xVDR");
        assertEquals("643cee9d42c54332801ce602b72bfd4b", signatureHelper.generateSignature(parameters));
    }

    @Test
    public void testPayment() {
        System.out.println("timestamp: " + System.currentTimeMillis());
        //http://api.vkontakte.ru/api.php?api_id=2044781&v=3.0&format=XML&method=secure.withdrawVotes&uid=41494592&votes=10&timestamp=1292241532263&sig=013ae29c98e44274ef111bf85201aefa
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("api_id", "2044781");
        parameters.put("v", "3.0");
        parameters.put("format", "XML");
        parameters.put("method", "secure.withdrawVotes");
        parameters.put("uid", "41494592");
        parameters.put("votes", "10");
        parameters.put("timestamp", "1292241532263");

        SignatureHelper signatureHelper = new SignatureHelper("AbDEwN8f4PhP5yOKVwfD");
        assertEquals("013ae29c98e44274ef111bf85201aefa", signatureHelper.generateSignature(parameters));
    }

    @Test
    public void testGetBalance() {
        System.out.println("timestamp: " + System.currentTimeMillis());
        //http://api.vkontakte.ru/api.php?api_id=2044781&v=3.0&format=XML&method=secure.getBalance&uid=41494592&timestamp=1292241532263&sig=5d56e694e3083c51a47b9fbb2c2087b8
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("api_id", "2044781");
        parameters.put("v", "3.0");
        parameters.put("format", "XML");
        parameters.put("method", "secure.getBalance");
        parameters.put("uid", "41494592");
        parameters.put("timestamp", "1292241532263");

        SignatureHelper signatureHelper = new SignatureHelper("AbDEwN8f4PhP5yOKVwfD");
        assertEquals("5d56e694e3083c51a47b9fbb2c2087b8", signatureHelper.generateSignature(parameters));
    }

/*
    @Test
    public void testFriendsGet() {
        System.out.println("timestamp: " + System.currentTimeMillis());
        //http://api.vkontakte.ru/api.php?api_id=2017128&v=3.0&format=XML&method=friends.get&uid=41494592&timestamp=1290582971382&sig=3a5ed0ff24aafd143702d22e32836464
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("api_id", "2017128");
        parameters.put("v", "3.0");
        parameters.put("format", "XML");
        parameters.put("method", "friends.get");
        parameters.put("uid", "41494592");
        parameters.put("timestamp", "1290582971382");

        SignatureHelper signatureHelper = new SignatureHelper("J25aUMdAkXwIWfv9xVDR");
        assertEquals("3a5ed0ff24aafd143702d22e32836464", signatureHelper.generateSignature(parameters));

        //http://api.vkontakte.ru/api.php?api_id=2017128&v=3.0&format=XML&method=friends.get&uid=736445&timestamp=1290583169521&sig=aa05f31716029039f601158021522901
        parameters = new HashMap<String, String>();
        parameters.put("api_id", "2017128");
        parameters.put("v", "3.0");
        parameters.put("format", "XML");
        parameters.put("method", "friends.get");
        parameters.put("uid", "736445");
        parameters.put("timestamp", "1290583169521");

        signatureHelper = new SignatureHelper("J25aUMdAkXwIWfv9xVDR");
        assertEquals("aa05f31716029039f601158021522901", signatureHelper.generateSignature(parameters));
    }
*/

}
