package com.azoft.poker.common.socialnetwork.facebook;

import org.junit.Test;

import static org.junit.Assert.*;

public class TestFBRequest {

    @Test
    public void testCreateFBRequest() {
        String json = "{algorithm: HMAC-SHA256, user_id: 56789}";
        FBRequest request = FBRequest.createFBRequest(json);
        System.out.println(request);
        assertEquals("HMAC-SHA256", request.getAlgorithm());
        assertEquals("56789", request.getUser_id());

        //request 'payments_get_items'
        json = "{algorithm: \"HMAC-SHA256\", user_id: \"63FGK47478566\", credits: {order_id: 27675, order_info: 'UID45678 TEST DATA'}}";
        request = FBRequest.createFBRequest(json);

        System.out.println(request);
        assertEquals("HMAC-SHA256", request.getAlgorithm());
        assertEquals("63FGK47478566", request.getUser_id());
        FBRequestBean bean = request.getCredits();
        assertNotNull(bean);
        assertEquals(27675L, bean.getOrder_id());
        assertEquals("UID45678 TEST DATA", bean.getOrder_info());
        assertNull(bean.getStatus());
        assertNull(bean.getTest_mode());

        //request 'payments_status_update'
        json = "{algorithm: 'HMAC-SHA256', user_id: 'KHOF977HR', credits: {order_id: 96837561, status: 'placed', test_mode: '1'}}";
        request = FBRequest.createFBRequest(json);

        System.out.println(request);
        assertEquals("HMAC-SHA256", request.getAlgorithm());
        assertEquals("KHOF977HR", request.getUser_id());
        bean = request.getCredits();
        assertNotNull(bean);
        assertEquals(96837561, bean.getOrder_id());
        assertEquals("placed", bean.getStatus());
        assertEquals("1", bean.getTest_mode());
        assertNull(bean.getOrder_info());
    }

    @Test
    public void testCreateFBRequest2() {
        String json = "{\"algorithm\":\"HMAC-SHA256\",\"credits\":{\"buyer\":100002297642397,\"receiver\":100002297642397,\"order_id\":9004908208985,\"order_info\":\"{\\\"product_url\\\":\\\"http:\\/\\/www.facebook.com\\/images\\/gifts\\/21.png\\\",\\\"desc\\\":\\\"10000 \\u0444\\u0438\\u0448\\u0435\\u043a\\\",\\\"price\\\":1000,\\\"img_url\\\":\\\"http:\\/\\/www.facebook.com\\/images\\/gifts\\/21.png\\\",\\\"title\\\":\\\"Buy chips\\\"}\"},\"expires\":1307437200,\"issued_at\":1307433539,\"oauth_token\":\"127692317309315|2.AQDlZWTiKTXf-E-Z.3600.1307437200.1-100002297642397|XIVXuHFLIY8wB0kLB0PmDdlN754\",\"user\":{\"country\":\"ru\",\"locale\":\"ru_RU\",\"age\":{\"min\":21}},\"user_id\":\"100002297642397\"";
        json += "}";
        FBRequest request = FBRequest.createFBRequest(json);

        System.out.println(request);
        assertEquals("HMAC-SHA256", request.getAlgorithm());
        assertEquals("100002297642397", request.getUser_id());
        FBRequestBean bean = request.getCredits();
        assertNotNull(bean);
        assertEquals(9004908208985L, bean.getOrder_id());
        assertEquals("{\"product_url\":\"http://www.facebook.com/images/gifts/21.png\",\"desc\":\"10000 фишек\",\"price\":1000,\"img_url\":\"http://www.facebook.com/images/gifts/21.png\",\"title\":\"Buy chips\"}",
                bean.getOrder_info());
        assertNull(bean.getStatus());
        assertNull(bean.getTest_mode());
        System.out.println(bean);
    }

    @Test
    public void testCreateFBRequest3() {
        String json = "{\"algorithm\":\"HMAC-SHA256\",\"credits\":{\"order_details\":\"{\\\"order_id\\\":217009128320049,\\\"buyer\\\":100002290462751,\\\"app\\\":127692317309315,\\\"receiver\\\":100002290462751,\\\"amount\\\":10,\\\"update_time\\\":1307508020,\\\"time_placed\\\":1307507997,\\\"data\\\":\\\"\\\",\\\"items\\\":[{\\\"item_id\\\":\\\"10\\\",\\\"title\\\":\\\"10000 \\\\u0444\\\\u0438\\\\u0448\\\\u0435\\\\u043a\\\",\\\"description\\\":\\\" \\\",\\\"image_url\\\":\\\"http:\\\\\\/\\\\\\/www.facebook.com\\\\\\/images\\\\\\/gifts\\\\\\/21.png\\\",\\\"product_url\\\":\\\"http:\\\\\\/\\\\\\/www.facebook.com\\\\\\/images\\\\\\/gifts\\\\\\/21.png\\\",\\\"price\\\":10,\\\"data\\\":\\\"\\\"}],\\\"status\\\":\\\"placed\\\"}\",\"status\":\"placed\",\"order_id\":217009128320049,\"test_mode\":1},\"expires\":1307512800,\"issued_at\":1307508020,\"oauth_token\":\"127692317309315|2.AQAFM0qiBDH3LdKd.3600.1307512800.1-100002290462751|rKJYN00czsco6dbqvusp5HUcNMI\",\"user\":{\"country\":\"ru\",\"locale\":\"ru_RU\",\"age\":{\"min\":21}},\"user_id\":\"10000229046275\"}";
        FBRequest request = FBRequest.createFBRequest(json);

        System.out.println("request: " + request);
        assertEquals("HMAC-SHA256", request.getAlgorithm());
        assertEquals("10000229046275", request.getUser_id());
        FBRequestBean bean = request.getCredits();
        System.out.println("bean: " + bean);
        assertNotNull(bean);
        assertEquals(217009128320049L, bean.getOrder_id());
        assertNull(bean.getOrder_info());
        assertEquals("placed", bean.getStatus());
        assertEquals("1", bean.getTest_mode());
        //assertEquals("{\\\"order_id\\\":217009128320049,\\\"buyer\\\":100002290462751,\\\"app\\\":127692317309315,\\\"receiver\\\":100002290462751,\\\"amount\\\":10,\\\"update_time\\\":1307508020,\\\"time_placed\\\":1307507997,\\\"data\\\":\\\"\\\",\\\"items\\\":[{\\\"item_id\\\":\\\"10\\\",\\\"title\\\":\\\"10000 \\\\u0444\\\\u0438\\\\u0448\\\\u0435\\\\u043a\\\",\\\"description\\\":\\\" \\\",\\\"image_url\\\":\\\"http:\\\\\\/\\\\\\/www.facebook.com\\\\\\/images\\\\\\/gifts\\\\\\/21.png\\\",\\\"product_url\\\":\\\"http:\\\\\\/\\\\\\/www.facebook.com\\\\\\/images\\\\\\/gifts\\\\\\/21.png\\\",\\\"price\\\":10,\\\"data\\\":\\\"\\\"}],\\\"status\\\":\\\"placed\\\"}", bean.getOrder_details());

        String orderDetails = bean.getOrder_details();
        FBOrderDetailsUpdate orderDetailsUpdate = FBOrderDetailsUpdate.createFBOrderDetailsUpdate(orderDetails);
        System.out.println("orderDetailsUpdate: " + orderDetailsUpdate);
        assertEquals(217009128320049L, orderDetailsUpdate.getOrder_id());
        assertEquals(10L, orderDetailsUpdate.getAmount());
        assertEquals(1307508020L, orderDetailsUpdate.getUpdate_time());
        assertEquals(1307507997L, orderDetailsUpdate.getTime_placed());

        FBOrderDetailsBean[] items = orderDetailsUpdate.getItems();
        assertNotNull(items);
        assertEquals(1, items.length);
        FBOrderDetailsBean data = items[0];
        System.out.println("data: " + data);
        assertEquals(10, data.getItem_id());
        assertEquals("10000 фишек", data.getTitle());
        assertEquals(" ", data.getDescription());
        assertEquals("http://www.facebook.com/images/gifts/21.png", data.getImage_url());
        assertEquals("http://www.facebook.com/images/gifts/21.png", data.getProduct_url());
        assertEquals(10, data.getPrice());
        assertEquals("", data.getData());

    }

}
