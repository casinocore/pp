package com.azoft.poker.common.persistence.personcache;

import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.tournament.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class TestPersonCacheManagerImpl {

    private final static PersonCacheManager cacheManager = PersonCacheManagerImpl.getInstance();
    private final static PersonManager personManager = PersonManagerImpl.getInstance();
    private final static TournamentManager tournamentManager = TournamentManagerImpl.getInstance();
    private static final int COUNT = 5;

    @Before
    public void beforeTests() {
        clear();
    }

    @After
    public void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_PERSON_STATUS);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_TOURNAMENT);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_PERSON);
    }

    private static Person createPerson(long i) {
        Person newPerson = new Person();
        newPerson.setUsername("username" + i);
        newPerson.setSocialNetworkID("SocialNetworkID" + i);
        newPerson.setFirstName("FirstName" + i);
        newPerson.setLastName("LastName" + i);
        newPerson.setBalance(10000);
        return newPerson;
    }

    private void createTournaments() {
        Tournament tournament = tournamentManager.createTournament(TournamentTypeID.SIT_AND_GO_TOURNAMENT);
        tournamentManager.changeTournamentStatus(tournament, TournamentStatusID.ACTIVE);
        tournament = tournamentManager.createTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        tournamentManager.changeTournamentStatus(tournament, TournamentStatusID.ACTIVE);
    }

    @Test
    public void testMoveBalance_ByRecord() throws Exception {
        testGetTotalBalanceSum(0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, 0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, 0);
        testStorePerson();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, 0);
        testMoveBalanceToGameBalance();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        testMoveGameBalanceToBalance_ByRecord();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, COUNT - 1);
    }

    @Test
    public void testMoveBalance_Batch() throws Exception {
        createTournaments();
        testGetTotalBalanceSum(0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, 0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, 0);
        testStorePerson();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, 0);
        testMoveBalanceToGameBalance();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        testMoveGameBalanceToBalance_Batch();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, COUNT - 1);
        testAddPersonCacheForTournament();
        testGetTotalBalance(10000 - TournamentManagerImpl.DEFAULT_TOURNAMENT_FEE);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, COUNT * 2 - 1);
    }

    @Test
    public void testPersonCacheManager_addBalanceAndZeroGameBalance() throws Exception {
        testGetTotalBalanceSum(0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, 0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, 0);
        testStorePerson();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, 0);
        testMoveBalanceToGameBalance();
        testGetTotalBalanceSum(10000 * COUNT);
        testGetTotalBalance(10000);
        testAddBalanceAndZeroGameBalance();
        testGetTotalBalanceSum(10000 * COUNT + 100);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON_CACHE, COUNT - 1);
    }

    public void testStorePerson() throws Exception {
        for (long i = 0; i < COUNT; i++) {
            Person person = createPerson(i);
            Date date = DateHelper.attributeDateTimeFormat.parse("2010-05-21 01:54:" + i);
            person.setRegistrationDate(date);
            personManager.storePerson(person);
        }
    }

    public void testGetTotalBalanceSum(long testTotalBalanceSum) {
        Long totalBalanceSum = cacheManager.getTotalBalanceSum();
        assertEquals(testTotalBalanceSum, totalBalanceSum.intValue());
    }

    public void testGetTotalBalance(long testTotalBalance) {
        List<Person> persons = personManager.getPersons();
        for (Person person : persons) {
            Long totalBalance = cacheManager.getTotalBalance(person);
            assertEquals(testTotalBalance, totalBalance.intValue());
        }
    }

    public void testMoveBalanceToGameBalance() {
        List<Person> persons = personManager.getPersons();
        PersonCache personCache;

        for (int i = 0; i < COUNT - 1; i++) {
            cacheManager.moveBalanceToGameBalance(persons.get(i), null, 1000L);
            personCache = cacheManager.getPersonCache(persons.get(i).getId(), null);
            assertNotNull(personCache);
            assertEquals(persons.get(i).getId(), personCache.getPersonId());
            assertEquals(1000, personCache.getGameBalance().longValue());
        }


        for (int i = 0; i < COUNT - 1; i++) {
            cacheManager.moveBalanceToGameBalance(persons.get(i), null, 100L);
            personCache = cacheManager.getPersonCache(persons.get(i).getId(), null);
            assertNotNull(personCache);
            assertEquals(persons.get(i).getId(), personCache.getPersonId());
            assertEquals(1100, personCache.getGameBalance().longValue());
        }

        for (int i = 0; i < COUNT - 1; i++) {
            cacheManager.moveBalanceToGameBalance(persons.get(i), null, (long) i);
            personCache = cacheManager.getPersonCache(persons.get(i).getId(), null);
            assertNotNull(personCache);
            assertEquals(persons.get(i).getId(), personCache.getPersonId());
            assertEquals(1100 + i, personCache.getGameBalance().longValue());
        }
    }

    private void testMoveGameBalanceToBalance_ByRecord() {
        List<Person> persons = personManager.getPersons();
        PersonCache personCache;
        for (int i = 0; i < COUNT - 1; i++) {
            cacheManager.moveGameBalanceToBalance(persons.get(i), null);
            personCache = cacheManager.getPersonCache(persons.get(i).getId(), null);
            assertNotNull(personCache);
            assertEquals(persons.get(i).getId(), personCache.getPersonId());
            assertEquals(0, personCache.getGameBalance().longValue());
        }
        cacheManager.moveGameBalanceToBalance(persons.get(COUNT - 1), null);
        personCache = cacheManager.getPersonCache(persons.get(COUNT - 1).getId(), null);
        assertNull(personCache);

        persons = personManager.getPersons();
        for (int i = 0; i < COUNT - 1; i++) {
            assertEquals(10000, persons.get(0).getBalance());
        }
    }

    private void testMoveGameBalanceToBalance_Batch() {
        List<Person> persons = personManager.getPersons();
        cacheManager.moveGameBalanceToBalance();
        PersonCache personCache;
        for (int i = 0; i < COUNT - 1; i++) {
            personCache = cacheManager.getPersonCache(persons.get(i).getId(), null);
            assertNotNull(personCache);
            assertEquals(persons.get(i).getId(), personCache.getPersonId());
            assertEquals(0, personCache.getGameBalance().longValue());
        }
        cacheManager.moveGameBalanceToBalance(persons.get(COUNT - 1), null);
        personCache = cacheManager.getPersonCache(persons.get(COUNT - 1).getId(), null);
        assertNull(personCache);

        persons = personManager.getPersons();
        for (int i = 0; i < COUNT - 1; i++) {
            assertEquals(10000, persons.get(i).getBalance());
        }
    }

    private void testAddBalanceAndZeroGameBalance() {
        List<Person> persons = personManager.getPersons();
        PersonCache personCache;
        for (int i = 0; i < COUNT - 1; i++) {
            cacheManager.addBalanceAndZeroGameBalance(persons.get(i), null, 1100L + i);
            personCache = cacheManager.getPersonCache(persons.get(i).getId(), null);
            assertNotNull(personCache);
            assertEquals(persons.get(i).getId(), personCache.getPersonId());
            assertEquals(0, personCache.getGameBalance().longValue());
        }
        cacheManager.addBalanceAndZeroGameBalance(persons.get(COUNT - 1), null, 100L);
        personCache = cacheManager.getPersonCache(persons.get(COUNT - 1).getId(), null);
        assertNull(personCache);

        persons = personManager.getPersons();
        for (int i = 0; i < COUNT - 1; i++) {
            assertEquals(10000, persons.get(i).getBalance());
        }
    }

    private void testAddPersonCacheForTournament() {
        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);
        List<Person> persons = personManager.getPersons();
        for (Person person : persons) {
            tournamentManager.addPlayerToTournament(tournament.getId(), person, true);
        }

        for (Person person : persons) {
            cacheManager.moveBalanceToGameBalance(person, tournament.getId(), 123L);
        }
        testGetTotalBalanceSum(10000 * COUNT - TournamentManagerImpl.DEFAULT_TOURNAMENT_FEE * COUNT);
    }

}