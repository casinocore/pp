package com.azoft.poker.common.socialnetwork.facebook;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestFBOrderDetailsBean {

    private FBOrderDetailsBean createBean() {
        FBOrderDetailsBean bean = new FBOrderDetailsBean();
        //System.out.println(bean.toJSON());
        bean.setItem_id(12345);
        bean.setTitle("[Test Mode] Unicorn");
        bean.setDescription("[Test Mode] Own your own mythical beast!");
        bean.setPrice(2);
        bean.setImage_url("http://www.facebook.com/images/gifts/21.png");
        bean.setProduct_url("http://www.facebook.com/images/gifts/56.png");
        return bean;
    }

    @Test
    public void testToJSON() {
        FBOrderDetailsBean response = createBean();
        //convert java object to JSON format
        String json = response.toJson();
        System.out.println(json);
        assertEquals("{\"item_id\":12345,\"title\":\"[Test Mode] Unicorn\",\"description\":\"[Test Mode] Own your own mythical beast!\",\"image_url\":\"http://www.facebook.com/images/gifts/21.png\",\"product_url\":\"http://www.facebook.com/images/gifts/56.png\",\"price\":2}", json);
    }

    @Test
    public void testCreateFBOrderDetailsBean() {
        String json = "{\"item_id\":12345,\"title\":\"[Test Mode] Unicorn\",\"description\":\"[Test Mode] Own your own mythical beast!\",\"image_url\":\"http://www.facebook.com/images/gifts/21.png\",\"product_url\":\"http://www.facebook.com/images/gifts/56.png\",\"price\":2}";
        FBOrderDetailsBean data = FBOrderDetailsBean.createFBOrderDetailsBean(json);
        System.out.println(data);
        assertEquals(12345, data.getItem_id());
        assertEquals("[Test Mode] Unicorn", data.getTitle());
        assertEquals("[Test Mode] Own your own mythical beast!", data.getDescription());
        assertEquals("http://www.facebook.com/images/gifts/21.png", data.getImage_url());
        assertEquals("http://www.facebook.com/images/gifts/56.png", data.getProduct_url());
        assertEquals(2, data.getPrice());
        assertEquals(null, data.getData());
    }

}