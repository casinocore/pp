package com.azoft.poker.common.bean;

import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TestSynchronousHand {

    @Test
    public void testSynchronousHandComparator() throws IOException {
        List<SynchronousHand> synchronousHands = new ArrayList<SynchronousHand>();
        synchronousHands.add(new SynchronousHand(32L, 29L));
        synchronousHands.add(new SynchronousHand(11L, 10L));
        synchronousHands.add(new SynchronousHand(41L, 40L));
        synchronousHands.add(new SynchronousHand(21L, 20L));

        Collections.sort(synchronousHands);

        assertEquals(41, synchronousHands.get(0).getStartNumber().longValue());
        assertEquals(32, synchronousHands.get(1).getStartNumber().longValue());
        assertEquals(21, synchronousHands.get(2).getStartNumber().longValue());
        assertEquals(11, synchronousHands.get(3).getStartNumber().longValue());

        Collections.sort(synchronousHands);


    }

}
