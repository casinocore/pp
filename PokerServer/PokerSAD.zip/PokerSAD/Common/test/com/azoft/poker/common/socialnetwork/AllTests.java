package com.azoft.poker.common.socialnetwork;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestSignatureHelper.class
})
public class AllTests {
}