package com.azoft.poker.common.persistence.quantityinfoentity;

import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestQuantityInfoEntityManagerImpl {

    private final static QuantityInfoEntityManager<QuantityInfoEntity> manager = QuantityInfoEntityManagerImpl.getInstance();

    @Test
    public void testPaymentManager() throws Exception {
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_QUANTITY_INFO_ENTITY, 2);
        testGetQuantityInfoEntity();
    }

    public void testGetQuantityInfoEntity() throws Exception {
        QuantityInfoEntity entity = manager.getQuantityInfoEntity(QuantityInfoEntityManager.QUANTITY_INFO_ENTITY_ID_RECORD);
        assertNotNull(entity);
        assertEquals(0, entity.getQuantityOfNewRegistrations().intValue());
        assertEquals(0, entity.getQuantityOfActivePlayers().intValue());
        assertEquals(0, entity.getQuantityOfPaymentPlayers().intValue());
        assertEquals(0, entity.getQuantityOfOnlinePlayers().intValue());

        entity.setQuantityOfNewRegistrations(11);
        entity.setQuantityOfActivePlayers(22);
        entity.setQuantityOfPaymentPlayers(33);
        entity.setQuantityOfOnlinePlayers(44);
        manager.update(entity);
        entity = manager.getQuantityInfoEntity(QuantityInfoEntityManager.QUANTITY_INFO_ENTITY_ID_RECORD);
        assertEquals(11, entity.getQuantityOfNewRegistrations().intValue());
        assertEquals(22, entity.getQuantityOfActivePlayers().intValue());
        assertEquals(33, entity.getQuantityOfPaymentPlayers().intValue());
        assertEquals(44, entity.getQuantityOfOnlinePlayers().intValue());

        entity.setQuantityOfNewRegistrations(0);
        entity.setQuantityOfActivePlayers(0);
        entity.setQuantityOfPaymentPlayers(0);
        entity.setQuantityOfOnlinePlayers(0);
        manager.update(entity);
        entity = manager.getQuantityInfoEntity(QuantityInfoEntityManager.QUANTITY_INFO_ENTITY_ID_RECORD);
        assertEquals(0, entity.getQuantityOfNewRegistrations().intValue());
        assertEquals(0, entity.getQuantityOfActivePlayers().intValue());
        assertEquals(0, entity.getQuantityOfPaymentPlayers().intValue());
        assertEquals(0, entity.getQuantityOfOnlinePlayers().intValue());
    }

}