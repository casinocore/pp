package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.socialnetwork.bean.SocialNetworkMoneyBean;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestSocialNetworkMoneyHandler {

    @Test
    public void testWithdrawVotesHandler_151_InvalidVotes() {
        SocialNetworkMoneyHandler handler =
                new SocialNetworkMoneyHandler(SocialNetworkMoneyHandler.ELEMENT_NAME_TRANSFERRED);

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/vkontakte/error_response_502.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SocialNetworkMoneyBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 1", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(1, errorMessages.size());
        assertEquals("Not enough votes on user's balance", errorMessages.get(502L));
    }

    @Test
    public void testWithdrawVotesHandler() {
        SocialNetworkMoneyHandler handler =
                new SocialNetworkMoneyHandler(SocialNetworkMoneyHandler.ELEMENT_NAME_TRANSFERRED);

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/vkontakte/secure.withdrawVotes_response_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SocialNetworkMoneyBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        assertEquals(350, bean.getSocialNetworkMoney().longValue());
    }

}
