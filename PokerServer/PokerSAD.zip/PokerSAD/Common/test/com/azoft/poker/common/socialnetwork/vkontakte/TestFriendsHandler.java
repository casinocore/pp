package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.socialnetwork.bean.FriendsBean;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestFriendsHandler {

    @Test
    public void testFriendsHandler() {
        FriendsHandler handler = new FriendsHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/vkontakte/friends.get_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        FriendsBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        List<String> friends = bean.getFriends();
        assertEquals(3, friends.size());
        assertEquals("1", friends.get(0));
        assertEquals("6492", friends.get(1));
        assertEquals("35828305", friends.get(2));
    }

}