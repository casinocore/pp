package com.azoft.poker.common.persistence.news;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import com.azoft.poker.common.persistence.CustomAttributesWrapper;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TestNewsManagerImpl {

    private final static int COUNT = 5;
    private static final int PERSON_COUNT = 5;

    private final static NewsManager<News> newsManager = NewsManagerImpl.getInstance();
    private final static PersonManager personManager = PersonManagerImpl.getInstance();
    private List<Person> persons;

    @Before
    public void beforeTests() {
        clear();
        createPersons();
        persons = personManager.getPersons();
    }

    @After
    public void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_NEWS_PERSON_LINK);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_PERSON);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_NEWS);
    }

    private static Person createPerson(long i) {
        Person newPerson = new Person();
        newPerson.setUsername("username" + i);
        newPerson.setSocialNetworkID("SocialNetworkID" + i);
        newPerson.setFirstName("FirstName" + i);
        newPerson.setLastName("LastName" + i);
        return newPerson;
    }

    private News createNews(long i) throws ParseException {
        News news = new News();
        Date date = CustomAttributesWrapper.attributeDateTimeFormat.parse("2010-09-20 14:25:" + i);
        news.setTimeStamp(date);
        news.setPreview(String.valueOf(i));
        news.setBody("Body  " + i +
                " :1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890");
        return news;
    }

    @Test
    public void testNewsManager() throws Exception {
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_NEWS_PERSON_LINK, 0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_NEWS, 0);
        testSave();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_NEWS_PERSON_LINK, COUNT * 3);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_NEWS, COUNT * 4);
        testGetNews();
        testMarkNewsAsRead();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_NEWS_PERSON_LINK, COUNT * 4);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_NEWS, COUNT * 4);
    }

    public void testSave() throws Exception {
        long count = 0;
        for (int i = 0; i < COUNT; i++) {
            News news = createNews(count++);
            newsManager.save(news);
        }
        for (int i = 0; i < COUNT; i++) {
            News news = createNews(count++);
            news.setPrivateAccess(false);
            newsManager.save(news);
            newsManager.addNewsPersonLink(news, persons.get(i), true);
        }
        for (int i = 0; i < COUNT; i++) {
            News news = createNews(count++);
            news.setPrivateAccess(true);
            newsManager.save(news);
            newsManager.addNewsPersonLink(news, persons.get(i), false);
        }
        for (int i = 0; i < COUNT; i++) {
            News news = createNews(count++);
            news.setPrivateAccess(true);
            newsManager.save(news);
            newsManager.addNewsPersonLink(news, persons.get(i), true);
        }
    }

    private void createPersons() {
        for (int i = 0; i < PERSON_COUNT; i++) {
            Person person = createPerson(i);
            personManager.storePerson(person);
        }
    }

    public void testGetNews() {
        List<NewsBean> news = newsManager.getInfoNews(persons.get(0).getId(), 20, false);
        assertEquals(12, news.size());
        assertEquals("15", news.get(0).getNews().getPreview());
        assertEquals(true, news.get(0).getNews().isPrivateAccess());
        assertEquals(1, news.get(0).getRead());
        assertEquals("10", news.get(1).getNews().getPreview());
        assertEquals(true, news.get(1).getNews().isPrivateAccess());
        assertEquals(0, news.get(1).getRead());
        for (int i = 0, newsSize = 10; i < newsSize; i++) {
            NewsBean newsBean = news.get(i + 2);
            assertEquals("i=" + i, String.valueOf(COUNT * 2 - 1 - i), newsBean.getNews().getPreview());
            assertEquals(false, newsBean.getNews().isPrivateAccess());
            if (i < COUNT) {
                assertEquals("i=" + i, 1, newsBean.getRead());
            } else {
                assertEquals("i=" + i, 0, newsBean.getRead());
            }
        }

        news = newsManager.getInfoNews(persons.get(0).getId(), 7, false);
        assertEquals(7, news.size());
        assertEquals("15", news.get(0).getNews().getPreview());
        assertEquals(true, news.get(0).getNews().isPrivateAccess());
        assertEquals(1, news.get(0).getRead());
        assertEquals("10", news.get(1).getNews().getPreview());
        assertEquals(true, news.get(1).getNews().isPrivateAccess());
        assertEquals(0, news.get(1).getRead());
        for (int i = 0, newsSize = 2; i < newsSize; i++) {
            NewsBean newsBean = news.get(i + 2);
            assertEquals("i=" + i, String.valueOf(COUNT * 2 - 1 - i), newsBean.getNews().getPreview());
            assertEquals(false, newsBean.getNews().isPrivateAccess());
            if (i < COUNT) {
                assertEquals("i=" + i, 1, newsBean.getRead());
            } else {
                assertEquals("i=" + i, 0, newsBean.getRead());
            }
        }

        news = newsManager.getInfoNews(persons.get(0).getId(), 20, true);
        assertEquals(6, news.size());
        assertEquals("10", news.get(0).getNews().getPreview());
        assertEquals(true, news.get(0).getNews().isPrivateAccess());
        assertEquals(0, news.get(1).getRead());
        for (int i = 0, newsSize = 5; i < newsSize; i++) {
            NewsBean newsBean = news.get(i + 1);
            assertEquals("i=" + i, String.valueOf(COUNT - 1 - i), newsBean.getNews().getPreview());
            assertEquals(false, newsBean.getNews().isPrivateAccess());
            assertEquals("i=" + i, 0, newsBean.getRead());
        }

        news = newsManager.getInfoNews(persons.get(0).getId(), 4, true);
        assertEquals(4, news.size());
        assertEquals("10", news.get(0).getNews().getPreview());
        assertEquals(true, news.get(0).getNews().isPrivateAccess());
        assertEquals(0, news.get(1).getRead());
        for (int i = 0, newsSize = 3; i < newsSize; i++) {
            NewsBean newsBean = news.get(i + 1);
            assertEquals("i=" + i, String.valueOf(COUNT - 1 - i), newsBean.getNews().getPreview());
            assertEquals(false, newsBean.getNews().isPrivateAccess());
            assertEquals("i=" + i, 0, newsBean.getRead());
        }
    }

    public void testMarkNewsAsRead() throws CommonException {
        List<NewsBean> news = newsManager.getInfoNews(persons.get(0).getId(), 20, true);
        assertEquals(6, news.size());

        //test 1 - empty newsIds
        List<Long> newsIds = new ArrayList<Long>();
        newsManager.markNewsAsRead(persons.get(0).getId(), newsIds);
        news = newsManager.getInfoNews(persons.get(0).getId(), 20, true);
        assertEquals(6, news.size());

        //test 2
        for (int i = 0, newsSize = 4; i < newsSize; i++) {
            NewsBean newsBean = news.get(i);
            newsIds.add(newsBean.getNews().getId());
        }
        newsManager.markNewsAsRead(persons.get(0).getId(), newsIds);
        news = newsManager.getInfoNews(persons.get(0).getId(), 20, true);
        assertEquals(2, news.size());
        assertEquals("1", news.get(0).getNews().getPreview());
        assertEquals(false, news.get(0).getNews().isPrivateAccess());
        assertEquals(0, news.get(1).getRead());
        assertEquals("0", news.get(1).getNews().getPreview());
        assertEquals(false, news.get(1).getNews().isPrivateAccess());
        assertEquals(0, news.get(1).getRead());

        //test 3 - all marked
        for (int i = 0, newsSize = news.size(); i < newsSize; i++) {
            NewsBean newsBean = news.get(i);
            newsIds.add(newsBean.getNews().getId());
        }
        newsManager.markNewsAsRead(persons.get(0).getId(), newsIds);
        news = newsManager.getInfoNews(persons.get(0).getId(), 20, true);
        assertEquals(0, news.size());
    }

}