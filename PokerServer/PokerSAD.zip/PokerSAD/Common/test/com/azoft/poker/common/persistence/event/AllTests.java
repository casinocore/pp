package com.azoft.poker.common.persistence.event;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestEventEntityManagerImpl.class
})
public class AllTests {
}
