package com.azoft.poker.common.socialnetwork.facebook;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestFBOrderDetails {

    private FBOrderDetailsBean createBean() {
        FBOrderDetailsBean bean = new FBOrderDetailsBean();
        //System.out.println(bean.toJSON());
        bean.setItem_id(12345);
        bean.setTitle("[Test Mode] Unicorn");
        bean.setDescription("[Test Mode] Own your own mythical beast!");
        bean.setPrice(2);
        bean.setImage_url("http://www.facebook.com/images/gifts/21.png");
        bean.setProduct_url("http://www.facebook.com/images/gifts/56.png");
        return bean;
    }

    @Test
    public void testToJSON() {
        FBOrderDetailsBean b = createBean();
        FBOrderDetails response = new FBOrderDetails();
        response.getContent()[0] = b;
        //convert java object to JSON format
        String json = response.toJson();
        System.out.println(json);
        assertEquals("{\"content\":[{\"item_id\":12345,\"title\":\"[Test Mode] Unicorn\",\"description\":\"[Test Mode] Own your own mythical beast!\",\"image_url\":\"http://www.facebook.com/images/gifts/21.png\",\"product_url\":\"http://www.facebook.com/images/gifts/56.png\",\"price\":2}],\"method\":\"payments_get_items\"}", json);
    }

    @Test
    public void testCreateFBOrderDetails() {
        String json = "{\"content\":[{\"item_id\":12345,\"title\":\"[Test Mode] Unicorn\",\"description\":\"[Test Mode] Own your own mythical beast!\",\"image_url\":\"http://www.facebook.com/images/gifts/21.png\",\"product_url\":\"http://www.facebook.com/images/gifts/56.png\",\"price\":2}],\"method\":\"payments_get_items\"}";
        FBOrderDetails data = FBOrderDetails.createFBOrderDetails(json);
        System.out.println(data);
        assertEquals("payments_get_items", data.getMethod());
        assertEquals(12345, data.getContent()[0].getItem_id());
        assertEquals("[Test Mode] Unicorn", data.getContent()[0].getTitle());
        assertEquals("[Test Mode] Own your own mythical beast!", data.getContent()[0].getDescription());
        assertEquals("http://www.facebook.com/images/gifts/21.png", data.getContent()[0].getImage_url());
        assertEquals("http://www.facebook.com/images/gifts/56.png", data.getContent()[0].getProduct_url());
        assertEquals(2, data.getContent()[0].getPrice());
        assertEquals(null, data.getContent()[0].getData());
    }

}
