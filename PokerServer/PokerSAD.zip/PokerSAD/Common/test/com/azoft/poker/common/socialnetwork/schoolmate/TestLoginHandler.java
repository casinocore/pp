package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.socialnetwork.bean.LoginBean;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestLoginHandler {

    @Test
    public void testLoginHandler_101_NoApplicationKey() {
        LoginHandler handler = new LoginHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/schoolmate/error_response_101.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        LoginBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 1", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(1, errorMessages.size());
        assertEquals("PARAM_API_KEY : No application key", errorMessages.get(101L));
    }

    @Test
    public void testLoginHandler() {
        LoginHandler handler = new LoginHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/schoolmate/auth.login_response_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        LoginBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        assertEquals("AAA", bean.getIud());
        assertEquals("IGLKNJOKNQJSLTECIGFEEHHLJHGMIGJHGHIKJIGDIGFDEBHET", bean.getSessionKey());
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", bean.getSessionSecretKey());
        assertEquals("7123132_wqerwer", bean.getAuthToken());
        assertEquals("http://195.218.169.227:8088/", bean.getApiServer());
    }

}