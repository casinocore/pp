package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestMTTTournamentWrapper {

    private final static TournamentManager tournamentManager = TournamentManagerImpl.getInstance();

    @Before
    public void beforeTests() {
        clear();
    }

    @After
    public void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_CA);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_TOURNAMENT);
    }

    private void createTournaments() {
        Tournament tournament = tournamentManager.createTournament(TournamentTypeID.MTT_TOURNAMENT);
    }

    @Test
    public void testMTTTournamentWrapper() throws Exception {
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT, 0);
        createTournaments();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT, 1);
        testMTTTournament();
    }

    public void testMTTTournament() {
        List<Tournament> tournamentList = tournamentManager.getTournaments(TournamentTypeID.MTT_TOURNAMENT, TournamentStatusID.PLANNED);
        assertEquals(1, tournamentList.size());
        Tournament tournament = tournamentList.get(0);
        assertNotNull(tournament);
        tournament.addAttribute(MTTTournamentWrapper.mttSynchronousHandStart_PREFIX + "1", "11");
        tournament.addAttribute(MTTTournamentWrapper.mttSynchronousHandFinished_PREFIX + "1", "10");
        tournament.addAttribute(MTTTournamentWrapper.mttSynchronousHandStart_PREFIX + "2", "20");
        tournament.addAttribute(MTTTournamentWrapper.mttSynchronousHandFinished_PREFIX + "2", "20");
        tournamentManager.updateTournament(tournament);
        assertEquals(4, tournament.getAttributes().size());

        short counter = 1;
        MTTTournamentWrapper mttTW = TournamentFactoryImpl.createMTTTournamentWrapper(tournament);
        assertEquals(11L, mttTW.getSynchronousHandStart(counter).longValue());
        assertEquals(10L, mttTW.getSynchronousHandFinished(counter).longValue());
        assertEquals(1, mttTW.getSynchronousHands().size());
        assertEquals(11L, mttTW.getSynchronousHands().get(0).getStartNumber().longValue());
        assertEquals(10L, mttTW.getSynchronousHands().get(0).getFinishedNumber().longValue());
    }

}
