package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.jaxp.AbstractBean;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestBaseSocialNetworkHandler {

    class BaseSocialNetworkHandlerImpl extends BaseSocialNetworkHandler<SocialNetworkBeanImpl> {

        BaseSocialNetworkHandlerImpl() {
            super();
        }

    }

    class SocialNetworkBeanImpl extends AbstractBean {

        SocialNetworkBeanImpl() {
        }

    }

    @Test
    public void testBaseSocialNetworkHandler_101_NoApplicationKey() {
        BaseSocialNetworkHandler<SocialNetworkBeanImpl> handler = new BaseSocialNetworkHandlerImpl();
        handler.setBean(new SocialNetworkBeanImpl());

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/schoolmate/error_response_101.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SocialNetworkBeanImpl bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 1", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(1, errorMessages.size());
        assertEquals("PARAM_API_KEY : No application key", errorMessages.get(101L));
    }

}
