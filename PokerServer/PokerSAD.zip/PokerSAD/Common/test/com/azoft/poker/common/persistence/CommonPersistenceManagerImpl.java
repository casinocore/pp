package com.azoft.poker.common.persistence;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigInteger;

import static org.junit.Assert.assertEquals;

/**
 * Common persistence manager
 */
public class CommonPersistenceManagerImpl {

    private final static Logger LOGGER = LoggerFactory.getLogger(CommonPersistenceManagerImpl.class);

    public static final String TABLE_PERSON = "person";
    public static final String TABLE_FRIEND_LINK = "friend_link";
    public static final String TABLE_PERSON_CACHE = "person_cache";
    public static final String TABLE_PAYMENT = "payment";
    public static final String TABLE_PRODUCT = "product";
    public static final String TABLE_EVENT_ENTITY = "event_entity";
    public static final String TABLE_EVENT_ENTITY_CA = "event_entity_ca";
    public static final String TABLE_QUANTITY_INFO_ENTITY = "quantity_info_entity";
    public static final String TABLE_CONFIGURATION_ATTRIBUTE = "configuration_attribute";
    public static final String TABLE_TOURNAMENT = "tournament";
    public static final String TABLE_TOURNAMENT_CA = "tournament_ca";
    public static final String TABLE_TOURNAMENT_PERSON_STATUS = "tournament_person_status";
    public static final String TABLE_NEWS = "news";
    public static final String TABLE_NEWS_PERSON_LINK = "news_person_link";

    private static final String QUERY_DELETE_PREFIX = "delete from ";
    private static final String QUERY_COUNT_PREFIX = "select count(*) from ";

    private static CommonPersistenceManagerImpl instance = null;

    public static synchronized CommonPersistenceManagerImpl getInstance() {
        if (instance == null) {
            instance = new CommonPersistenceManagerImpl();
        }
        return instance;
    }

    private CommonPersistenceManagerImpl() {
        super();
    }


    protected Session getSession() {
        return HibernateUtil.getSessionFactory().getCurrentSession();
    }

    /**
     * Clear table
     *
     * @param tableName table name
     */
    public void clearTable(String tableName) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        session.createSQLQuery(QUERY_DELETE_PREFIX + tableName).executeUpdate();
        transaction.commit();
    }

    /**
     * Store object
     *
     * @param persistenceObject persistence object
     */
    public void store(Object persistenceObject) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.merge(persistenceObject);
        transaction.commit();
    }

    /**
     * Delete object
     *
     * @param persistenceObject persistence object
     */
    public void delete(Object persistenceObject) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.delete(persistenceObject);
        transaction.commit();
    }

    /**
     * Get count
     *
     * @param tableName table name
     * @return count
     */
    public BigInteger getCount(String tableName) {
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        transaction.begin();
        BigInteger count = (BigInteger) session.createSQLQuery(QUERY_COUNT_PREFIX + tableName).uniqueResult();
        transaction.commit();
        return count;
    }

    /**
     * Test 'get count'
     *
     * @param tableName table name
     * @param testCount test count
     */
    public static void testGetCount(String tableName, int testCount) {
        BigInteger count = CommonPersistenceManagerImpl.getInstance().getCount(tableName);
        assertEquals(testCount, count.intValue());
    }

}
