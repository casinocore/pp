package com.azoft.poker.common.persistence.personcache;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestPersonCacheManagerImpl.class
})
public class AllTests {
}