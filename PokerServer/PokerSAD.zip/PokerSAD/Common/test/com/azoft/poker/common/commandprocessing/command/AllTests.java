package com.azoft.poker.common.commandprocessing.command;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestCommand.class,
        TestRequestCommand.class
})
public class AllTests {
}
