package com.azoft.poker.common.persistence.event;

import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import com.azoft.poker.common.persistence.CustomAttributesWrapper;
import com.azoft.poker.common.publisher.Event;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TestEventEntityManagerImpl {

    private final static EventEntityManager<EventEntity, Event> manager = EventEntityManagerImpl.getInstance();

    @BeforeClass
    public static void beforeTests() {
        clear();
        manager.initialization(null);
    }

    @AfterClass
    public static void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_EVENT_ENTITY_CA);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_EVENT_ENTITY);
    }

    private EventEntity createEvent(long i) throws ParseException {
        EventEntity event = new EventEntity(EventTypeID.TEST_EVENT.getTypeId(), i);
        Date date = CustomAttributesWrapper.attributeDateTimeFormat.parse("2010-05-20 14:25:" + i);
        event.setTimeStamp(date);
        event.addAttribute("TEST_NAME" + i, "test_value" + i);
        return event;
    }

    @Test
    public void testEventEntityManager() throws Exception {
        testBatchStore();
        testGetEventEntitiesForPeriod_String();
        testEventEntitiesForPeriod_String();
        testEventEntities();
        testEventEntitiesByReferenceMaxForPeriod();
        testGetCountEventsForPeriod();
        testSumEventsValuesForPeriod();
        testSumUserEventsValues();
        testMaxUserEventsValues();
    }

    public void testBatchStore() throws Exception {
        int batchMax = 5;
        manager.setBatchMax(batchMax);
        for (long i = 0; i < batchMax; i++) {
            EventEntity event = createEvent(i);
            manager.batchStore(event);
            event = createEvent(2L);
            Date date = CustomAttributesWrapper.attributeDateTimeFormat.parse("2010-05-25 10:45:" + i);
            event.setTimeStamp(date);
            event.addAttribute("NUMBER_NAME", String.valueOf(i));
            manager.batchStore(event);
        }
        EventEntity event = createEvent(2L);
        Date date = CustomAttributesWrapper.attributeDateTimeFormat.parse("2010-08-15 05:12:23");
        event.setTimeStamp(date);
        event.addAttribute("NUMBER_NAME", "440");
        manager.batchStore(event);
        for (long i = 0; i < batchMax; i++) {
            event = new EventEntity(EventTypeID.TEST_EVENT.getTypeId(), i + 100);
            date = CustomAttributesWrapper.attributeDateTimeFormat.parse("2010-05-21 01:54:" + i);
            event.setTimeStamp(date);
            event.addAttribute("TEST_NAME_100_" + i, "test_value_100_" + i);
            event.addAttribute("NUMBER_NAME", String.valueOf(i + 0.11 * i));
            manager.batchStore(event);
        }
    }

    public void testGetEventEntitiesForPeriod_String() {
        List<EventEntity> events = manager.getEventEntitiesForPeriod("2010-05-18", "2010-05-19");
        assertEquals(0, events.size());

        events = manager.getEventEntitiesForPeriod("2010-05-20", "2010-05-20");
        assertEquals(5, events.size());
        for (int i = 0; i < events.size(); i++) {
            EventEntity event = events.get(i);
            assertEquals(999, event.getEventType().intValue());
            assertEquals("i = " + i, i, event.getReferenceId().intValue());
            assertEquals("i = " + i, 1, event.getAttributes().size());
            assertEquals("i = " + i, "test_value" + i, event.getAttributeValue("TEST_NAME" + i));
        }

        events = manager.getEventEntitiesForPeriod("2010-05-21", "2010-05-21");
        assertEquals(5, events.size());

        events = manager.getEventEntitiesForPeriod("2010-05-20", "2010-05-21");
        assertEquals(10, events.size());
    }

    public void testEventEntitiesForPeriod_String() {
        List<EventEntity> events = manager.getUserEventEntitiesForPeriod("2010-05-18", "2010-05-19", 2L);
        assertEquals(0, events.size());

        events = manager.getUserEventEntitiesForPeriod("2010-05-20", "2010-05-21", 1000L);
        assertEquals(0, events.size());

        events = manager.getUserEventEntitiesForPeriod("2010-05-20", "2010-05-21", 2L);
        assertEquals(1, events.size());
        EventEntity event = events.get(0);
        assertEquals(999, event.getEventType().intValue());
        assertEquals(2, event.getReferenceId().intValue());
        assertEquals(1, event.getAttributes().size());
        assertEquals("test_value2", event.getAttributeValue("TEST_NAME2"));
    }

    public void testEventEntities() {
        List<EventEntity> events = manager.getUserEventEntities(1L);
        assertEquals(1, events.size());

        events = manager.getUserEventEntities(2L);
        assertEquals(7, events.size());

        events = manager.getUserEventEntities(1000L);
        assertEquals(0, events.size());
    }

    public void testEventEntitiesByReferenceMaxForPeriod() throws Exception {
        Date fromDate = DateHelper.attributeDateFormat.parse("2010-05-20");
        Date toDate = DateHelper.attributeDateFormat.parse("2010-05-22");
        List<EventEntity> events = manager.getEventEntitiesByReferenceMaxForPeriod(EventTypeID.TEST_EVENT, fromDate, toDate);
        assertEquals(1, events.size());

        EventEntity event = events.get(0);
        assertEquals(999, event.getEventType().intValue());
        assertEquals(104, event.getReferenceId().intValue());
        assertEquals(0, event.getAttributes().size());
    }

    public void testGetCountEventsForPeriod() throws Exception {
        Date fromDate = DateHelper.attributeDateFormat.parse("2010-05-20");
        Date toDate = DateHelper.attributeDateFormat.parse("2010-05-22");
        Integer count = manager.getCountEventsForPeriod(EventTypeID.TEST_EVENT, fromDate, toDate);
        assertEquals(10, count.intValue());
    }

    public void testSumEventsValuesForPeriod() throws Exception {
        Date fromDate = DateHelper.attributeDateFormat.parse("2010-05-25");
        Date toDate = DateHelper.attributeDateFormat.parse("2010-05-27");
        Double count = manager.getSumEventsValuesForPeriod(EventTypeID.TEST_EVENT, fromDate, toDate, "NUMBER_NAME");
        assertEquals(10, count.intValue());

        fromDate = DateHelper.attributeDateFormat.parse("2010-05-21");
        toDate = DateHelper.attributeDateFormat.parse("2010-05-22");
        count = manager.getSumEventsValuesForPeriod(EventTypeID.TEST_EVENT, fromDate, toDate, "NUMBER_NAME");
        assertEquals(11.1, count, 0.0001);
    }

    public void testSumUserEventsValues() throws Exception {
        Double count = manager.getSumUserEventsValues(2L, EventTypeID.TEST_EVENT, "FHUGFD_NAME");
        assertEquals(0, count.intValue());

        count = manager.getSumUserEventsValues(2L, EventTypeID.TEST_EVENT, "NUMBER_NAME");
        assertEquals(450, count.intValue());
    }

    public void testMaxUserEventsValues() throws Exception {
        BigDecimal count = manager.getMaxUserEventsValues(2L, EventTypeID.TEST_EVENT, "FHUGFD_NAME");
        assertEquals(0, count.intValue());

        count = manager.getMaxUserEventsValues(2L, EventTypeID.TEST_EVENT, "NUMBER_NAME");
        assertEquals(440, count.intValue());
    }

}
