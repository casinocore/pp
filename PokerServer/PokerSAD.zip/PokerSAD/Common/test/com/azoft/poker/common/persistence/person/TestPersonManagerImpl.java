package com.azoft.poker.common.persistence.person;

import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class TestPersonManagerImpl {

    private final static PersonManager manager = PersonManagerImpl.getInstance();
    private final static CommonPersistenceManagerImpl commonManager = CommonPersistenceManagerImpl.getInstance();

    @Before
    public void beforeTests() {
        clear();
    }

    @After
    public void afterTests() {
        clear();
    }

    private static void clear() {
        commonManager.clearTable(CommonPersistenceManagerImpl.TABLE_FRIEND_LINK);
        commonManager.clearTable(CommonPersistenceManagerImpl.TABLE_PERSON);
    }

    private static Person createPerson(long i) {
        Person newPerson = new Person();
        newPerson.setUsername("username" + i);
        newPerson.setSocialNetworkID("SocialNetworkID" + i);
        newPerson.setFirstName("FirstName" + i);
        newPerson.setLastName("LastName" + i);
        return newPerson;
    }

    @Test
    public void testPersonManager() throws Exception {
        testGetCountPersons(0);
        testStorePerson();
        testGetCountPersons(10);
        testGetNewPersonsForPeriod_String();
        testGetCountNewPersonsForPeriod_String();
        testGetPersonBySNID();
    }

    public void testStorePerson() throws Exception {
        int batchMax = 5;
        manager.setBatchMax(batchMax);
        for (int i = 0; i < batchMax; i++) {
            Person person = createPerson(i);
            Date date = DateHelper.attributeDateTimeFormat.parse("2010-05-20 14:25:" + i);
            person.setRegistrationDate(date);
            manager.storePerson(person);
        }
        List<Person> parents = manager.getPersons();
        assertEquals(batchMax, parents.size());
        for (int i = 0; i < batchMax; i++) {
            Person person = createPerson(i + batchMax);
            Date date = DateHelper.attributeDateTimeFormat.parse("2010-05-21 01:54:" + i);
            person.setRegistrationDate(date);
            person.setExistsParentBonus(true);
            if (i == 1 || i == 2) {
                person.setParent(parents.get(1));
            } else if (i == 3 || i == 4) {
                person.setParent(parents.get(2));
            } else {
                person.setParent(parents.get(0));
            }
            manager.storePerson(person);
        }
    }

    public void testGetCountPersons(int testCount) {
        Integer count = manager.getCountPersons();
        assertEquals(testCount, count.intValue());
    }

    public void testGetNewPersonsForPeriod_String() {
        List<Person> persons = manager.getNewPersonsForPeriod("2010-05-18", "2010-05-19");
        assertEquals(0, persons.size());

        persons = manager.getNewPersonsForPeriod("2010-05-20", "2010-05-20");
        assertEquals(5, persons.size());
        for (int i = 0; i < persons.size(); i++) {
            Person person = persons.get(i);
            assertEquals("i = " + i, "username" + i, person.getUsername());
            assertEquals("i = " + i, "SocialNetworkID" + i, person.getSocialNetworkID());
            assertEquals("i = " + i, "FirstName" + i, person.getFirstName());
            assertEquals("i = " + i, "LastName" + i, person.getLastName());
            if (i < 5) {
                assertEquals("i = " + i, false, person.isExistsParentBonus());
            } else {
                assertEquals("i = " + i, true, person.isExistsParentBonus());
            }
        }

        persons = manager.getNewPersonsForPeriod("2010-05-20", "2010-05-21");
        assertEquals(10, persons.size());

        for (int i = 0; i < 5; i++) {
            Person parent = persons.get(i + 5).getParent();
            assertNotNull(parent);
            if (i == 1 || i == 2) {
                assertEquals(persons.get(1), parent);
            } else if (i == 3 || i == 4) {
                assertEquals(persons.get(2), parent);
            } else {
                assertEquals(persons.get(0), parent);
            }
        }
    }

    public void testGetCountNewPersonsForPeriod_String() {
        Integer count = manager.getCountNewPersonsForPeriod("2010-05-18", "2010-05-19");
        assertEquals(0, count.intValue());

        count = manager.getCountNewPersonsForPeriod("2010-05-20", "2010-05-20");
        assertEquals(5, count.intValue());

        count = manager.getCountNewPersonsForPeriod("2010-05-21", "2010-05-21");
        assertEquals(5, count.intValue());

        count = manager.getCountNewPersonsForPeriod("2010-05-20", "2010-05-21");
        assertEquals(10, count.intValue());
    }

    public void testGetPersonBySNID() {
        Person person = manager.getPersonBySNID("SocialNetworkID0");
        assertNotNull(person);
        assertEquals("SocialNetworkID0", person.getSocialNetworkID());

        person = manager.getPersonBySNID("SocialNetworkID4");
        assertNotNull(person);
        assertEquals("SocialNetworkID4", person.getSocialNetworkID());

        person = manager.getPersonBySNID("SocialNetworkID446856");
        assertNull(person);
    }

    @Test
    public void testFriendManager() throws Exception {
        testGetCountPersons(0);
        testStorePerson();
        testGetCountPersons(10);
        testFriend();
    }

    public void testGetCountFriends(int testCount) {
        BigInteger count = commonManager.getCount(CommonPersistenceManagerImpl.TABLE_FRIEND_LINK);
        assertEquals(testCount, count.intValue());
    }

    public void testFriend() throws Exception {
        testGetCountFriends(0);
        List<Person> persons = manager.getPersons();

        //Add test
        manager.addFriend(persons.get(0).getId(), persons.get(1).getId());

        manager.addFriend(persons.get(2).getId(), persons.get(3).getId());
        manager.addFriend(persons.get(2).getId(), persons.get(4).getId());
        manager.addFriend(persons.get(2).getId(), persons.get(5).getId());

        manager.addFriend(persons.get(3).getId(), persons.get(4).getId());
        manager.addFriend(persons.get(3).getId(), persons.get(1).getId());

        manager.addFriend(persons.get(5).getId(), persons.get(2).getId());
        testGetCountFriends(7);

        //Get test
        List<Person> friends = manager.getFriends(persons.get(0).getId());
        assertEquals(1, friends.size());
        assertEquals(persons.get(1), friends.get(0));

        friends = manager.getFriends(persons.get(1).getId());
        assertEquals(0, friends.size());

        friends = manager.getFriends(persons.get(2).getId());
        assertEquals(3, friends.size());
        assertEquals(persons.get(3), friends.get(0));
        assertEquals(persons.get(4), friends.get(1));
        assertEquals(persons.get(5), friends.get(2));

        friends = manager.getFriends(persons.get(3).getId());
        assertEquals(2, friends.size());
        assertEquals(persons.get(1), friends.get(0));
        assertEquals(persons.get(4), friends.get(1));

        friends = manager.getFriends(persons.get(5).getId());
        assertEquals(1, friends.size());
        assertEquals(persons.get(2), friends.get(0));

        friends = manager.getFriends(persons.get(9).getId());
        assertEquals(0, friends.size());

        //Delete test
        manager.deleteFriend(persons.get(0).getId(), persons.get(1).getId());
        friends = manager.getFriends(persons.get(0).getId());
        assertEquals(0, friends.size());

        manager.deleteFriend(persons.get(2).getId(), persons.get(3).getId());
        friends = manager.getFriends(persons.get(2).getId());
        assertEquals(2, friends.size());
        assertEquals(persons.get(4), friends.get(0));
        assertEquals(persons.get(5), friends.get(1));
        manager.deleteFriend(persons.get(2).getId(), persons.get(4).getId());
        manager.deleteFriend(persons.get(2).getId(), persons.get(5).getId());
        friends = manager.getFriends(persons.get(2).getId());
        assertEquals(0, friends.size());

        manager.deleteFriend(persons.get(3).getId(), persons.get(4).getId());
        friends = manager.getFriends(persons.get(3).getId());
        assertEquals(1, friends.size());
        assertEquals(persons.get(1), friends.get(0));
        manager.deleteFriend(persons.get(3).getId(), persons.get(1).getId());
        friends = manager.getFriends(persons.get(3).getId());
        assertEquals(0, friends.size());

        manager.deleteFriend(persons.get(5).getId(), persons.get(2).getId());
        testGetCountFriends(0);
        manager.deleteFriend(persons.get(5).getId(), persons.get(2).getId());
        testGetCountFriends(0);
    }

    @Test
    public void testFriendManager_Exceptions() throws Exception {
        testGetCountPersons(0);
        testStorePerson();
        testGetCountPersons(10);
        testFriend_Exceptions();
    }

    public void testFriend_Exceptions() throws Exception {
        testGetCountFriends(0);
        List<Person> persons = manager.getPersons();

        //Add exception test
        String exceptionMessage = null;
        try {
            manager.addFriend(persons.get(2).getId(), 875445);
        } catch (CommonException e) {
            exceptionMessage = e.getMessage();
        }
        assertNotNull(exceptionMessage);
        assertEquals("Not exists friend with personId: 875445", exceptionMessage);

        exceptionMessage = null;
        try {
            manager.addFriend(54346456, 9675986);
        } catch (CommonException e) {
            exceptionMessage = e.getMessage();
        }
        assertNotNull(exceptionMessage);
        assertEquals("Not exists personId: 54346456", exceptionMessage);
        testGetCountFriends(0);

        //Delete exception test
        exceptionMessage = null;
        try {
            manager.deleteFriend(persons.get(2).getId(), 754768);
        } catch (CommonException e) {
            exceptionMessage = e.getMessage();
        }
        assertNotNull(exceptionMessage);
        assertEquals("Not exists friend with personId: 754768", exceptionMessage);

        exceptionMessage = null;
        try {
            manager.deleteFriend(7567885, 54763);
        } catch (CommonException e) {
            exceptionMessage = e.getMessage();
        }
        assertNotNull(exceptionMessage);
        assertEquals("Not exists personId: 7567885", exceptionMessage);
    }

    @Test
    public void testTopInvitedFriends() throws Exception {
        testGetCountPersons(0);
        testStorePerson();
        testGetCountPersons(10);
        testGetTopInvitedFriends();
    }

    public void testGetTopInvitedFriends() {
        List<InvitedFriendsBean> beans = manager.getTopInvitedFriends(10);
        assertEquals(3, beans.size());

        List<Person> persons = manager.getPersons();
        assertTrue(beans.get(0).getPlayerId().equals(persons.get(1).getId()) || beans.get(0).getPlayerId().equals(persons.get(2).getId()));
        assertTrue(beans.get(1).getPlayerId().equals(persons.get(1).getId()) || beans.get(1).getPlayerId().equals(persons.get(2).getId()));
        assertTrue(beans.get(2).getPlayerId().equals(persons.get(0).getId()));

        assertEquals(1, beans.get(0).getRanked().intValue());
        assertEquals(2, beans.get(0).getInvitedFriendsCount().intValue());
        assertEquals(1, beans.get(1).getRanked().intValue());
        assertEquals(2, beans.get(1).getInvitedFriendsCount().intValue());
        assertEquals(3, beans.get(2).getRanked().intValue());
        assertEquals(1, beans.get(2).getInvitedFriendsCount().intValue());

        assertEquals(1, manager.getRankByInvitedFriends(2).intValue());
        assertEquals(3, manager.getRankByInvitedFriends(1).intValue());
        assertEquals(4, manager.getRankByInvitedFriends(0).intValue());

        assertEquals(1, manager.getCountInvitedFriends(persons.get(0).getId()).intValue());
        assertEquals(2, manager.getCountInvitedFriends(persons.get(1).getId()).intValue());
        assertEquals(2, manager.getCountInvitedFriends(persons.get(2).getId()).intValue());
        assertEquals(0, manager.getCountInvitedFriends(persons.get(3).getId()).intValue());
        assertEquals(0, manager.getCountInvitedFriends(persons.get(4).getId()).intValue());
        assertEquals(0, manager.getCountInvitedFriends(persons.get(5).getId()).intValue());
    }

    @Test
    public void testNewInvitedFriends() throws Exception {
        testGetCountPersons(0);
        testStorePerson();
        testGetCountPersons(10);
        testNewInvitedFriend_Get_Delete();
    }

    public void testNewInvitedFriend_Get_Delete() {
        List<Person> persons = manager.getPersons();

        assertEquals(1, manager.getCountNewInvitedFriends(persons.get(0).getId()).intValue());
        assertEquals(2, manager.getCountNewInvitedFriends(persons.get(1).getId()).intValue());
        assertEquals(2, manager.getCountNewInvitedFriends(persons.get(2).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(3).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(4).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(5).getId()).intValue());

        assertEquals(1, manager.setNotExistsNewInvitedFriends(persons.get(0).getId()));
        assertEquals(2, manager.setNotExistsNewInvitedFriends(persons.get(1).getId()));
        assertEquals(2, manager.setNotExistsNewInvitedFriends(persons.get(2).getId()));
        assertEquals(0, manager.setNotExistsNewInvitedFriends(persons.get(3).getId()));
        assertEquals(0, manager.setNotExistsNewInvitedFriends(persons.get(4).getId()));
        assertEquals(0, manager.setNotExistsNewInvitedFriends(persons.get(5).getId()));

        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(0).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(1).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(2).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(3).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(4).getId()).intValue());
        assertEquals(0, manager.getCountNewInvitedFriends(persons.get(5).getId()).intValue());
    }

}
