package com.azoft.poker.common.persistence.product;

import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class TestProductManagerImpl {

    private final static int COUNT = 10;

    private final static ProductManager<Product> manager = ProductManagerImpl.getInstance();

    @BeforeClass
    public static void beforeTests() {
        clear();
    }

    @AfterClass
    public static void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_PRODUCT);
    }

    private static Product createProduct(long i) throws Exception {
        Product newProduct = new Product();
        newProduct.setProductCode("ProductCode" + i);
        newProduct.setProductDescriptor("ProductDescriptor" + i);
        newProduct.setAmount(i + 1);
        newProduct.setBalance(newProduct.getAmount() * 10);
        return newProduct;
    }

    @Test
    public void testProductManager() throws Exception {
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PRODUCT, 0);
        testStoreProduct();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PRODUCT, COUNT);
        testGetProducts();
        testGetProduct();
    }

    public void testStoreProduct() throws Exception {
        for (long i = 0; i < COUNT; i++) {
            Product product = createProduct(i);
            manager.save(product);
        }
    }

    public void testGetProducts() {
        List<Product> products = manager.getProducts();
        assertEquals(10, products.size());
        assertEquals(1, products.get(0).getAmount().longValue());
        assertEquals(6, products.get(5).getAmount().longValue());
        assertEquals(10, products.get(9).getAmount().longValue());
    }

    public void testGetProduct() {
        Product product = manager.getProduct("ProductCode0");
        assertNotNull(product);
        assertEquals(1, product.getAmount().longValue());

        product = manager.getProduct("ProductCode9");
        assertNotNull(product);
        assertEquals(10, product.getAmount().longValue());

        product = manager.getProduct("ProductCode957567");
        assertNull(product);
    }

}