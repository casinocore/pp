package com.azoft.poker.common.persistence.quantityinfoentity;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestQuantityInfoEntityManagerImpl.class
})
public class AllTests {
}