package com.azoft.poker.common.persistence.tournament;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestTournamentManagerImpl.class,
        TestMTTTournamentWrapper.class
})
public class AllTests {

}