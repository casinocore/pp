package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.socialnetwork.bean.UserInfoBean;
import com.azoft.poker.common.socialnetwork.bean.UsersInfoBean;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import static org.junit.Assert.*;

public class TestUsersInfoHandler {

    @Test
    public void testUsersInfoHandler_101_NoApplicationKey() {
        UsersInfoHandler handler = new UsersInfoHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/schoolmate/error_response_101.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        UsersInfoBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 1", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(1, errorMessages.size());
        assertEquals("PARAM_API_KEY : No application key", errorMessages.get(101L));
    }

    @Test
    public void testUsersInfoHandler() {
        UsersInfoHandler handler = new UsersInfoHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/schoolmate/users.getInfo_response_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        UsersInfoBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        Map<String, UserInfoBean> userInfoBeanMap = bean.getUsersInfo();
        assertEquals(3, userInfoBeanMap.size());

        Date date = null;
        try {
            date = Constants.dateFormat.parse("1983-11-26");
        } catch (ParseException e) {
            //empty
        }

        UserInfoBean userInfoBean = userInfoBeanMap.get("AAA");
        assertEquals("AAA", userInfoBean.getSocialNetworkID());
        assertEquals("First name 1", userInfoBean.getFirstName());
        assertEquals("Last name 1", userInfoBean.getLastName());
        assertEquals("Name 1", userInfoBean.getName());
        assertEquals("male", userInfoBean.getSex());
        assertEquals(date, userInfoBean.getDateOfBirth());
        assertEquals("latvia, Riga", userInfoBean.getLocation());

        userInfoBean = userInfoBeanMap.get("BBB");
        assertEquals("BBB", userInfoBean.getSocialNetworkID());
        assertEquals("First name 2", userInfoBean.getFirstName());
        assertEquals("Last name 2", userInfoBean.getLastName());
        assertNull(userInfoBean.getName());
        assertNull(userInfoBean.getSex());
        assertNull(userInfoBean.getDateOfBirth());
        assertEquals("Russia", userInfoBean.getLocation());

        try {
            date = Constants.dateFormat.parse("2001-02-15");
        } catch (ParseException e) {
            //empty
        }
        userInfoBean = userInfoBeanMap.get("CCC");
        assertEquals("CCC", userInfoBean.getSocialNetworkID());
        assertEquals("First name 3", userInfoBean.getFirstName());
        assertEquals("Last name 3", userInfoBean.getLastName());
        assertEquals("Name 3", userInfoBean.getName());
        assertEquals("female", userInfoBean.getSex());
        assertEquals(date, userInfoBean.getDateOfBirth());
        assertEquals("Russia, Novosibirsk", userInfoBean.getLocation());
    }

}
