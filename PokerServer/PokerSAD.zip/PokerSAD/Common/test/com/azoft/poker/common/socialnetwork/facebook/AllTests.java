package com.azoft.poker.common.socialnetwork.facebook;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestFBRequest.class,
        TestFBOrderDetails.class,
        TestFBOrderDetailsBean.class
})
public class AllTests {
}