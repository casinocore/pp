package com.azoft.poker.common.bean;

import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TestBlind {

    @Test
    public void testBlindComparator() throws IOException {
        List<Blind> blinds = new ArrayList<Blind>();
        blinds.add(new Blind(20, 40));
        blinds.add(new Blind(5, 10));
        blinds.add(new Blind(100, 200));
        blinds.add(new Blind(10, 20));

        Collections.sort(blinds);
        assertEquals(200, blinds.get(0).getBigBlind().longValue());
        assertEquals(40, blinds.get(1).getBigBlind().longValue());
        assertEquals(20, blinds.get(2).getBigBlind().longValue());
        assertEquals(10, blinds.get(3).getBigBlind().longValue());

        Collections.sort(blinds, new AscBlindComparator());
        assertEquals(10, blinds.get(0).getBigBlind().longValue());
        assertEquals(20, blinds.get(1).getBigBlind().longValue());
        assertEquals(40, blinds.get(2).getBigBlind().longValue());
        assertEquals(200, blinds.get(3).getBigBlind().longValue());
    }

}
