package com.azoft.poker.common.socialnetwork.schoolmate;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestBaseSocialNetworkHandler.class,
        TestUsersInfoHandler.class,
        TestFriendsHandler.class,
        TestLoginHandler.class,
        TestSendNotificationHandler.class
})
public class AllTests {
}
