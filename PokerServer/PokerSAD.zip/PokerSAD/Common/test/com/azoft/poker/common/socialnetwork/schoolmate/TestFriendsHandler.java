package com.azoft.poker.common.socialnetwork.schoolmate;

import com.azoft.poker.common.socialnetwork.bean.FriendsBean;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestFriendsHandler {

    @Test
    public void testFriendsHandler_101_NoApplicationKey() {
        FriendsHandler handler = new FriendsHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/schoolmate/error_response_101.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        FriendsBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 1", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(1, errorMessages.size());
        assertEquals("PARAM_API_KEY : No application key", errorMessages.get(101L));
    }

    @Test
    public void testFriendsHandler() {
        FriendsHandler handler = new FriendsHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/schoolmate/friends.get_response_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        FriendsBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        List<String> friends = bean.getFriends();
        assertEquals(3, friends.size());
        assertEquals("AAA", friends.get(0));
        assertEquals("BBB", friends.get(1));
        assertEquals("CCC", friends.get(2));
    }

}