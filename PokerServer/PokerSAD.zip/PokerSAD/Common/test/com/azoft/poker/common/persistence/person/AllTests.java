package com.azoft.poker.common.persistence.person;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestPersonManagerImpl.class
})
public class AllTests {
}
