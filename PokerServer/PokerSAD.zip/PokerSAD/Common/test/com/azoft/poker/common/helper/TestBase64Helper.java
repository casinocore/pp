package com.azoft.poker.common.helper;

import com.azoft.poker.common.socialnetwork.facebook.CallbacksPaymentServiceImpl;
import org.apache.commons.codec.binary.Base64;
import org.junit.Test;
import sun.misc.BASE64Decoder;

import java.io.UnsupportedEncodingException;

import static org.junit.Assert.assertEquals;

public class TestBase64Helper {

    @Test
    public void testBase64EncodeAndDecode() throws Exception {
        String input = "Hello world";
        String data = Base64Helper.encode(input);
        assertEquals("SGVsbG8gd29ybGQ=", data);

        input = "SGVsbG8gd29ybGQ=";
        data = Base64Helper.decode(input);
        assertEquals("Hello world", data);

        input = "Auto - moto";
        data = Base64Helper.encode(input);
        assertEquals("QXV0byAtIG1vdG8=", data);

        input = "QXV0byAtIG1vdG8=";
        data = Base64Helper.decode(input);
        assertEquals("Auto - moto", data);

        input = "{algorithm: \"HMAC-SHA256\", user_id: 6347478566, credits: {order_id: 27675, order_info: 'UID45678 TEST DATA'}}";
        data = Base64Helper.encode(input);
        assertEquals("e2FsZ29yaXRobTogIkhNQUMtU0hBMjU2IiwgdXNlcl9pZDogNjM0NzQ3ODU2NiwgY3JlZGl0czoge29yZGVyX2lkOiAyNzY3" +
                "\nNSwgb3JkZXJfaW5mbzogJ1VJRDQ1Njc4IFRFU1QgREFUQSd9fQ==", data);

        input = "e2FsZ29yaXRobTogIkhNQUMtU0hBMjU2IiwgdXNlcl9pZDogNjM0NzQ3ODU2NiwgY3JlZGl0czoge29yZGVyX2lkOiAyNzY3NSwgb3JkZXJfaW5mbzogJ1VJRDQ1Njc4IFRFU1QgREFUQSd9fQ==";
        data = Base64Helper.decode(input);
        assertEquals("{algorithm: \"HMAC-SHA256\", user_id: 6347478566, credits: {order_id: 27675, order_info: 'UID45678 TEST DATA'}}", data);
    }

    @Test
    public void testBase64Decode_JSON() throws Exception {
        String input = "eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsIjAiOiJwYXlsb2FkIn0";
        String data = Base64Helper.decode(input);
        //System.out.println("Base64Decode JSON: " + data);
        assertEquals("{\"algorithm\":\"HMAC-SHA256\",\"0\":\"payload\"}", data);
    }

    @Test
    public void testCheckSig() throws Exception {
        String secret = "151335f7dbe44baa1a8f000726b6ed3a";
        String encodedSig = "gBDU2iXWYQ6_uBDo3IBLGsxrakzKl5kNssk3jlszRSs";
        String data = "eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNyZWRpdHMiOnsib3JkZXJfZGV0YWlscyI6IntcIm9yZGVyX2lkXCI6MTAzOTU2MDgzMDMwMDYzLFwiYnV5ZXJcIjoxMDAwMDIyOTc2NDIzOTcsXCJhcHBcIjoxMjc2OTIzMTczMDkzMTUsXCJyZWNlaXZlclwiOjEwMDAwMjI5NzY0MjM5NyxcImFtb3VudFwiOjUsXCJ1cGRhdGVfdGltZVwiOjEzMDc2NzgwOTIsXCJ0aW1lX3BsYWNlZFwiOjEzMDc2NzgwODksXCJkYXRhXCI6XCJcIixcIml0ZW1zXCI6W3tcIml0ZW1faWRcIjpcIjVcIixcInRpdGxlXCI6XCI1MDAwMCBcXHUwNDQ0XFx1MDQzOFxcdTA0NDhcXHUwNDM1XFx1MDQzYVwiLFwiZGVzY3JpcHRpb25cIjpcIiBcIixcImltYWdlX3VybFwiOlwiaHR0cDpcXFwvXFxcL3d3dy5mYWNlYm9vay5jb21cXFwvaW1hZ2VzXFxcL2dpZnRzXFxcLzIxLnBuZ1wiLFwicHJvZHVjdF91cmxcIjpcImh0dHA6XFxcL1xcXC93d3cuZmFjZWJvb2suY29tXFxcL2ltYWdlc1xcXC9naWZ0c1xcXC8yMS5wbmdcIixcInByaWNlXCI6NSxcImRhdGFcIjpcIlwifV0sXCJzdGF0dXNcIjpcInNldHRsZWRcIn0iLCJzdGF0dXMiOiJzZXR0bGVkIiwib3JkZXJfaWQiOjEwMzk1NjA4MzAzMDA2MywidGVzdF9tb2RlIjoxfSwiZXhwaXJlcyI6MTMwNzY4MjAwMCwiaXNzdWVkX2F0IjoxMzA3Njc4MDkyLCJvYXV0aF90b2tlbiI6IjEyNzY5MjMxNzMwOTMxNXwyLkFRQWlyY0h0bDh2MUlQVUMuMzYwMC4xMzA3NjgyMDAwLjEtMTAwMDAyMjk3NjQyMzk3fGVrZjc2a1JKRGFqWXJBYlh4MWY5MkVqYTZjMCIsInVzZXIiOnsiY291bnRyeSI6InJ1IiwibG9jYWxlIjoicnVfUlUiLCJhZ2UiOnsibWluIjoyMX19LCJ1c2VyX2lkIjoiMTAwMDAyMjk3NjQyMzk3In0";
        checkSig("Test 1 - ", secret, encodedSig, data);

        encodedSig = "g81c6fHlm3XYIU1Bn3u11LhbLw4a7mIX7Y0ARP2e42U";
        data = "eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNyZWRpdHMiOnsiYnV5ZXIiOjEwMDAwMjI5NzY0MjM5NywicmVjZWl2ZXIiOjEwMDAwMjI5NzY0MjM5Nywib3JkZXJfaWQiOjIyMDgyNjIxNDYwODMwMCwib3JkZXJfaW5mbyI6IntcInByb2R1Y3RfdXJsXCI6XCJodHRwOlwvXC93d3cuZmFjZWJvb2suY29tXC9pbWFnZXNcL2dpZnRzXC8yMS5wbmdcIixcImltYWdlX3VybFwiOlwiaHR0cDpcL1wvd3d3LmZhY2Vib29rLmNvbVwvaW1hZ2VzXC9naWZ0c1wvMjEucG5nXCIsXCJ0aXRsZVwiOlwiMjAwMDAgXHUwNDQ0XHUwNDM4XHUwNDQ4XHUwNDM1XHUwNDNhXCIsXCJkZXNjcmlwdGlvblwiOlwiIFwiLFwicHJpY2VcIjoyLFwiaXRlbV9pZFwiOlwiMlwifSIsInRlc3RfbW9kZSI6MX0sImV4cGlyZXMiOjEzMDc2MjQ0MDAsImlzc3VlZF9hdCI6MTMwNzYxNzcxOSwib2F1dGhfdG9rZW4iOiIxMjc2OTIzMTczMDkzMTV8Mi5BUUM5NEZyUkd2ZVJPTFFSLjM2MDAuMTMwNzYyNDQwMC4xLTEwMDAwMjI5NzY0MjM5N3xEMEhBUDdrdG9nZHNUZUIzRlZ3bE84Y18taXMiLCJ1c2VyIjp7ImNvdW50cnkiOiJydSIsImxvY2FsZSI6InJ1X1JVIiwiYWdlIjp7Im1pbiI6MjF9fSwidXNlcl9pZCI6IjEwMDAwMjI5NzY0MjM5NyJ9";
        checkSig("Test 2 - ", secret, encodedSig, data);

        encodedSig = "nPRJXXsBRTVaiXA14ZqR_im0NBq68zzfrW5PjcHPPyo";
        data = "eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNyZWRpdHMiOnsiYnV5ZXIiOjEwMDAwMjI5NzY0MjM5NywicmVjZWl2ZXIiOjEwMDAwMjI5NzY0MjM5Nywib3JkZXJfaWQiOjEwMzk1NjA4MzAzMDA2Mywib3JkZXJfaW5mbyI6IntcIml0ZW1faWRcIjpcIjVcIixcImltYWdlX3VybFwiOlwiaHR0cDpcL1wvd3d3LmZhY2Vib29rLmNvbVwvaW1hZ2VzXC9naWZ0c1wvMjEucG5nXCIsXCJ0aXRsZVwiOlwiNTAwMDAgXHUwNDQ0XHUwNDM4XHUwNDQ4XHUwNDM1XHUwNDNhXCIsXCJkZXNjcmlwdGlvblwiOlwiIFwiLFwicHJpY2VcIjo1LFwicHJvZHVjdF91cmxcIjpcImh0dHA6XC9cL3d3dy5mYWNlYm9vay5jb21cL2ltYWdlc1wvZ2lmdHNcLzIxLnBuZ1wifSIsInRlc3RfbW9kZSI6MX0sImV4cGlyZXMiOjEzMDc2ODIwMDAsImlzc3VlZF9hdCI6MTMwNzY3ODA4OCwib2F1dGhfdG9rZW4iOiIxMjc2OTIzMTczMDkzMTV8Mi5BUUFpcmNIdGw4djFJUFVDLjM2MDAuMTMwNzY4MjAwMC4xLTEwMDAwMjI5NzY0MjM5N3xla2Y3NmtSSkRhallyQWJYeDFmOTJFamE2YzAiLCJ1c2VyIjp7ImNvdW50cnkiOiJydSIsImxvY2FsZSI6InJ1X1JVIiwiYWdlIjp7Im1pbiI6MjF9fSwidXNlcl9pZCI6IjEwMDAwMjI5NzY0MjM5NyJ9";
        checkSig("Test 3 - ", secret, encodedSig, data);

        encodedSig = "w9SUARFCcM2XeYiKQ_tJCBK-21A3jdxD1IUE527_qbQ";
        data = "eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImNyZWRpdHMiOnsiYnV5ZXIiOjEwMDAwMjI5NzY0MjM5NywicmVjZWl2ZXIiOjEwMDAwMjI5NzY0MjM5Nywib3JkZXJfaWQiOjE5Njc0NDMzMDM3Mzc0Miwib3JkZXJfaW5mbyI6IntcInByb2R1Y3RfdXJsXCI6XCJodHRwOlwvXC93d3cuZmFjZWJvb2suY29tXC9pbWFnZXNcL2dpZnRzXC8yMS5wbmdcIixcIml0ZW1faWRcIjpcIjJcIixcInRpdGxlXCI6XCIyMDAwMCBcdTA0NDRcdTA0MzhcdTA0NDhcdTA0MzVcdTA0M2FcIixcImRlc2NyaXB0aW9uXCI6XCIgXCIsXCJwcmljZVwiOjIsXCJpbWFnZV91cmxcIjpcImh0dHA6XC9cL3d3dy5mYWNlYm9vay5jb21cL2ltYWdlc1wvZ2lmdHNcLzIxLnBuZ1wifSIsInRlc3RfbW9kZSI6MX0sImV4cGlyZXMiOjEzMDgwMzQ4MDAsImlzc3VlZF9hdCI6MTMwODAyOTg2Nywib2F1dGhfdG9rZW4iOiIxMjc2OTIzMTczMDkzMTV8Mi5BUURSMUc4ektSWE1iNU1vLjM2MDAuMTMwODAzNDgwMC4xLTEwMDAwMjI5NzY0MjM5N3x5Nnh3a3lJZHF6RHp0dkhmOTNNbTJTZWhxdWMiLCJ1c2VyIjp7ImNvdW50cnkiOiJydSIsImxvY2FsZSI6InJ1X1JVIiwiYWdlIjp7Im1pbiI6MjF9fSwidXNlcl9pZCI6IjEwMDAwMjI5NzY0MjM5NyJ9";
        checkSig("Test 4 - ", secret, encodedSig, data);
    }

    private void checkSig(String label, String secret, String encodedSig, String data) throws UnsupportedEncodingException {
        byte[] expectedSig = Base64Helper.byteDecode(Base64Helper.replaceBeforeDecode(encodedSig));
        String strExpectedSig = new String(expectedSig).trim();
        //System.out.println(label + "expectedSig: " + strExpectedSig);
        byte[] actualSig = CallbacksPaymentServiceImpl.getActualSig(secret, data);
        String strActualSig = new String(actualSig).trim();
        //System.out.println(label + "actualSig  : " + strActualSig);
        if (expectedSig == null || actualSig == null || !strActualSig.equals(strExpectedSig) /*!Arrays.equals(actualSig, expectedSig)*/) {
            System.out.println(label + "Bad Signed JSON signature!");
        }
        assertEquals(strExpectedSig, strActualSig);
    }

    @Test
    public void testCheckSig_variants() throws Exception {
        String encodedSig = "151335f7dbe44baa1a8f000726b6ed3a";

        byte[] expectedSig1 = (new BASE64Decoder()).decodeBuffer(encodedSig);
        String sig1 = new String(expectedSig1);
        //System.out.println("expectedSig 1: " + sig1);

        byte[] expectedSig2 = Base64.decodeBase64(encodedSig.getBytes());
        String sig2 = new String(expectedSig2);
        //System.out.println("expectedSig 2: " + sig2);

        byte[] expectedSig3 = Base64Helper.byteDecode(encodedSig);
        String sig3 = new String(expectedSig3);
        //System.out.println("expectedSig 3: " + sig3);

        assertEquals(sig1, sig2);
        assertEquals(sig1, sig3);
        assertEquals(sig2, sig3);
    }

    @Test
    public void testCheckSig_hello() throws Exception {
        String encodedSig = "aGVsbG8=";

        byte[] expectedSig1 = (new BASE64Decoder()).decodeBuffer(encodedSig);
        String sig1 = new String(expectedSig1);
        //System.out.println("expectedSig 1: " + sig1);

        byte[] expectedSig2 = Base64.decodeBase64(encodedSig.getBytes());
        String sig2 = new String(expectedSig2);
        //System.out.println("expectedSig 2: " + sig2);

        byte[] expectedSig3 = Base64Helper.byteDecode(encodedSig);
        String sig3 = new String(expectedSig3);
        //System.out.println("expectedSig 3: " + sig3);

        assertEquals(sig1, sig2);
        assertEquals(sig1, sig3);
        assertEquals(sig2, sig3);
        //System.out.println("expectedSig: " + sig1);
    }

}
