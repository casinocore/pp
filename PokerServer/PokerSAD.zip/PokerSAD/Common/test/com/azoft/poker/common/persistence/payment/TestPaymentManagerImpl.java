package com.azoft.poker.common.persistence.payment;

import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import com.azoft.poker.common.persistence.CustomAttributesWrapper;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class TestPaymentManagerImpl {

    private final static int COUNT = 10;

    private static final String TRANSACTION_ID_PREFIX = "TransactionId";
    private static final String PRODUCT_CODE_PREFIX = "ProductCode";
    private static final String PRODUCT_OPTION_PREFIX = "ProductOption";

    private final static PaymentManager<Payment> manager = PaymentManagerImpl.getInstance();

    @BeforeClass
    public static void beforeTests() {
        clear();
    }

    @AfterClass
    public static void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_PAYMENT);
    }

    private static Payment createPayment(long i) throws Exception {
        Payment newPayment = new Payment();
        newPayment.setSocialNetworkID("SocialNetworkID" + i);
        Date date = CustomAttributesWrapper.attributeDateTimeFormat.parse("2010-05-20 14:25:" + i);
        newPayment.setTransactionTime(date);
        newPayment.setTransactionId(TRANSACTION_ID_PREFIX + i);
        newPayment.setProductCode(PRODUCT_CODE_PREFIX + i);
        newPayment.setProductOption(PRODUCT_OPTION_PREFIX + i);
        newPayment.setAmount(100 + i);
        return newPayment;
    }

    @Test
    public void testPaymentManager() throws Exception {
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PAYMENT, 0);
        testStorePayment();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PAYMENT, COUNT);
        testGetPayment();
    }

    public void testStorePayment() throws Exception {
        for (long i = 0; i < COUNT; i++) {
            Payment payment = createPayment(i);
            manager.save(payment);
        }
    }

    public void testGetPayment() throws Exception {
        Payment payment = manager.getPayment("erbrynjtu1");
        assertNull(payment);
        for (long i = 0; i < COUNT; i++) {
            payment = manager.getPayment(TRANSACTION_ID_PREFIX + i);
            assertNotNull(payment);
            assertEquals(TRANSACTION_ID_PREFIX + i, payment.getTransactionId());
            assertEquals(PRODUCT_CODE_PREFIX + i, payment.getProductCode());
            assertEquals(PRODUCT_OPTION_PREFIX + i, payment.getProductOption());
        }
        for (long i = COUNT; i < COUNT * 2; i++) {
            payment = manager.getPayment(TRANSACTION_ID_PREFIX + i);
            assertNull(payment);
        }
    }

}
