package com.azoft.poker.common.socialnetwork.facebook;

import org.junit.Test;

public class TestCallbacksPaymentServiceImpl {

    @Test
    public void testParseSignedRequest() {
//        String signedRequest = "vlXgu64BQGFSQrY0ZcJBZASMvYvTHu9GQ0YM9rjPSso.eyJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsIjAiOiJwYXlsb2FkIn0";
        String signedRequest = "vlXgu64BQGFSQrY0ZcJBZASMvYvTHu9GQ0YM9rjPSso" +
                "." +
                "e2FsZ29yaXRobTogIkhNQUMtU0hBMjU2IiwgdXNlcl9pZDogNjM0NzQ3ODU2NiwgY3JlZGl0czoge29yZGVyX2lkOiAyNzY3NSwgb3JkZXJfaW5mbzogJ1VJRDQ1Njc4IFRFU1QgREFUQSd9fQ==";

        String secret = "1234";
        FBRequest data = CallbacksPaymentServiceImpl.parseSignedRequest(signedRequest, secret);
        System.out.println(data);
    }

    @Test
    public void testParseSignedRequest_Error() {
        String signedRequest = "vlXgu64BQGFSQrY0ZcJBZASMvYvTHu9GQ0YM9rjPSso" +
                "." +
                "khNQUMtU0hBMjU2IiwgdXNlcl9pZDogNjM0NzQ3ODU2Ni";
        String secret = "1234";
        FBRequest data = CallbacksPaymentServiceImpl.parseSignedRequest(signedRequest, secret);
        System.out.println(data);
    }


}
