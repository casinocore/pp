package com.azoft.poker.common.bean;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestBlind.class,
        TestSynchronousHand.class
})
public class AllTests {
}
