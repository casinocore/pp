package com.azoft.poker.common.persistence.configurationattribute;

import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.text.ParseException;
import java.util.List;

import static org.junit.Assert.*;

public class TestConfigurationAttributeManagerImpl {

    private final static ConfigurationAttributeManager manager = ConfigurationAttributeManagerImpl.getInstance();

    @BeforeClass
    public static void beforeTests() {
        clear();
    }

    @AfterClass
    public static void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_CONFIGURATION_ATTRIBUTE);
    }

    private ConfigurationAttribute createConfigurationAttribute(short type, String name, String value) throws ParseException {
        ConfigurationAttribute attribute = new ConfigurationAttribute();
        attribute.setType(type);
        attribute.setName(name);
        attribute.setValue(value);
        return attribute;
    }

    @Test
    public void testConfigurationAttributeManager() throws Exception {
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_CONFIGURATION_ATTRIBUTE, 0);
        testStore();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_CONFIGURATION_ATTRIBUTE, 8);
        testGetConfigurationAttributes();
    }

    public void testStore() throws Exception {
        for (long i = 0; i < 5; i++) {
            ConfigurationAttribute attribute = createConfigurationAttribute(ConfigurationAttributeTypeID.LOGIN_SERVER_ATTRIBUTE.getTypeId(), "BONUS" + i, "5000");
            manager.save(attribute);
        }
        for (long i = 0; i < 3; i++) {
            ConfigurationAttribute attribute = createConfigurationAttribute(ConfigurationAttributeTypeID.LOBBY_SERVER_ATTRIBUTE.getTypeId(), "BONUS" + i, "5000");
            manager.save(attribute);
        }
    }

    public void testGetConfigurationAttributes() {
        List<ConfigurationAttribute> attributes = manager.getConfigurationAttributes();
        assertEquals(8, attributes.size());

        attributes = manager.getConfigurationAttributes(ConfigurationAttributeTypeID.LOGIN_SERVER_ATTRIBUTE);
        assertEquals(5, attributes.size());

        attributes = manager.getConfigurationAttributes(ConfigurationAttributeTypeID.LOBBY_SERVER_ATTRIBUTE);
        assertEquals(3, attributes.size());

        ConfigurationAttribute attribute = manager.getConfigurationAttribute(ConfigurationAttributeTypeID.LOBBY_SERVER_ATTRIBUTE, "asdf");
        assertNull(attribute);

        attribute = manager.getConfigurationAttribute(ConfigurationAttributeTypeID.LOBBY_SERVER_ATTRIBUTE, "BONUS0");
        assertNotNull(attribute);

        attribute = manager.getConfigurationAttribute(ConfigurationAttributeTypeID.LOBBY_SERVER_ATTRIBUTE, "BONUS3");
        assertNull(attribute);

    }

}