package com.azoft.poker.common.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.communicator.BaseConstants;
import org.apache.mina.core.session.IoSession;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestRequestCommand {

    class RequestCommandImpl extends RequestCommand {

        RequestCommandImpl(IoSession session, CommandTypeID commandTypeID) {
            super(session, commandTypeID);
        }

        public void execute() {
        }

    }

    @Test
    public void testToString() {
        RequestCommand command = new RequestCommandImpl(null, CommandTypeID.GET_LOBBY_CASH);
        command.setCommandID(927712345);

        assertEquals("Command{commandTypeID=CommandTypeID{name=GET_LOBBY_CASH, typeId=4}, protocolVersion=" + BaseConstants.PROTOCOL_VERSION + ", bodySize=0} - " +
                "RequestCommand{commandID=927712345, errorFlag=0, errorCode=0}", command.toString());
    }

}
