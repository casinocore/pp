package com.azoft.poker.common.persistence.tournament;

import com.azoft.poker.common.helper.DateHelper;
import com.azoft.poker.common.persistence.CommonPersistenceManagerImpl;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class TestTournamentManagerImpl {

    private final static PersonManager personManager = PersonManagerImpl.getInstance();
    private final static TournamentManager tournamentManager = TournamentManagerImpl.getInstance();
    private static final int COUNT = 5;

    @Before
    public void beforeTests() {
        clear();
    }

    @After
    public void afterTests() {
        clear();
    }

    private static void clear() {
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_PERSON_STATUS);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_CA);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_TOURNAMENT);
        CommonPersistenceManagerImpl.getInstance().clearTable(CommonPersistenceManagerImpl.TABLE_PERSON);
    }

    private static Person createPerson(long i) {
        Person newPerson = new Person();
        newPerson.setUsername("username" + i);
        newPerson.setSocialNetworkID("SocialNetworkID" + i);
        newPerson.setFirstName("FirstName" + i);
        newPerson.setLastName("LastName" + i);
        newPerson.setBalance(10000);
        return newPerson;
    }

    private void createTournaments() {
        Tournament tournament = tournamentManager.createTournament(TournamentTypeID.SIT_AND_GO_TOURNAMENT);
        tournamentManager.changeTournamentStatus(tournament, TournamentStatusID.ACTIVE);
        tournament = tournamentManager.createTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        tournamentManager.changeTournamentStatus(tournament, TournamentStatusID.ACTIVE);
    }

    @Test
    public void testTournamentManagerImpl() throws Exception {
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, 0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT, 0);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_PERSON_STATUS, 0);
        createTournaments();
        testStorePerson();
        testGetCurrentTournament();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT, 2);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_PERSON_STATUS, 0);
        testAddPlayerToTournament();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT, 2);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_PERSON_STATUS, COUNT);
        testGetTournamentPersonStatus();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT, 2);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_PERSON_STATUS, COUNT);
        testRemovePlayerFromTournament();
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_PERSON, COUNT);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT, 2);
        CommonPersistenceManagerImpl.testGetCount(CommonPersistenceManagerImpl.TABLE_TOURNAMENT_PERSON_STATUS, 0);
        testGetTournaments();
    }

    public void testStorePerson() throws Exception {
        for (long i = 0; i < COUNT; i++) {
            Person person = createPerson(i);
            Date date = DateHelper.attributeDateTimeFormat.parse("2010-05-21 01:54:" + i);
            person.setRegistrationDate(date);
            personManager.storePerson(person);
        }
    }

    public void testGetTournaments() {
        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);

        Long tournamentsCount = tournamentManager.getTournamentsCount();
        assertEquals(2, tournamentsCount.longValue());

        List<Tournament> tournaments = tournamentManager.getTournaments();
        assertEquals(2, tournaments.size());

        tournaments = tournamentManager.getTournaments(null, null);
        assertEquals(2, tournaments.size());

        tournaments = tournamentManager.getTournaments(TournamentTypeID.SIT_AND_GO_TOURNAMENT, null);
        assertEquals(1, tournaments.size());

        tournaments = tournamentManager.getTournaments(TournamentTypeID.TEMPORAL_TOURNAMENT, null);
        assertEquals(1, tournaments.size());

        tournaments = tournamentManager.getTournaments(null, TournamentStatusID.ACTIVE);
        assertEquals(2, tournaments.size());

        tournaments = tournamentManager.getTournaments(TournamentTypeID.SIT_AND_GO_TOURNAMENT, TournamentStatusID.ACTIVE);
        assertEquals(1, tournaments.size());

        tournaments = tournamentManager.getTournaments(TournamentTypeID.TEMPORAL_TOURNAMENT, TournamentStatusID.ACTIVE);
        assertEquals(1, tournaments.size());

        tournaments = tournamentManager.getActiveTournaments(TournamentTypeID.SIT_AND_GO_TOURNAMENT);
        assertEquals(1, tournaments.size());

        tournaments = tournamentManager.getActiveTournaments(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertEquals(1, tournaments.size());
    }

    public void testGetCurrentTournament() {
        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);
        assertEquals(TournamentTypeID.TEMPORAL_TOURNAMENT.getTypeId(), tournament.getType().byteValue());
    }

    public void testAddPlayerToTournament() {
        List<Person> persons = personManager.getPersons();

        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        Long tpsCount = tournamentManager.getTournamentPersonStatusCount(tournament.getId());
        assertNotNull(tournament);
        assertEquals(0, tpsCount.intValue());

        boolean isInitializationTournamentBalance = true;
        for (Person person : persons) {
            tournamentManager.addPlayerToTournament(tournament.getId(), person, isInitializationTournamentBalance);
            isInitializationTournamentBalance = !isInitializationTournamentBalance;
        }

        tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);
        tpsCount = tournamentManager.getTournamentPersonStatusCount(tournament.getId());
        assertEquals(COUNT, tpsCount.intValue());
    }

    public void testRemovePlayerFromTournament() {
        List<Person> persons = personManager.getPersons();

        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        for (Person person : persons) {
            Long returnFee = tournamentManager.removePlayerFromTournament(tournament.getId(), person);
            assertEquals(tournament.getFee(), returnFee);
        }

        assertNotNull(tournament);
        Long tpsCount = tournamentManager.getTournamentPersonStatusCount(tournament.getId());
        assertEquals(0, tpsCount.intValue());
    }

    public void testGetTournamentPersonStatus() {
        List<Person> persons = personManager.getPersons();

        Tournament currentTournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(currentTournament);

        Long statusesCount = tournamentManager.getTournamentPersonStatusCount(currentTournament.getId());
        assertEquals(5, statusesCount.longValue());

        for (Person person : persons) {
            TournamentPersonStatus status = tournamentManager.getTournamentPersonStatus(currentTournament.getId(), person.getId());
            assertNotNull(status);
            Tournament tournament = status.getTournament();
            assertNotNull(tournament);
            assertEquals(currentTournament, tournament);
        }

        boolean isInitializationTournamentBalance = true;
        for (Person person : persons) {
            TournamentPersonStatus status = tournamentManager.getTournamentPersonStatus(currentTournament.getId(), person.getId());
            assertNotNull(status);

            if (isInitializationTournamentBalance) {
                assertEquals(TournamentManagerImpl.DEFAULT_TOURNAMENT_START_CHIPS_COUNT, status.getTournamentBalance());
            } else {
                assertEquals(0, status.getTournamentBalance().longValue());
            }
            isInitializationTournamentBalance = !isInitializationTournamentBalance;

            assertEquals(9700, person.getBalance());
            Tournament tournament = status.getTournament();
            assertNotNull(tournament);
            assertEquals(currentTournament, tournament);
        }
    }

    @Test
    public void testIncPaymentsNumber() throws Exception {
        createTournaments();
        testStorePerson();

        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);
        List<Person> persons = personManager.getPersons();
        for (Person person : persons) {
            TournamentPersonStatus status = tournamentManager.getTournamentPersonStatus(tournament.getId(), person.getId());
            assertNull(status);
            tournamentManager.addPlayerToTournament(tournament.getId(), person, true);
            status = tournamentManager.getTournamentPersonStatus(tournament.getId(), person.getId());
            assertEquals(1, status.getPaymentsNumber().shortValue());
        }
    }

    @Test
    public void testGetFee() throws Exception {
        createTournaments();

        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);
        tournament.setFee(1111L);
        tournament.addAttribute(TournamentWrapper.FEE_PREFIX + "2", "2222");
        tournament.addAttribute(TournamentWrapper.FEE_PREFIX + "4", "4444");
        tournamentManager.updateTournament(tournament);

        Long fee = tournamentManager.getFee(tournament, (short) 1);
        assertNotNull(fee);
        assertEquals(1111L, fee.longValue());

        fee = tournamentManager.getFee(tournament, (short) 2);
        assertNotNull(fee);
        assertEquals(2222L, fee.longValue());

        fee = tournamentManager.getFee(tournament, (short) 3);
        assertNotNull(fee);
        assertEquals(2222L, fee.longValue());

        fee = tournamentManager.getFee(tournament, (short) 4);
        assertNotNull(fee);
        assertEquals(4444L, fee.longValue());

        fee = tournamentManager.getFee(tournament, (short) 5);
        assertNotNull(fee);
        assertEquals(4444L, fee.longValue());

        fee = tournamentManager.getFee(tournament, (short) 9826);
        assertNotNull(fee);
        assertEquals(4444L, fee.longValue());
    }

    @Test
    public void testCreateTournament() throws Exception {
        createTournaments();

        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);
        tournament.setFee(1111L);
        tournament.addAttribute(TournamentWrapper.FEE_PREFIX + "2", "2222");
        tournament.addAttribute(TournamentWrapper.FEE_PREFIX + "4", "4444");
        tournamentManager.updateTournament(tournament);

        assertEquals(2, tournament.getAttributes().size());

        Long fee = tournamentManager.getFee(tournament, (short) 1);
        assertNotNull(fee);
        assertEquals(1111L, fee.longValue());

        fee = tournamentManager.getFee(tournament, (short) 2);
        assertNotNull(fee);
        assertEquals(2222L, fee.longValue());

        Tournament newTournament = tournamentManager.createTournament(tournament);
        assertNotNull(newTournament);
        assertEquals(TournamentTypeID.TEMPORAL_TOURNAMENT.getTypeId(), newTournament.getType().byteValue());
        assertEquals(TournamentTypeID.TEMPORAL_TOURNAMENT.getLabel(), newTournament.getName());
        assertEquals(1111L, newTournament.getFee().longValue());
        assertEquals(TournamentManagerImpl.DEFAULT_TOURNAMENT_START_CHIPS_COUNT.longValue(), newTournament.getStartChipsCount().longValue());
        assertEquals(TournamentStatusID.PLANNED.getTypeId(), newTournament.getStatus().byteValue());

        assertEquals(2, newTournament.getAttributes().size());

        fee = tournamentManager.getFee(newTournament, (short) 1);
        assertNotNull(fee);
        assertEquals(1111L, fee.longValue());

        fee = tournamentManager.getFee(newTournament, (short) 2);
        assertNotNull(fee);
        assertEquals(2222L, fee.longValue());
    }

    @Test
    public void testGetTournamentPersons() throws Exception {
        createTournaments();
        testStorePerson();
        Tournament tournament = tournamentManager.getCurrentTournament(TournamentTypeID.TEMPORAL_TOURNAMENT);
        assertNotNull(tournament);

        List<Person> tournamentPersons = tournamentManager.getTournamentPersons(tournament.getId());
        assertEquals(0, tournamentPersons.size());

        List<Person> persons = personManager.getPersons();
        assertEquals(COUNT, persons.size());
        for (Person person : persons) {
            tournamentManager.addPlayerToTournament(tournament.getId(), person, true);
        }

        tournamentPersons = tournamentManager.getTournamentPersons(tournament.getId());
        assertEquals(COUNT, tournamentPersons.size());
    }

}