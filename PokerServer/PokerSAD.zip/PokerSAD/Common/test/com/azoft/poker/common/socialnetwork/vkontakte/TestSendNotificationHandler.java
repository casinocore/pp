package com.azoft.poker.common.socialnetwork.vkontakte;

import com.azoft.poker.common.socialnetwork.bean.SendNotificationBean;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestSendNotificationHandler {

    @Test
    public void testFriendsHandler() {
        SendNotificationHandler handler = new SendNotificationHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("Common/testresources/socialnetwork/vkontakte/secure.sendNotification_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SendNotificationBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        assertEquals("6492,1", bean.getResponse());
    }

}