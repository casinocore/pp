package com.azoft.poker.common.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.communicator.BaseConstants;
import org.apache.mina.core.session.IoSession;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import static org.junit.Assert.assertEquals;

public class TestCommand {

    class CommandImpl extends Command {

        CommandImpl(IoSession session, CommandTypeID commandTypeID) {
            super(session, commandTypeID);
        }

        public void execute() {
        }

        @Override
        public void encodeBody(DataOutputStream out) throws IOException {
            //prepare body content
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            dos.flush();
            byte[] body = baos.toByteArray();
            //encode body size
            setBodySize(body.length);
            out.writeInt(body.length);
            //encode body itself
            out.write(body);
        }
    }

    @Test
    public void testToString() {
        Command command = new CommandImpl(null, CommandTypeID.LOGIN);
        assertEquals("Command{commandTypeID=CommandTypeID{name=LOGIN, typeId=2}, protocolVersion=" + BaseConstants.PROTOCOL_VERSION + ", bodySize=0}", command.toString());
    }

    @Test
    public void testEncode() throws IOException {
        Command command = new CommandImpl(null, CommandTypeID.LOGIN);
        assertEquals(0, command.getBodySize());

        command.encode();
        //calculate body size
        assertEquals(0, command.getBodySize());
        //check full size
        assertEquals(7, command.getFullSize());
        //check constant
        assertEquals(Command.HEADER_SIZE, command.getFullSize());
    }

}
