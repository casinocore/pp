package com.azoft.poker.common.persistence;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        com.azoft.poker.common.persistence.configurationattribute.AllTests.class,
        com.azoft.poker.common.persistence.event.AllTests.class,
        com.azoft.poker.common.persistence.news.AllTests.class,
        com.azoft.poker.common.persistence.payment.AllTests.class,
        com.azoft.poker.common.persistence.person.AllTests.class,
        com.azoft.poker.common.persistence.personcache.AllTests.class,
        com.azoft.poker.common.persistence.product.AllTests.class,
        com.azoft.poker.common.persistence.quantityinfoentity.AllTests.class,
        com.azoft.poker.common.persistence.tournament.AllTests.class
})
public class AllTests {
}
