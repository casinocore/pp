﻿use poker_3;

-- Modify person

alter table person add column parent_id bigint;
alter table person add column exists_parent_bonus tinyint default 0;
alter table person add constraint fk_person_parent_id foreign key (parent_id)
    references person(id) on delete set null;
    
-- Friend

create table friend_link (
  id bigint auto_increment primary key,
  person_id bigint not null,
  friend_id bigint not null,
  constraint fk_friend_person_id foreign key (person_id)
    references person(id) on delete restrict,
  constraint fk_friend_friend_id foreign key (person_id)
    references person(id) on delete restrict,
  constraint ui_friend unique index (person_id, friend_id)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- News

create table news (
  id bigint auto_increment primary key,
  time_stamp datetime not null,
  preview varchar(4000) not null,
  body text,
  private_access tinyint default 0
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- News-person link

create table news_person_link (
  id bigint auto_increment primary key,
  news_id bigint not null,
  person_id bigint not null,
  is_read tinyint default 0,
  constraint fk_news_person_news_id foreign key (news_id)
    references news(id) on delete restrict,
  constraint fk_news_person_person_id foreign key (person_id)
    references person(id) on delete restrict,
  constraint ui_news_person unique index (news_id, person_id)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Configuration_attribute (type - com.azoft.poker.common.persistence.configurationattribute.ConfigurationAttributeTypeID)
delete from configuration_attribute;

insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(1, 2, 'DAILY_BONUS', '2000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(2, 2, 'FRIEND_BONUS', '500');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(3, 2, 'NEW_FRIEND_BONUS', '5000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(4, 2, 'MAX_BONUS', '10000000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(5, 3, 'DEFAULT_PRODUCT', '1');

commit;
