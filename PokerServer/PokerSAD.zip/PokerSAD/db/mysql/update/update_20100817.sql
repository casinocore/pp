﻿use poker_2;

-- clear events
delete from event_entity
    where event_entity.event_type in (7000);

commit;

delete from event_entity
    where event_entity.event_type in (5003, 5001);

commit;

delete from event_entity
    where event_entity.event_type in (3000, 2008,  2007,  2006, 2002, 2001, 2000, 1001, 1000, 101, 100);

commit;

delete event_entity_ca from event_entity_ca
    inner join event_entity on (event_entity.id=event_entity_ca.event_entity_id and event_entity.event_type = 5004);
delete from event_entity
   where event_entity.event_type = 5004;

commit;

delete event_entity_ca from event_entity_ca
    inner join event_entity on (event_entity.id=event_entity_ca.event_entity_id and event_entity.event_type = 5005);
delete from event_entity
   where event_entity.event_type = 5005;

commit;

insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(5, 3, 'DEFAULT_PRODUCT', '1');

commit;

-- InnoDB format:
ALTER TABLE server ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE configuration_attribute ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE person ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE person_cache ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE event_entity ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE event_entity_ca ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE payment ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE product ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE quantity_info_entity ENGINE = InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Change columns:
ALTER TABLE server MODIFY COLUMN server_name VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE server MODIFY COLUMN server_address VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;

ALTER TABLE configuration_attribute MODIFY COLUMN name VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE configuration_attribute MODIFY COLUMN value VARCHAR(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;

ALTER TABLE person MODIFY COLUMN user_name VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE person MODIFY COLUMN social_network_id VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE person MODIFY COLUMN first_name VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE person MODIFY COLUMN last_name VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE person MODIFY COLUMN location VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci;

ALTER TABLE event_entity_ca MODIFY COLUMN name VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE event_entity_ca MODIFY COLUMN value VARCHAR(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;

ALTER TABLE payment MODIFY COLUMN social_network_id VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE payment MODIFY COLUMN transaction_id VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE payment MODIFY COLUMN product_code VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE payment MODIFY COLUMN product_option VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci;

ALTER TABLE product MODIFY COLUMN product_code VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE product MODIFY COLUMN product_descriptor VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;

alter table person modify column balance bigint not null;
alter table payment modify column amount bigint not null;
alter table product modify column amount bigint not null;
alter table product modify column balance bigint not null;
alter table person_cache modify column game_balance bigint not null;
alter table person_cache add column tournament_id bigint not null;
-- Create columns:
alter table person add column session_start_date datetime;

alter table person_cache drop index ui_person_cache_person_id;

-- DROP OLD TABLES:
drop table if exists persons_status_in_WT;
drop table if exists weekly_tournaments;

-- CREATE NEW TABLES:

-- Tournaments

create table tournament (
   id bigint auto_increment primary key,
   name varchar(255) not null,
   type smallint,
   status smallint,
   min_players_count bigint,
   max_players_count bigint,
   fee bigint not null,
   winner_count smallint,
   start_chips_count bigint not null,
   from_date datetime,
   to_date datetime,
   descriptor varchar(4000)
   ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Tournaments custom attribute

create table tournament_ca (
  tournament_id bigint,
  name varchar(255) not null,
  value varchar(4000) not null,
  primary key (tournament_id, name),
  constraint fk_tournament_id foreign key (tournament_id)
    references tournament(id) on delete restrict
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

create index idx_tournament_ca_name on tournament_ca (name);

-- Persons' status in tournaments

create table tournament_person_status (
   id bigint auto_increment primary key,
   tournament_id bigint not null,
   person_id bigint not null,
   tournament_balance bigint,
   payments_number smallint,
  constraint ui_tournament_person_status unique index (tournament_id, person_id),
  constraint fk_tournament_person_status_tid foreign key (tournament_id)
    references tournament(id) on delete restrict,
  constraint fk_tournament_person_status_pid foreign key (person_id)
    references person(id) on delete restrict
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

--  constraints
alter table person_cache add constraint fk_person_cache_person_id foreign key (person_id)
    references person(id) on delete restrict;
alter table event_entity_ca add constraint fk_event_entity_id foreign key (event_entity_id)
    references event_entity(id) on delete restrict;
