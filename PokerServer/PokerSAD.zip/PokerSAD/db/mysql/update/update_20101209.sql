use poker_3;

-- Admins table
create table admins(
  
  id bigint(20) unsigned NOT NULL auto_increment,
  
  login varchar(255) NOT NULL,
  
  password varchar(255) NOT NULL,
  
  PRIMARY KEY  (id),
  
  UNIQUE KEY ui_admin_login (login)

) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- default dev/dev admin
insert into admins (login, password) values("admin", "2B0E56EAD2363CDEBB0956FDF578371A");

commit;