use poker_4;

alter table tournament_person_status add column leaving_time datetime;

update admins set password = md5('don123river!') where id = 1;

commit;