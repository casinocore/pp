﻿use poker;

-- Servers
drop table if exists server;

-- Configuration attributes
drop table if exists configuration_attribute;

-- Tournaments
drop table if exists tournament_person_status;
drop table if exists tournament_ca;
drop table if exists tournament;

-- Persons cache
drop table if exists person_cache;

-- News-person link
drop table if exists news_person_link;

-- Persons
drop table if exists friend_link;
drop table if exists person;

-- News
drop table if exists news;

-- Event entity custom attribute
drop table if exists event_entity_ca;
-- Event entity
drop table if exists event_entity;

-- Payment
drop table if exists payment;

-- Product
drop table if exists product;

-- Quantity info entity
drop table if exists quantity_info_entity;

-- Admins
drop table if exists admins;