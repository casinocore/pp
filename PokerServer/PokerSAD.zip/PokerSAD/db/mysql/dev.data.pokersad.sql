﻿use poker;

-- Lobby servers
delete from server;

-- Servers (server_type - com.azoft.poker.common.persistence.server.ServerTypeID)
-- access server: server_type=1; login server: server_type=2; lobby server: server_type=3; admin server: server_type=4
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(1, 1, 'Access server', '87.251.89.54', 843);
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(2, 2, 'Login server', '87.251.89.54', 9123);
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(3, 3, 'Lobby server 1', '87.251.89.54', 9124);
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(4, 4, 'Admin server', '87.251.89.54', 80);


commit;