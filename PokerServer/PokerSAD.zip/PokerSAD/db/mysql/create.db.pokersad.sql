﻿CREATE DATABASE poker_4 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

GRANT ALL PRIVILEGES ON poker_4.* TO pokersad@localhost IDENTIFIED BY 'pokersad';
GRANT ALL PRIVILEGES ON poker_4.* TO pokersad@172.16.0.8 IDENTIFIED BY 'pokersad';
GRANT ALL PRIVILEGES ON poker_4.* TO 'pokersad'@'%' IDENTIFIED BY 'pokersad';