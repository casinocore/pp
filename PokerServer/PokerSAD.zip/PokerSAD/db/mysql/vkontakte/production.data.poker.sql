﻿use poker_vk_1;

-- Servers (server_type - com.azoft.poker.common.persistence.server.ServerTypeID)
-- access server: server_type=1; login server: server_type=2; lobby server: server_type=3; admin server: server_type=4
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(1, 1, 'Access server', '92.241.175.228', 843);
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(2, 2, 'Login server', '92.241.175.228', 9123);
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(3, 3, 'Lobby server 1', '92.241.175.228', 9124);
insert into server (`id`, `server_type`, `server_name`, `server_address`, `server_port`)
  values(4, 4, 'Admin server', '92.241.175.228', 80);

-- Quantity info entity
insert into quantity_info_entity (`id`, `time_stamp`, `quantity_new_registrations`, `quantity_active_players`,
    `quantity_payment_players`, `quantity_online_players`, `online_peak_time`)
  values(1, now(), 0, 0, 0, 0, now());

insert into quantity_info_entity (`id`, `time_stamp`, `quantity_new_registrations`, `quantity_active_players`,
    `quantity_payment_players`, `quantity_online_players`, `online_peak_time`)
  values(2, now(), 0, 0, 0, 0, now());

-- configuration_attribute (type - com.azoft.poker.common.persistence.configurationattribute.ConfigurationAttributeTypeID)
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(1, 2, 'DAILY_BONUS', '1000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(2, 2, 'FRIEND_BONUS', '500');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(3, 2, 'NEW_FRIEND_BONUS', '2000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(4, 2, 'MAX_BONUS', '10000000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(5, 3, 'DEFAULT_PRODUCT', '1');

-- Product

insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(1, '10', '10000', 1000, 10000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(2, '20', '20000', 2000, 20000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(3, '30', '30000', 3000, 30000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(4, '40', '40000', 4000, 40000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(5, '50', '50000', 5000, 50000);

commit;