use poker_vk_1;

delete from configuration_attribute;
delete from product;

-- configuration_attribute (type - com.azoft.poker.common.persistence.configurationattribute.ConfigurationAttributeTypeID)
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(1, 2, 'DAILY_BONUS', '1000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(2, 2, 'FRIEND_BONUS', '500');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(3, 2, 'NEW_FRIEND_BONUS', '2000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(4, 2, 'MAX_BONUS', '10000000');
insert into configuration_attribute (`id`, `type`, `name`, `value`)
  values(5, 3, 'DEFAULT_PRODUCT', '1');

-- Product

insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(1, '10', '10000', 1000, 10000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(2, '20', '20000', 2000, 20000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(3, '30', '30000', 3000, 30000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(4, '40', '40000', 4000, 40000);
insert into product (`id`, `product_code`, `product_descriptor`, `amount`, `balance`)
  values(5, '50', '50000', 5000, 50000);

commit;
