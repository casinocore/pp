use poker_vk_1;

-- clear script

-- Quantity info entity
delete from quantity_info_entity;

-- Event entity custom attribute
delete from event_entity_ca;
-- Event entity
delete from event_entity;

-- Tournaments
delete from tournament_person_status;
delete from tournament_ca;
delete from tournament;

-- News person link
delete from news_person_link;
-- News
delete from news;

-- Friend link
delete from friend_link;
-- Persons cache
delete from person_cache;
-- Persons
delete from person;

-- Payment
delete from payment;

commit;
