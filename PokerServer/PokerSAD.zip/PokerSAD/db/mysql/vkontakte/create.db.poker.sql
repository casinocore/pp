﻿CREATE DATABASE poker_vk_1 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

GRANT ALL PRIVILEGES ON poker_vk_1.* TO pokersad@localhost IDENTIFIED BY 'pokersad';
GRANT ALL PRIVILEGES ON poker_vk_1.* TO pokersad@212.76.152.244 IDENTIFIED BY 'pokersad';
