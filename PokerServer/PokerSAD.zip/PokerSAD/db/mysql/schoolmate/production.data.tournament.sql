﻿use poker;

insert into tournament (`id`, `name`, `type`, `status`, `min_players_count`, `max_players_count`,
    `fee`, `prize_count`, `start_chips_count`, `from_date`, `to_date`)
  values(1, 'Weekly tournament', 2, 3, null, null, 10000, 1, 10000, null, null);

commit;