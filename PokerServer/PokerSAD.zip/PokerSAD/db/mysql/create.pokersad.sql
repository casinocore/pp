﻿use poker;

-- DATETIME format: 'YYYY-MM-DD HH:MM:SS'

-- Servers (login server: server_type=0; lobby server: server_type=1)

create table server (
  id bigint auto_increment primary key,
  server_type smallint not null,
  server_name varchar(255) not null,
  server_address varchar(255) not null,
  server_port int not null,
  constraint ui_server_name unique index (server_name)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Configuration attributes

create table configuration_attribute (
  id bigint auto_increment primary key,
  type smallint not null,
  name varchar(255) not null,
  value varchar(4000) not null,
  constraint ui_configuration_attribute unique index (type, name)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Persons

create table person (
  id bigint auto_increment primary key,
  user_name varchar(255) not null,
  account_type smallint not null,
  social_network_id varchar(255) not null,
  first_name varchar(255) not null,
  last_name varchar(255) not null,
  balance bigint not null,
  registration_date datetime not null,
  date_of_birth datetime,
  sex smallint not null,
  location varchar(255),
  session_start_date datetime,
  parent_id bigint,
  exists_parent_bonus tinyint default 0,
  constraint fk_person_parent_id foreign key (parent_id)
    references person(id) on delete set null,
  constraint ui_user_name unique index (user_name)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

create index idx_person_registration_date on person (registration_date);
create index idx_person_social_network_id on person(social_network_id);

-- Persons cache

create table person_cache (
  id bigint auto_increment primary key,
  person_id bigint not null,
  game_balance bigint not null,
  tournament_id bigint not null,
  constraint fk_person_cache_person_id foreign key (person_id)
    references person(id) on delete restrict
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Event entity

create table event_entity (
  id bigint auto_increment primary key,
  event_type smallint not null,
  time_stamp datetime not null,
  reference_id bigint
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

create index idx_event_entity_event_type on event_entity (event_type);
create index idx_event_entity_time_stamp on event_entity (time_stamp);
create index idx_event_entity_reference_id on event_entity (reference_id);

-- Event entity custom attribute

create table event_entity_ca (
  event_entity_id bigint,
  name varchar(255) not null,
  value varchar(4000) not null,
  primary key (event_entity_id, name),
  constraint fk_event_entity_id foreign key (event_entity_id)
    references event_entity(id) on delete restrict
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

create index idx_event_entity_ca_name on event_entity_ca (name);

-- Payment

create table payment (
  id bigint auto_increment primary key,
  social_network_id varchar(255) not null,
  transaction_time datetime not null,
  transaction_id varchar(255) not null,
  product_code varchar(255) not null,
  product_option varchar(255),
  amount bigint not null
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

create index idx_payment_social_network_id on payment (social_network_id);

-- Product

create table product (
  id bigint auto_increment primary key,
  product_code varchar(255) not null,
  product_descriptor varchar(255) not null,
  amount bigint not null,
  balance bigint not null
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Quantity info entity

create table quantity_info_entity (
  id bigint primary key,
  time_stamp datetime not null,
  quantity_new_registrations int not null,
  quantity_active_players int not null,
  quantity_payment_players int not null,
  quantity_online_players int not null,
  online_peak_time datetime not null
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Tournaments

create table tournament (
   id bigint auto_increment primary key,
   name varchar(255) not null,
   type smallint,
   status smallint,
   min_players_count bigint,
   max_players_count bigint,
   fee bigint not null,
   winner_count smallint,
   start_chips_count bigint not null,
   from_date datetime,
   to_date datetime,
   descriptor varchar(4000)
) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Tournaments custom attribute

create table tournament_ca (
  tournament_id bigint,
  name varchar(255) not null,
  value varchar(4000) not null,
  primary key (tournament_id, name),
  constraint fk_tournament_id foreign key (tournament_id)
    references tournament(id) on delete restrict
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

create index idx_tournament_ca_name on tournament_ca (name);

-- Persons' status in tournaments

create table tournament_person_status (
   id bigint auto_increment primary key,
   tournament_id bigint not null,
   person_id bigint not null,
   tournament_balance bigint,
   payments_number smallint,
   leaving_time datetime,
  constraint ui_tournament_person_status unique index (tournament_id, person_id),
  constraint fk_tournament_person_status_tid foreign key (tournament_id)
    references tournament(id) on delete restrict,
  constraint fk_tournament_person_status_pid foreign key (person_id)
    references person(id) on delete restrict
) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Friend link

create table friend_link (
  id bigint auto_increment primary key,
  person_id bigint not null,
  friend_id bigint not null,
  constraint fk_friend_person_id foreign key (person_id)
    references person(id) on delete restrict,
  constraint fk_friend_friend_id foreign key (person_id)
    references person(id) on delete restrict,
  constraint ui_friend unique index (person_id, friend_id)    
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- News

create table news (
  id bigint auto_increment primary key,
  time_stamp datetime not null,
  preview varchar(4000) not null,
  body text,
  private_access tinyint default 0
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- News-person link

create table news_person_link (
  id bigint auto_increment primary key,
  news_id bigint not null,
  person_id bigint not null,
  is_read tinyint default 0,
  constraint fk_news_person_news_id foreign key (news_id)
    references news(id) on delete restrict,
  constraint fk_news_person_person_id foreign key (person_id)
    references person(id) on delete restrict,
  constraint ui_news_person unique index (news_id, person_id)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Admins table

create table admins(
  
  id bigint(20) unsigned NOT NULL auto_increment,
  
  login varchar(255) NOT NULL,
  
  password varchar(255) NOT NULL,
  
  PRIMARY KEY  (id),
  
  UNIQUE KEY ui_admin_login (login)

) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;