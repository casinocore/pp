package com.azoft.poker.botclient.bot.behaviour;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TestParametrisedBehaviourHelper {

    @Test
    public void testPrepareOrderPositionsByBigBlind_FindPosistion() {
        //2 players
        List<Byte> positions = new ArrayList<Byte>();
        positions.add((byte) 1);
        positions.add((byte) 3);

        //test case 2 - 1
        List<Byte> result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 1, positions);
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).byteValue());
        assertEquals(3, result.get(1).byteValue());
        byte position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(0, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(1, position);

        //test case 2 - 2
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 3, positions);
        assertEquals(2, result.size());
        assertEquals(3, result.get(0).byteValue());
        assertEquals(1, result.get(1).byteValue());
        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(1, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(0, position);

        //3 players test
        positions = new ArrayList<Byte>();
        positions.add((byte) 1);
        positions.add((byte) 3);
        positions.add((byte) 5);

        //test case 3 - 1
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 1, positions);
        assertEquals(3, result.size());
        assertEquals(1, result.get(0).byteValue());
        assertEquals(3, result.get(1).byteValue());
        assertEquals(5, result.get(2).byteValue());

        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(2, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(1, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 5, result);
        assertEquals(0, position);

        //test case 3 - 2
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 3, positions);
        assertEquals(3, result.size());
        assertEquals(3, result.get(0).byteValue());
        assertEquals(5, result.get(1).byteValue());
        assertEquals(1, result.get(2).byteValue());

        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(0, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(2, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 5, result);
        assertEquals(1, position);

        //test case 3 - 3
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 5, positions);
        assertEquals(3, result.size());
        assertEquals(5, result.get(0).byteValue());
        assertEquals(1, result.get(1).byteValue());
        assertEquals(3, result.get(2).byteValue());

        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(1, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(0, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 5, result);
        assertEquals(2, position);

        //4 players test
        positions = new ArrayList<Byte>();
        positions.add((byte) 1);
        positions.add((byte) 3);
        positions.add((byte) 5);
        positions.add((byte) 6);

        //test case 4 - 1
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 1, positions);
        assertEquals(4, result.size());
        assertEquals(6, result.get(0).byteValue());
        assertEquals(1, result.get(1).byteValue());
        assertEquals(3, result.get(2).byteValue());
        assertEquals(5, result.get(3).byteValue());

        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(2, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(1, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 5, result);
        assertEquals(0, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 6, result);
        assertEquals(3, position);

        //test case 4 - 2
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 3, positions);
        assertEquals(4, result.size());
        assertEquals(1, result.get(0).byteValue());
        assertEquals(3, result.get(1).byteValue());
        assertEquals(5, result.get(2).byteValue());
        assertEquals(6, result.get(3).byteValue());

        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(3, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(2, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 5, result);
        assertEquals(1, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 6, result);
        assertEquals(0, position);

        //test case 4 - 3
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 5, positions);
        assertEquals(4, result.size());
        assertEquals(3, result.get(0).byteValue());
        assertEquals(5, result.get(1).byteValue());
        assertEquals(6, result.get(2).byteValue());
        assertEquals(1, result.get(3).byteValue());

        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(0, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(3, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 5, result);
        assertEquals(2, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 6, result);
        assertEquals(1, position);

        //test case 4 - 4
        result = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind((byte) 6, positions);
        assertEquals(4, result.size());
        assertEquals(5, result.get(0).byteValue());
        assertEquals(6, result.get(1).byteValue());
        assertEquals(1, result.get(2).byteValue());
        assertEquals(3, result.get(3).byteValue());

        position = ParametrisedBehaviourHelper.findPosition((byte) 1, result);
        assertEquals(1, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 3, result);
        assertEquals(0, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 5, result);
        assertEquals(3, position);
        position = ParametrisedBehaviourHelper.findPosition((byte) 6, result);
        assertEquals(2, position);

    }

}
