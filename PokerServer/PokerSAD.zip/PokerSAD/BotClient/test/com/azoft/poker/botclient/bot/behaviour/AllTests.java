package com.azoft.poker.botclient.bot.behaviour;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestParametrisedBehaviourHelper.class,
        com.azoft.poker.botclient.bot.behaviour.cardscombination.AllTests.class
})
public class AllTests {
}
