package com.azoft.poker.botclient.configuration;

import com.azoft.poker.botclient.bot.behaviour.BankStatusTypeID;
import com.azoft.poker.botclient.bot.behaviour.cardscombination.CardsCombination;
import com.azoft.poker.botclient.configuration.behaviour.BankBean;
import com.azoft.poker.botclient.configuration.behaviour.BotDealBean;
import com.azoft.poker.botclient.configuration.behaviour.ParametrisedBehaviourBean;
import com.azoft.poker.botclient.configuration.behaviour.ParametrisedBehaviourHandler;
import com.azoft.poker.lobbyserver.tableprocessing.DealType;
import com.azoft.poker.lobbyserver.tableprocessing.lead.LeadType;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

public class TestParametrisedBehaviourHandler {

    @Test
    public void testParametrisedBehaviourHandler_Error() {
        ParametrisedBehaviourHandler handler = new ParametrisedBehaviourHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("BotClient/testresources/configuration/behaviour/bot_behaviour_error.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        ParametrisedBehaviourBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 10", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(10, errorMessages.size());
        assertEquals("Invalid format 'min-timeout': 'n'", errorMessages.get(1L));
        assertEquals("Invalid format 'max-timeout': '2H0'", errorMessages.get(2L));
        assertEquals("Not exists 'value' attribute for 'bank'", errorMessages.get(3L));
        assertEquals("Invalid format 'value' attribute for 'lead' : 'CALL7'", errorMessages.get(4L));
        assertEquals("Not exists cards combination: HR+", errorMessages.get(5L));
        assertEquals("Invalid format 'value' attribute for 'bank' : 'M1'", errorMessages.get(6L));
        assertEquals("Not exists 'value' attribute for 'place'", errorMessages.get(7L));
        assertEquals("Invalid format 'value' attribute for 'place' : '3J'", errorMessages.get(8L));
        assertEquals("Not exists 'value' attribute for 'deal'", errorMessages.get(9L));
        assertEquals("Invalid format 'value' attribute for 'deal' : 'TURN1'", errorMessages.get(10L));

        BotDealBean botDealBean = bean.getDealBean(DealType.PRE_FLOP);
        assertNotNull(botDealBean);
        botDealBean = bean.getDealBean(DealType.FLOP);
        assertNull(botDealBean);
        botDealBean = bean.getDealBean(DealType.TURN);
        assertNull(botDealBean);
        botDealBean = bean.getDealBean(DealType.RIVER);
        assertNull(botDealBean);
    }

    @Test
    public void testParametrisedBehaviourHandler() {
        ParametrisedBehaviourHandler handler = new ParametrisedBehaviourHandler();
        handler.setBean(new ParametrisedBehaviourBean());

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("BotClient/testresources/configuration/behaviour/bot_behaviour_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        ParametrisedBehaviourBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        assertEquals("com.azoft.poker.botclient.bot.behaviour.BotBehaviour", bean.getBehaviourClass());
        assertEquals(3L, bean.getMinTimeout().longValue());
        assertEquals(10L, bean.getMaxTimeout().longValue());

        //PRE_FLOP
        BotDealBean botDealBean = bean.getDealBean(DealType.PRE_FLOP);
        assertNotNull(botDealBean);
        BankBean bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(bankBean);
        BankBean findBankBean = botDealBean.findBankBean((byte) 0, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(findBankBean);
        assertTrue(bankBean.equals(findBankBean));
        findBankBean = botDealBean.findBankBean((byte) 1, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(findBankBean);
        assertTrue(bankBean.equals(findBankBean));
        findBankBean = botDealBean.findBankBean((byte) 2, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(findBankBean);
        assertFalse(bankBean.equals(findBankBean));

        List<CardsCombination> cardsCombinations = bankBean.getCardsCombinations(LeadType.FOLD);
        assertEquals(1, cardsCombinations.size());
        assertEquals(CardsCombination.getCardsCombination("any"), cardsCombinations.get(0));
        cardsCombinations = bankBean.getCardsCombinations(LeadType.CALL);
        assertEquals(3, cardsCombinations.size());
        assertEquals(CardsCombination.getCardsCombination("s"), cardsCombinations.get(0));
        assertEquals(CardsCombination.getCardsCombination("F"), cardsCombinations.get(1));
        assertEquals(CardsCombination.getCardsCombination("23+"), cardsCombinations.get(2));
        cardsCombinations = bankBean.getCardsCombinations(LeadType.RAISE);
        assertEquals(1, cardsCombinations.size());
        assertEquals(CardsCombination.getCardsCombination("99+"), cardsCombinations.get(0));

        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.CALL_LEAD);
        assertNull(bankBean);

        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.RAISE_LEAD);
        assertNotNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 0, BankStatusTypeID.CALL_LEAD);
        assertNotNull(findBankBean);
        assertFalse(bankBean.equals(findBankBean));
        findBankBean = botDealBean.findBankBean((byte) 0, BankStatusTypeID.RAISE_LEAD);
        assertNotNull(findBankBean);
        assertTrue(bankBean.equals(findBankBean));
        findBankBean = botDealBean.findBankBean((byte) 0, BankStatusTypeID.MULTI_RAISE);
        assertNotNull(findBankBean);
        assertTrue(bankBean.equals(findBankBean));

        findBankBean = botDealBean.findBankBean((byte) 1, BankStatusTypeID.CALL_LEAD);
        assertNotNull(findBankBean);
        findBankBean = botDealBean.findBankBean((byte) 2, BankStatusTypeID.CALL_LEAD);
        assertNotNull(findBankBean);

        cardsCombinations = bankBean.getCardsCombinations(LeadType.FOLD);
        assertNull(cardsCombinations);
        cardsCombinations = bankBean.getCardsCombinations(LeadType.CALL);
        assertEquals(1, cardsCombinations.size());
        assertEquals(CardsCombination.getCardsCombination("ANY"), cardsCombinations.get(0));
        cardsCombinations = bankBean.getCardsCombinations(LeadType.RAISE);
        assertEquals(1, cardsCombinations.size());
        assertEquals(CardsCombination.getCardsCombination("jJ+"), cardsCombinations.get(0));

        bankBean = botDealBean.getBankBean((byte) 1, BankStatusTypeID.CLOSE_BANK);
        assertNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 1, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(findBankBean);
        bankBean = botDealBean.getBankBean((byte) 1, BankStatusTypeID.CALL_LEAD);
        assertNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 1, BankStatusTypeID.CALL_LEAD);
        assertNotNull(findBankBean);
        bankBean = botDealBean.getBankBean((byte) 2, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 2, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(findBankBean);
        assertTrue(bankBean.equals(findBankBean));
        bankBean = botDealBean.getBankBean((byte) 2, BankStatusTypeID.CALL_LEAD);
        assertNotNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 2, BankStatusTypeID.CALL_LEAD);
        assertNotNull(findBankBean);
        assertTrue(bankBean.equals(findBankBean));
        findBankBean = botDealBean.findBankBean((byte) 2, BankStatusTypeID.RAISE_LEAD);
        assertNotNull(findBankBean);
        assertTrue(bankBean.equals(findBankBean));
        bankBean = botDealBean.getBankBean((byte) 2, BankStatusTypeID.RAISE_LEAD);
        assertNull(bankBean);

        //FLOP
        botDealBean = bean.getDealBean(DealType.FLOP);
        assertNotNull(botDealBean);
        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 0, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(findBankBean);
        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.CALL_LEAD);
        assertNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 0, BankStatusTypeID.CALL_LEAD);
        assertNotNull(findBankBean);
        bankBean = botDealBean.getBankBean((byte) 1, BankStatusTypeID.CLOSE_BANK);
        assertNull(bankBean);
        findBankBean = botDealBean.findBankBean((byte) 1, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(findBankBean);

        //TURN
        botDealBean = bean.getDealBean(DealType.TURN);
        assertNotNull(botDealBean);
        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.CLOSE_BANK);
        assertNotNull(bankBean);
        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.CALL_LEAD);
        assertNull(bankBean);
        bankBean = botDealBean.getBankBean((byte) 1, BankStatusTypeID.CLOSE_BANK);
        assertNull(bankBean);
        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.RAISE_LEAD);
        assertNotNull(bankBean);
        bankBean = botDealBean.getBankBean((byte) 0, BankStatusTypeID.MULTI_RAISE);
        assertNotNull(bankBean);

        //RIVER
        botDealBean = bean.getDealBean(DealType.RIVER);
        assertNull(botDealBean);
    }

}