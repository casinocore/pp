package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerHandData;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TestCardsCombination {

    @Test
    public void testIsCardsInside_OneCardsCombination() {
        //ANY
        List<CardsCombination> combinations = new ArrayList<CardsCombination>();
        combinations.add(CardsCombination.getCardsCombination("any"));

        List<Card> cards = new ArrayList<Card>();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 0, (byte) 1));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));
        cards.clear();
        cards.add(new Card((byte) 7, (byte) 3));
        cards.add(new Card((byte) 4, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        //FACE
        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("F"));

        cards.clear();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 0, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 2, (byte) 3));
        cards.add(new Card((byte) 2, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 9, (byte) 0));
        cards.add(new Card((byte) 6, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 11, (byte) 1));
        cards.add(new Card((byte) 11, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        //TWO_FACE
        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("FF"));

        cards.clear();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 0, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 2, (byte) 3));
        cards.add(new Card((byte) 2, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 9, (byte) 0));
        cards.add(new Card((byte) 6, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 9, (byte) 0));
        cards.add(new Card((byte) 9, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 11, (byte) 1));
        cards.add(new Card((byte) 11, (byte) 1));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 8, (byte) 1));
        cards.add(new Card((byte) 12, (byte) 3));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        //SUIT
        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("s"));

        cards.clear();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 1, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 9, (byte) 3));
        cards.add(new Card((byte) 9, (byte) 0));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 9, (byte) 0));
        cards.add(new Card((byte) 9, (byte) 0));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 3, (byte) 2));
        cards.add(new Card((byte) 10, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        //PAIR
        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("55+"));

        cards.clear();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 0, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 2, (byte) 3));
        cards.add(new Card((byte) 2, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 3, (byte) 0));
        cards.add(new Card((byte) 3, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 7, (byte) 1));
        cards.add(new Card((byte) 7, (byte) 3));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        //CONNECTOR
        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("56+"));

        cards.clear();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 1, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 2, (byte) 3));
        cards.add(new Card((byte) 3, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 3, (byte) 2));
        cards.add(new Card((byte) 4, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 7, (byte) 1));
        cards.add(new Card((byte) 8, (byte) 3));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        //SUIT_CONNECTOR
        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("56s+"));

        cards.clear();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 1, (byte) 0));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 2, (byte) 2));
        cards.add(new Card((byte) 3, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 3, (byte) 1));
        cards.add(new Card((byte) 4, (byte) 0));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 3, (byte) 2));
        cards.add(new Card((byte) 4, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 7, (byte) 3));
        cards.add(new Card((byte) 8, (byte) 3));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 7, (byte) 3));
        cards.add(new Card((byte) 8, (byte) 0));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));
    }

    @Test
    public void testIsCardsInside_PokerHand() {
        //TWO_PAIR
        List<CardsCombination> combinations = new ArrayList<CardsCombination>();
        combinations.add(CardsCombination.getCardsCombination("TWO_PAIR"));

        List<Card> cards = PokerHandData.create_FLUSH_1();
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards = PokerHandData.create_TWO_PAIR_1();
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 4, (byte) 0));
        cards.add(new Card((byte) 4, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 4, (byte) 0));
        cards.add(new Card((byte) 8, (byte) 2));
        cards.add(new Card((byte) 10, (byte) 3));
        cards.add(new Card((byte) 8, (byte) 1));
        cards.add(new Card((byte) 4, (byte) 1));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        //SET
        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("SET"));

        cards = PokerHandData.create_ONE_PAIR_1();
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards = PokerHandData.create_SET_1();
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 8, (byte) 3));
        cards.add(new Card((byte) 0, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 6, (byte) 0));
        cards.add(new Card((byte) 8, (byte) 2));
        cards.add(new Card((byte) 8, (byte) 3));
        cards.add(new Card((byte) 0, (byte) 3));
        cards.add(new Card((byte) 8, (byte) 1));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));
    }

    @Test
    public void testIsCardsInside_MultiCardsCombination() {
        List<CardsCombination> combinations = new ArrayList<CardsCombination>();
        combinations.add(CardsCombination.getCardsCombination("F"));
        combinations.add(CardsCombination.getCardsCombination("78+"));

        List<Card> cards = new ArrayList<Card>();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 0, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 4, (byte) 3));
        cards.add(new Card((byte) 5, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 5, (byte) 3));
        cards.add(new Card((byte) 6, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 9, (byte) 0));
        cards.add(new Card((byte) 2, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        combinations.clear();
        combinations.add(CardsCombination.getCardsCombination("FF"));
        combinations.add(CardsCombination.getCardsCombination("78s+"));

        cards = new ArrayList<Card>();
        cards.add(new Card((byte) 0, (byte) 0));
        cards.add(new Card((byte) 0, (byte) 1));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 8, (byte) 3));
        cards.add(new Card((byte) 7, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 5, (byte) 0));
        cards.add(new Card((byte) 6, (byte) 2));
        assertFalse(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 5, (byte) 2));
        cards.add(new Card((byte) 6, (byte) 2));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 9, (byte) 1));
        cards.add(new Card((byte) 9, (byte) 3));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));

        cards.clear();
        cards.add(new Card((byte) 10, (byte) 2));
        cards.add(new Card((byte) 11, (byte) 3));
        assertTrue(CardsCombination.isCardsInside(cards, combinations));
    }

}
