package com.azoft.poker.botclient.configuration;

import com.azoft.poker.botclient.configuration.behaviour.BotBehaviourBean;
import com.azoft.poker.botclient.configuration.behaviour.BotBehaviourHandler;
import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestBotBehaviourHandler {

    @Test
    public void testBotBehaviourHandler_Error() {
        BotBehaviourHandler handler = new BotBehaviourHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("BotClient/testresources/configuration/behaviour/bot_behaviour_error.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        BotBehaviourBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 2", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(2, errorMessages.size());
        assertEquals("Invalid format 'min-timeout': 'n'", errorMessages.get(1L));
        assertEquals("Invalid format 'max-timeout': '2H0'", errorMessages.get(2L));
    }

    @Test
    public void testBotBehaviourHandler() {
        BotBehaviourHandler handler = new BotBehaviourHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("BotClient/testresources/configuration/behaviour/bot_behaviour_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        BotBehaviourBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        assertEquals("com.azoft.poker.botclient.bot.behaviour.BotBehaviour", bean.getBehaviourClass());
        assertEquals(3, bean.getMinTimeout().longValue());
        assertEquals(10, bean.getMaxTimeout().longValue());
    }

}