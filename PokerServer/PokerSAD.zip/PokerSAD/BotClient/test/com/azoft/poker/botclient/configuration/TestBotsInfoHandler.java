package com.azoft.poker.botclient.configuration;

import org.junit.Test;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestBotsInfoHandler {

    @Test
    public void testBotsInfoHandler_Error() {
        BotsInfoHandler handler = new BotsInfoHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("BotClient/testresources/configuration/bots_info_error.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        BotsInfoBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Error; number of errors: 2", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(2, errorMessages.size());
        assertEquals("Invalid format 'big-blind': 'n'", errorMessages.get(1L));
        assertEquals("Invalid format 'big-blind': '2H0'", errorMessages.get(2L));

        Map<String, BotInfoBean> botsInfoMap = bean.getBotsInfo();
        assertEquals(3, botsInfoMap.size());
    }

    @Test
    public void testBotsInfoHandler() {
        BotsInfoHandler handler = new BotsInfoHandler();

        try {
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
            reader.parse("BotClient/testresources/configuration/bots_info_1.xml");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        BotsInfoBean bean = handler.getBean();
        assertNotNull(bean);
        assertEquals("processingResult: Success", bean.toString());
        Map<Long, String> errorMessages = bean.getErrorMessages();
        assertEquals(0, errorMessages.size());
        Map<String, BotInfoBean> botsInfoMap = bean.getBotsInfo();
        assertEquals(3, botsInfoMap.size());

        BotInfoBean botInfoBean = botsInfoMap.get("123451");
        assertEquals("Bot1", botInfoBean.getLogin());
        assertEquals("Bot1-pwd", botInfoBean.getPassword());
        assertEquals("123451", botInfoBean.getSocialNetworkID());
        assertEquals("Vasya", botInfoBean.getFirstName());
        assertEquals("Pupkin", botInfoBean.getLastName());
        assertEquals("loose-pass1.xml", botInfoBean.getConf());
        assertEquals(false, botInfoBean.isNewTable());
        Set<Long> blinds = botInfoBean.getBlinds();
        assertEquals(2, blinds.size());
        Iterator<Long> blindsIterator = blinds.iterator();
        assertEquals(20L, blindsIterator.next().longValue());
        assertEquals(200L, blindsIterator.next().longValue());

        botInfoBean = botsInfoMap.get("123452");
        assertEquals("Bot2", botInfoBean.getLogin());
        assertEquals("Bot2-pwd", botInfoBean.getPassword());
        assertEquals("123452", botInfoBean.getSocialNetworkID());
        assertEquals("Vasya2", botInfoBean.getFirstName());
        assertEquals("Pupkin2", botInfoBean.getLastName());
        assertEquals("loose-pass2.xml", botInfoBean.getConf());
        assertEquals(true, botInfoBean.isNewTable());
        blinds = botInfoBean.getBlinds();
        assertEquals(2, blinds.size());
        blindsIterator = blinds.iterator();
        assertEquals(2000L, blindsIterator.next().longValue());
        assertEquals(20000L, blindsIterator.next().longValue());

        botInfoBean = botsInfoMap.get("123453");
        assertEquals("Bot3", botInfoBean.getLogin());
        assertEquals("Bot3-pwd", botInfoBean.getPassword());
        assertEquals("123453", botInfoBean.getSocialNetworkID());
        assertEquals("Vasya3", botInfoBean.getFirstName());
        assertEquals("Pupkin3", botInfoBean.getLastName());
        assertEquals("loose-pass3 ASD.xml", botInfoBean.getConf());
        assertEquals(false, botInfoBean.isNewTable());
        blinds = botInfoBean.getBlinds();
        assertEquals(3, blinds.size());
        blindsIterator = blinds.iterator();
        assertEquals(20L, blindsIterator.next().longValue());
        assertEquals(200L, blindsIterator.next().longValue());
        assertEquals(2000L, blindsIterator.next().longValue());
    }

}
