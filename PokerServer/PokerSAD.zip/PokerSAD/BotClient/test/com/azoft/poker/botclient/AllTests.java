package com.azoft.poker.botclient;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        com.azoft.poker.botclient.configuration.AllTests.class,
        com.azoft.poker.botclient.bot.behaviour.AllTests.class
})
public class AllTests {
}
