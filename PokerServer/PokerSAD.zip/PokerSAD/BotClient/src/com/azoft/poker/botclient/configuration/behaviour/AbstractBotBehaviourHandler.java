package com.azoft.poker.botclient.configuration.behaviour;

import com.azoft.poker.common.jaxp.AbstractHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Abstract bot behaviour handler
 */
public abstract class AbstractBotBehaviourHandler<TypeBean extends BotBehaviourBean> extends AbstractHandler<TypeBean> {

    private final static Logger LOGGER = LoggerFactory.getLogger(AbstractBotBehaviourHandler.class);

    protected long errorCounter = 0;

    public AbstractBotBehaviourHandler() {
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        text = "";
        String tag = getTag(lName, qName);
        if (tag.equals("behaviour")) {
            //empty
        }
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        String tag = getTag(lName, qName);
        if (tag.equals("behaviour")) {
            getBean().setIfNullProcessingResult(RESULT_SUCCESS);
        } else if (tag.equals("behaviour-class")) {
            getBean().setBehaviourClass(text);
        } else if (tag.equals("min-timeout")) {
            try {
                Integer minTimeout = Integer.parseInt(text);
                getBean().setMinTimeout(minTimeout);
            } catch (NumberFormatException e) {
                addError("Invalid format 'min-timeout': '" + text + "'");
            }
        } else if (tag.equals("max-timeout")) {
            try {
                Integer maxTimeout = Integer.parseInt(text);
                getBean().setMaxTimeout(maxTimeout);
            } catch (NumberFormatException e) {
                addError("Invalid format 'max-timeout': '" + text + "'");
            }
        }
    }

    protected void addError(String message) {
        bean.setProcessingResult(RESULT_ERROR);
        bean.addErrorMessage(++errorCounter, message);
        LOGGER.error(message);
    }

}