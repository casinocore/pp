package com.azoft.poker.botclient.bot.behaviour;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.commandprocessing.command.ClientNotifyAboutTheLeadCommand;
import com.azoft.poker.botclient.commandprocessing.handler.HandlerHelper;
import com.azoft.poker.botclient.configuration.behaviour.BotBehaviourBean;
import com.azoft.poker.botclient.tableprocessing.bet.PlayersBets;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.lead.Lead;
import com.azoft.poker.lobbyserver.tableprocessing.lead.LeadType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Cautious bot behaviour
 */
public class CautiousBehaviour extends BotBehaviour<BotBehaviourBean> {

    private final static Logger LOGGER = LoggerFactory.getLogger(CautiousBehaviour.class);

    public CautiousBehaviour() {
        super();
    }

    @Override
    public void execute(Command command) {
        super.execute(command);
        Bot bot = getBotAttribute(command.getSession());
        if (command instanceof ClientNotifyAboutTheLeadCommand) {
            ClientNotifyAboutTheLeadCommand c = (ClientNotifyAboutTheLeadCommand) command;
            bot.getPlayersBets().addPlayerBet(c.getId(), c.getLead().getValue());
            if (c.getUserId().equals(c.getNextId())) {
                Lead lead = prepareCheckOrCallLead(bot.getPlayersBets(), command.getUserId());
                LOGGER.debug("sendLeadCommand: " + lead + " for bot: " + bot.toString());
                HandlerHelper.sendLeadCommand(command.getSession(), lead);
            }
        }
    }

    private Lead prepareCheckOrCallLead(PlayersBets playersBet, Long userId) {
        Lead lead;
        Long delta = playersBet.maxDelta(userId);
        Long gameBalance = playersBet.getGameBalance();
        if (delta > gameBalance) {
            delta = gameBalance;
        }
        if (delta == 0L) {
            lead = new Lead(LeadType.CHECK.getLeadId());
        } else {
            lead = new Lead(LeadType.CALL.getLeadId(), delta);
        }
        return lead;
    }

}
