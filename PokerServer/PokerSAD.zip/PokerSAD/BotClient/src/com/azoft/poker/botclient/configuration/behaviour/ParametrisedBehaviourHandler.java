package com.azoft.poker.botclient.configuration.behaviour;

import com.azoft.poker.botclient.bot.behaviour.BankStatusTypeID;
import com.azoft.poker.botclient.bot.behaviour.cardscombination.CardsCombination;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.lobbyserver.tableprocessing.DealType;
import com.azoft.poker.lobbyserver.tableprocessing.lead.LeadType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Parametrised behaviour handler
 */
public class ParametrisedBehaviourHandler extends AbstractBotBehaviourHandler<ParametrisedBehaviourBean> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ParametrisedBehaviourHandler.class);

    private DealType dealType;

    private BotDealBean botDealBean;

    private Byte place = 0;

    private BankStatusTypeID bankStatus;

    private BankBean bankBean;

    private LeadType leadType;

    public ParametrisedBehaviourHandler() {
        super();
        setBean(new ParametrisedBehaviourBean());
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        super.startElement(uri, lName, qName, attr);
        text = "";
        String tag = getTag(lName, qName);
        if (tag.equals("deal")) {
            dealType = null;
            botDealBean = null;
            place = 0;
            if (attr.getLength() == 1 && !StringHelper.isEmptyTrimmed(attr.getValue("value"))) {
                String attributeValue = attr.getValue("value");
                try {
                    dealType = DealType.valueOf(attributeValue);
                } catch (IllegalArgumentException e) {
                    //empty
                }
                if (dealType == null) {
                    addError("Invalid format 'value' attribute for 'deal' : '" + attributeValue + "'");
                } else {
                    botDealBean = new BotDealBean();
                }
            } else {
                addError("Not exists 'value' attribute for 'deal'");
            }
        } else if (tag.equals("place")) {
            place = null;
            boolean isInvalid = false;
            String message = "";
            if (attr.getLength() == 1 && !StringHelper.isEmptyTrimmed(attr.getValue("value"))) {
                String attributeValue = attr.getValue("value");
                try {
                    place = Byte.valueOf(attributeValue);
                } catch (NumberFormatException e) {
                    isInvalid = true;
                    message = "Invalid format 'value' attribute for 'place' : '" + attributeValue + "'";
                }
            }
            if (place == null) {
                if (!isInvalid) {
                    message = "Not exists 'value' attribute for 'place'";
                }
                addError(message);
            }
        } else if (tag.equals("bank")) {
            bankStatus = null;
            boolean isInvalid = false;
            String message = "";
            if (attr.getLength() == 1 && !StringHelper.isEmptyTrimmed(attr.getValue("value"))) {
                String attributeValue = attr.getValue("value");
                try {
                    isInvalid = true;
                    Byte bankStatusID = Byte.valueOf(attributeValue);
                    bankStatus = BankStatusTypeID.valueOf(bankStatusID);
                } catch (NumberFormatException e) {
                    message = "Invalid format 'value' attribute for 'bank' : '" + attributeValue + "'";
                } catch (IllegalArgumentException e) {
                    message = "Invalid format 'value' attribute for 'bank' : '" + attributeValue + "'";
                }
            }
            if (bankStatus == null) {
                if (!isInvalid) {
                    message = "Not exists 'value' attribute for 'bank'";
                }
                addError(message);
            } else {
                bankBean = new BankBean();
            }

        } else if (tag.equals("lead")) {
            leadType = null;
            if (attr.getLength() == 1 && !StringHelper.isEmptyTrimmed(attr.getValue("value"))) {
                String attributeValue = attr.getValue("value");
                try {
                    leadType = LeadType.valueOf(attributeValue);
                } catch (IllegalArgumentException e) {
                    //empty
                }
                if (leadType == null) {
                    addError("Invalid format 'value' attribute for 'lead' : '" + attributeValue + "'");
                }
            } else {
                addError("Not exists 'value' attribute for 'lead'");
            }
        }

    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        super.endElement(uri, lName, qName);
        String tag = getTag(lName, qName);
        if (tag.equals("deal") && botDealBean != null) {
            getBean().putDealBean(dealType, botDealBean);
        } else if (tag.equals("bank") && botDealBean != null && place != null && bankStatus != null && bankBean != null) {
            botDealBean.putBankBean(place, bankStatus, bankBean);
        } else if ((tag.equals("lead") || tag.equals("combination")) && leadType != null && !StringHelper.isEmptyTrimmed(text)) {
            prepareCardsCombination();
        }
    }

    private void prepareCardsCombination() {
        String str = StringHelper.makeEmptyTrimmed(text);
        CardsCombination cardsCombination = CardsCombination.getCardsCombination(str);
        if (cardsCombination != null) {
            bankBean.putCardsCombination(leadType, cardsCombination);
        } else {
            String message = "Not exists cards combination: " + str;
            addError(message);
        }
    }

}