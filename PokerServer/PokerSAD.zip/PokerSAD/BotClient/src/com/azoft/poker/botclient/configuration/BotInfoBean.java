package com.azoft.poker.botclient.configuration;

import java.util.Set;
import java.util.TreeSet;

/**
 * Bot info bean
 */
public class BotInfoBean {

    /**
     * Login
     */
    private String login;

    /**
     * Password
     */
    private String password;

    /**
     * Social network ID (uid)
     */
    private String socialNetworkID;

    /**
     * First name
     */
    private String firstName;

    /**
     * Last name
     */
    private String lastName;

    /**
     * Configuration XML file
     */
    private String conf;

    /**
     * New table (if 'yes' or 'true', default value - 'false')
     */
    private boolean newTable = false;

    /**
     * Big blinds
     */
    private Set<Long> blinds = new TreeSet<Long>();

    public BotInfoBean() {
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSocialNetworkID() {
        return socialNetworkID;
    }

    public void setSocialNetworkID(String socialNetworkID) {
        this.socialNetworkID = socialNetworkID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getConf() {
        return conf;
    }

    public void setConf(String conf) {
        this.conf = conf;
    }

    public boolean isNewTable() {
        return newTable;
    }

    public void setNewTable(boolean newTable) {
        this.newTable = newTable;
    }

    public Set<Long> getBlinds() {
        return blinds;
    }

    public void addBlind(Long blind) {
        blinds.add(blind);
    }

    @Override
    public String toString() {
        return "BotInfoBean{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", socialNetworkID='" + socialNetworkID + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", conf='" + conf + '\'' +
                ", newTable=" + newTable +
                ", blinds=" + blinds +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BotInfoBean that = (BotInfoBean) o;

        if (newTable != that.newTable) return false;
        if (!blinds.equals(that.blinds)) return false;
        if (!conf.equals(that.conf)) return false;
        if (!firstName.equals(that.firstName)) return false;
        if (!lastName.equals(that.lastName)) return false;
        if (!login.equals(that.login)) return false;
        if (!password.equals(that.password)) return false;
        if (!socialNetworkID.equals(that.socialNetworkID)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = login.hashCode();
        result = 31 * result + password.hashCode();
        result = 31 * result + socialNetworkID.hashCode();
        result = 31 * result + firstName.hashCode();
        result = 31 * result + lastName.hashCode();
        result = 31 * result + conf.hashCode();
        result = 31 * result + (newTable ? 1 : 0);
        result = 31 * result + blinds.hashCode();
        return result;
    }

}
