package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClientNotifyTableClosedCommand extends Command {

    /**
     * table identifier (in)
     */
    private Long tableId;

    public ClientNotifyTableClosedCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getTableId() {
        return tableId;
    }

    public void setTableId(Long tableId) {
        this.tableId = tableId;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientNotifyTableClosedCommand{" +
                "tableId='" + tableId + '\'' + '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        tableId = dis.readLong();
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
    }

}