package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;

import java.util.List;

/**
 * Suit connector cards combination
 */
public class SuitCardsCombination extends ConnectorCardsCombination {

    public SuitCardsCombination(String name, CardsCombinationType type) {
        super(name, type);
    }

    public SuitCardsCombination(String name, CardsCombinationType type, Byte value) {
        super(name, type, value);
    }

    protected boolean isInside(List<Card> cards) {
        return cards.get(0).getSuit() == cards.get(1).getSuit();
    }

}