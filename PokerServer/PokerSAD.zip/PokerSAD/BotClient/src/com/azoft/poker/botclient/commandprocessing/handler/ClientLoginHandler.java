package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.ClientCommandFactoryImpl;
import com.azoft.poker.botclient.commandprocessing.command.ClientLoginCommand;
import com.azoft.poker.botclient.commandprocessing.command.ClientRegisterCommand;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.ErrorCodes;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.persistence.server.Server;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientLoginHandler extends ClientHandler<ClientLoginCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientLoginHandler.class);

    public ClientLoginHandler() {
        super();
    }


    public void execute(ClientLoginCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        if (!command.isExistsError()) {
            bot.setUserId(command.getUserId());
            String serverPath = command.getServerPath();
            if (!StringHelper.isEmpty(serverPath)) {
                String[] paramsServer = serverPath.split(Server.SERVER_PATH_DELIMITER);
                if (paramsServer.length == 2) {
                    Integer port = null;
                    try {
                        port = Integer.valueOf(paramsServer[1]);
                    } catch (Exception e) {
                        //empty
                    }
                    if (port != null) {
                        bot.setStatus(BotStatus.LOGIN);
                        LOGGER.debug("Login parameters - address: : " + paramsServer[0] + "; port: " + port);
                        bot.shutdownLoginAndInitializationLobby(port, paramsServer[0]);
                        return;
                    }
                }
            }
            bot.setStatus(BotStatus.ERROR);
            LOGGER.error("Error. Invalid format server path: '" + serverPath + "'");
        } else {
            if (ErrorCodes.LOGIN_ERROR_NOT_EXISTS_USER.getErrorCode() == command.getErrorCode()) {
                bot.setStatus(BotStatus.LOGIN_NOT_EXISTS_USER);
                sendClientRegisterCommand(command.getSession(), bot);
            } else {
                bot.setStatus(BotStatus.ERROR);
                LOGGER.error("Error. ClientLoginCommand");
            }
        }
    }

    private void sendClientRegisterCommand(IoSession session, Bot bot) {
        LOGGER.debug("Not exists person");
        try {
            ClientRegisterCommand cmd = (ClientRegisterCommand) ClientCommandFactoryImpl.createClientCommand(
                    session, CommandTypeID.REGISTER.getTypeId());
            cmd.setUsername(bot.getBotInfoBean().getLogin());
            cmd.setSocialNetworkID(bot.getBotInfoBean().getSocialNetworkID());
            cmd.setFirstName(bot.getBotInfoBean().getFirstName());
            cmd.setLastName(bot.getBotInfoBean().getLastName());
            cmd.send();
        } catch (Exception e) {
            LOGGER.error("Create and send command: REGISTER", e);
        }
    }

}
