package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.Winner;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import com.azoft.poker.lobbyserver.tableprocessing.player.PlayerCard;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerHand;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientDealFinishedCommand extends Command {

    /**
     * winners (in)
     */
    private List<Winner> winners;

    /**
     * players (in)
     */
    private List<PlayerCard> players;

    public ClientDealFinishedCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public List<Winner> getWinners() {
        return winners;
    }

    public List<PlayerCard> getPlayers() {
        return players;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientDealFinishedCommand{" +
                "winners='" + winners + '\'' +
                ", players='" + players + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        byte winnerSize = dis.readByte();

        winners = new ArrayList<Winner>();
        players = new ArrayList<PlayerCard>();

        for (int i = 0; i < winnerSize; i++) {
            List<Card> cards = new ArrayList<Card>();
            Winner winner = new Winner();

            long playerId = dis.readLong();
            byte type = dis.readByte();
            //win and high cards
            for (int j = 0; j < 5; j++) {
                byte suit = dis.readByte();
                byte value = dis.readByte();
                cards.add(new Card(value, suit));
            }
            long winValue = dis.readLong();

            byte banksSize = dis.readByte();
            for (int j = 0; j < banksSize; j++) {
                dis.readByte();
                dis.readLong();
            }


            PokerHand pokerHand = new PokerHand(playerId, cards);
            winner.setValue(winValue);
            winner.setPokerHand(pokerHand);
            winners.add(winner);
        }
        int playersSize = dis.readByte();
        for (int j = 0; j < playersSize; j++) {
            List<Card> cards = new ArrayList<Card>();
            PlayerCard playerCard = new PlayerCard();

            long playerId = dis.readLong();
            for (int k = 0; k < 2; k++) {
                byte suit = dis.readByte();
                byte value = dis.readByte();
                cards.add(new Card(value, suit));
            }
            long pcValue = dis.readLong();

            playerCard.setPlayerId(playerId);
            playerCard.setCards(cards);
            players.add(playerCard);
        }
    }

    public void encodeBody(DataOutputStream out) throws IOException {
    }

}
