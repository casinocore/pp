package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.command.ClientHandOutDealerButtonCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientHandOutDealerButtonHandler extends ClientHandler<ClientHandOutDealerButtonCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientHandOutDealerButtonHandler.class);

    public ClientHandOutDealerButtonHandler() {
        super();
    }

    public void execute(ClientHandOutDealerButtonCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        bot.setStatus(BotStatus.DEAL_OUT);
        Byte dealerButton = command.getPlaceId();
        bot.setDealerButton(dealerButton);
        LOGGER.debug("ClientHandOutDealerButtonHandler completed for bot: " + bot.toString());
    }

}