package com.azoft.poker.botclient.service;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.configuration.BotInfoBean;
import com.azoft.poker.botclient.configuration.BotsInfoBean;
import com.azoft.poker.botclient.configuration.ConfigurationLoader;
import com.azoft.poker.botclient.configuration.behaviour.BotBehaviourLoader;
import com.azoft.poker.common.service.LifecycleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Bots configuration service
 */
public class BotsConfigurationServiceImpl implements LifecycleService {

    private final static Logger LOGGER = LoggerFactory.getLogger(BotsConfigurationServiceImpl.class);

    /**
     * Service type
     */
    private static final String SERVICE_TYPE = "BOTS_CONFIGURATION";

    /**
     * Bots configuration termination timeout
     */
    private final static long BOTS_CONFIGURATION_TERMINATION_TIMEOUT = 1000 * 10;

    /**
     * Service type
     */
    private String type = SERVICE_TYPE;

    /**
     * Bot client parameters
     */
    private Map<String, Object> parameters = new HashMap<String, Object>();

    /**
     * Configuration loader
     */
    private ConfigurationLoader configurationLoader;

    /**
     * Bot behaviour path prefix
     */
    private String botBehaviourPathPrefix;

    /**
     * Bots info bean
     */
    private BotsInfoBean botsInfoBean;

    /**
     * Bots - map (key: social network ID, value: Bot)
     */
    private Map<String, Bot> bots = new HashMap<String, Bot>();

    /**
     * Bots for remove
     */
    private Set<String> botsForRemove = new HashSet<String>();

    /**
     * Bots for add
     */
    private Set<String> botsForAdd = new HashSet<String>();

    /**
     * Scheduled executor service
     */
    private ScheduledExecutorService executor;

    private static LifecycleService instance = null;

    public static synchronized LifecycleService getInstance() {
        if (instance == null) {
            instance = new BotsConfigurationServiceImpl();
        }
        return instance;
    }

    private BotsConfigurationServiceImpl() {
        super();
        executor = Executors.newSingleThreadScheduledExecutor();
    }


    private void schedule(Map<String, Object> parameters) {
        Long configurationPeriod = (Long) parameters.get(ConfigurationLoader.PARAMETER_CONFIGURATION_PERIOD);
        executor.scheduleAtFixedRate(new SchedulerRunnable(),
                ConfigurationLoader.DEFAULT_CONFIGURATION_INITIAL_DELAY, configurationPeriod, TimeUnit.SECONDS);
    }

    /**
     * Initialization
     *
     * @param parameters parameters
     */
    public void initialization(Map<String, Object> parameters) {
        this.parameters = parameters;
        schedule(parameters);
    }

    public void shutdown() {
        boolean terminated = false;
        try {
            executor.shutdown();
            terminated = executor.awaitTermination(BOTS_CONFIGURATION_TERMINATION_TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOGGER.error(type + ": shutdown", e);
        }
        LOGGER.info(type + ": shutdown: " + terminated);
        for (Bot bot : bots.values()) {
            bot.shutdown();
        }
    }

    /**
     * Reinitialization
     */
    private void reinitialization() {
        LOGGER.debug("reinitialization");
        initializationConfiguration(parameters);
        if (validationBotsInfoBean()) {
            if (!equalsBotsInfoBean()) {
                removeBots();
                addBots();
            }
        }
        LOGGER.debug("reinitialization completed");
    }

    /**
     * initialization
     *
     * @param parameters parameters
     */
    private void initializationConfiguration(Map<String, Object> parameters) {
        LOGGER.debug("initializationConfiguration");
        String botsInfoPath = (String) parameters.get(ConfigurationLoader.PARAMETER_BOTS_INFO_PATH);
        int ind = botsInfoPath.lastIndexOf('\\');
        if (ind == -1) {
            ind = botsInfoPath.lastIndexOf('/');
        }
        botBehaviourPathPrefix = botsInfoPath.substring(0, ind + 1);
        configurationLoader = new ConfigurationLoader(botsInfoPath);
        configurationLoader.load();
        botsInfoBean = configurationLoader.getBotsInfoBean();
        LOGGER.debug("initializationConfiguration completed. ProcessingResult: " + botsInfoBean.getProcessingResult()
                + ". BotsInfo().size(): " + botsInfoBean.getBotsInfo().size());
    }

    /**
     * Validation bots info bean
     *
     * @return true if Ok
     */
    private boolean validationBotsInfoBean() {
        LOGGER.debug("validationBotsInfoBean");
        boolean result = true;
        Set<String> uniqueSocialNetworkIDs = new HashSet<String>();
        for (BotInfoBean entry : botsInfoBean.getBotsInfo().values()) {
            result = uniqueSocialNetworkIDs.add(entry.getSocialNetworkID());
            if (!result) { //duplicate
                LOGGER.warn("validationBotsInfoBean. Duplicate for " + entry.getSocialNetworkID());
                break;
            }
        }
        for (BotInfoBean entry : botsInfoBean.getBotsInfo().values()) {
            if (entry.getBlinds().size() == 0) {
                result = false;
                LOGGER.warn("validationBotsInfoBean. Empty blinds for " + entry.getSocialNetworkID());
                break;
            }
        }
        LOGGER.debug("validationBotsInfoBean completed: " + String.valueOf(result));
        return result;
    }

    /**
     * Equals bots info bean
     *
     * @return true if equals
     */
    private boolean equalsBotsInfoBean() {
        LOGGER.debug("equalsBotsInfoBean");
        boolean result = true;
        botsForRemove.clear();
        botsForAdd.clear();
        for (Map.Entry<String, BotInfoBean> entry : botsInfoBean.getBotsInfo().entrySet()) {
            if (bots.containsKey(entry.getKey())) {
                if (!entry.getValue().equals(bots.get(entry.getKey()).getBotInfoBean())) {
                    botsForRemove.add(entry.getKey());
                    botsForAdd.add(entry.getKey());
                    result = false;
                }
            } else {
                botsForAdd.add(entry.getKey());
                result = false;
            }
        }
        for (Map.Entry<String, Bot> entry : bots.entrySet()) {
            if (!botsInfoBean.getBotsInfo().containsKey(entry.getKey())) {
                botsForRemove.add(entry.getKey());
                result = false;
            }
        }
        //check bot status
        for (Bot bot : bots.values()) {
            if (BotStatus.ERROR.equals(bot.getStatus())) {
                if (!botsForRemove.contains(bot.getBotInfoBean().getSocialNetworkID())) {
                    botsForRemove.add(bot.getBotInfoBean().getSocialNetworkID());
                    LOGGER.warn("In removeBot add bot " + bot.getBotInfoBean().getSocialNetworkID() + " with ERROR status");
                    result = false;
                }
            }
        }
        LOGGER.debug("equalsBotsInfoBean completed: " + String.valueOf(result)
                + ". botsForRemove.size(): " + botsForRemove.size() + ". botsForAdd.size(): " + botsForAdd.size());
        return result;
    }

    /**
     * Remove bots
     */
    private void removeBots() {
        for (String id : botsForRemove) {
            Bot bot = bots.remove(id);
            bot.shutdown();
            LOGGER.debug("removeBot: " + id);
        }
    }

    /**
     * Add bots
     */
    private void addBots() {
        for (String id : botsForAdd) {
            BotInfoBean botInfoBean = botsInfoBean.getBotsInfo().get(id);
            Bot bot = new Bot(botInfoBean);
            parameters.put(BotBehaviourLoader.PARAMETER_BOT_BEHAVIOUR_PATH, botBehaviourPathPrefix + botInfoBean.getConf());
            bot.initialization(parameters);
            try {
                bot.open();
                bot.sendLoginCommand();
                bots.put(id, bot);
                LOGGER.debug("addBot: " + id);
            } catch (IOException e) {
                LOGGER.error("Not addBot: " + id, e);
            }
        }
    }

    /**
     * Scheduler runnable
     */
    private class SchedulerRunnable implements Runnable {

        public SchedulerRunnable() {
            super();
        }

        public void run() {
            reinitialization();
        }
    }

}
