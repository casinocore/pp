package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * {com.azoft.poker.loginserver.commandprocessing.command.LoginCommand} for client
 */
public class ClientLoginCommand extends RequestCommand {

    /**
     * Логин пользователя (in)
     */
    private String username;

    /**
     *  Unique user id (out) - Long getUserId() / setUserId(Long UserId)
     */

    /**
     * Name - Имя сервера (out)
     */
    private String serverName;

    /**
     * Path - IP адрес сервера и порт (out)
     */
    private String serverPath;

    /**
     * Daily bonus
     */
    private Long dailyBonus;

    /**
     * Friend bonus
     */
    private Long friendBonus;

    /**
     * Active friend number
     */
    private Integer activeFriendNumber;

    /**
     * New friend bonus
     */
    private Long newFriendBonus;

    /**
     * New friend number
     */
    private Integer newFriendNumber;

    /**
     * Total bonus
     */
    private Long totalBonus;

    public ClientLoginCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getServerPath() {
        return serverPath;
    }

    public void setServerPath(String serverPath) {
        this.serverPath = serverPath;
    }

    public Long getDailyBonus() {
        return dailyBonus;
    }

    public void setDailyBonus(Long dailyBonus) {
        this.dailyBonus = dailyBonus;
    }

    public Long getFriendBonus() {
        return friendBonus;
    }

    public void setFriendBonus(Long friendBonus) {
        this.friendBonus = friendBonus;
    }

    public Integer getActiveFriendNumber() {
        return activeFriendNumber;
    }

    public void setActiveFriendNumber(Integer activeFriendNumber) {
        this.activeFriendNumber = activeFriendNumber;
    }

    public Long getNewFriendBonus() {
        return newFriendBonus;
    }

    public void setNewFriendBonus(Long newFriendBonus) {
        this.newFriendBonus = newFriendBonus;
    }

    public Integer getNewFriendNumber() {
        return newFriendNumber;
    }

    public void setNewFriendNumber(Integer newFriendNumber) {
        this.newFriendNumber = newFriendNumber;
    }

    public Long getTotalBonus() {
        return totalBonus;
    }

    public void setTotalBonus(Long totalBonus) {
        this.totalBonus = totalBonus;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientLoginCommand{" +
                "username='" + username + '\'' +
                ", userId='" + getUserId() + '\'' +
                ", serverName='" + serverName + '\'' +
                ", serverPath='" + serverPath + '\'' +
                ", dailyBonus='" + dailyBonus + '\'' +
                ", friendBonus='" + friendBonus + '\'' +
                ", activeFriendNumber='" + activeFriendNumber + '\'' +
                ", newFriendBonus='" + newFriendBonus + '\'' +
                ", newFriendNumber='" + newFriendNumber + '\'' +
                ", totalBonus='" + totalBonus + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            setUserId(dis.readLong());
            serverName = dis.readUTF();
            serverPath = dis.readUTF();
            dailyBonus = dis.readLong();
            friendBonus = dis.readLong();
            activeFriendNumber = dis.readInt();
            newFriendBonus = dis.readLong();
            newFriendNumber = dis.readInt();
            totalBonus = dis.readLong();
        }
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            //encode content
            dos.writeUTF(username);
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}