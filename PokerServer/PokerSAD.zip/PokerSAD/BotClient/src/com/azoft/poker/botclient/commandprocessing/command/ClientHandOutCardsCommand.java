package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ClientHandOutCardsCommand extends Command {

    /**
     * Player info (in)
     */
    private List<Card> preFlop;

    public ClientHandOutCardsCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientHandOutCardsCommand{" +
                "preFlop='" + preFlop + '\'' + '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
        preFlop = new ArrayList<Card>();
        for (int i = 0; i < 2; i++) {
            byte suit = dis.readByte();
            byte value = dis.readByte();
            Card card = new Card(value, suit);
            preFlop.add(card);
        }
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content
        for (Card card : preFlop) {
            dos.writeByte(card.getSuit());
            dos.writeByte(card.getValue());
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public List<Card> getPreFlop() {
        return preFlop;
    }

    public void setPreFlop(List<Card> preFlop) {
        this.preFlop = preFlop;
    }

}
