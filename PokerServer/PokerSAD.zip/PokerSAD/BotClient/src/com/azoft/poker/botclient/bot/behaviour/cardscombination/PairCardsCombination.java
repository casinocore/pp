package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;

import java.util.List;

/**
 * Pair cards combination
 */
public class PairCardsCombination extends CardsCombination {

    public PairCardsCombination(String name, CardsCombinationType type) {
        super(name, type);
    }

    public PairCardsCombination(String name, CardsCombinationType type, Byte value) {
        super(name, type, value);
    }

    protected boolean isInside(List<Card> cards) {
        return cards.get(0).getValue() == cards.get(1).getValue() && cards.get(0).getValue() >= getValue();
    }

}
