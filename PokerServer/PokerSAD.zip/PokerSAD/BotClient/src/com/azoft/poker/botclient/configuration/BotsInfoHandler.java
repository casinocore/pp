package com.azoft.poker.botclient.configuration;

import com.azoft.poker.common.jaxp.AbstractHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Bots info handler
 */
public class BotsInfoHandler extends AbstractHandler<BotsInfoBean> {

    private final static Logger LOGGER = LoggerFactory.getLogger(BotsInfoHandler.class);

    private BotInfoBean botInfoBean;
    private BotsInfoBean botsInfoBean;
    private long errorCounter = 0;

    public BotsInfoHandler() {
        botsInfoBean = new BotsInfoBean();
        setBean(botsInfoBean);
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) {
        text = "";
        String tag = getTag(lName, qName);
        if (tag.equals("bots")) {
            botsInfoBean.getBotsInfo().clear();
        } else if (tag.equals("bot")) {
            botInfoBean = new BotInfoBean();
        }
    }

    @Override
    public void endElement(String uri, String lName, String qName) throws SAXException {
        String tag = getTag(lName, qName);
        if (tag.equals("bots")) {
            botsInfoBean.setIfNullProcessingResult(RESULT_SUCCESS);
        } else if (tag.equals("bot")) {
            botsInfoBean.addBotInfoBean(botInfoBean);
        } else if (tag.equals("login")) {
            botInfoBean.setLogin(text);
        } else if (tag.equals("password")) {
            botInfoBean.setPassword(text);
        } else if (tag.equals("id")) {
            botInfoBean.setSocialNetworkID(text);
        } else if (tag.equals("first-name")) {
            botInfoBean.setFirstName(text);
        } else if (tag.equals("last-name")) {
            botInfoBean.setLastName(text);
        } else if (tag.equals("big-blind")) {
            try {
                Long blind = Long.parseLong(text);
                botInfoBean.addBlind(blind);
            } catch (NumberFormatException e) {
                String message = "Invalid format 'big-blind': '" + text + "'";
                bean.setProcessingResult(RESULT_ERROR);
                bean.addErrorMessage(++errorCounter, message);
                LOGGER.error(message);
            }
        } else if (tag.equals("new-table")) {
            boolean newTable = text != null && ("yes".equalsIgnoreCase(text) || "true".equalsIgnoreCase(text));
            botInfoBean.setNewTable(newTable);
        } else if (tag.equals("conf")) {
            botInfoBean.setConf(text);
        }
    }

}
