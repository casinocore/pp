package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.bot.behaviour.BankStatusTypeID;
import com.azoft.poker.botclient.commandprocessing.command.ClientHandOutCardsCommand;
import com.azoft.poker.lobbyserver.tableprocessing.DealType;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ClientHandOutCardsHandler extends ClientHandler<ClientHandOutCardsCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientHandOutCardsHandler.class);

    public ClientHandOutCardsHandler() {
        super();
    }

    public void execute(ClientHandOutCardsCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        bot.setStatus(BotStatus.HAND_OUT_CARDS);
        bot.setDealType(DealType.PRE_FLOP);
        List<Card> cards = command.getPreFlop();
        bot.setCards(cards);
        bot.setBankStatusTypeID(BankStatusTypeID.CLOSE_BANK);
        bot.setLastRaise((long) bot.getTable().getBigBlind());
        LOGGER.debug("ClientHandOutCardsHandler completed for bot: " + bot.toString());
    }

}