package com.azoft.poker.botclient.configuration.behaviour;

import com.azoft.poker.common.jaxp.AbstractXMLLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

/**
 * Bot behaviourBean loader
 */
public class BotBehaviourLoader extends AbstractXMLLoader {

    private final static Logger LOGGER = LoggerFactory.getLogger(BotBehaviourLoader.class);

    /**
     * Bot behaviour path parameter
     */
    public static final String PARAMETER_BOT_BEHAVIOUR_PATH = "BOT_BEHAVIOUR_PATH";

    /**
     * XML document path
     */
    private String botBehaviourPath;

    /**
     * Bot behaviour bean
     */
    private BotBehaviourBean behaviourBean;

    public BotBehaviourLoader(String botsInfoPath) {
        super();
        this.botBehaviourPath = botsInfoPath;
    }

    public BotBehaviourBean getBehaviourBean() {
        return behaviourBean;
    }

    public void load() {
        ParametrisedBehaviourHandler botBehaviourHandler = new ParametrisedBehaviourHandler();
        try {
            load(botBehaviourPath, botBehaviourHandler);
            behaviourBean = botBehaviourHandler.getBean();
        } catch (SAXException e) {
            LOGGER.error("load", e);
        } catch (ParserConfigurationException e) {
            LOGGER.error("load", e);
        } catch (IOException e) {
            LOGGER.error("load", e);
        }
    }

}