package com.azoft.poker.botclient.tableprocessing;

import com.azoft.poker.lobbyserver.tableprocessing.TableImpl;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;

/**
 * Client table
 */
public class ClientTable extends TableImpl {

    private final static byte FREE_PLACE_COUNT = 2;

    public ClientTable() {
        super((byte) 0);
    }

    public ClientTable(byte playerCountMax) {
        super(playerCountMax);
    }

    public boolean checkFreePlace() {
        return getPlayerCountMax() - getPlayerCount() > FREE_PLACE_COUNT;
    }

    public boolean checkExitBot() {
        return getPlayerCountMax() - getPlayerCount() < FREE_PLACE_COUNT;
    }

    protected void initializationTableStateListener() {
        //empty
    }

    public void notifyAboutNewPlayer(Player player) {
        //empty
    }

    public boolean addPlayer(Player player, boolean isCreateEmptyTable) {
        return getPlayers().add(player);
    }

}
