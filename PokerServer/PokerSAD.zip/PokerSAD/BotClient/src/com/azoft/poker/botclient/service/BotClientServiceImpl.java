package com.azoft.poker.botclient.service;

import com.azoft.poker.common.service.LifecycleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Bot client service
 */
public class BotClientServiceImpl implements LifecycleService {

    private final static Logger LOGGER = LoggerFactory.getLogger(BotClientServiceImpl.class);

    private List<LifecycleService> lifecycleServices = new CopyOnWriteArrayList<LifecycleService>();

    private static LifecycleService instance = null;

    public static synchronized LifecycleService getInstance() {
        if (instance == null) {
            instance = new BotClientServiceImpl();
        }
        return instance;
    }

    private BotClientServiceImpl() {
        super();
    }

    /**
     * Register lifecycle service
     *
     * @param lifecycleService lifecycle service
     */
    public void registerLifecycleService(LifecycleService lifecycleService) {
        if (!lifecycleServices.contains(lifecycleService)) {
            lifecycleServices.add(lifecycleService);
        }
    }

    public void initialization(Map<String, Object> parameters) {
        //Initialization
        LifecycleService botsConfigurationService = BotsConfigurationServiceImpl.getInstance();
        botsConfigurationService.initialization(parameters);

        //Register lifecycle services
        registerLifecycleService(botsConfigurationService);
    }

    public void shutdown() {
        for (LifecycleService lifecycleService : lifecycleServices) {
            lifecycleService.shutdown();
        }
    }

}
