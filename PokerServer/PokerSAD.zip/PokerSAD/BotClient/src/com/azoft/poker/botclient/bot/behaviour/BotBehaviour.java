package com.azoft.poker.botclient.bot.behaviour;

import com.azoft.poker.botclient.commandprocessing.handler.ClientHandler;
import com.azoft.poker.botclient.configuration.behaviour.BotBehaviourBean;
import com.azoft.poker.botclient.helper.RandomHelper;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Bot behaviour
 */
public abstract class BotBehaviour<BeanType extends BotBehaviourBean> extends ClientHandler<Command> {

    private final static Logger LOGGER = LoggerFactory.getLogger(BotBehaviour.class);

    private static final long SEC_MSEC = 1000;

    private static final int DEFAULT_MIN_TIMEOUT = 1;

    private static final int DEFAULT_MAX_TIMEOUT = 10;

    private BeanType bean;

    protected BotBehaviour() {
    }

    public BeanType getBean() {
        return bean;
    }

    public void setBean(BeanType bean) {
        this.bean = bean;
        if (this.bean.getMinTimeout() == null) {
            this.bean.setMinTimeout(DEFAULT_MIN_TIMEOUT);
        }
        if (this.bean.getMaxTimeout() == null) {
            this.bean.setMaxTimeout(DEFAULT_MAX_TIMEOUT);
        }
    }

    @Override
    public void execute(Command command) {
        long timeout = RandomHelper.getRandomInt(bean.getMaxTimeout());
        if (timeout < bean.getMinTimeout()) {
            timeout = bean.getMinTimeout();
        }
        try {
            //LOGGER.debug("Sleep for behaviour. Timeout: " + timeout);
            Thread.sleep(timeout * SEC_MSEC);
        } catch (InterruptedException e) {
            LOGGER.error("Sleep for behaviour. Timeout: " + timeout, e);
        }
    }

}
