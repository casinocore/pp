package com.azoft.poker.botclient.bot.behaviour.cardscombination;

/**
 * Cards combination type
 */
public enum CardsCombinationType {

    ANY,
    FACE,
    TWO_FACE,
    SUIT,
    PAIR,
    CONNECTOR,
    SUIT_CONNECTOR,
    POKER_HAND_TYPE

}
