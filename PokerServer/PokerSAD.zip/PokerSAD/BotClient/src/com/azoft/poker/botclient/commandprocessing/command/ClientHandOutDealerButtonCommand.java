package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


public class ClientHandOutDealerButtonCommand extends Command {

    /**
     * Place identifier (in)
     */
    private Byte placeId;

    /**
     * lead time (in)
     */
    private Byte leadTime;

    public ClientHandOutDealerButtonCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientHandOutDealerButtonCommand{" +
                "userId='" + getUserId() + '\'' + "," +
                "placeId='" + placeId + '\'' + "," +
                "leadTime='" + leadTime + '\'' + '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
        super.decodeBody(dis);
        placeId = dis.readByte();
        leadTime = dis.readByte();
    }

    public void encodeBody(DataOutputStream out) throws IOException {
    }

    public Byte getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    public Byte getLeadTime() {
        return leadTime;
    }

    public void setLeadTime(Byte leadTime) {
        this.leadTime = leadTime;
    }

}
