package com.azoft.poker.botclient.configuration.behaviour;

import com.azoft.poker.botclient.bot.behaviour.BankStatusTypeID;
import com.azoft.poker.lobbyserver.tableprocessing.lead.LeadType;

import java.util.Map;
import java.util.TreeMap;

/**
 * Bot deal bean
 */
public class BotDealBean {

    /**
     * Bank bean map (key: position, value: Map.key: bank status type Id, Map.value: BankBean)
     */
    private Map<Byte, Map<Byte, BankBean>> bankBeanMap = new TreeMap<Byte, Map<Byte, BankBean>>();

    public BotDealBean() {
    }

    public void putBankBean(Byte position, BankStatusTypeID bankStatus, BankBean bankBean) {
        Map<Byte, BankBean> map = bankBeanMap.get(position);
        if (map == null) {
            map = new TreeMap<Byte, BankBean>();
            bankBeanMap.put(position, map);
        }
        map.put(bankStatus.getTypeId(), bankBean);
    }

    public BankBean getBankBean(Byte position, BankStatusTypeID bankStatus) {
        return getBankBean(position, bankStatus.getTypeId());
    }

    public BankBean getBankBean(Byte position, Byte bankStatusTypeId) {
        BankBean result = null;
        Map<Byte, BankBean> map = bankBeanMap.get(position);
        if (map != null) {
            result = map.get(bankStatusTypeId);
        }
        return result;
    }

    public BankBean findBankBean(Byte position, BankStatusTypeID bankStatus) {
        BankBean result = null;
        while (result == null && position >= 0) {
            byte bankStatusTypeId = bankStatus.getTypeId();
            while (result == null && bankStatusTypeId >= 0) {
                result = getBankBean(position, bankStatusTypeId);
                bankStatusTypeId--;
            }
            position--;
        }
        return result;
    }

}
