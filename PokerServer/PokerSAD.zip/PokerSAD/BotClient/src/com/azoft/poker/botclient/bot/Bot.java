package com.azoft.poker.botclient.bot;

import com.azoft.poker.botclient.bot.behaviour.BankStatusTypeID;
import com.azoft.poker.botclient.bot.behaviour.BotBehaviour;
import com.azoft.poker.botclient.bot.behaviour.CautiousBehaviour;
import com.azoft.poker.botclient.codec.ClientCommandDecoder;
import com.azoft.poker.botclient.commandprocessing.ClientCommandFactoryImpl;
import com.azoft.poker.botclient.commandprocessing.command.ClientLoginCommand;
import com.azoft.poker.botclient.commandprocessing.command.ClientRegisterOnServerCommand;
import com.azoft.poker.botclient.configuration.BotInfoBean;
import com.azoft.poker.botclient.configuration.behaviour.BotBehaviourBean;
import com.azoft.poker.botclient.configuration.behaviour.BotBehaviourLoader;
import com.azoft.poker.botclient.tableprocessing.ClientTable;
import com.azoft.poker.botclient.tableprocessing.bet.PlayersBets;
import com.azoft.poker.common.commandprocessing.CommandProcessorImpl;
import com.azoft.poker.common.commandprocessing.CommandProcessorType;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.LifecycleCommandProcessor;
import com.azoft.poker.common.communicator.CommandSessionHandler;
import com.azoft.poker.common.communicator.MinaClientImpl;
import com.azoft.poker.common.helper.StringHelper;
import com.azoft.poker.common.service.LifecycleService;
import com.azoft.poker.lobbyserver.commandprocessing.command.ExitFromLobbyCommand;
import com.azoft.poker.lobbyserver.tableprocessing.DealType;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Bot
 */
public class Bot implements LifecycleService {

    private final static Logger LOGGER = LoggerFactory.getLogger(Bot.class);

    /**
     * Bot parameter
     */
    public static final String PARAMETER_BOT = "PARAMETER_BOT";

    /**
     * Bot processor termination timeout
     */
    private final static long BOT_PROCESSOR_TERMINATION_TIMEOUT = 1000 * 10;

    /**
     * Default bot behaviour class
     */
    public static final String DEFAULT_BOT_BEHAVIOUR_CLASS = "com.azoft.poker.botclient.bot.behaviour.CautiousBehaviour";
    /**
     * Bot info bean
     */
    private final BotInfoBean botInfoBean;

    /**
     * Lifecycle command processor
     */
    private final LifecycleCommandProcessor processor;

    /**
     * Client communicator
     */
    private MinaClientImpl communicator;

    /**
     * Parameters
     */
    private Map<String, Object> parameters;

    /**
     * Bot status
     */
    private BotStatus status;

    /**
     * User id
     */
    private Long userId;

    /**
     * Place id
     */
    private Byte placeId;

    /**
     * Deal type
     */
    private DealType dealType;

    /**
     * Cards
     */
    private List<Card> cards = new ArrayList<Card>();

    /**
     * Bank status type ID
     */
    private BankStatusTypeID bankStatusTypeID;

    /**
     * Last raise
     */
    private Long lastRaise;

    /**
     * Dealer button
     */
    private Byte dealerButton;

    /**
     * Tables
     */
    private List<Table> tables;

    /**
     * Table
     */
    private ClientTable table;

    /**
     * Load flag
     */
    private boolean loadFlag = false;

    /**
     * Behaviour
     */
    private BotBehaviour behaviour;

    /**
     * Players bets
     */
    private PlayersBets playersBets;

    public Bot(BotInfoBean botInfoBean) {
        this.botInfoBean = botInfoBean;
        playersBets = new PlayersBets();
        processor = new CommandProcessorImpl(CommandProcessorType.BOT_PROCESSOR, BOT_PROCESSOR_TERMINATION_TIMEOUT);
        communicator = new MinaClientImpl();
        this.status = BotStatus.NEW;
    }

    public BotInfoBean getBotInfoBean() {
        return botInfoBean;
    }

    public BotStatus getStatus() {
        return status;
    }

    public void setStatus(BotStatus status) {
        this.status = status;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
        playersBets.setId(userId);
    }

    public Byte getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    public DealType getDealType() {
        return dealType;
    }

    public void setDealType(DealType dealType) {
        this.dealType = dealType;
    }

    public List<Card> getCards() {
        return cards;
    }

    public void setCards(List<Card> cards) {
        this.cards = cards;
    }

    public void addCards(List<Card> cards) {
        this.cards.addAll(cards);
    }

    public BankStatusTypeID getBankStatusTypeID() {
        return bankStatusTypeID;
    }

    public void setBankStatusTypeID(BankStatusTypeID bankStatusTypeID) {
        this.bankStatusTypeID = bankStatusTypeID;
    }

    public Long getLastRaise() {
        return lastRaise;
    }

    public void setLastRaise(Long lastRaise) {
        this.lastRaise = lastRaise;
    }

    public Byte getDealerButton() {
        return dealerButton;
    }

    public void setDealerButton(Byte dealerButton) {
        this.dealerButton = dealerButton;
    }

    public List<Table> getTables() {
        return tables;
    }

    public void setTables(List<Table> tables) {
        this.tables = tables;
    }

    public ClientTable getTable() {
        return table;
    }

    public void setTable(ClientTable table) {
        this.table = table;
    }

    public BotBehaviour getBehaviour() {
        return behaviour;
    }

    public PlayersBets getPlayersBets() {
        return playersBets;
    }

    public void initialization(Map<String, Object> parameters) {
        this.parameters = new HashMap<String, Object>(parameters);
        initializationParameters(this.parameters);
        loadBehaviour();
        if (loadFlag) {
            processor.initialization(null);
            communicator.initialization(this.parameters);
        }
    }

    public void shutdown() {
        if (loadFlag) {
            sendExitFromLobbyCommand();
            communicator.shutdown();
            processor.shutdown();
        }
        LOGGER.info("Shutdown bot: " + this.toString());
    }

    private void initializationParameters(Map<String, Object> parameters) {
        parameters.put(MinaClientImpl.HANDLER_ADAPTER_PARAMETER, new CommandSessionHandler(processor));
        parameters.put(MinaClientImpl.COMMAND_DECODER_PARAMETER, ClientCommandDecoder.class);
    }

    public void loadBehaviour() {
        LOGGER.debug("loadBehaviour");
        String botBehaviourPath = (String) parameters.get(BotBehaviourLoader.PARAMETER_BOT_BEHAVIOUR_PATH);
        BotBehaviourLoader configurationBehaviour = new BotBehaviourLoader(botBehaviourPath);
        configurationBehaviour.load();
        BotBehaviourBean behaviourBean = configurationBehaviour.getBehaviourBean();
        if (behaviourBean.isSuccessResult()) {
            loadFlag = true;
            String behaviourClass = behaviourBean.getBehaviourClass();
            if (StringHelper.isEmptyTrimmed(behaviourClass)) {
                behaviourClass = DEFAULT_BOT_BEHAVIOUR_CLASS;
                LOGGER.warn("Default behaviour class: " + behaviourClass + " for bot: " + this.toString());
            } else {
                LOGGER.debug("Behaviour class: " + behaviourClass + " for bot: " + this.toString());
            }
            try {
                behaviour = (BotBehaviour) ClassLoader.getSystemClassLoader().loadClass(behaviourClass).getConstructor().newInstance();
            } catch (Exception e) {
                LOGGER.error("Load behaviour class for bot: " + this.toString(), e);
            }
            if (behaviour == null) {
                behaviour = new CautiousBehaviour();
                LOGGER.warn("Default behaviour class: " + behaviour.getClass().getName() + " for bot: " + this.toString());
            }
            behaviour.setBean(behaviourBean);
        } else {
            status = BotStatus.ERROR;
        }
    }

    public void open() throws IOException {
        Map<String, Object> sessionParameters = new HashMap<String, Object>();
        sessionParameters.put(PARAMETER_BOT, this);
        communicator.open(sessionParameters);
    }

    public void shutdownLoginAndInitializationLobby(Integer serverPort, String serverAddress) {
        parameters.put(MinaClientImpl.SERVER_PORT_PARAMETER, serverPort);
        parameters.put(MinaClientImpl.SERVER_ADDRESS_PARAMETER, serverAddress);

        communicator.shutdown();
        communicator = new MinaClientImpl();
        communicator.initialization(this.parameters);
        try {
            open();
            sendRegisterOnServerCommand();
        } catch (IOException e) {
            status = BotStatus.ERROR;
            LOGGER.error("Not open lobby server for bot: " + botInfoBean.getLogin(), e);
        }
    }

    public void sendLoginCommand() {
        try {
            ClientLoginCommand cmd = (ClientLoginCommand) ClientCommandFactoryImpl.createClientCommand(
                    communicator.getSession(), CommandTypeID.LOGIN.getTypeId());
            cmd.setUsername(getBotInfoBean().getLogin());
            cmd.send();
        } catch (Exception e) {
            status = BotStatus.ERROR;
            LOGGER.error("Create and send command: LOGIN", e);
        }
    }

    private void sendRegisterOnServerCommand() {
        try {
            ClientRegisterOnServerCommand cmd = (ClientRegisterOnServerCommand) ClientCommandFactoryImpl.createClientCommand(
                    communicator.getSession(), CommandTypeID.REGISTER_ON_SERVER.getTypeId());
            cmd.setUserId(userId);
            cmd.send();
        } catch (Exception e) {
            status = BotStatus.ERROR;
            LOGGER.error("Create and send command: REGISTER_ON_SERVER", e);
        }
    }

    private void sendExitFromLobbyCommand() {
        if (BotStatus.SIT.equals(status)) {
            try {
                ExitFromLobbyCommand cmd = (ExitFromLobbyCommand) ClientCommandFactoryImpl.createClientCommand(
                        communicator.getSession(), CommandTypeID.EXIT_FROM_LOBBY.getTypeId());
                cmd.send();
                status = BotStatus.EXIT_FROM_LOBBY;
            } catch (Exception e) {
                status = BotStatus.ERROR;
                LOGGER.error("Create and send command: EXIT_FROM_LOBBY", e);
            }
        }
    }

    @Override
    public String toString() {
        return "Bot{" +
                "status=" + status +
                ", botInfoBean=" + botInfoBean +
                ", userId=" + userId +
                ", placeId=" + placeId +
                ", table=" + table +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Bot bot = (Bot) o;

        return botInfoBean.equals(bot.botInfoBean);

    }

    @Override
    public int hashCode() {
        return botInfoBean.hashCode();
    }

}
