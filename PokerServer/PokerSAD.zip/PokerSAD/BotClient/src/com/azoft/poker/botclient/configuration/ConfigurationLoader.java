package com.azoft.poker.botclient.configuration;

import com.azoft.poker.common.jaxp.AbstractXMLLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

/**
 * Configuration loader
 */
public class ConfigurationLoader extends AbstractXMLLoader {

    private final static Logger LOGGER = LoggerFactory.getLogger(ConfigurationLoader.class);

    /**
     * Configuration bots info path parameter
     */
    public static final String PARAMETER_BOTS_INFO_PATH = "BOTS_INFO_PATH";

    /**
     * Configuration scheduler period parameter
     */
    public final static String PARAMETER_CONFIGURATION_PERIOD = "CONFIGURATION_PERIOD";

    /**
     * Default configuration scheduler initial delay
     */
    public final static long DEFAULT_CONFIGURATION_INITIAL_DELAY = 0;

    /**
     * Default configuration scheduler period (minutes)
     */
    public final static long DEFAULT_CONFIGURATION_PERIOD = 15;

    /**
     * Default bots info path
     */
    public static final String DEFAULT_BOTS_INFO_PATH = "configuration/bots_info.xml";

    /**
     * XML document path
     */
    private String botsInfoPath;

    /**
     * Bots info bean
     */
    private BotsInfoBean botsInfoBean;

    public ConfigurationLoader(String botsInfoPath) {
        super();
        this.botsInfoPath = botsInfoPath;
    }

    public BotsInfoBean getBotsInfoBean() {
        return botsInfoBean;
    }

    public void load() {
        BotsInfoHandler botsInfoHandler = new BotsInfoHandler();
        try {
            load(botsInfoPath, botsInfoHandler);
            botsInfoBean = botsInfoHandler.getBean();
        } catch (SAXException e) {
            LOGGER.error("load", e);
        } catch (ParserConfigurationException e) {
            LOGGER.error("load", e);
        } catch (IOException e) {
            LOGGER.error("load", e);
        }
    }

}
