package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.botclient.tableprocessing.ClientTable;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClientSitCommand extends RequestCommand {

    /**
     * Place id (in)
     */
    private Byte placeId;

    private Table table;

    public ClientSitCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Byte getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    public Table getTable() {
        return table;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientSitCommand{" +
                "userId='" + getUserId() + '\'' +
                ", placeId='" + placeId + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            table = new ClientTable();
            ClientJoinTableCommand.readTable(dis, table);
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        dos.writeByte(placeId);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
