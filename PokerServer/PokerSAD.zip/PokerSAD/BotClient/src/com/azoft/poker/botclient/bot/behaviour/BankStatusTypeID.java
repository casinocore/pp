package com.azoft.poker.botclient.bot.behaviour;

/**
 * Bank status type ID
 */
public enum BankStatusTypeID {

    CLOSE_BANK((byte) 0),
    CALL_LEAD((byte) 1),
    RAISE_LEAD((byte) 2),
    MULTI_RAISE((byte) 3);

    private byte typeId;

    public byte getTypeId() {
        return typeId;
    }

    BankStatusTypeID(byte leadId) {
        this.typeId = leadId;
    }

    public static BankStatusTypeID valueOf(byte bankStatusId) {
        BankStatusTypeID result = null;
        for (BankStatusTypeID bankStatusTypeID : BankStatusTypeID.values()) {
            if (bankStatusTypeID.getTypeId() == bankStatusId) {
                result = bankStatusTypeID;
                break;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "BankStatusTypeID{" +
                "name=" + name() +
                ", typeId=" + typeId +
                '}';
    }

}
