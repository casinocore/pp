package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.behaviour.BotBehaviour;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Bot behaviour handler
 */
public class BotBehaviourHandler extends ClientHandler<Command> {

    private final static Logger LOGGER = LoggerFactory.getLogger(BotBehaviourHandler.class);

    public BotBehaviourHandler() {
        super();
    }

    public void execute(Command command) {
        Bot bot = getBotAttribute(command.getSession());
        BotBehaviour behaviour = bot.getBehaviour();
        LOGGER.debug("Move command: " + command.toString() + " to behaviour for bot: " + bot.toString());
        behaviour.execute(command);
    }

}
