package com.azoft.poker.botclient.commandprocessing;

import com.azoft.poker.botclient.commandprocessing.command.*;
import com.azoft.poker.botclient.commandprocessing.handler.*;
import com.azoft.poker.common.commandprocessing.CommandFactory;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.common.commandprocessing.command.EmptyCommand;
import com.azoft.poker.common.commandprocessing.handler.ExitHandler;
import com.azoft.poker.common.commandprocessing.handler.HandlersRegister;
import com.azoft.poker.lobbyserver.commandprocessing.command.ExitFromLobbyCommand;
import org.apache.mina.core.session.IoSession;

public class ClientCommandFactoryImpl implements CommandFactory {

    public ClientCommandFactoryImpl() {
        super();
        handlersRegister();
    }

    private void handlersRegister() {
        HandlersRegister.setHandler(CommandTypeID.LOGIN, new ClientLoginHandler());
        HandlersRegister.setHandler(CommandTypeID.REGISTER, new ClientRegisterHandler());
        HandlersRegister.setHandler(CommandTypeID.EXIT_FROM_LOGIN, new ExitHandler());
        HandlersRegister.setHandler(CommandTypeID.EXIT_FROM_LOBBY, new ExitHandler());
        HandlersRegister.setHandler(CommandTypeID.REGISTER_ON_SERVER, new ClientRegisterOnServerHandler());
        HandlersRegister.setHandler(CommandTypeID.GET_LOBBY_CASH, new ClientGetLobbyCashHandler());
        HandlersRegister.setHandler(CommandTypeID.JOIN_TABLE, new ClientJoinTableHandler());
        HandlersRegister.setHandler(CommandTypeID.NOTIFY_ABOUT_NEW_PLAYER, new ClientNotifyAboutNewPlayerHandler());
        HandlersRegister.setHandler(CommandTypeID.HAND_OUT_DEALER_BUTTON, new ClientHandOutDealerButtonHandler());
        HandlersRegister.setHandler(CommandTypeID.SIT, new ClientSitHandler());
        HandlersRegister.setHandler(CommandTypeID.HAND_OUT_CARDS, new ClientHandOutCardsHandler());
        HandlersRegister.setHandler(CommandTypeID.DEAL_OUT, new ClientDealOutHandler());
        HandlersRegister.setHandler(CommandTypeID.DEAL_FINISHED, new ClientDealFinishedHandler());
        HandlersRegister.setHandler(CommandTypeID.NOTIFY_ABOUT_PLAYER_EXIT, new ClientNotifyAboutPlayerExitHandler());
        HandlersRegister.setHandler(CommandTypeID.NOTIFY_TABLE_CLOSED, new ClientNotifyTableClosedHandler());

        //commands for bot behaviour
        HandlersRegister.setHandler(CommandTypeID.NOTIFY_ABOUT_THE_LEAD, new BotBehaviourHandler());

        //temp - commands for log handler
        HandlersRegister.setHandler(CommandTypeID.PLAY_NOW, new LogHandler());
        HandlersRegister.setHandler(CommandTypeID.LEAD, new LogHandler());
        HandlersRegister.setHandler(CommandTypeID.NOTIFY_COMBINATION, new LogHandler());
    }

    public Command createCommand(IoSession session, short typeID) throws Exception {
        return createClientCommand(session, typeID);
    }

    public static Command createClientCommand(IoSession session, short typeID) throws Exception {
        Command command = null;
        int bodySize = 0;
        CommandTypeID commandTypeID = CommandTypeID.valueOf(typeID);
        if (commandTypeID != null) {
            //clients commands - login
            if (CommandTypeID.LOGIN.equals(commandTypeID)) {
                command = new ClientLoginCommand(session, commandTypeID);
            } else if (CommandTypeID.REGISTER.equals(commandTypeID)) {
                command = new ClientRegisterCommand(session, commandTypeID);
            } else if (CommandTypeID.EXIT_FROM_LOGIN.equals(commandTypeID)) {
                command = new EmptyCommand(session, commandTypeID);
                //clients commands - lobby
            } else if (CommandTypeID.EXIT_FROM_LOBBY.equals(commandTypeID)) {
                command = new ExitFromLobbyCommand(session, commandTypeID);
            } else if (CommandTypeID.REGISTER_ON_SERVER.equals(commandTypeID)) {
                command = new ClientRegisterOnServerCommand(session, commandTypeID);
            } else if (CommandTypeID.GET_LOBBY_CASH.equals(commandTypeID)) {
                command = new ClientGetLobbyCashCommand(session, commandTypeID);
            } else if (CommandTypeID.JOIN_TABLE.equals(commandTypeID)) {
                command = new ClientJoinTableCommand(session, commandTypeID);
            } else if (CommandTypeID.SIT.equals(commandTypeID)) {
                command = new ClientSitCommand(session, commandTypeID);
            } else if (CommandTypeID.PLAY_NOW.equals(commandTypeID)) {
                command = new ClientPlayNowCommand(session, commandTypeID);
            } else if (CommandTypeID.NOTIFY_ABOUT_NEW_PLAYER.equals(commandTypeID)) {
                command = new ClientNotifyAboutNewPlayerCommand(session, commandTypeID);
            } else if (CommandTypeID.HAND_OUT_DEALER_BUTTON.equals(commandTypeID)) {
                command = new ClientHandOutDealerButtonCommand(session, commandTypeID);
            } else if (CommandTypeID.HAND_OUT_CARDS.equals(commandTypeID)) {
                command = new ClientHandOutCardsCommand(session, commandTypeID);
            } else if (CommandTypeID.LEAD.equals(commandTypeID)) {
                command = new ClientLeadCommand(session, commandTypeID);
            } else if (CommandTypeID.NOTIFY_ABOUT_THE_LEAD.equals(commandTypeID)) {
                command = new ClientNotifyAboutTheLeadCommand(session, commandTypeID);
            } else if (CommandTypeID.DEAL_OUT.equals(commandTypeID)) {
                command = new ClientDealOutCommand(session, commandTypeID);
            } else if (CommandTypeID.DEAL_FINISHED.equals(commandTypeID)) {
                command = new ClientDealFinishedCommand(session, commandTypeID);
            } else if (CommandTypeID.GET_UP.equals(commandTypeID)) {
                command = new ClientGetUpCommand(session, commandTypeID);
            } else if (CommandTypeID.NOTIFY_ABOUT_PLAYER_EXIT.equals(commandTypeID)) {
                command = new ClientNotifyAboutPlayerExitCommand(session, commandTypeID);
            } else if (CommandTypeID.NOTIFY_BANK_READY.equals(commandTypeID)) {
                command = new ClientNotifyAboutBankReadyCommand(session, commandTypeID);
            } else if (CommandTypeID.NOTIFY_TABLE_CLOSED.equals(commandTypeID)) {
                command = new ClientNotifyTableClosedCommand(session, commandTypeID);
            } else if (CommandTypeID.NOTIFY_COMBINATION.equals(commandTypeID)) {
                command = new ClientNotifyCombinationCommand(session, commandTypeID);
            }
        } else {
            throw new Exception("Not exists Command Type ID: " + typeID);
        }
        return command;
    }

}