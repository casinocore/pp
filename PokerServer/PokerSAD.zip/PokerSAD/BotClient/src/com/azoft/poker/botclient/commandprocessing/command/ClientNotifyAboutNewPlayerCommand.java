package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


public class ClientNotifyAboutNewPlayerCommand extends Command {

    /**
     * Player info
     */
    private Player player;

    public ClientNotifyAboutNewPlayerCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientNotifyAboutNewPlayerCommand{" +
                "player='" + player + '\'' + '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        player = new Player();
        player.setId(dis.readLong());
        player.setPlaceId(dis.readByte());
        player.setNetworkUserId(dis.readUTF());
        player.setGameBalance(dis.readLong());
        player.setPlaying(dis.readByte());
        Byte medalsSize = dis.readByte();
        for (int j = 0; j < medalsSize; j++) {
            Byte medalType = dis.readByte();
        }
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
    }

}
