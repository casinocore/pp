package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.command.ClientGetLobbyCashCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientGetLobbyCashHandler extends ClientHandler<ClientGetLobbyCashCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientGetLobbyCashHandler.class);

    public ClientGetLobbyCashHandler() {
        super();
    }

    public void execute(ClientGetLobbyCashCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        if (!command.isExistsError()) {
            bot.setStatus(BotStatus.GET_LOBBY_CASH);
            bot.setTables(command.getTables());
            HandlerHelper.selectTable(command, bot);
        } else {
            bot.setStatus(BotStatus.ERROR);
            LOGGER.error("Error. ClientGetLobbyCashCommand for bot: " + bot.toString());
        }
    }

}