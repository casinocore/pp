package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.botclient.tableprocessing.ClientTable;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientPlayNowCommand extends RequestCommand {

    /**
     *  Unique user id (in) - Long getUserId() / setUserId(Long UserId)
     */

    /**
     * Table (out)
     */
    private Table table = null;

    /**
     * placeId - place identifier at table (out)
     */
    private Byte placeId;

    private Long tournamentId;

    private Player player;

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public ClientPlayNowCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Table getTable() {
        return table;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    public Byte getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    public Long getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Long tournamentId) {
        this.tournamentId = tournamentId;
    }

    @Override
    public String toString() {
        StringBuffer str = new StringBuffer(super.toString());
        str.append(" - ClientPlayNowCommand{").append("userId='").append(getUserId()).append('\'');
        if (table != null) {
            List players = table.getPlayers();
            str.append(", ").append(table).append('\'').append(", playersCount='").append(players.size()).append('\'');
        }
        str.append(", placeId='").append(placeId).append('\'').append('}');
        return str.toString();
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            //decode content
            tournamentId = dis.readLong();
            table = new ClientTable();
            ClientJoinTableCommand.readTable(dis, table);
            int playerCount;

            List<Player> players = new ArrayList<Player>();

            // current player will be added to table's players after PlayNowCommand execution
            playerCount = dis.readByte();
            for (int i = 0; i < playerCount; i++) {
                Player player = new Player();
                player.setId(dis.readLong());
                player.setPlaceId(dis.readByte());
                player.setName(dis.readUTF());
                player.setGameBalance(dis.readLong());
                player.setPlaying(dis.readByte());
                players.add(player);
            }
            table.setPlayers(players);

            placeId = dis.readByte();
        }
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (tournamentId != null) {
            dos.writeLong(tournamentId);
        } else {
            dos.writeLong(0L);
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
