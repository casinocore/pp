package com.azoft.poker.botclient.service;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Bot table manager
 */
public class BotTableManagerImpl implements BotTableManager {

    private final static Map<Long, Date> timestampExitBotMap = new ConcurrentHashMap<Long, Date>();

    private static BotTableManager instance = null;

    public static synchronized BotTableManager getInstance() {
        if (instance == null) {
            instance = new BotTableManagerImpl();
        }
        return instance;
    }

    private BotTableManagerImpl() {
        super();
    }

    private void addExitBotForTable(Long tableId) {
        timestampExitBotMap.put(tableId, new Date());
    }

    public synchronized void removeExitBotForTable(Long tableId) {
        timestampExitBotMap.remove(tableId);
    }

    public synchronized boolean checkExitBotForTable(Long tableId) {
        boolean result = true;
        Date timestampExitBot = timestampExitBotMap.get(tableId);
        if (timestampExitBot != null) {
            result = (new Date().getTime() - timestampExitBot.getTime()) > TIMEOUT_EXIT_BOX;
            if (result) {
                addExitBotForTable(tableId);
            }
        } else {
            addExitBotForTable(tableId);
        }
        return result;
    }
}
