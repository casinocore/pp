package com.azoft.poker.botclient.codec;

import com.azoft.poker.botclient.commandprocessing.ClientCommandFactoryImpl;
import com.azoft.poker.common.codec.AbstractCommandDecoder;

/**
 * Client command decoder
 */
public class ClientCommandDecoder extends AbstractCommandDecoder {

    public ClientCommandDecoder() {
        super();
        setCommandFactory(new ClientCommandFactoryImpl());
    }

}