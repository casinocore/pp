package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ClientRegisterOnServerCommand extends RequestCommand {

    private List<String> friendsSNIDs;

    private PersonSNHeader personSNHeader;

    private List<PersonSNHeader> friendsSNHeaders;

    class PersonSNHeader {
        public Long id;
        public String socialNetworkID;
        public boolean isOnline;
        public Long balance;

        PersonSNHeader() {
        }

        public PersonSNHeader(Long id, String socialNetworkID, boolean isOnline, Long balance) {
            this.id = id;
            this.socialNetworkID = socialNetworkID;
            this.balance = balance;
            this.isOnline = isOnline;
        }

    }

    public List<PersonSNHeader> getFriendsSNHeaders() {
        return friendsSNHeaders;
    }

    public ClientRegisterOnServerCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
        friendsSNIDs = new ArrayList<String>();
        friendsSNHeaders = new ArrayList<PersonSNHeader>();
    }

    public List<String> getFriendsSNIDs() {
        return friendsSNIDs;
    }

    public void setFriendsSNIDs(List<String> friendsSNIDs) {
        this.friendsSNIDs = friendsSNIDs;
    }

    public PersonSNHeader getPersonSNHeader() {
        return personSNHeader;
    }

    public void setPersonSNHeader(PersonSNHeader personSNHeader) {
        this.personSNHeader = personSNHeader;
    }

    public long getBalance() {
        return personSNHeader.balance;
    }

    @Override
    public String toString() {
        return "ClientRegisterOnServerCommand{" +
                "userId='" + getUserId() + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
             personSNHeader = new PersonSNHeader();
            readSNHeader(dis, personSNHeader);
            int count = dis.readInt();
            for (int i = 0; i < count; i++) {
                PersonSNHeader friend = new PersonSNHeader();
                readSNHeader(dis, friend);
                friendsSNHeaders.add(friend);
            }
        }
    }

    private void readSNHeader(DataInputStream dis, PersonSNHeader personSNHeader) throws IOException {
        personSNHeader.id = dis.readLong();
        personSNHeader.socialNetworkID = dis.readUTF();
        personSNHeader.isOnline = dis.readBoolean();
        personSNHeader.balance = dis.readLong();
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            //encode content
            dos.writeLong(getUserId());
            dos.writeInt(0);
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
