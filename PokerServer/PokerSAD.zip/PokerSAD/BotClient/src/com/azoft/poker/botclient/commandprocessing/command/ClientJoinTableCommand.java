package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.botclient.tableprocessing.ClientTable;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.lobbyserver.tableprocessing.ModeType;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientJoinTableCommand extends RequestCommand {

    private Long tableID;

    private ClientTable table = null;

    public Long getTableID() {
        return tableID;
    }

    public void setTableID(Long tableID) {
        this.tableID = tableID;
    }

    public ClientTable getTable() {
        return table;
    }

    public void setTable(ClientTable table) {
        this.table = table;
    }

    public ClientJoinTableCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientJoinTableCommand{" +
                "tableID=" + tableID +
                (table != null ? (", table=" + table) : "") +
                '}';
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            table = new ClientTable();
            readTable(dis, table);

            List<Player> players = new ArrayList<Player>();

            byte count = dis.readByte();
            for (int i = 0; i < count; i++) {
                Player player = new Player();
                player.setId(dis.readLong());
                player.setPlaceId(dis.readByte());
                player.setNetworkUserId(dis.readUTF());
                player.setGameBalance(dis.readLong());
                player.setPlaying(dis.readByte());
                Byte medalsSize = dis.readByte();
                for (int j = 0; j < medalsSize; j++) {
                    Byte medalType = dis.readByte();
                }
                players.add(player);
            }
            table.setPlayers(players);


            //TableGameInfo
            //cards on table
            int cardsNum = dis.readByte();
            for (int i = 0; i < cardsNum; i++) {
                dis.readByte();
                dis.readByte();
            }
            //formed banks
            int banksNum = dis.readByte();
            for (int i = 0; i < banksNum; i++) {
                dis.readByte();
                dis.readLong();
            }
            //current player bets
            //formed banks
            int usersNum = dis.readByte();
            for (int i = 0; i < usersNum; i++) {
                dis.readLong();
                dis.readLong();
            }

        }
    }

    public static Byte readTable(DataInputStream dis, Table table) throws IOException {
        long tableId = dis.readLong();
        String tableName = dis.readUTF();
        Byte modeId = dis.readByte();
        Byte modeTime = dis.readByte();
        Byte playerCountMax = dis.readByte();
        Byte playerCount = dis.readByte();
        Integer bigBlind = dis.readInt();
        Integer smallBlind = dis.readInt();
        Byte gameType = dis.readByte();

        ModeType modeType = ModeType.valueOf(modeId);
        table.setTableId(tableId);
        table.setTableName(tableName);
        table.setMode(modeType);
        table.setPlayerCountMax(playerCountMax);
        table.setBigBlind(bigBlind);
        table.setSmallBlind(smallBlind);
        table.setGameType(gameType);

        return playerCount;
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            dos.writeLong(getTableID());
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
