package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClientNotifyAboutBankReadyCommand extends Command {

    public ClientNotifyAboutBankReadyCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientNotifyAboutBankReadyCommand{" +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {

        int count = dis.readByte();
        for (int i = 0; i < count; i++) {
            long userId = dis.readLong();
            int countBanks = dis.readByte();
            for (int j = 0; j < countBanks; j++) {
                dis.readByte();
                dis.readLong();
            }
        }
        //formed banks
        int banksNum = dis.readByte();
        for (int i = 0; i < banksNum; i++) {
            dis.readByte();
            dis.readLong();
        }


    }

    public void encodeBody(DataOutputStream out) throws IOException {
    }

    @Override
    public void run() {
        //do nothing
    }

}