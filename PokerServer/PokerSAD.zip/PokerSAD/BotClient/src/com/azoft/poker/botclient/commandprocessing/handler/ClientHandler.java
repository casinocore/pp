package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.common.commandprocessing.handler.Handler;
import org.apache.mina.core.session.IoSession;

public abstract class ClientHandler<CommandType> extends Handler<CommandType> {

    public ClientHandler() {
        super();
    }

    public static Bot getBotAttribute(IoSession session) {
        return (Bot) session.getAttribute(Bot.PARAMETER_BOT);
    }

}
