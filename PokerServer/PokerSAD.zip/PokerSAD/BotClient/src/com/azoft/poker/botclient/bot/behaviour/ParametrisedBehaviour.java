package com.azoft.poker.botclient.bot.behaviour;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.behaviour.cardscombination.CardsCombination;
import com.azoft.poker.botclient.commandprocessing.command.ClientNotifyAboutTheLeadCommand;
import com.azoft.poker.botclient.commandprocessing.handler.HandlerHelper;
import com.azoft.poker.botclient.configuration.behaviour.BankBean;
import com.azoft.poker.botclient.configuration.behaviour.BotDealBean;
import com.azoft.poker.botclient.configuration.behaviour.ParametrisedBehaviourBean;
import com.azoft.poker.botclient.tableprocessing.bet.PlayersBets;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.DealType;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import com.azoft.poker.lobbyserver.tableprocessing.lead.Lead;
import com.azoft.poker.lobbyserver.tableprocessing.lead.LeadType;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Parametrised behaviour
 */
public class ParametrisedBehaviour extends BotBehaviour<ParametrisedBehaviourBean> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ParametrisedBehaviour.class);

    private static final int RAISE_FACTOR = 2;

    private StringBuffer info;

    public ParametrisedBehaviour() {
        super();
    }

    @Override
    public void execute(Command command) {
        super.execute(command);
        Bot bot = getBotAttribute(command.getSession());
        if (command instanceof ClientNotifyAboutTheLeadCommand) {
            ClientNotifyAboutTheLeadCommand c = (ClientNotifyAboutTheLeadCommand) command;
            bot.getPlayersBets().addPlayerBet(c.getId(), c.getLead().getValue());
            BankStatusTypeID bankStatusTypeID = bot.getBankStatusTypeID();
            prepareBankStatusTypeID(c.getLead(), bankStatusTypeID, bot);
            prepareLastRaise(c.getLead(), bot);
            if (c.getUserId().equals(c.getNextId())) {
                info = new StringBuffer("\n\n----------------------- Parametrised behaviour --------------------------------------------\n");
                info.append("bot:\t\t\t").append(bot.toString()).append("\n");
                ParametrisedBehaviourBean bean = getBean();
                BotDealBean botDealBean = bean.getDealBean(bot.getDealType());
                String mesDefaultSendLead = "Default send lead: FOLD for bot: " + bot.toString();
                if (botDealBean != null && bankStatusTypeID != null) {
                    Byte position = 0;
                    if (DealType.PRE_FLOP.equals(bot.getDealType())) {
                        position = preparePosition(bot);
                    }
                    BankBean bankBean = botDealBean.findBankBean(position, bankStatusTypeID);
                    info.append("dealType:\t\t").append(bot.getDealType().toString()).append("\n");
                    info.append("position:\t\t").append(position).append("\n");
                    info.append("bankStatusTypeID:\t").append(bankStatusTypeID.toString()).append("\n");
                    if (bankBean != null) {
                        boolean isSendLead = false;
                        for (LeadType leadType : OrderLeadTypes.getOrderLeadTypes()) {
                            List<CardsCombination> cardsCombinations = bankBean.getCardsCombinations(leadType);
                            List<Card> cards = bot.getCards();
                            if (CardsCombination.isCardsInside(cards, cardsCombinations)) {
                                sendLeadCommand(command, leadType, bot);
                                isSendLead = true;
                                info.append("leadType:\t\t").append(leadType.toString()).append("\n");
                                info.append("cardsCombinations:\t").append(cardsCombinations.toString()).append("\n");
                                info.append("cards:\t\t\t").append(cards).append("\n");
                                break;
                            }
                        }
                        if (!isSendLead) {
                            HandlerHelper.sendLeadCommand(command.getSession(), new Lead(LeadType.FOLD.getLeadId()));
                            info.append(mesDefaultSendLead).append("\n");
                        }
                    } else {
                        HandlerHelper.sendLeadCommand(command.getSession(), new Lead(LeadType.FOLD.getLeadId()));
                        info.append("Not exists parameters: bankBean. ").append(". ").append(mesDefaultSendLead).append("\n");
                    }
                } else {
                    HandlerHelper.sendLeadCommand(command.getSession(), new Lead(LeadType.FOLD.getLeadId()));
                    info.append("Not exists parameters: botDealBean==null: ").append(botDealBean == null)
                            .append("; bankStatusTypeID==null: ").append(bankStatusTypeID == null).append(". ")
                            .append(mesDefaultSendLead).append("\n");
                }
                info.append("-------------------------------------------------------------------------------------------\n");
                LOGGER.debug(info.toString());
            }
        }
    }

    private void prepareBankStatusTypeID(Lead lead, BankStatusTypeID bankStatusTypeID, Bot bot) {
        BankStatusTypeID newBankStatusTypeID = null;
        if (lead.getLeadId() == LeadType.CALL.getLeadId()) {
            newBankStatusTypeID = BankStatusTypeID.CALL_LEAD;
        } else if (lead.getLeadId() == LeadType.RAISE.getLeadId()) {
            if (!BankStatusTypeID.RAISE_LEAD.equals(bankStatusTypeID)) {
                newBankStatusTypeID = BankStatusTypeID.RAISE_LEAD;
            } else {
                newBankStatusTypeID = BankStatusTypeID.MULTI_RAISE;
            }
        }
        if (newBankStatusTypeID != null && (bankStatusTypeID == null || newBankStatusTypeID.getTypeId() > bankStatusTypeID.getTypeId())) {
            bot.setBankStatusTypeID(newBankStatusTypeID);
            LOGGER.debug("bankStatusTypeID: " + bankStatusTypeID);
        }
    }

    private void prepareLastRaise(Lead lead, Bot bot) {
        if ((lead.getLeadId() == LeadType.BIG_BLIND.getLeadId() || lead.getLeadId() == LeadType.RAISE.getLeadId())) {
            bot.setLastRaise(lead.getValue());
        }
    }

    //TODO bot

    private Byte preparePosition(Bot bot) {
        Byte position = 0;
        Byte placeId = bot.getPlaceId();
        Byte dealerButton = bot.getDealerButton();
        Table table = bot.getTable();
        info.append("placeId:\t\t").append(placeId).append("\n");
        info.append("dealerButton:\t\t").append(dealerButton).append("\n");
        if (placeId != null && dealerButton != null && table != null) {
            List<Player> players = table.getPlayers();
            if (players != null && !players.isEmpty()) {
                List<Byte> positions = new ArrayList<Byte>();
                for (Player player : players) {
                    positions.add(player.getPlaceId());
                }
                Collections.sort(positions);
                info.append("positions:\t\t").append(positions).append("\n");
                positions = ParametrisedBehaviourHelper.prepareOrderPositionsByBigBlind(dealerButton, positions);
                info.append("sort positions:\t\t").append(positions).append("\n");
                position = ParametrisedBehaviourHelper.findPosition(placeId, positions);
            }
        }
        return position;
    }

    private void sendLeadCommand(Command command, LeadType leadType, Bot bot) {
        Lead lead = null;
        if (LeadType.RAISE.equals(leadType)) {
            Long valueRaise;
            if (BankStatusTypeID.RAISE_LEAD.equals(bot.getBankStatusTypeID())
                    || BankStatusTypeID.MULTI_RAISE.equals(bot.getBankStatusTypeID())) {
                valueRaise = bot.getLastRaise() * RAISE_FACTOR; //Last raise * RAISE_FACTOR
            } else {
                valueRaise = bot.getLastRaise() * RAISE_FACTOR;  //Big blind
            }
            Long gameBalance = bot.getPlayersBets().getGameBalance();
            if (gameBalance > bot.getLastRaise()) {
                if (gameBalance < valueRaise) {
                    valueRaise = gameBalance;
                }
                lead = new Lead(LeadType.RAISE.getLeadId(), valueRaise);
            } else {
                leadType = LeadType.CALL;
            }
            info.append("bot.getGameBalance:\t").append(gameBalance).append("\n");
            info.append("bot.getLastRaise:\t").append(bot.getLastRaise()).append("\n");
            info.append("bot.valueRaise:\t\t").append(valueRaise).append("\n");
        }
        if (LeadType.CALL.equals(leadType)) {
            lead = prepareCheckOrCallLead(bot.getPlayersBets(), command.getUserId());
        }
        if (lead == null) {
            lead = new Lead(LeadType.FOLD.getLeadId());
        }
        info.append("sendLeadCommand:\t").append(lead.toString()).append("\n");
        HandlerHelper.sendLeadCommand(command.getSession(), lead);
    }

    private Lead prepareCheckOrCallLead(PlayersBets playersBet, Long userId) {
        Lead lead;
        Long delta = playersBet.maxDelta(userId);
        Long gameBalance = playersBet.getGameBalance();
        if (delta > gameBalance) {
            delta = gameBalance;
        }
        if (delta <= 0L) {
            lead = new Lead(LeadType.CHECK.getLeadId());
        } else {
            lead = new Lead(LeadType.CALL.getLeadId(), delta);
        }
        return lead;
    }

}