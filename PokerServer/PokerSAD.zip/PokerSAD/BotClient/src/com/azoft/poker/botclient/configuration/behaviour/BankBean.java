package com.azoft.poker.botclient.configuration.behaviour;

import com.azoft.poker.botclient.bot.behaviour.cardscombination.CardsCombination;
import com.azoft.poker.lobbyserver.tableprocessing.lead.LeadType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BankBean {

    /**
     * Deal map (key: LeadType, value: cards combinations)
     */
    private Map<LeadType, List<CardsCombination>> leadCardsCombinationsMap = new HashMap<LeadType, List<CardsCombination>>();

    public BankBean() {
        super();
    }

    public void putCardsCombination(LeadType leadType, CardsCombination cardsCombination) {
        List<CardsCombination> cardsCombinations = leadCardsCombinationsMap.get(leadType);
        if (cardsCombinations == null) {
            cardsCombinations = new ArrayList<CardsCombination>();
            leadCardsCombinationsMap.put(leadType, cardsCombinations);
        }
        if (!cardsCombinations.contains(cardsCombination)) {
            cardsCombinations.add(cardsCombination);
        }
    }

    public List<CardsCombination> getCardsCombinations(LeadType leadType) {
        return leadCardsCombinationsMap.get(leadType);
    }

}
