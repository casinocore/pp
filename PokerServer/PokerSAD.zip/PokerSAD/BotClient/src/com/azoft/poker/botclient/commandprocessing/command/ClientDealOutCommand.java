package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientDealOutCommand extends Command {

    /**
     * deal identifier (in)
     */
    private Byte dealId;

    /**
     * Cards (in)
     */
    private List<Card> cards;


    public ClientDealOutCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Byte getDealId() {
        return dealId;
    }

    public List<Card> getCards() {
        return cards;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientDealOutCommand{" +
                "dealId='" + dealId + '\'' +
                ", cards='" + cards + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //empty
        dealId = dis.readByte();
        int count = 0;
        if (dealId == 1) count = 3;
        else if (dealId == 2 || dealId == 3) count = 1;
        cards = new ArrayList<Card>();
        for (int i = 0; i < count; i++) {
            byte value = dis.readByte();
            byte suite = dis.readByte();
            Card card = new Card(value, suite);
            cards.add(card);
        }
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content

        dos.writeLong(this.dealId);
        for (Card card : cards) {
            dos.writeByte(card.getSuit());
            dos.writeByte(card.getValue());
        }

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public void setDealId(Byte dealId) {
        this.dealId = dealId;
    }

    public void setCards(List<Card> cards) {
        this.cards = cards;
    }

}
