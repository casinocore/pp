package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


public class ClientGetUpCommand extends Command {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientGetUpCommand.class);

    /**
     * place identifier at the table
     */
    private Byte placeId;

    public ClientGetUpCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public void setPlaceId(Byte placeId) {
        this.placeId = placeId;
    }

    @Override
    public String toString() {
        return "ClientGetUpCommand{" +
                "userId='" + getUserId() + '\'' +
                ", placeId=" + placeId +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //  placeId = dis.readByte();
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        //encode content
        dos.writeByte(placeId);
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public Byte getPlaceId() {
        return placeId;
    }

}
