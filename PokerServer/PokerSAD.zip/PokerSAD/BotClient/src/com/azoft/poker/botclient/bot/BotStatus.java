package com.azoft.poker.botclient.bot;

public enum BotStatus {

    NEW,
    ERROR,
    LOGIN,
    LOGIN_NOT_EXISTS_USER,
    REGISTER,
    REGISTER_ON_SERVER,
    GET_LOBBY_CASH,
    JOIN_TABLE,
    SIT,
    HAND_OUT_CARDS,
    DEAL_OUT,
    EXIT_FROM_LOBBY;

    BotStatus() {
    }

    public String toString() {
        return name();
    }

}
