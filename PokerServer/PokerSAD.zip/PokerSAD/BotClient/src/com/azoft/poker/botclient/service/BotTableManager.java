package com.azoft.poker.botclient.service;

import com.azoft.poker.common.helper.DateHelper;

/**
 * Bot table manager interface
 */
public interface BotTableManager {

    long TIMEOUT_EXIT_BOX = DateHelper.SEC_MSEC * 2;

    void removeExitBotForTable(Long tableId);

    boolean checkExitBotForTable(Long tableId);

}
