package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.botclient.tableprocessing.ClientTable;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientGetLobbyCashCommand extends RequestCommand {

    private Integer bigBlind;

    private List<Table> tables;

    public Integer getBigBlind() {
        return bigBlind;
    }

    public void setBigBlind(Integer bigBlind) {
        this.bigBlind = bigBlind;
    }

    public List<Table> getTables() {
        return tables;
    }

    public void setTables(List<Table> tables) {
        this.tables = tables;
    }

    public ClientGetLobbyCashCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        StringBuffer stringBuffer = new StringBuffer(super.toString());
        stringBuffer.append(" - ClientGetLobbyCashCommand{")
                .append("bigBlind=").append(bigBlind);
        if (tables != null) {
            stringBuffer.append(", tables=").append(tables);
        }
        stringBuffer.append("}");
        return stringBuffer.toString();
    }

    @Override
    public void decodeBody(DataInputStream dis) throws Exception {
        super.decodeBody(dis);
        if (!isExistsError()) {
            int count = dis.readInt();
            tables = new ArrayList<Table>();
            for (int i = 0; i < count; i++) {
                Table table = new ClientTable();
                Byte playerCount = ClientJoinTableCommand.readTable(dis, table);
                Integer bigBlindMultiplier = dis.readInt();
                for (byte j = 0; j < playerCount; j++) {
                    table.addPlayer(new Player(), false);
                }
                tables.add(table);
            }
        }
    }

    @Override
    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            dos.writeInt(getBigBlind());
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
