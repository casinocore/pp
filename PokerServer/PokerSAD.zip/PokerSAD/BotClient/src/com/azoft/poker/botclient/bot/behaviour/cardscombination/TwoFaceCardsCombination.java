package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;

import java.util.List;

/**
 * Two face cards combination
 */
public class TwoFaceCardsCombination extends CardsCombination {

    public TwoFaceCardsCombination(String name, CardsCombinationType type) {
        super(name, type);
    }

    public TwoFaceCardsCombination(String name, CardsCombinationType type, Byte value) {
        super(name, type, value);
    }

    protected boolean isInside(List<Card> cards) {
        return cards.get(0).getValue() >= getValue() && cards.get(1).getValue() >= getValue();
    }

}