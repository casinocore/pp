package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.ClientCommandFactoryImpl;
import com.azoft.poker.botclient.commandprocessing.command.ClientJoinTableCommand;
import com.azoft.poker.botclient.commandprocessing.command.ClientSitCommand;
import com.azoft.poker.botclient.helper.RandomHelper;
import com.azoft.poker.botclient.tableprocessing.ClientTable;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientJoinTableHandler extends ClientHandler<ClientJoinTableCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientJoinTableHandler.class);

    public ClientJoinTableHandler() {
        super();
    }

    public void execute(ClientJoinTableCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        if (!command.isExistsError()) {
            bot.setStatus(BotStatus.JOIN_TABLE);
            ClientTable table = command.getTable();
            if (table.checkFreePlace()) {
                bot.setTable(table);
                Byte placeId = selectPlaceId(table);
                //System.out.println("PLACE:        "+placeId);
                if (placeId != null) {
                    bot.setPlaceId(placeId);
                    sendClientSitCommand(command.getSession(), placeId);
                } else {
                    bot.setStatus(BotStatus.ERROR);
                    LOGGER.error("Error. Not select placeId in table: " + table + " for bot: " + bot.toString());
                }
            } else {
                bot.setStatus(BotStatus.ERROR);
                LOGGER.debug("Error. Small free place in table: " + table + " for bot: " + bot.toString());
            }
        } else {
            bot.setStatus(BotStatus.ERROR);
            LOGGER.error("Error. ClientJoinTableCommand for bot: " + bot.toString());
        }
    }

    private Byte selectPlaceId(Table table) {
        Byte result = null;
        if (table.getPlayerCountMax() > 0) {
            while (result == null) {
                byte r = (byte) RandomHelper.getRandomInt(table.getPlayerCountMax() - 1);
                boolean isExists = false;
                for (Player player : table.getPlayers()) {
                    if (player.getPlaceId() == r) {
                        isExists = true;
                        break;
                    }
                }
                if (!isExists) {
                    result = r;
                }
            }
        }
        return result;
    }

    private void sendClientSitCommand(IoSession session, Byte placeId) {
        try {
            ClientSitCommand cmd = (ClientSitCommand) ClientCommandFactoryImpl.createClientCommand(
                    session, CommandTypeID.SIT.getTypeId());
            cmd.setPlaceId(placeId);
            cmd.send();
        } catch (Exception e) {
            LOGGER.error("Create and send command: SIT", e);
        }
    }

}