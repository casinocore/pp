package com.azoft.poker.botclient.exception;

import com.azoft.poker.common.exception.AbstractException;

/**
 * Bot client exception
 */
public class BotClientException extends AbstractException {

    public BotClientException(String message) {
        super(message);
    }

    public BotClientException(String message, Throwable cause) {
        super(message, cause);
    }

    public BotClientException(Throwable cause) {
        super(cause);
    }

}
