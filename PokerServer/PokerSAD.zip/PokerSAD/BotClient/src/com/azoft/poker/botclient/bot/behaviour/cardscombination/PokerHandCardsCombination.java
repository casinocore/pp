package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerHand;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerHandType;

import java.util.List;

/**
 * Poker hand cards combination
 */
public class PokerHandCardsCombination extends CardsCombination {

    public PokerHandCardsCombination(String name, CardsCombinationType type) {
        super(name, type);
    }

    public PokerHandCardsCombination(String name, CardsCombinationType type, Byte value) {
        super(name, type, value);
    }

    protected boolean isInside(List<Card> cards) {
        PokerHand pokerHand = new PokerHand(null, cards);
        PokerHandType handRating = pokerHand.ratingCheck();
        return handRating.name().equals(getName());
    }

}