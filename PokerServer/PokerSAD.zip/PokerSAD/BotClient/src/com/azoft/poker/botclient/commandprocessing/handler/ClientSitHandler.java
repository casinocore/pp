package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.command.ClientSitCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientSitHandler extends ClientHandler<ClientSitCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientSitHandler.class);

    public ClientSitHandler() {
        super();
    }

    public void execute(ClientSitCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        if (command.isExistsError()) {
            bot.setPlaceId(null);
            bot.setStatus(BotStatus.ERROR);
            LOGGER.error("Error. Error code: " + command.getErrorCode() + " for bot: " + bot.toString());
        }
    }

}