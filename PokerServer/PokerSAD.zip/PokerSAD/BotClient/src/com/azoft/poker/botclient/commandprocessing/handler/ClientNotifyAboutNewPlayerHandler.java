package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.command.ClientNotifyAboutNewPlayerCommand;
import com.azoft.poker.botclient.service.BotTableManagerImpl;
import com.azoft.poker.botclient.tableprocessing.ClientTable;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ClientNotifyAboutNewPlayerHandler extends ClientHandler<ClientNotifyAboutNewPlayerCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientNotifyAboutNewPlayerHandler.class);

    public ClientNotifyAboutNewPlayerHandler() {
        super();
    }

    public void execute(ClientNotifyAboutNewPlayerCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        Player player = command.getPlayer();
        boolean isCurrentUser = bot.getUserId().equals(player.getId());
        if (isCurrentUser) {
            bot.getPlayersBets().setGameBalance(command.getPlayer().getGameBalance());
            bot.setStatus(BotStatus.SIT);
        } else {
            bot.getPlayersBets().clearPlayerBet(command.getPlayer().getId());
        }
        ClientTable table = bot.getTable();
        if (table != null) {
            List<Player> players = table.getPlayers();
            if (players != null && !players.contains(player)) {
                players.add(player);
                LOGGER.debug("Add to table player: " + player + " for bot: " + bot.toString());
                if (!isCurrentUser && table.checkExitBot()
                        && BotTableManagerImpl.getInstance().checkExitBotForTable(table.getTableId())) {
                    bot.setStatus(BotStatus.ERROR);
                    LOGGER.debug("Error. Small free place in table: " + table + " for bot: " + bot.toString());
                }
            }
        }
        LOGGER.debug("ClientNotifyAboutNewPlayerHandler completed for bot: " + bot.toString());
    }

}