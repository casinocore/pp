package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.ClientCommandFactoryImpl;
import com.azoft.poker.botclient.commandprocessing.command.ClientLoginCommand;
import com.azoft.poker.botclient.commandprocessing.command.ClientRegisterCommand;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientRegisterHandler extends ClientHandler<ClientRegisterCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientRegisterHandler.class);

    public ClientRegisterHandler() {
        super();
    }

    public void execute(ClientRegisterCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        if (!command.isExistsError()) {
            bot.setStatus(BotStatus.REGISTER);
            sendClientLoginCommand(command.getSession(), bot);
        } else {
            bot.setStatus(BotStatus.ERROR);
            LOGGER.error("Error. ClientRegisterCommand for bot: " + bot.toString());
        }
    }

    private void sendClientLoginCommand(IoSession session, Bot bot) {
        try {
            ClientLoginCommand cmd = (ClientLoginCommand) ClientCommandFactoryImpl.createClientCommand(
                    session, CommandTypeID.LOGIN.getTypeId());
            cmd.setUsername(bot.getBotInfoBean().getLogin());
            cmd.send();
        } catch (Exception e) {
            LOGGER.error("Create and send command: LOGIN", e);
        }
    }

}