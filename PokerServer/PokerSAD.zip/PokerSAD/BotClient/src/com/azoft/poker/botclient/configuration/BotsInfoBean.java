package com.azoft.poker.botclient.configuration;

import com.azoft.poker.common.jaxp.AbstractBean;

import java.util.HashMap;
import java.util.Map;

/**
 * Bots info bean
 */
public class BotsInfoBean extends AbstractBean {

    /**
     * Get bots info - map (key: social network ID, value: BotInfoBean)
     */
    private Map<String, BotInfoBean> botsInfo = new HashMap<String, BotInfoBean>();

    public BotsInfoBean() {
    }

    /**
     * Get bots info
     *
     * @return bots info - map (key: social network ID, value: BotInfoBean)
     */
    public Map<String, BotInfoBean> getBotsInfo() {
        return botsInfo;
    }

    /**
     * Add user info bean
     *
     * @param userInfoBean user info bean
     */
    public void addBotInfoBean(BotInfoBean userInfoBean) {
        botsInfo.put(userInfoBean.getSocialNetworkID(), userInfoBean);
    }

}
