package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.RequestCommand;
import com.azoft.poker.common.helper.StringHelper;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClientRegisterCommand extends RequestCommand {

    /**
     * Логин пользователя
     */
    private String username;

    /**
     * Social network ID
     */
    private String socialNetworkID;

    /**
     * Имя пользователя
     */
    private String firstName;

    /**
     * Фамилия пользователя
     */
    private String lastName;

    /**
     * Social network ID parent
     */
    private String socialNetworkIDParent;

    public ClientRegisterCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSocialNetworkID() {
        return socialNetworkID;
    }

    public void setSocialNetworkID(String socialNetworkID) {
        this.socialNetworkID = socialNetworkID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSocialNetworkIDParent() {
        return socialNetworkIDParent;
    }

    public void setSocialNetworkIDParent(String socialNetworkIDParent) {
        this.socialNetworkIDParent = socialNetworkIDParent;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientRegisterCommand{" +
                "username='" + username + '\'' +
                ", socialNetworkID='" + socialNetworkID + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", socialNetworkIDParent='" + socialNetworkIDParent + '\'' +
                '}';
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        super.encodeBody(dos);
        if (!isExistsError()) {
            //encode content
            dos.writeUTF(StringHelper.makeEmpty(username));
            dos.writeUTF(StringHelper.makeEmpty(socialNetworkID));
            dos.writeUTF(StringHelper.makeEmpty(firstName));
            dos.writeUTF(StringHelper.makeEmpty(lastName));
            dos.writeUTF(StringHelper.makeEmpty(socialNetworkIDParent));
        }
        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

}
