package com.azoft.poker.botclient.bot.behaviour;

import com.azoft.poker.lobbyserver.tableprocessing.lead.LeadType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Order lead types
 */
public class OrderLeadTypes {

    private final static List<LeadType> orderLeadTypes = new ArrayList<LeadType>();

    static {
        orderLeadTypes.add(LeadType.RAISE);
        orderLeadTypes.add(LeadType.CALL);
        orderLeadTypes.add(LeadType.FOLD);
    }

    public static Collection<LeadType> getOrderLeadTypes() {
        return orderLeadTypes;
    }

}
