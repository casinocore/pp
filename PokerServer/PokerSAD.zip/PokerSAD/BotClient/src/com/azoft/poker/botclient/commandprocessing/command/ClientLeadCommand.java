package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.lead.Lead;
import org.apache.mina.core.session.IoSession;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClientLeadCommand extends Command {

    /**
     *  Unique user id (in) - Long getUserId() / setUserId(Long UserId)
     */

    /**
     * Lead (in)
     */
    private Lead lead;

    public ClientLeadCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientLeadCommand{" +
                "userId='" + getUserId() + '\'' +
                ", lead='" + lead + '\'' +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        //   lead.setLeadId(dis.readByte());
        //  lead.setValue(dis.readLong());
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
        //out.writeByte(lead.getLeadId());
        //out.writeLong(lead.getValue());

        //prepare body content
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        //encode content
        dos.writeByte(lead.getLeadId());
        dos.writeLong(lead.getValue());

        dos.flush();
        byte[] body = baos.toByteArray();
        //encode body size
        setBodySize(body.length);
        out.writeInt(body.length);
        //encode body itself
        out.write(body);
    }

    public void setLead(Lead lead) {
        this.lead = lead;
    }

    public Lead getLead() {
        return lead;
    }

}
