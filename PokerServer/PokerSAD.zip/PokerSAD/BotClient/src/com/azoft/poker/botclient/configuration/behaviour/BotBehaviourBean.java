package com.azoft.poker.botclient.configuration.behaviour;

import com.azoft.poker.common.jaxp.AbstractBean;

/**
 * Bot behaviour bean
 */
public class BotBehaviourBean extends AbstractBean {

    /**
     * Behaviour class
     */
    private String behaviourClass;

    /**
     * Min timeout
     */
    private Integer minTimeout;

    /**
     * Max timeout
     */
    private Integer maxTimeout;

    public BotBehaviourBean() {
        super();
    }

    public String getBehaviourClass() {
        return behaviourClass;
    }

    public void setBehaviourClass(String behaviourClass) {
        this.behaviourClass = behaviourClass;
    }

    public Integer getMinTimeout() {
        return minTimeout;
    }

    public void setMinTimeout(Integer minTimeout) {
        this.minTimeout = minTimeout;
    }

    public Integer getMaxTimeout() {
        return maxTimeout;
    }

    public void setMaxTimeout(Integer maxTimeout) {
        this.maxTimeout = maxTimeout;
    }

}
