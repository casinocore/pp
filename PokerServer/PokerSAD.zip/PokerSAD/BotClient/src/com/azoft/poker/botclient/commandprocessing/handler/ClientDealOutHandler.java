package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.bot.behaviour.BankStatusTypeID;
import com.azoft.poker.botclient.commandprocessing.command.ClientDealOutCommand;
import com.azoft.poker.lobbyserver.tableprocessing.DealType;
import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ClientDealOutHandler extends ClientHandler<ClientDealOutCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientDealOutHandler.class);

    public ClientDealOutHandler() {
        super();
    }

    public void execute(ClientDealOutCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        bot.setStatus(BotStatus.DEAL_OUT);
        DealType dealType = DealType.valueOf(command.getDealId());
        bot.setDealType(dealType);
        List<Card> cards = command.getCards();
        bot.addCards(cards);
        bot.setBankStatusTypeID(BankStatusTypeID.CLOSE_BANK);
        if (bot.getTable() != null && bot.getTable().getBigBlind() != null) {
            bot.setLastRaise((long) bot.getTable().getBigBlind());
        }
        LOGGER.debug("ClientDealOutHandler completed for bot: " + bot.toString());
    }

}