package com.azoft.poker.botclient;

import com.azoft.poker.botclient.configuration.ConfigurationLoader;
import com.azoft.poker.botclient.service.BotClientServiceImpl;
import com.azoft.poker.common.communicator.BaseConstants;
import com.azoft.poker.common.communicator.MinaClientImpl;
import com.azoft.poker.common.service.LifecycleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Bot client
 */
public class BotClient {

    private final static Logger LOGGER = LoggerFactory.getLogger(BotClient.class);

    private static final String QUIT_OPERATION = "quit";

    /**
     * Bot client parameters
     */
    private static final Map<String, Object> parameters = new HashMap<String, Object>();

    public static void main(String[] args) throws Throwable {
        LOGGER.info("Start BotClient");
        LOGGER.info("Quit: quit + ENTER");
        initializationParameters(args);

        LifecycleService botClientService = BotClientServiceImpl.getInstance();
        botClientService.initialization(parameters);

        BufferedReader bReader = new BufferedReader(new InputStreamReader(System.in));
        while (!bReader.readLine().equals(QUIT_OPERATION)) {
            bReader = new BufferedReader(new InputStreamReader(System.in));
        }

        botClientService.shutdown();
        LOGGER.info("Quit Bot client");
    }

    private static void initializationParameters(String[] args) {
        Integer serverPort = null;
        if (args.length > 0) {
            try {
                serverPort = Integer.parseInt(args[0]);
                LOGGER.info("Server port: " + String.valueOf(serverPort));
            } catch (NumberFormatException e) {
                //empty
            }
        }
        if (serverPort == null) {
            serverPort = BaseConstants.LOGIN_SERVER_PORT;
            LOGGER.warn("Default server port: " + String.valueOf(serverPort));
        }

        String serverAddress = null;
        if (args.length > 1) {
            serverAddress = args[1];
            LOGGER.info("Server address: " + serverAddress);
        }
        if (serverAddress == null) {
            serverAddress = BaseConstants.SERVER_ADDRESS;
            LOGGER.warn("Default server address: " + String.valueOf(serverAddress));
        }

        Long configurationPeriod = null;
        if (args.length > 2) {
            try {
                configurationPeriod = Long.parseLong(args[2]);
                LOGGER.info("Configuration period: " + String.valueOf(configurationPeriod));
            } catch (NumberFormatException e) {
                //empty;
            }
        }
        if (configurationPeriod == null) {
            configurationPeriod = ConfigurationLoader.DEFAULT_CONFIGURATION_PERIOD;
            LOGGER.warn("Default configuration period: " + String.valueOf(configurationPeriod));
        }
        String configurationPath = null;
        if (args.length > 3) {
            configurationPath = args[3];
            LOGGER.info("Configuration path: " + configurationPath);
        }
        if (configurationPath == null) {
            configurationPath = ConfigurationLoader.DEFAULT_BOTS_INFO_PATH;
            LOGGER.warn("Default configuration path: " + String.valueOf(serverAddress));
        }

        parameters.put(ConfigurationLoader.PARAMETER_BOTS_INFO_PATH, configurationPath);
        parameters.put(ConfigurationLoader.PARAMETER_CONFIGURATION_PERIOD, configurationPeriod);
        parameters.put(MinaClientImpl.SERVER_PORT_PARAMETER, serverPort);
        parameters.put(MinaClientImpl.SERVER_ADDRESS_PARAMETER, serverAddress);

    }

}
