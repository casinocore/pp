package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;

import java.util.List;

/**
 * Connector cards combination
 */
public class ConnectorCardsCombination extends CardsCombination {

    public ConnectorCardsCombination(String name, CardsCombinationType type) {
        super(name, type);
    }

    public ConnectorCardsCombination(String name, CardsCombinationType type, Byte value) {
        super(name, type, value);
    }

    protected boolean isInside(List<Card> cards) {
        return cards.get(1).getValue() - cards.get(0).getValue() == 1 && cards.get(1).getValue() >= getValue();
    }

}