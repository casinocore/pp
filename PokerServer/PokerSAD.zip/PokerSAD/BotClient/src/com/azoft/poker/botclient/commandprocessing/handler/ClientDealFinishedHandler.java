package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.command.ClientDealFinishedCommand;
import com.azoft.poker.lobbyserver.tableprocessing.Winner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientDealFinishedHandler extends ClientHandler<ClientDealFinishedCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientDealFinishedHandler.class);

    public ClientDealFinishedHandler() {
        super();
    }

    public void execute(ClientDealFinishedCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        bot.getPlayersBets().clear();
        for (Winner winner : command.getWinners()) {
            if (command.getUserId().equals(winner.getPokerHand().getPlayerId())) {
                bot.getPlayersBets().addGameBalance(command.getUserId(), winner.getValue());
                break;
            }
        }
        if (bot.getPlayersBets().getGameBalance() == null || bot.getPlayersBets().getGameBalance() <= 0) {
            LOGGER.debug("Zero game balance for bot: " + bot.toString());
            bot.setStatus(BotStatus.ERROR);
        }
        LOGGER.debug("ClientDealFinishedHandler completed for bot: " + bot.toString());
    }

}