package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.ClientCommandFactoryImpl;
import com.azoft.poker.botclient.commandprocessing.command.ClientJoinTableCommand;
import com.azoft.poker.botclient.commandprocessing.command.ClientLeadCommand;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.lead.Lead;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Handler helper
 */
public class HandlerHelper {

    private final static Logger LOGGER = LoggerFactory.getLogger(HandlerHelper.class);

    /**
     * Select table
     *
     * @param command command
     * @param bot     bot
     */
    public static void selectTable(Command command, Bot bot) {
        Table selectTable = null;
        if (bot.getTables() != null && !bot.getTables().isEmpty()) {
            if (bot.getBotInfoBean().isNewTable()) {
                for (Table table : bot.getTables()) {
                    if (table.getPlayerCount() == 0) {
                        selectTable = table;
                        break;
                    }
                }
            } else {
                Byte playerCountMin = 1;
                for (Table table : bot.getTables()) {
                    //todo need to check if table will be used lfter this checks...
                    //if (table.getPlayerCount() > 0 && playerCountMin >= table.getPlayerCount()) {
                    if (table.getPlayerCount() > 0 && table.getPlayerCount() < table.getPlayerCountMax()) {
                        selectTable = table;
                        playerCountMin = selectTable.getPlayerCount();
                    }
                }
            }
            if (selectTable != null) {
                sendJoinTable(command.getSession(), selectTable.getTableId());
            } else {
                bot.setStatus(BotStatus.ERROR);
                LOGGER.error("Error. Not select table in command: " + command.toString() + "for bot: " + bot.toString());
            }
        } else {
            bot.setStatus(BotStatus.ERROR);
            LOGGER.error("Error. Not exists tables in command: " + command.toString() + "for bot: " + bot.toString());
        }
    }

    private static void sendJoinTable(IoSession session, Long tableID) {
        try {
            ClientJoinTableCommand cmd = (ClientJoinTableCommand) ClientCommandFactoryImpl.createClientCommand(
                    session, CommandTypeID.JOIN_TABLE.getTypeId());
            cmd.setTableID(tableID);
            cmd.send();
        } catch (Exception e) {
            LOGGER.error("Create and send command: JOIN_TABLE", e);
        }
    }

    public static void sendLeadCommand(IoSession session, Lead lead) {
        try {
            ClientLeadCommand cmd = (ClientLeadCommand) ClientCommandFactoryImpl.createClientCommand(
                    session, CommandTypeID.LEAD.getTypeId());
            cmd.setLead(lead);
            cmd.send();
        } catch (Exception e) {
            LOGGER.error("Create and send command: LEAD", e);
        }
    }

}
