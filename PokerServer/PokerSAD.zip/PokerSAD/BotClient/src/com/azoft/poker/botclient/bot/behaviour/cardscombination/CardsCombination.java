package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerHandType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Cards combination
 */
public class CardsCombination {

    private final static Logger LOGGER = LoggerFactory.getLogger(CardsCombination.class);

    private final static List<CardsCombination> cardsCombinations = new ArrayList<CardsCombination>();

    private final static Map<String, CardsCombination> cardsCombinationMap = new HashMap<String, CardsCombination>();

    static {
        cardsCombinations.add(new CardsCombination("ANY", CardsCombinationType.ANY));
        cardsCombinations.add(new FaceCardsCombination("F", CardsCombinationType.FACE, (byte) 9));
        cardsCombinations.add(new TwoFaceCardsCombination("FF", CardsCombinationType.TWO_FACE, (byte) 9));
        cardsCombinations.add(new SuitCardsCombination("S", CardsCombinationType.SUIT));

        //22+/77+/QQ+
        cardsCombinations.add(new PairCardsCombination("22+", CardsCombinationType.PAIR, (byte) 0));
        cardsCombinations.add(new PairCardsCombination("33+", CardsCombinationType.PAIR, (byte) 1));
        cardsCombinations.add(new PairCardsCombination("44+", CardsCombinationType.PAIR, (byte) 2));
        cardsCombinations.add(new PairCardsCombination("55+", CardsCombinationType.PAIR, (byte) 3));
        cardsCombinations.add(new PairCardsCombination("66+", CardsCombinationType.PAIR, (byte) 4));
        cardsCombinations.add(new PairCardsCombination("77+", CardsCombinationType.PAIR, (byte) 5));
        cardsCombinations.add(new PairCardsCombination("88+", CardsCombinationType.PAIR, (byte) 6));
        cardsCombinations.add(new PairCardsCombination("99+", CardsCombinationType.PAIR, (byte) 7));
        cardsCombinations.add(new PairCardsCombination("TT+", CardsCombinationType.PAIR, (byte) 8));
        cardsCombinations.add(new PairCardsCombination("JJ+", CardsCombinationType.PAIR, (byte) 9));
        cardsCombinations.add(new PairCardsCombination("QQ+", CardsCombinationType.PAIR, (byte) 10));
        cardsCombinations.add(new PairCardsCombination("KK+", CardsCombinationType.PAIR, (byte) 11));
        cardsCombinations.add(new PairCardsCombination("AA+", CardsCombinationType.PAIR, (byte) 12));

        //45+/89+
        cardsCombinations.add(new ConnectorCardsCombination("A2+", CardsCombinationType.CONNECTOR, (byte) 0));
        cardsCombinations.add(new ConnectorCardsCombination("23+", CardsCombinationType.CONNECTOR, (byte) 1));
        cardsCombinations.add(new ConnectorCardsCombination("34+", CardsCombinationType.CONNECTOR, (byte) 2));
        cardsCombinations.add(new ConnectorCardsCombination("45+", CardsCombinationType.CONNECTOR, (byte) 3));
        cardsCombinations.add(new ConnectorCardsCombination("56+", CardsCombinationType.CONNECTOR, (byte) 4));
        cardsCombinations.add(new ConnectorCardsCombination("67+", CardsCombinationType.CONNECTOR, (byte) 5));
        cardsCombinations.add(new ConnectorCardsCombination("78+", CardsCombinationType.CONNECTOR, (byte) 6));
        cardsCombinations.add(new ConnectorCardsCombination("89+", CardsCombinationType.CONNECTOR, (byte) 7));
        cardsCombinations.add(new ConnectorCardsCombination("9T+", CardsCombinationType.CONNECTOR, (byte) 8));
        cardsCombinations.add(new ConnectorCardsCombination("TJ+", CardsCombinationType.CONNECTOR, (byte) 9));
        cardsCombinations.add(new ConnectorCardsCombination("JQ+", CardsCombinationType.CONNECTOR, (byte) 10));
        cardsCombinations.add(new ConnectorCardsCombination("QK+", CardsCombinationType.CONNECTOR, (byte) 11));
        cardsCombinations.add(new ConnectorCardsCombination("KA+", CardsCombinationType.CONNECTOR, (byte) 12));

        //45s+/89s+/JQs+
        cardsCombinations.add(new SuitConnectorCardsCombination("A2S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 0));
        cardsCombinations.add(new SuitConnectorCardsCombination("23S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 1));
        cardsCombinations.add(new SuitConnectorCardsCombination("34S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 2));
        cardsCombinations.add(new SuitConnectorCardsCombination("45S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 3));
        cardsCombinations.add(new SuitConnectorCardsCombination("56S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 4));
        cardsCombinations.add(new SuitConnectorCardsCombination("67S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 5));
        cardsCombinations.add(new SuitConnectorCardsCombination("78S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 6));
        cardsCombinations.add(new SuitConnectorCardsCombination("89S+", CardsCombinationType.SUIT_CONNECTOR, (byte) 7));
        cardsCombinations.add(new SuitConnectorCardsCombination("9TS+", CardsCombinationType.SUIT_CONNECTOR, (byte) 8));
        cardsCombinations.add(new SuitConnectorCardsCombination("TJS+", CardsCombinationType.SUIT_CONNECTOR, (byte) 9));
        cardsCombinations.add(new SuitConnectorCardsCombination("JQS+", CardsCombinationType.SUIT_CONNECTOR, (byte) 10));
        cardsCombinations.add(new SuitConnectorCardsCombination("QKS+", CardsCombinationType.SUIT_CONNECTOR, (byte) 11));
        cardsCombinations.add(new SuitConnectorCardsCombination("KAS+", CardsCombinationType.SUIT_CONNECTOR, (byte) 12));

        for (PokerHandType pokerHandType : PokerHandType.values()) {
            cardsCombinations.add(new PokerHandCardsCombination(pokerHandType.name(), CardsCombinationType.POKER_HAND_TYPE));
        }

        for (CardsCombination cardsCombination : cardsCombinations) {
            cardsCombinationMap.put(cardsCombination.name, cardsCombination);
        }
    }

    private String name;

    private CardsCombinationType type;

    private Byte value;

    public CardsCombination(String name, CardsCombinationType type) {
        this.name = name;
        this.type = type;
    }

    public CardsCombination(String name, CardsCombinationType type, Byte value) {
        this.name = name;
        this.type = type;
        this.value = value;
    }

    public static CardsCombination getCardsCombination(String name) {
        return cardsCombinationMap.get(name.toUpperCase());
    }

    public String getName() {
        return name;
    }

    public CardsCombinationType getType() {
        return type;
    }

    public Byte getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "CardsCombination{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", value=" + value +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CardsCombination that = (CardsCombination) o;

        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (type != that.type) return false;
        if (value != null ? !value.equals(that.value) : that.value != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }

    protected boolean isInside(List<Card> cards) {
        return true;
    }

    public static boolean isCardsInside(List<Card> cards, List<CardsCombination> cardsCombinations) {
        boolean result = false;
        if (cards != null && cardsCombinations != null && cards.size() >= 2) {
            Collections.sort(cards);
            for (CardsCombination cardsCombination : cardsCombinations) {
                if (cardsCombination.isInside(cards)) {
                    result = true;
                    break;
                }
            }
        }
        return result;
    }

}
