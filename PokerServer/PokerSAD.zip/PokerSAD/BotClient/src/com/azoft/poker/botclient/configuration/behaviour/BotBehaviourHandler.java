package com.azoft.poker.botclient.configuration.behaviour;

/**
 * Bot behaviour handler
 */
public class BotBehaviourHandler extends AbstractBotBehaviourHandler<BotBehaviourBean> {

    public BotBehaviourHandler() {
        setBean(new BotBehaviourBean());
    }

}