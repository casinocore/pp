package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.commandprocessing.command.ClientNotifyTableClosedCommand;
import com.azoft.poker.botclient.service.BotTableManagerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientNotifyTableClosedHandler extends ClientHandler<ClientNotifyTableClosedCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientNotifyTableClosedHandler.class);

    public ClientNotifyTableClosedHandler() {
        super();
    }

    public void execute(ClientNotifyTableClosedCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        Long tableId = command.getTableId();
        BotTableManagerImpl.getInstance().removeExitBotForTable(tableId);
        LOGGER.debug("ClientNotifyTableClosedHandler completed for bot: " + bot.toString());
    }

}