package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogHandler extends ClientHandler<Command> {

    private final static Logger LOGGER = LoggerFactory.getLogger(LogHandler.class);

    public LogHandler() {
        super();
    }

    public void execute(Command command) {
        Bot bot = getBotAttribute(command.getSession());
        LOGGER.debug("Execute stub - command: " + command + " for bot: " + bot.toString());
    }

}
