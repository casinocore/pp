package com.azoft.poker.botclient.tableprocessing.bet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Players bets
 */
public class PlayersBets {

    private final static Logger LOGGER = LoggerFactory.getLogger(PlayersBets.class);

    /**
     * Player id
     */
    private Long id;

    /**
     * Player game balance
     */
    private Long gameBalance;

    /**
     * Players bets (key: player Id, value: bets)
     */
    private Map<Long, Long> playersBetsMap = new HashMap<Long, Long>();

    public PlayersBets() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameBalance() {
        return gameBalance;
    }

    public void setGameBalance(Long gameBalance) {
        this.gameBalance = gameBalance;
    }

    public void addGameBalance(Long playerId, Long deltaGameBalance) {
        if (id.equals(playerId)) {
            gameBalance += deltaGameBalance;
            LOGGER.debug("add GameBalance: " + deltaGameBalance + " for playerId: " + playerId);
        }
    }

    public void addPlayerBet(Long playerId, Long value) {
        if (id.equals(playerId)) {
            gameBalance -= value;
            LOGGER.debug("remove GameBalance: " + value + " for playerId: " + playerId);
        }

        Long v = playersBetsMap.get(playerId);
        if (v == null) {
            v = value;
        } else {
            v += value;
        }
        playersBetsMap.put(playerId, v);
    }

    public void clearPlayerBet(Long playerId) {
        playersBetsMap.put(playerId, 0L);
    }

    public Long maxDelta(Long playerId) {
        Long bet = playersBetsMap.get(playerId);
        if (bet == null) {
            bet = 0L;
        }
        Long betMax = 0L;
        for (Map.Entry<Long, Long> entry : playersBetsMap.entrySet()) {
            if (betMax < entry.getValue()) {
                betMax = entry.getValue();
            }
        }
        return betMax - bet;
    }

    public void clear() {
        playersBetsMap.clear();
    }

}
