package com.azoft.poker.botclient.configuration.behaviour;

import com.azoft.poker.lobbyserver.tableprocessing.DealType;

import java.util.HashMap;
import java.util.Map;

/**
 * Parametrised behaviour bean
 */
public class ParametrisedBehaviourBean extends BotBehaviourBean {

    /**
     * Deal map (key: DealType, value: BotDealBean)
     */
    private Map<DealType, BotDealBean> dealBeanMap = new HashMap<DealType, BotDealBean>();

    public ParametrisedBehaviourBean() {
        super();
    }

    public void putDealBean(DealType dealType, BotDealBean dealBean) {
        dealBeanMap.put(dealType, dealBean);
    }

    public BotDealBean getDealBean(DealType dealType) {
        return dealBeanMap.get(dealType);
    }

}
