package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import com.azoft.poker.lobbyserver.tableprocessing.pokerhand.PokerCombinationAnalyzer;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClientNotifyCombinationCommand extends Command {

    private static final int NOT_EXISTS_CARD_VALUE = -1;

    /**
     * Table identifier
     */
    private PokerCombinationAnalyzer combinationAnalyzer;

    public ClientNotifyCombinationCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public PokerCombinationAnalyzer getCombinationAnalyzer() {
        return combinationAnalyzer;
    }

    public void setCombinationAnalyzer(PokerCombinationAnalyzer combinationAnalyzer) {
        this.combinationAnalyzer = combinationAnalyzer;
    }

    @Override
    public String toString() {
        return "ClientNotifyCombinationCommand{" +
                "combinationAnalyzer=" + combinationAnalyzer +
                '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        dis.readByte();
        dis.readByte();
        dis.readByte();
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
    }

}
