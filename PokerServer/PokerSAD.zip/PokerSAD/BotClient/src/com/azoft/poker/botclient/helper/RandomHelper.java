package com.azoft.poker.botclient.helper;

/**
 * Random helper
 */
public class RandomHelper {

    /**
     * Get positive random integer
     *
     * @param intMax integer max
     * @return positive random integer
     */
    public static int getRandomInt(int intMax) {
        int result = 0;
        if (intMax > 0) {
            result = (int) ((intMax + 1) * Math.random());
            if (result > intMax) {
                result = intMax;
            }
        }
        return result;
    }

}
