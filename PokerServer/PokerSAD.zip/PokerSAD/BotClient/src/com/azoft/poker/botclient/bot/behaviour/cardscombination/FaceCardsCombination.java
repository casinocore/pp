package com.azoft.poker.botclient.bot.behaviour.cardscombination;

import com.azoft.poker.lobbyserver.tableprocessing.dealer.Card;

import java.util.List;

/**
 * Face cards combination
 */
public class FaceCardsCombination extends CardsCombination {

    public FaceCardsCombination(String name, CardsCombinationType type) {
        super(name, type);
    }

    public FaceCardsCombination(String name, CardsCombinationType type, Byte value) {
        super(name, type, value);
    }

    protected boolean isInside(List<Card> cards) {
        return cards.get(0).getValue() >= getValue() || cards.get(1).getValue() >= getValue();
    }

}