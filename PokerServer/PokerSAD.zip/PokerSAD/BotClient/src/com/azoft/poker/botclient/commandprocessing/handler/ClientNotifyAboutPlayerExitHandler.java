package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.commandprocessing.command.ClientNotifyAboutPlayerExitCommand;
import com.azoft.poker.lobbyserver.tableprocessing.Table;
import com.azoft.poker.lobbyserver.tableprocessing.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ClientNotifyAboutPlayerExitHandler extends ClientHandler<ClientNotifyAboutPlayerExitCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientNotifyAboutPlayerExitHandler.class);

    public ClientNotifyAboutPlayerExitHandler() {
        super();
    }

    public void execute(ClientNotifyAboutPlayerExitCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        Long playerId = command.getId();
        Table table = bot.getTable();
        if (table != null) {
            List<Player> players = table.getPlayers();
            if (players != null) {
                int i = 0, playersSize = players.size();
                while (i < playersSize) {
                    Player player = players.get(i);
                    if (playerId.equals(player.getId())) {
                        players.remove(player);
                        LOGGER.debug("Remove from table player: " + player + " for bot: " + bot.toString());
                        break;
                    }
                    i++;
                }
            }
        }
        LOGGER.debug("ClientNotifyAboutPlayerExitHandler completed for bot: " + bot.toString());
    }

}