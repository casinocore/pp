package com.azoft.poker.botclient.commandprocessing.handler;

import com.azoft.poker.botclient.bot.Bot;
import com.azoft.poker.botclient.bot.BotStatus;
import com.azoft.poker.botclient.commandprocessing.ClientCommandFactoryImpl;
import com.azoft.poker.botclient.commandprocessing.command.ClientGetLobbyCashCommand;
import com.azoft.poker.botclient.commandprocessing.command.ClientRegisterOnServerCommand;
import com.azoft.poker.botclient.helper.RandomHelper;
import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.lobbyserver.Constants;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class ClientRegisterOnServerHandler extends ClientHandler<ClientRegisterOnServerCommand> {

    private final static Logger LOGGER = LoggerFactory.getLogger(ClientRegisterOnServerHandler.class);

    public ClientRegisterOnServerHandler() {
        super();
    }

    public void execute(ClientRegisterOnServerCommand command) {
        Bot bot = getBotAttribute(command.getSession());
        if (!command.isExistsError()) {
            bot.setStatus(BotStatus.REGISTER_ON_SERVER);
            command.setUserId(bot.getUserId());
            long balance = command.getBalance();
            Set<Long> blinds = bot.getBotInfoBean().getBlinds();
            if (blinds.size() > 0) {
                Long minBigBlind = null;
                List<Long> checkBlinds = new ArrayList<Long>();
                for (Long blind : blinds) {
                    if (minBigBlind == null) {
                        minBigBlind = blind;
                    }
                    if (Constants.bigBlindMultiplier * blind < balance / Constants.gameBalanceCoef) { //see in GameEngine processCommand for SitCommand 
                        checkBlinds.add(blind);
                    }
                }
                if (!checkBlinds.isEmpty()) {
                    sendGetLobbyCashCommand(command.getSession(), checkBlinds);
                } else {
                    bot.setStatus(BotStatus.ERROR);
                    LOGGER.warn("Error. Small balance: " + balance + ", min big blind: " + minBigBlind + "for bot: " + bot.toString());
                }
            } else {
                bot.setStatus(BotStatus.ERROR);
                LOGGER.warn("Error. Empty blinds for bot: " + bot.toString());
            }
        } else {
            bot.setStatus(BotStatus.ERROR);
            LOGGER.error("Error. Not register on server for bot: " + bot.toString());
        }
    }

    private void sendGetLobbyCashCommand(IoSession session, List<Long> checkBlinds) {
        try {
            ClientGetLobbyCashCommand cmd = (ClientGetLobbyCashCommand) ClientCommandFactoryImpl.createClientCommand(
                    session, CommandTypeID.GET_LOBBY_CASH.getTypeId());
            long blind = checkBlinds.get(RandomHelper.getRandomInt(checkBlinds.size() - 1));
            cmd.setBigBlind((int) blind);
            cmd.send();
        } catch (Exception e) {
            LOGGER.error("Create and send command: GET_LOBBY_CASH", e);
        }
    }

}