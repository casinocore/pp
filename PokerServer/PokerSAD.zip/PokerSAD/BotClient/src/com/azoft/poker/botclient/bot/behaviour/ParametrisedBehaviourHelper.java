package com.azoft.poker.botclient.bot.behaviour;

import java.util.ArrayList;
import java.util.List;

/**
 * Parametrised behaviour helper
 */
public class ParametrisedBehaviourHelper {

    public static List<Byte> prepareOrderPositionsByBigBlind(Byte dealer, List<Byte> positions) {
        List<Byte> result = prepareOrderPositions(dealer, positions);
        if (positions.size() > 3) {
            result = prepareOrderPositions(result.get(3), result);
        }
        return result;
    }

    private static List<Byte> prepareOrderPositions(Byte first, List<Byte> positions) {
        List<Byte> result = new ArrayList<Byte>();
        int firstIndex = 0;
        for (int i = 0, dealPlayersSize = positions.size(); i < dealPlayersSize; i++) {
            Byte dealPlayer = positions.get(i);
            if (first.equals(dealPlayer)) {
                firstIndex = i;
            }
        }
        result.addAll(positions.subList(firstIndex, positions.size()));
        if (firstIndex > 0) {
            result.addAll(positions.subList(0, firstIndex));
        }
        return result;
    }

    public static Byte findPosition(Byte placeId, List<Byte> positions) {
        int position = 0;
        for (int i = 0, positionsSize = positions.size(); i < positionsSize; i++) {
            Byte aByte = positions.get(i);
            if (placeId.equals(aByte)) {
                position = (byte) i;
                break;
            }
        }
        if (positions.size() > 2) {
            position = positions.size() - 1 - position;
        }
        return (byte) position;
    }

}
