package com.azoft.poker.botclient.commandprocessing.command;

import com.azoft.poker.common.commandprocessing.CommandTypeID;
import com.azoft.poker.common.commandprocessing.command.Command;
import org.apache.mina.core.session.IoSession;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClientNotifyAboutPlayerExitCommand extends Command {

    /**
     * player identifier (in)
     */
    private Long id;

    public ClientNotifyAboutPlayerExitCommand(IoSession session, CommandTypeID commandTypeID) {
        super(session, commandTypeID);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return super.toString() + " - ClientNotifyAboutPlayerExitCommand{" +
                "id='" + id + '\'' + '}';
    }

    public void decodeBody(DataInputStream dis) throws Exception {
        id = dis.readLong();
    }

    public void encodeBody(DataOutputStream out) throws IOException {
        //empty
    }

}
