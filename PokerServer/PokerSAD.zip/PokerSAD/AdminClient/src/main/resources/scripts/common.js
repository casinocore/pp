function jq(myid) {
	return '#' + myid.replace(/:/g, "\\:").replace(/\./g, "\\.");
}