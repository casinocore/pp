package com.azoft.poker.adminclient.actions.User;

import java.util.List;

import org.apache.struts2.interceptor.validation.SkipValidation;

import com.azoft.poker.adminclient.actions.AbstractAction;
import com.azoft.poker.adminclient.adapters.PagerAdapter;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.person.PersonSearchParams;
import com.opensymphony.xwork2.ModelDriven;

public class UserListAction extends AbstractAction implements
        ModelDriven<PersonSearchParams> {

    private static final long serialVersionUID = 1L;
    private List<Person> users;
    private PagerAdapter pagerAdapter = new PagerAdapter();
    private PersonManager manager;

    private PersonSearchParams params = new PersonSearchParams();

    @Override
    @SkipValidation
    public String execute() {
        pagerAdapter.setRecordsCountAtAll(manager.getPersonCount(params));
        users = manager.getPersons(params, pagerAdapter.getStartFromCount(),
                pagerAdapter.getRecordsCountOnPage());
        return SUCCESS;
    }

    @Override
    public void prepare() {
        manager = PersonManagerImpl.getInstance();
    }

    public List<Person> getUsers() {
        return users;
    }

    public PersonSearchParams getModel() {
        return params;
    }

    public PagerAdapter getPagerAdapter() {
        return pagerAdapter;
    }

    public void setPagerAdapter(PagerAdapter pagerAdapter) {
        this.pagerAdapter = pagerAdapter;
    }

}