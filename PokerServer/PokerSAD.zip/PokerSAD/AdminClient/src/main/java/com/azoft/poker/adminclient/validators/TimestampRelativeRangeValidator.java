package com.azoft.poker.adminclient.validators;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import com.azoft.poker.adminclient.adapters.TimestampAdapter;
import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

public class TimestampRelativeRangeValidator extends FieldValidatorSupport {

    private Integer maxDaysOffset;

    public void setMaxDaysOffset(Integer maxDaysOffset) {
        this.maxDaysOffset = maxDaysOffset;
    }

    public Date getMax() {
        if (maxDaysOffset == null) {
            return null;
        }
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, maxDaysOffset);
        return cal.getTime();
    }

    @Override
    public void validate(Object object) throws ValidationException {
        Object obj = getFieldValue(getFieldName(), object);
        TimestampAdapter value = (TimestampAdapter) obj;
        if (value == null) {
            return;
        }
        Date date = null;
        try {
            date = value.getTimestamp();
        } catch (ParseException e) {
            // ignore
        }
        if (date == null) {
            return;
        }
        if (date.compareTo(getMax()) > 0) {
            addFieldError(getFieldName(), object);
        }
    }

}
