package com.azoft.poker.adminclient.engine;

import com.azoft.poker.common.persistence.admin.Admin;

public class UserSessionImpl implements UserSession {

	private static final long serialVersionUID = 1L;
	private Admin user;

	public Admin getUser() {
		return user;
	}

	/* package */void setUser(Admin user) {
		this.user = user;
	}

}
