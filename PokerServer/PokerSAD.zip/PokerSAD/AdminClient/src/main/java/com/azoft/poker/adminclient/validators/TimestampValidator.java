package com.azoft.poker.adminclient.validators;

import java.text.ParseException;

import com.azoft.poker.adminclient.adapters.TimestampAdapter;
import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

public class TimestampValidator extends FieldValidatorSupport {

	private boolean acceptNull = false;

	public void validate(Object object) throws ValidationException {
		String fieldName = getFieldName();
		Object valueObj = getFieldValue(fieldName, object);

		if (valueObj == null && !acceptNull) {
			addFieldError(fieldName, object);
			return;
		}
		TimestampAdapter adapter;
		if (valueObj instanceof TimestampAdapter) {

			adapter = (TimestampAdapter) valueObj;
		} else {
			addFieldError(fieldName, object);
			return;
		}

		try {
			if (adapter.getTimestamp() == null && !acceptNull) {
				addFieldError(fieldName, object);
				return;
			}
		} catch (ParseException e) {
			addFieldError(fieldName, object);
			return;
		}

	}

	public boolean isAcceptNull() {
		return acceptNull;
	}

	public void setAcceptNull(boolean acceptNull) {
		this.acceptNull = acceptNull;
	}

}
