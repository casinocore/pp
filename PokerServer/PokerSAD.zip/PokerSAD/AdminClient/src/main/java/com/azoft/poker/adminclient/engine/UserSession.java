package com.azoft.poker.adminclient.engine;

import java.io.Serializable;

import com.azoft.poker.common.persistence.admin.Admin;

public interface UserSession extends Serializable {

	Admin getUser();
}
