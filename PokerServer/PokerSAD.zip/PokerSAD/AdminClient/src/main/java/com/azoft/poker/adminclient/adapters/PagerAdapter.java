package com.azoft.poker.adminclient.adapters;

import java.util.ArrayList;
import java.util.List;

public class PagerAdapter {
    private Integer position;
    private long recordCountTotal;
    private Integer recordCountOnPage;
    private static List<Integer> recordCountOnPageList = new ArrayList<Integer>();
    static {
        recordCountOnPageList.add(5);
        recordCountOnPageList.add(10);
        recordCountOnPageList.add(20);
        recordCountOnPageList.add(50);
        recordCountOnPageList.add(100);
        recordCountOnPageList.add(500);
        recordCountOnPageList.add(1000);
    }

    public PagerAdapter() {
        position = 1;
        recordCountOnPage = 10;
    }

    public Integer getBackwardPosition() {
        if (getCurrentPosition() > 1) {
            return position - 1;
        }
        return null;
    }

    public Integer getCurrentPosition() {
        return Math.min(position, getPageCountInAPager());
    }

    public Integer getForwardPosition() {
        if (getCurrentPosition() < getPageCountInAPager()) {
            return position + 1;
        }
        return null;
    }

    public Integer getPageCountInAPager() {
        long pageCountInAPager = (recordCountTotal / recordCountOnPage)
                + (0 != recordCountTotal % recordCountOnPage ? 1 : 0);
        return (int) Math.max(pageCountInAPager, 1);
    }

    public long getRecordsCountAtAll() {
        return recordCountTotal;
    }

    public Integer getRecordsCountOnPage() {
        return recordCountOnPage;
    }

    public List<Integer> getRecordsCountOnPageList() {
        return recordCountOnPageList;
    }

    public long getStartFromCount() {
        return (getCurrentPosition() - 1) * recordCountOnPage;
    }

    public void setCurrentPosition(Integer position) {
        this.position = position;
    }

    public void setRecordsCountOnPage(Integer count) {
        recordCountOnPage = count;
    }

    public void setRecordsCountAtAll(long count) {
        recordCountTotal = count;
    }
}
