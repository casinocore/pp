package com.azoft.poker.adminclient.actions.Tournament;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.azoft.poker.adminclient.actions.AbstractEditAction;
import com.azoft.poker.adminclient.adapters.TimestampAdapter;
import com.azoft.poker.common.bean.Blind;
import com.azoft.poker.common.bean.SynchronousHand;
import com.azoft.poker.common.exception.CommonException;
import com.azoft.poker.common.persistence.person.InfoPlayerBean;
import com.azoft.poker.common.persistence.person.Person;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;
import com.azoft.poker.common.persistence.tournament.MTTTournamentWrapper;
import com.azoft.poker.common.persistence.tournament.TemporalTournamentWrapper;
import com.azoft.poker.common.persistence.tournament.Tournament;
import com.azoft.poker.common.persistence.tournament.TournamentFactoryImpl;
import com.azoft.poker.common.persistence.tournament.TournamentManager;
import com.azoft.poker.common.persistence.tournament.TournamentManagerImpl;
import com.azoft.poker.common.persistence.tournament.TournamentStatusID;
import com.azoft.poker.common.persistence.tournament.TournamentWrapper;
import com.opensymphony.xwork2.ModelDriven;

public class TournamentEditAction extends AbstractEditAction implements
        ModelDriven<TournamentWrapper> {

    private static final long serialVersionUID = 1L;

    private static final String FROM_TIME_FIELD = "fromTime";
    private static final String TO_TIME_FIELD = "toTime";
    private static final String REGISTRATION_START_FIELD = "registrationStart";
    private static final String CANCEL_REGISTRATION_PERIOD_FIELD = "cancelRegistrationPeriod";
    private static final String REBUY_PERIOD_FIELD = "rebuyField";
    private static final String REBUY_FIELD = "rebuy";
    private static final String BLINDS_FIELD = "blinds";
    private static final String BLIND_PERIOD_FIELD = "blindPeriod";
    private static final String MIN_PLAYERS_COUNT_FIELD = "minPlayersCount";

    private static final String END_BEFORE_START_ERROR_KEY = "tournament.error.end_before_start";
    private static final String START_TOO_SOON_ERROR_KEY = "tournament.error.start_too_soon";
    private static final String TOURNAMENT_EXIST_ERROR_KEY = "tournament.error.already_exist";
    private static final String NO_BLINDS_ERROR_KEY = "tournament.error.no_blinds";
    private static final String BLINDS_INVALID_ERROR_KEY = "tournament.error.invalid_blinds";
    private static final String MIN_PLAYERS_ERROR_KEY = "tournament.error.min_players";
    private static final String REQUIRED_FIELD = "validation.required";
    private static final String REGISTRATION_AFTER_START_ERROR_KEY = "tournament.error.registration_after_start";
    private static final String REGISTRATION_TOO_SOON_ERROR_KEY = "tournament.error.registration_too_soon";

    private static final String MINUTE_GAP_KEY = "tournament.minute_gap";

    private TournamentManager tournamentManager = TournamentManagerImpl
            .getInstance();
    private PersonManager personManager = PersonManagerImpl.getInstance();

    private Long pk;
    private Byte type;

    private TournamentWrapper wrapper;
    private TimestampAdapter fromTime;
    private TimestampAdapter toTime;
    private TimestampAdapter registrationStart;

    private List<Integer> feeNumbers;
    private List<Integer> feeValues;

    private List<String> smallBlinds;
    private List<String> bigBlinds;

    private List<Long> syncHandStarts;
    private List<Long> syncHandFinishes;

    private List<Byte> types;

    private List<InfoPlayerBean> players;
    private Map<Long, Person> persons;

    @Override
    public void prepare() {
        Tournament tournament = tournamentManager.getTournament(pk);
        try {
            wrapper = TournamentFactoryImpl.createTournamentWrapper(tournament);
        } catch (CommonException e) {
            throw new RuntimeException(e);
        }
        prepareDates();
        prepareLists();
        preparePlayers();
    }

    @Override
    public void prepareInsert() {
        Tournament tournament = new Tournament();
        tournament.setType(type == null ? TournamentType.TEMPORAL_TOURNAMENT
                .getTypeId() : type);
        try {
            wrapper = TournamentFactoryImpl.createTournamentWrapper(tournament);
        } catch (CommonException e) {
            throw new RuntimeException(e);
        }
        prepareDates();
        prepareLists();
    }

    @Override
    public String submitInsert() {
        validateTournament();
        if (hasErrors()) {
            return INPUT;
        }
        saveDates();
        saveLists();
        tournamentManager.saveTournament(wrapper.getEntity());
        pk = wrapper.getId();
        return SUCCESS;
    }

    @Override
    public String update() {
        if (!isEditable()) {
            return ACCESS_DENIED;
        }
        return super.update();
    }

    @Override
    public String submitUpdate() {
        if (!isEditable()) {
            return ACCESS_DENIED;
        }
        validateTournament();
        if (hasErrors()) {
            return INPUT;
        }
        saveDates();
        saveLists();
        tournamentManager.updateTournament(wrapper.getEntity());
        return SUCCESS;
    }

    private void validateTournament() {
        Map<String, List<String>> errors = getFieldErrors();

        Date fromDate = null;
        try {
            fromDate = fromTime.getTimestamp();
        } catch (ParseException e) {
            // ignore, should be validated before
        }

        Calendar cal = Calendar.getInstance(getTimeZone());
        String minuteGapStr = getText(MINUTE_GAP_KEY);
        Integer minuteGap = Integer.valueOf(minuteGapStr);
        Date now = cal.getTime();
        cal.add(Calendar.MINUTE, minuteGap);
        if (!fromDate.after(cal.getTime())) {
            addFieldError(
                    FROM_TIME_FIELD,
                    getText(START_TOO_SOON_ERROR_KEY,
                            new String[] { minuteGapStr }));
        }

        if (wrapper instanceof MTTTournamentWrapper) {
            MTTTournamentWrapper mttWrapper = (MTTTournamentWrapper) wrapper;

            Short cancelPeriod = mttWrapper.getCancelRegistrationPeriod();
            if ((cancelPeriod == null || cancelPeriod <= 0)
                    && !errors.containsKey(CANCEL_REGISTRATION_PERIOD_FIELD)) {
                mttWrapper.setCancelRegistrationAccessible(false);
            }

            Short rebuyPeriod = mttWrapper.getRebuyPeriod();
            Long rebuyValue = mttWrapper.getRebuy();
            if ((rebuyPeriod == null || rebuyPeriod <= 0 || rebuyValue == null || rebuyValue <= 0)
                    && (!errors.containsKey(REBUY_PERIOD_FIELD) && !errors
                            .containsKey(REBUY_FIELD))) {
                mttWrapper.setRebuyAccessible(false);
            }

            if (mttWrapper.getBlindPeriod() == null) {
                addFieldError(BLIND_PERIOD_FIELD, getText(REQUIRED_FIELD));
            }

            boolean blindsExist = false;
            boolean blindsCorrect = true;
            for (int i = 0; i < smallBlinds.size(); i++) {
                if (i > bigBlinds.size()) {
                    break;
                }
                Integer small;
                Integer big;
                try {
                    small = Integer.parseInt(smallBlinds.get(i));
                    big = Integer.valueOf(bigBlinds.get(i));
                } catch (NumberFormatException e) {
                    small = null;
                    big = null;
                }
                if (small != null && big != null) {
                    blindsExist = true;
                    if (small >= big) {
                        blindsCorrect = false;
                    }
                }
            }
            if (!blindsExist) {
                addFieldError(BLINDS_FIELD, getText(NO_BLINDS_ERROR_KEY));
            } else if (!blindsCorrect) {
                addFieldError(BLINDS_FIELD, getText(BLINDS_INVALID_ERROR_KEY));
            }

            if (wrapper.getMinPlayersCount() == null) {
                addFieldError(MIN_PLAYERS_COUNT_FIELD, getText(REQUIRED_FIELD));
            } else if (wrapper.getMinPlayersCount() < 2) {
                addFieldError(MIN_PLAYERS_COUNT_FIELD,
                        getText(MIN_PLAYERS_ERROR_KEY));
            }

            Date registrationDate = null;

            try {
                registrationDate = registrationStart.getTimestamp();
            } catch (ParseException e) {
                // ignore
            }
            if (registrationDate == null) {
                addFieldError(REGISTRATION_START_FIELD, getText(REQUIRED_FIELD));
                return;
            }

            if (!registrationDate.before(fromDate)) {
                addFieldError(REGISTRATION_START_FIELD,
                        getText(REGISTRATION_AFTER_START_ERROR_KEY));
            }

            if (!registrationDate.after(now)) {
                addFieldError(REGISTRATION_START_FIELD,
                        getText(REGISTRATION_TOO_SOON_ERROR_KEY));
            }
        } else {

            Date toDate = null;

            try {
                toDate = toTime.getTimestamp();
            } catch (ParseException e) {
                // ignore
            }
            if (toDate == null) {
                addFieldError(TO_TIME_FIELD, getText(REQUIRED_FIELD));
                return;
            }

            if (!toDate.after(fromDate)) {
                addFieldError(TO_TIME_FIELD,
                        getText(END_BEFORE_START_ERROR_KEY));
            }

            if (hasErrors()) {
                return;
            }

            int existingCount = tournamentManager.getExistingTournamentsCount(
                    fromDate, toDate, wrapper.getType(), wrapper.getId());
            if (existingCount != 0) {
                addFieldError(FROM_TIME_FIELD,
                        getText(TOURNAMENT_EXIST_ERROR_KEY));
            }
        }

    }

    private void preparePlayers() {
        if (wrapper.getType().equals(
                TournamentType.MULTI_TABLE_TOURNAMENT.getTypeId())) {
            if (wrapper.getStatus().equals(TournamentStatusID.ACTIVE)) {
                players = tournamentManager.getMTTPlayersByBalance(pk,
                        wrapper.getWinnerCount());
            } else {
                players = tournamentManager.getMTTPlayersByLeavingTime(pk,
                        wrapper.getWinnerCount());
            }
        } else {
            players = tournamentManager.getTournamentPlayers(pk,
                    wrapper.getWinnerCount());
        }
        persons = new HashMap<Long, Person>();
        for (InfoPlayerBean player : players) {
            persons.put(player.getPlayerId(),
                    personManager.getPerson(player.getPlayerId()));
        }
    }

    private void prepareDates() {
        fromTime = new TimestampAdapter(wrapper.getFromDate());
        toTime = new TimestampAdapter(wrapper.getToDate());
        if (wrapper instanceof MTTTournamentWrapper) {
            MTTTournamentWrapper mttWrapper = (MTTTournamentWrapper) wrapper;
            registrationStart = new TimestampAdapter(
                    mttWrapper.getStartRegistration());
        } else {
            registrationStart = new TimestampAdapter();
        }
    }

    private void prepareLists() {
        feeValues = new ArrayList<Integer>();
        feeNumbers = new ArrayList<Integer>();

        smallBlinds = new ArrayList<String>();
        bigBlinds = new ArrayList<String>();
        syncHandStarts = new ArrayList<Long>();
        syncHandFinishes = new ArrayList<Long>();

        if (wrapper.getId() == null) {
            syncHandStarts.add(11L);
            syncHandFinishes.add(10L);
        }

        if (wrapper instanceof TemporalTournamentWrapper) {
            Map<String, String> attributes = wrapper.getAttributes();
            for (String key : attributes.keySet()) {
                if (key.startsWith(TournamentWrapper.FEE_PREFIX)) {
                    Integer feeNumber = Integer.valueOf(key
                            .substring(TournamentWrapper.FEE_PREFIX.length()));
                    feeNumbers.add(feeNumber);
                }
            }
            Collections.sort(feeNumbers);
            for (Integer number : feeNumbers) {
                Integer feeValue = Integer.valueOf(attributes
                        .get(TournamentWrapper.FEE_PREFIX + number));
                feeValues.add(feeValue);
            }
        }

        if (wrapper instanceof MTTTournamentWrapper) {
            MTTTournamentWrapper mttWrapper = (MTTTournamentWrapper) wrapper;

            List<Blind> blinds = mttWrapper.getBlinds();
            for (Blind blind : blinds) {
                bigBlinds.add(blind.getBigBlind().toString());
                smallBlinds.add(blind.getSmallBlind().toString());
            }

            List<SynchronousHand> syncHands = mttWrapper.getSynchronousHands();
            for (SynchronousHand syncHand : syncHands) {
                syncHandStarts.add(syncHand.getStartNumber());
                syncHandFinishes.add(syncHand.getFinishedNumber());
            }

        }
    }

    private void saveLists() {

        if (wrapper instanceof TemporalTournamentWrapper) {
            clearAttributesByPrefix(TournamentWrapper.FEE_PREFIX);
            if (feeNumbers != null && feeValues != null) {
                for (int i = 0; i < feeNumbers.size(); i++) {
                    Integer number = feeNumbers.get(i);
                    if (number == null) {
                        continue;
                    }
                    if (i > feeValues.size()) {
                        break;
                    }
                    Integer value = feeValues.get(i);
                    wrapper.addAttribute(TournamentWrapper.FEE_PREFIX + number,
                            value == null ? null : value.toString());
                }
            }
        }
        if (wrapper instanceof MTTTournamentWrapper) {
            MTTTournamentWrapper mttWrapper = (MTTTournamentWrapper) wrapper;

            clearAttributesByPrefix(MTTTournamentWrapper.mttBigBlind_PREFIX);
            clearAttributesByPrefix(MTTTournamentWrapper.mttSmallBlind_PREFIX);
            clearAttributesByPrefix(MTTTournamentWrapper.mttSynchronousHandStart_PREFIX);
            clearAttributesByPrefix(MTTTournamentWrapper.mttSynchronousHandFinished_PREFIX);

            int blindCount = 0;
            if (smallBlinds != null && bigBlinds != null) {
                for (int i = 0; i < smallBlinds.size(); i++) {
                    if (i > bigBlinds.size()) {
                        break;
                    }
                    Integer small;
                    Integer big;
                    try {
                        small = Integer.valueOf(smallBlinds.get(i));
                        big = Integer.valueOf(bigBlinds.get(i));
                    } catch (NumberFormatException e) {
                        small = null;
                        big = null;
                    }
                    if (small == null || big == null) {
                        continue;
                    }
                    mttWrapper.setSmallBlind((short) (blindCount + 1), small);
                    mttWrapper.setBigBlind((short) (blindCount + 1), big);
                    blindCount++;
                }
            }

            if (syncHandStarts != null && syncHandFinishes != null) {
                for (int i = 0; i < syncHandStarts.size(); i++) {
                    Long start = syncHandStarts.get(i);
                    if (i > syncHandFinishes.size()) {
                        break;
                    }
                    Long finish = syncHandFinishes.get(i);
                    if (start == null || finish == null) {
                        continue;
                    }
                    mttWrapper.setSynchronousHandStart((short) (i + 1), start);
                    mttWrapper.setSynchronousHandFinished((short) (i + 1),
                            finish);
                }
            }

        }
    }

    private void clearAttributesByPrefix(String prefix) {
        Iterator<Entry<String, String>> iterator = wrapper.getAttributes()
                .entrySet().iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getKey().startsWith(prefix)) {
                iterator.remove();
            }
        }
    }

    private void saveDates() {
        try {
            wrapper.setFromDate(fromTime.getTimestamp());
            wrapper.setToDate(toTime.getTimestamp());
            if (wrapper instanceof MTTTournamentWrapper) {
                MTTTournamentWrapper mttWrapper = (MTTTournamentWrapper) wrapper;
                mttWrapper.setStartRegistration(registrationStart
                        .getTimestamp());
            }
        } catch (ParseException e) {
            // ignore, should be validated before
        }
    }

    @Override
    public TournamentWrapper getModel() {
        return wrapper;
    }

    public Long getPk() {
        return pk;
    }

    public void setPk(Long pk) {
        this.pk = pk;
    }

    public TimestampAdapter getFromTime() {
        return fromTime;
    }

    public void setFromTime(TimestampAdapter fromTime) {
        this.fromTime = fromTime;
    }

    public TimestampAdapter getToTime() {
        return toTime;
    }

    public void setToTime(TimestampAdapter toTime) {
        this.toTime = toTime;
    }

    public List<Byte> getTypes() {
        if (types == null) {
            types = new ArrayList<Byte>();
            for (TournamentType id : TournamentType.values()) {
                types.add(id.getTypeId());
            }
            Collections.sort(types);
        }
        return types;
    }

    public boolean isEditable() {
        return wrapper != null
                && wrapper.getStatus().equals(
                        TournamentStatusID.PLANNED.getTypeId());
    }

    public Integer getFeeValue(Integer index) {
        return feeValues.get(index);
    }

    public List<Integer> getFeeValues() {
        return feeValues;
    }

    public void setFeeValues(List<Integer> feeValues) {
        this.feeValues = feeValues;
    }

    public void setFeeNumbers(List<Integer> feeNumbers) {
        this.feeNumbers = feeNumbers;
    }

    public List<Integer> getFeeNumbers() {
        return feeNumbers;
    }

    public List<InfoPlayerBean> getPlayers() {
        return players;
    }

    public Person getPerson(Long personId) {
        return persons.get(personId);
    }

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public TimestampAdapter getRegistrationStart() {
        return registrationStart;
    }

    public void setRegistrationStart(TimestampAdapter registrationStart) {
        this.registrationStart = registrationStart;
    }

    public List<String> getSmallBlinds() {
        return smallBlinds;
    }

    public void setSmallBlinds(List<String> smallBlinds) {
        this.smallBlinds = smallBlinds;
    }

    public List<String> getBigBlinds() {
        return bigBlinds;
    }

    public void setBigBlinds(List<String> bigBlinds) {
        this.bigBlinds = bigBlinds;
    }

    public List<Long> getSyncHandStarts() {
        return syncHandStarts;
    }

    public void setSyncHandStarts(List<Long> syncHandStarts) {
        this.syncHandStarts = syncHandStarts;
    }

    public List<Long> getSyncHandFinishes() {
        return syncHandFinishes;
    }

    public void setSyncHandFinishes(List<Long> syncHandFinishes) {
        this.syncHandFinishes = syncHandFinishes;
    }

}