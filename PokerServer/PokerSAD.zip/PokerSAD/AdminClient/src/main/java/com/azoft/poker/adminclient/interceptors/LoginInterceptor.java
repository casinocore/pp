package com.azoft.poker.adminclient.interceptors;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.StrutsStatics;

import com.azoft.poker.adminclient.engine.AuthServiceImpl;
import com.azoft.poker.adminclient.engine.AuthenticationException;
import com.azoft.poker.adminclient.engine.UserSession;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class LoginInterceptor extends AbstractInterceptor {

    private static final long serialVersionUID = 1L;

    private static final String USER_HANDLE = "__user";
    private static final String USER_LOGIN_HANDLE = "__user_login";
    private static final String USER_SESSION_HANDLE = "__user_session";

    private static final int LOGIN_STATUS_CODE = HttpServletResponse.SC_UNAUTHORIZED;
    private static final int ACCESS_DENIED_STATUS_CODE = HttpServletResponse.SC_FORBIDDEN;
    private static final int EXCEPTION_STATUS_CODE = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;

    public static UserSession getUserSession() {
        ActionContext context = ActionContext.getContext();
        HttpServletRequest request = (HttpServletRequest) context
                .get(StrutsStatics.HTTP_REQUEST);
        HttpSession session = request.getSession(false);
        return (UserSession) session.getAttribute(USER_SESSION_HANDLE);
    }

    public static String getLogin() {
        ActionContext context = ActionContext.getContext();
        HttpServletRequest request = (HttpServletRequest) context
                .get(StrutsStatics.HTTP_REQUEST);
        HttpSession session = request.getSession(false);
        return (String) session.getAttribute(USER_LOGIN_HANDLE);
    }

    public static void logout() {
        ActionContext context = ActionContext.getContext();
        HttpServletRequest request = (HttpServletRequest) context
                .get(StrutsStatics.HTTP_REQUEST);
        HttpSession session = request.getSession(false);
        session.removeAttribute(USER_SESSION_HANDLE);
        session.removeAttribute(USER_HANDLE);
        session.invalidate();
    }

    @Override
    public String intercept(ActionInvocation invocation) throws Exception {
        ActionContext context = invocation.getInvocationContext();
        HttpServletRequest request = (HttpServletRequest) context
                .get(StrutsStatics.HTTP_REQUEST);
        HttpServletResponse response = (HttpServletResponse) context
                .get(StrutsStatics.HTTP_RESPONSE);
        HttpSession session = request.getSession(true);

        // Is there a "user" object stored in the user's HttpSession?
        Object user = session.getAttribute(USER_HANDLE);
        if (user == null) {
            // The user has not logged in yet.
            String loginAttempt = request.getParameter("login_attempt");

            // Is the user attempting to log in right now?
            if (loginAttempt != null && loginAttempt != "") {
                // The user is attempting to log in.
                try {
                    // Process the user's login attempt.
                    if (login(request, session)) {
                        // The login succeeded send them the login-success page.
                        return invocation.invoke();
                    } else {
                        response.setStatus(ACCESS_DENIED_STATUS_CODE);
                        request.setAttribute("error_message",
                                "login.access_denied");
                    }
                } catch (Throwable t) {
                    Logger.getLogger(LoginInterceptor.class).error(
                            "Cannot process login attempt", t);
                    invocation.getStack().set("exception", t);
                    response.setStatus(EXCEPTION_STATUS_CODE);
                    return "exception";
                }
            }

            invocation.getStack().set("parameterMap", context.getParameters());
            invocation.getStack().set("request", request);

            // Either the login attempt failed or the user hasn't tried to login
            // yet,
            // and we need to send the login form.

            response.setStatus(LOGIN_STATUS_CODE);
            return "login";
        } else {
            return invocation.invoke();
        }
    }

    private boolean login(HttpServletRequest request, HttpSession session) {
        try {
            UserSession userSession = doAuth(request.getParameter("login"),
                    request.getParameter("password"), request);

            processLoginAttempt(userSession, session,
                    request.getParameter("login"));
            return true;
        } catch (AuthenticationException e) {
            return false;
        }
    }

    private UserSession doAuth(String login, String password,
            HttpServletRequest request) throws AuthenticationException {

        return AuthServiceImpl.getInstance().auth(login, password);
    }

    private void processLoginAttempt(UserSession userSession,
            HttpSession session, String login) {
        session.setAttribute(USER_SESSION_HANDLE, userSession);
        session.setAttribute(USER_LOGIN_HANDLE, login);
        session.setAttribute(USER_HANDLE, userSession.getUser());
    }

    public static String requestParams(ActionInvocation actionInvocation) {
        StringBuilder requestString = new StringBuilder();
        Map<String, Object> parameters = actionInvocation
                .getInvocationContext().getParameters();

        int count = 0;
        Iterator<Map.Entry<String, Object>> parametersItr = parameters
                .entrySet().iterator();
        while (parametersItr.hasNext()) {
            Map.Entry<String, Object> entry = parametersItr.next();

            // add the parameter onto the request string
            String parameterKey = entry.getKey();
            String[] parameterValue = LoginInterceptor
                    .extractParameterValue(entry.getValue());
            if (parameterValue != null) {
                for (String element : parameterValue) {
                    // if it's the first parameter add a '?' else add a '&'
                    requestString.append((count == 0) ? "?" : "&");

                    // get the parameter at this point
                    requestString.append(parameterKey).append("=")
                            .append(element);
                    count++;
                }
            }
        }
        return requestString.toString();
    }

    private static String[] extractParameterValue(Object parameterValueObj) {
        String[] parameterValue = null;
        if (parameterValueObj instanceof String) {
            parameterValue = new String[1];
            parameterValue[0] = (String) parameterValueObj;
        } else if (parameterValueObj instanceof String[]) {
            parameterValue = (String[]) parameterValueObj;
        }
        return parameterValue;
    }

}
