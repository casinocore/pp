package com.azoft.poker.adminclient.adapters;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import com.azoft.poker.adminclient.engine.util.DateFormat;
import com.azoft.poker.common.helper.StringHelper;

public class TimestampAdapter implements Comparable<Date> {
    private final SimpleDateFormat dateFormat = new DateFormat(
            DateFormat.HUMAN_DATE_FORMAT);
    private final SimpleDateFormat timeFormat = new DateFormat(
            DateFormat.HUMAN_TIME_FORMAT);
    private final SimpleDateFormat timestampFormat = new DateFormat(
            DateFormat.HUMAN_TIMESTAMP_FORMAT);
    private String time;
    private String date;
    public static final String DEFAULT_TIME = "00:00";

    public TimestampAdapter() {

    }

    public TimestampAdapter(Date timestamp) {
        if (timestamp != null) {
            setTimestamp(timestamp, TimeZone.getDefault());
        }
    }

    public TimestampAdapter(Date timestamp, TimeZone timezone) {
        if (timestamp != null) {
            setTimestamp(timestamp, timezone);
        }
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setTime(Date time, TimeZone timezone) {
        dateFormat.setTimeZone(timezone);
        this.time = dateFormat.format(time);
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDate(Date date, TimeZone timezone) {
        dateFormat.setTimeZone(timezone);
        this.date = dateFormat.format(date);
    }

    public void setTimestamp(Date timestamp, TimeZone timezone) {
        dateFormat.setTimeZone(timezone);
        timeFormat.setTimeZone(timezone);
        time = timeFormat.format(timestamp);
        date = dateFormat.format(timestamp);
    }

    public Date getTimestamp(TimeZone timezone) throws ParseException {
        if (time == null || date == null) {
            return null;
        } else if (time.equalsIgnoreCase("") || date.equalsIgnoreCase("")) {
            return null;
        }

        timestampFormat.setTimeZone(timezone);

        return timestampFormat.parse(time + " " + date);

    }

    public Date getTimestamp() throws ParseException {
        return getTimestamp(TimeZone.getDefault());
    }

    public String getTime() {
        return time;
    }

    public String getDate() {
        return date;
    }

    public boolean isEmpty() {
        return StringHelper.isEmpty(time) || StringHelper.isEmpty(date);
    }

    static public TimestampAdapter createDefaultTimestampFromAdapter(
            TimeZone timezone) {
        TimestampAdapter timestampAdapter = new TimestampAdapter();
        timestampAdapter.setTime(TimestampAdapter.DEFAULT_TIME);
        Calendar calendar = Calendar.getInstance(timezone);
        timestampAdapter.setDate(calendar.getTime(), timezone);
        return timestampAdapter;
    }

    static public TimestampAdapter createDefaultTimestampTillAdapter(
            TimeZone timezone) {
        TimestampAdapter timestampAdapter = new TimestampAdapter();
        timestampAdapter.setTime(TimestampAdapter.DEFAULT_TIME);
        Calendar calendar = Calendar.getInstance(timezone);
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        timestampAdapter.setDate(calendar.getTime(), timezone);
        return timestampAdapter;
    }

    @Override
    public int compareTo(Date o) {
        try {
            Date value = getTimestamp();
            if (value == null) {
                return o == null ? 0 : -1;
            }
            return o == null ? 1 : value.compareTo(o);
        } catch (ParseException e) {
            return -1;
        }
    }
}
