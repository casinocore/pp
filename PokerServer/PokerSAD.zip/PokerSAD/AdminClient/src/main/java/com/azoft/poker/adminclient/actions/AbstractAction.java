package com.azoft.poker.adminclient.actions;

import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import org.apache.struts2.interceptor.ParameterAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public abstract class AbstractAction extends ActionSupport implements
        Preparable, ParameterAware {

    private static final long serialVersionUID = 1L;

    private String tab;

    private Map<String, String[]> parameters;

    public String getTab() {
        return tab;
    }

    public void setTab(String tab) {
        this.tab = tab;
    }

    public void prepare() {

    }

    public TimeZone getTimeZone() {
        return TimeZone.getDefault();
    }

    public Date getCurrentDate() {
        return new Date();
    }

    public void setParameters(Map<String, String[]> parameters) {
        this.parameters = parameters;

    }

    public Map<String, String[]> getParameters() {
        return parameters;
    }

}
