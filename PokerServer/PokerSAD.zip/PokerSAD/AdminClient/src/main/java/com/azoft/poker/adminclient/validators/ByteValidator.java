package com.azoft.poker.adminclient.validators;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

public class ByteValidator extends FieldValidatorSupport {

	public void validate(Object object) throws ValidationException {
		Object obj = getFieldValue(getFieldName(), object);

		if (obj == null || !(obj instanceof Byte)) {
			addFieldError(getFieldName(), object);
		}

	}

}
