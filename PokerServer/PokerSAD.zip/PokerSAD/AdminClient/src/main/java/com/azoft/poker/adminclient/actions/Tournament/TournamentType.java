package com.azoft.poker.adminclient.actions.Tournament;

public enum TournamentType {
    TEMPORAL_TOURNAMENT((byte) 2), MULTI_TABLE_TOURNAMENT((byte) 3);

    private byte typeId;

    TournamentType(byte typeId) {
        this.typeId = typeId;
    }

    public byte getTypeId() {
        return typeId;
    }

    public static TournamentType valueOf(byte typeId) {
        TournamentType result = null;
        for (TournamentType type : TournamentType.values()) {
            if (type.getTypeId() == typeId) {
                result = type;
                break;
            }
        }
        return result;
    }

}
