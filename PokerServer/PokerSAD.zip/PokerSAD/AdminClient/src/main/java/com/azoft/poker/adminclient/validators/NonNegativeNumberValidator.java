package com.azoft.poker.adminclient.validators;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

public class NonNegativeNumberValidator extends FieldValidatorSupport {

	private boolean acceptNull = false;

	public void validate(Object object) throws ValidationException {
		String fieldName = getFieldName();
		Object valueObj = getFieldValue(fieldName, object);

		if (valueObj == null && !acceptNull) {
			addFieldError(fieldName, object);
			return;
		}

		Number value = null;
		if (valueObj instanceof Number) {
			value = (Number) valueObj;
		} else {
			addFieldError(fieldName, object);
			return;
		}

		if (value.intValue() <= 0) {
			addFieldError(fieldName, object);
			return;
		}

	}

	public boolean isAcceptNull() {
		return acceptNull;
	}

	public void setAcceptNull(boolean acceptNull) {
		this.acceptNull = acceptNull;
	}
}
