package com.azoft.poker.adminclient.interceptors;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
import com.opensymphony.xwork2.interceptor.PrefixMethodInvocationUtil;

public class PrepareInterceptor extends MethodFilterInterceptor {
	private static final long serialVersionUID = -3886243747500389967L;

	private final static String PREPARE_PREFIX = "prepare";
	private final static String ALT_PREPARE_PREFIX = "prepareDo";

	private boolean alwaysInvokePrepare = true;

	public void setAlwaysInvokePrepare(String alwaysInvokePrepare) {
		this.alwaysInvokePrepare = Boolean.parseBoolean(alwaysInvokePrepare);
	}

	@Override
	public String doIntercept(ActionInvocation invocation) throws Exception {
		Object action = invocation.getAction();

		if (action instanceof Preparable) {
			PrefixMethodInvocationUtil.invokePrefixMethod(invocation,
					new String[] { PREPARE_PREFIX, ALT_PREPARE_PREFIX });
			if (alwaysInvokePrepare) {
				((Preparable) action).prepare();
			}
		}
		return invocation.invoke();
	}
}
