package com.azoft.poker.adminclient.actions.User.ajax;

import org.apache.struts2.interceptor.validation.SkipValidation;

import com.azoft.poker.adminclient.actions.AbstractAction;
import com.azoft.poker.common.persistence.person.PersonManager;
import com.azoft.poker.common.persistence.person.PersonManagerImpl;

public class UserAddChipsAction extends AbstractAction {

    private static final long serialVersionUID = 1L;
    private static final String ERROR_KEY = "user.add_chips.error.invalid_number";

    PersonManager manager;

    private Long pk;
    private Long value;
    private Long balance;
    private String error;

    @Override
    @SkipValidation
    public String execute() {
        if (pk != null && value != null) {
            manager.addChips(pk, value);
            balance = manager.getPerson(pk).getBalance();
        } else {
            error = getText(ERROR_KEY);
        }
        return SUCCESS;
    }

    @Override
    public void prepare() {
        manager = PersonManagerImpl.getInstance();
    }

    public Long getPk() {
        return pk;
    }

    public void setPk(Long pk) {
        this.pk = pk;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    public Long getBalance() {
        return balance;
    }

    public String getError() {
        return error;
    }

}
