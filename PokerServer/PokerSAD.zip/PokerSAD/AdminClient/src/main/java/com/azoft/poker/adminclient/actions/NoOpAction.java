package com.azoft.poker.adminclient.actions;

import com.azoft.poker.adminclient.interceptors.LoginInterceptor;

public class NoOpAction extends AbstractAction {

	private static final long serialVersionUID = 1L;

	@Override
	public String execute() {
		return SUCCESS;
	}

	public String logout() throws Exception {
		LoginInterceptor.logout();
		return SUCCESS;
	}
}
