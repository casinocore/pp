package com.azoft.poker.adminclient.actions.Tournament;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.azoft.poker.adminclient.actions.AbstractAction;
import com.azoft.poker.common.persistence.tournament.Tournament;
import com.azoft.poker.common.persistence.tournament.TournamentManager;
import com.azoft.poker.common.persistence.tournament.TournamentManagerImpl;

public class TournamentListAction extends AbstractAction {

	private static final long serialVersionUID = 1L;

	private List<Tournament> tournaments;

	@Override
	public String execute() {
		return SUCCESS;
	}

	@Override
	public void prepare() {
		TournamentManager manager = TournamentManagerImpl.getInstance();
		tournaments = manager.getTournaments();
		Collections.sort(tournaments, new Comparator<Tournament>() {

			public int compare(Tournament o1, Tournament o2) {
				return -o1.getFromDate().compareTo(o2.getFromDate());
			}
		});
	}

	public List<Tournament> getTournaments() {
		return tournaments;
	}
}
