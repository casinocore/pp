package com.azoft.poker.adminclient.engine.util;

import java.text.SimpleDateFormat;

public class DateFormat extends SimpleDateFormat {
	public DateFormat(String dateFormat) {
		super(dateFormat);
	}

	public static final String DAYS_TIMESTAMP_FORMAT = "yyyyMMdd";
	public static final String MINUTES_TIMESTAMP_FORMAT = "yyyyMMddHHmm";
	public static final String SECONDS_TIMESTAMP_FORMAT = "yyyyMMddHHmmss";
	public static final String MILLISECONDS_TIMESTAMP_FORMAT = "yyyyMMddHHmmss,SSS";
	public static final String HOURS_AND_MINUTES_TIME_FORMAT = "HHmm";

	public static final String HUMAN_DATE_FORMAT = "dd.MM.yyyy";
	public static final String HUMAN_TIME_FORMAT = "HH:mm";
	public static final String HUMAN_TIMESTAMP_FORMAT = DateFormat.HUMAN_TIME_FORMAT
			+ " " + DateFormat.HUMAN_DATE_FORMAT;
	public static final String MONTH_YEAR_FORMAT = "MM.yyyy";
	public static final String YEAR_FORMAT = "yyyy";
	private static final long serialVersionUID = 1L;

}
