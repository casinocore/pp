package com.azoft.poker.adminclient.actions;

public abstract class AbstractEditAction extends AbstractAction {

	private static final long serialVersionUID = 1L;

	private static final String CANCEL = "cancel";
	protected static final String ACCESS_DENIED = "access_denied";

	private String actionKind;
	private String message;

	@Override
	public void prepare() {

	}

	public void prepareView() {
		prepare();
	}

	public String view() {
		return SUCCESS;
	}

	public void prepareInsert() {

	}

	public String insert() {
		return SUCCESS;
	}

	public void prepareSubmitInsert() {
		prepareInsert();
	}

	public String submitInsert() {
		return SUCCESS;
	}

	public void prepareUpdate() {
		prepare();
	}

	public String update() {
		return SUCCESS;
	}

	public void prepareSubmitUpdate() {
		prepareUpdate();
	}

	public String submitUpdate() {
		return SUCCESS;
	}

	public void prepareSubmitDelete() throws Exception {
		prepare();
	}

	public String submitDelete() {
		return SUCCESS;
	}

	public String cancelUpdate() {
		return CANCEL;
	}

	public String cancelInsert() {
		return CANCEL;
	}

	public void prepareCancelUpdate() throws Exception {
		prepare();
	}

	public void prepareCancelInsert() throws Exception {
		prepareInsert();
	}

	public String getActionKind() {
		return actionKind;
	}

	public void setActionKind(String actionKind) {
		this.actionKind = actionKind;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
