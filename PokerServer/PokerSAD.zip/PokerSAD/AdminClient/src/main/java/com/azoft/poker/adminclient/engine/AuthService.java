package com.azoft.poker.adminclient.engine;

public interface AuthService {

	UserSession auth(String login, String password)
			throws AuthenticationException;
}
