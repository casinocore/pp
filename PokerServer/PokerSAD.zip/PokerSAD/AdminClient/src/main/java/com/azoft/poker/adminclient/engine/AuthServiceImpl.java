package com.azoft.poker.adminclient.engine;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

import com.azoft.poker.common.persistence.admin.Admin;
import com.azoft.poker.common.persistence.admin.AdminManagerImpl;

public class AuthServiceImpl implements AuthService {

	private static final Logger log = Logger.getLogger(AuthServiceImpl.class);

	private static AuthService instance = null;

	public static synchronized AuthService getInstance() {
		if (instance == null) {
			instance = new AuthServiceImpl();
		}
		return instance;
	}

	public UserSession auth(String login, String password)
			throws AuthenticationException {
		MessageDigest m = null;
		try {
			m = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			log.error("MD5 algorithm initialization failed", e);
			throw new RuntimeException(e);
		}
		byte[] data = password.getBytes();
		m.update(data, 0, data.length);
		BigInteger i = new BigInteger(1, m.digest());
		String hash = String.format("%1$032X", i);
		Admin admin = AdminManagerImpl.getInstance().findPersonByLogin(login);
		if (admin != null && hash.equalsIgnoreCase(admin.getPassword())) {
			UserSessionImpl result = new UserSessionImpl();
			result.setUser(admin);
			return result;
		} else {
			throw new AuthenticationException("Invalid login/password");
		}

	}
}
